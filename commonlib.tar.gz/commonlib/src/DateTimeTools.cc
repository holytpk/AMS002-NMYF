#include "DateTimeTools.hh"
#include "Units.hh"
#include "debug.hh"

using Unit::min;
using Unit::hr;
using Unit::day;

const UShort_t STR_LENGTH = 128;

const Long64_t FIRST_BR = -4351622400; // Unix time corresponding to the first Bartels rotation: Feb. 8th, 1832

const Char_t *DateTimeTools::NormalizeDate(const Char_t *date, const Char_t *src_frmt, const Char_t *dst_frmt)
{
   tm tms;
   strptime(date, src_frmt, &tms);

   if (strstr(src_frmt, "%m") == NULL) tms.tm_mon  = 0;
   if (strstr(src_frmt, "%d") == NULL) tms.tm_mday = 1;
   if (strstr(src_frmt, "%H") == NULL) tms.tm_hour = 0;
   if (strstr(src_frmt, "%M") == NULL) tms.tm_min  = 0;
   if (strstr(src_frmt, "%S") == NULL) tms.tm_sec  = 0;

   Char_t *norm_date = new Char_t[STR_LENGTH];
   strftime(norm_date, STR_LENGTH, dst_frmt, &tms);

   return norm_date;
}

const Char_t *DateTimeTools::UTCTimeToString(time_t utime, const Char_t *format)
{
   tm *tms = new tm(*gmtime(&utime));

   Char_t *date = new Char_t[STR_LENGTH];
   strftime(date, STR_LENGTH, format, tms);

   delete tms;

   return date;
}

tm *DateTimeTools::StringToTM(const Char_t *date, const Char_t *format)
{
   const Char_t *norm_frmt = "%Y-%m-%d %H:%M:%S";
   tm *tms = new tm();
   strptime(NormalizeDate(date, format, norm_frmt), norm_frmt, tms);

   return tms;
}

time_t DateTimeTools::StringToUTCTime(const Char_t *date, const Char_t *format)
{
   const Char_t *norm_frmt = "%Y-%m-%d %H:%M:%S";
   tm tms;
   strptime(NormalizeDate(date, format, norm_frmt), norm_frmt, &tms);

   return timegm(&tms);
}

time_t DateTimeTools::UIntToUTCTime(UInt_t date)
{
   static Char_t str_date[11];
   snprintf(str_date, 11, "%u", date);

   return StringToUTCTime(str_date, "%Y%m%d");
}

UInt_t DateTimeTools::UTCTimeToUInt(time_t utime)
{
   tm *tms = new tm(*gmtime(&utime));

   UInt_t date = (tms->tm_year + 1900)*10000 + (tms->tm_mon + 1)*100 + tms->tm_mday;

   delete tms;

   return date;
}

UInt_t DateTimeTools::UTCTimeToBR(time_t utime)
{
   return (utime - FIRST_BR) / (27*day) + 1;
}

time_t DateTimeTools::BRToUTCTime(UInt_t BR)
{
   return (BR - 1) * (27*day) + FIRST_BR;
}

Bool_t DateTimeTools::UTCTimeFromDateAndTime(const Char_t *date, const Char_t *time, time_t &utime)
{
   // TODO: usa cstring invece di TString
   utime = 0;

   TString date_time(date);
   date_time.Append(" ").Append(time);

   TString format("%Y%m%d %H");
   UShort_t ndots = date_time.CountChar('.');

   if (ndots == 1) format += ".%M";
   else if (ndots == 2) format += ".%M.%S";
   else if (ndots != 0) return false;

   utime = StringToUTCTime(date_time.Data(), format.Data());

   return true;
}

const Char_t *DateTimeTools::AddToDate(const Char_t *date, time_t sec, const Char_t *format)
{
   time_t utime = StringToUTCTime(date, format) + sec;
   tm *tms = new tm(*gmtime(&utime));

   Char_t *final_date = new Char_t[STR_LENGTH];
   strftime(final_date, STR_LENGTH, format, tms);

   delete tms;

   return final_date;
}

Bool_t DateTimeTools::ParseTimeIntervals(const Char_t *date, const Char_t *intervals, std::vector<TimeInterval> &bins)
{
   /* intervals = string defining the time intervals
    * format accepted:
    *    explicit intervals: T1,T2,...,Tn
    *       build intervals from T1 to T2, from T2 to T3, ..., from Tn-1 to Tn
    *    explicit intervals: T1,T2;T3,T4
    *       build intervals from T1 to T2, T3 to T4
    *    implicit intervals: Ti:step:Tf
    *       build linear intervals from Ti to Tf (including Tf), using step as the length of the intervals
    *    mixed intervals: T1,T2;T3:step:T4,T5,T6,T7;...
    * T = HH[.MM[.SS]]
    *    HH = hours
    *    MM = minutes (optional); if not present, they are set to 0
    *    SS = seconds (optional); if not present, they are set to 0
    * step = T|ns
    *    T = see above
    *    ns = n is an integer number
    *         s a unit specifier: s=seconds, m=minutes, h=hours
    */
ULong64_t debug = Debug::Get();
Debug::Disable(Debug::ALL);
PRINT_FUNCTION()

   time_t udate = StringToUTCTime(date);
PRINT_VARIABLE(udate)
   TString str_ints(intervals);
   TString time_ints;
   Ssiz_t from_glob = 0;
PRINT_VARIABLE(str_ints.Data())
PRINT_STRING("START PARSING")
   while (str_ints.Tokenize(time_ints, from_glob, ";"))
   {
PRINT_STRING("START TOKEN")
PRINT_VARIABLE(time_ints.Data())
      TString tok;
      Ssiz_t from = 0;
      time_t last_utime = 0;
      while (time_ints.Tokenize(tok, from, ","))
      {
PRINT_STRING("START TIME INTERVAL")
PRINT_VARIABLE(tok.Data())
         if (tok.Contains(":"))
         {
PRINT_STRING("START IMPLICIT INTERVAL")
            TObjArray *seq = tok.Tokenize(":");
            if (seq->GetEntries() == 3)
            {
PRINT_STRING("START GOOD INTERVAL")
               UInt_t step_sec = 0;

               TString first = ((TObjString *)seq->UncheckedAt(0))->GetString();
               TString step  = ((TObjString *)seq->UncheckedAt(1))->GetString();
               TString last  = ((TObjString *)seq->UncheckedAt(2))->GetString();
PRINT_VARIABLE(first.Data())
PRINT_VARIABLE(step.Data())
PRINT_VARIABLE(last.Data())
               if (step.Contains(TRegexp("[hms]")))
               {
                  Int_t n = step.Atoi();
                  if (n > 0)
                  {
                     UChar_t s = step.Contains("s");
                     UChar_t m = step.Contains("m");
                     UChar_t h = step.Contains("h");

                     if (s+m+h > 1)
                     {
                        std::cerr << Form(" !!! Error while parsing intervals '%s': more than one unit specifier found in step '%s'\n", intervals, step.Data());
                        return false;
                     }
                     else
                     {
                        if (s) step_sec = n;
                        else if (m) step_sec = n*min;
                        else if (h) step_sec = n*hr;
                     }
                  }
                  else
                  {
                     std::cerr << Form(" !!! Error while parsing intervals '%s': step '%s' is negative or zero\n", intervals, step.Data());
                     return false;
                  }
               }
               else
               {
                  time_t utime;
                  if (!UTCTimeFromDateAndTime(date, step.Data(), utime))
                  {
                     std::cerr << Form(" !!! Error while parsing intervals '%s': time '%s' malformed\n", intervals, step.Data());
                     return false;
                  }
                  else step_sec = utime - udate;
               }
PRINT_VARIABLE(step_sec)
               if (step_sec > 0)
               {
PRINT_STRING("START GOOD STEP")
                  time_t ufirst;
                  time_t ulast;
                  if (!UTCTimeFromDateAndTime(date, first.Data(), ufirst))
                  {
                     std::cerr << Form(" !!! Error while parsing intervals '%s': time '%s' malformed\n", intervals, first.Data());
                     return false;
                  }
                  const Char_t *last_date = date;
                  if (last[0] == '2' && last[1] == '4')
                  {
                     last_date = AddToDate(date, 1*day);
                     last[0] = '0';
                     last[1] = '0';
                  }
                  if (!UTCTimeFromDateAndTime(last_date, last.Data(), ulast))
                  {
                     std::cerr << Form(" !!! Error while parsing intervals '%s': time '%s' malformed\n", intervals, last.Data());
                     return false;
                  }
                  UShort_t ntimebins = (ulast - ufirst) / step_sec;
PRINT_VARIABLE(ufirst)
PRINT_VARIABLE(ulast)
PRINT_VARIABLE(ntimebins)
                  if (ntimebins > 0)
                  {
PRINT_STRING("START FILL")
                     for (UShort_t ibin = 0; ibin <= ntimebins; ++ibin)
                     {
PRINT_STRING("START BIN")
                        time_t utime = ufirst + ibin*step_sec;
PRINT_VARIABLE(ibin)
PRINT_VARIABLE(last_utime)
PRINT_VARIABLE(utime)
                        if (last_utime != 0)
                        {
PRINT_STRING("START INSERTING")
                           bins.push_back(std::make_pair(last_utime, utime));
PRINT_STRING("END INSERTING")
                        }
                        last_utime = utime;
PRINT_STRING("END BIN")
                     }
PRINT_STRING("END FILL")
                  }
                  else
                  {
                     std::cerr << Form(" !!! Error while parsing intervals '%s': step is greater than the difference between first and last in '%s'\n", intervals, tok.Data());
                     return false;
                  }
PRINT_STRING("END GOOD STEP")
               }
PRINT_STRING("END GOOD INTERVAL")
            }
            else
            {
               std::cerr << Form(" !!! Error while parsing intervals '%s': size mismatch for '%s'\n", intervals, tok.Data());
               return false;
            }
PRINT_STRING("DELETING SEQUENCE")
            delete seq;
PRINT_STRING("END IMPLICIT INTERVAL")
         }
         else
         {
PRINT_STRING("START EXPLICIT INTERVAL")
            time_t utime;
PRINT_VARIABLE(last_utime)
            const Char_t *last_date = date;
            if (tok[0] == '2' && tok[1] == '4')
            {
               last_date = AddToDate(date, 1*day);
               tok[0] = '0';
               tok[1] = '0';
            }
            if (!UTCTimeFromDateAndTime(last_date, tok.Data(), utime))
            {
               std::cerr << Form(" !!! Error while parsing intervals '%s': time '%s' malformed\n", intervals, tok.Data());
               return false;
            }
            else
            {
               if (last_utime != 0)
               {
PRINT_STRING("START INSERTING")
                  bins.push_back(std::make_pair(last_utime, utime));
PRINT_STRING("END INSERTING")
               }
               last_utime = utime;
            }
PRINT_VARIABLE(utime)
PRINT_STRING("END EXPLICIT INTERVAL")
         }
PRINT_STRING("END TIME INTERVAL")
      }
PRINT_STRING("END TOKEN")
   }
PRINT_STRING("END PARSING")
if (Debug::Enabled(Debug::VARIABLE))
{
   for (UShort_t ibin = 0; ibin < bins.size(); ++ibin)
   {
      Char_t first_date[STR_LENGTH];
      Char_t second_date[STR_LENGTH];
      strftime(first_date, STR_LENGTH, "%Y-%m-%d %H:%M:%S", gmtime(&bins[ibin].first));
      strftime(second_date, STR_LENGTH, "%Y-%m-%d %H:%M:%S", gmtime(&bins[ibin].second));
      std::cout << Form("%lu - %lu: '%s' - '%s'\n", bins[ibin].first, bins[ibin].second, first_date, second_date);
   }
}
PRINT_FUNCTION_EXIT()
Debug::Set(debug);
   return true;
}

Char_t *DateTimeTools::TimeIntervalsToString(const std::vector<TimeInterval> &bins)
{
   UShort_t nintervals = bins.size();

   Char_t *intervals = new Char_t[nintervals*18]();

   for (UShort_t ibin = 0; ibin < nintervals; ++ibin)
   {
      TimeInterval interval = bins[ibin];

      if (ibin > 0) strcat(intervals, ";");
      strcat(intervals, UTCTimeToString(interval.first, "%H.%M.%S"));
      strcat(intervals, ",");
      strcat(intervals, UTCTimeToString(interval.second, "%H.%M.%S"));
   }

   return intervals;
}

UShort_t DateTimeTools::GetTimeBin(UInt_t time, std::vector<TimeInterval> &timebins)
{
   UShort_t ntimebins = timebins.size();
   UShort_t itimebin = 0;

   if (time >= timebins[0].first)
   {
      for ( ; itimebin < ntimebins; ++itimebin)
      {
         if (timebins[itimebin].first <= time && time < timebins[itimebin].second) break;
      }
      ++itimebin;
   }

   return itimebin;
}

Char_t *DateTimeTools::SplitDate(UInt_t date, Char_t *str_date)
{
   snprintf(str_date, 11, "%u/%02u/%02u", date / 10000, (date % 10000) / 100, (date % 10000) % 100);

   return str_date;
}

const Char_t *DateTimeTools::SplitDate(UInt_t date)
{
   static Char_t str_date[11] = "";
   snprintf(str_date, 11, "%u/%02u/%02u", date / 10000, (date % 10000) / 100, (date % 10000) % 100);

   return str_date;
}

UShort_t DateTimeTools::nDays(UShort_t imonth, UShort_t year)
{
   static UShort_t ndays[12] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

   return ndays[imonth] + (imonth == 1 ? IsLeapYear(year) : 0);
}

Bool_t DateTimeTools::IsLeapYear(UShort_t year)
{
   if (year % 400 == 0) return true;
   else if (year % 100 == 0) return false;
   else if (year % 4 == 0) return true;
   else return false;
}

UShort_t DateTimeTools::nDays(std::tm *tmd)
{
   return nDays(tmd->tm_mon, tmd->tm_year + 1900);
}

Bool_t DateTimeTools::IsLeapYear(std::tm *tmd)
{
   return IsLeapYear(tmd->tm_year + 1900);
}
