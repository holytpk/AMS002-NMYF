#include <iostream>
#include <iomanip>
#include <cstring>

#include "TFile.h"
#include "TTree.h"
#include "TString.h"

using namespace std;

const UShort_t STR_LENGTH = 256;

Int_t dat2root(const Char_t *infile_path, Char_t *tree_name = "", Char_t *outfile_path = "", Char_t *tree_title = "")
{
   if (strlen(tree_name) == 0)
   {
      const Char_t *path_delim = strrchr(infile_path, '/');
      const Char_t *ext_delim  = strrchr(infile_path, '.');
      size_t name_len = ext_delim != NULL ? (path_delim != NULL ? (ext_delim - path_delim)/sizeof(Char_t) - 1 : (ext_delim - infile_path)/sizeof(Char_t)) : STR_LENGTH;

      strncpy(tree_name, path_delim != NULL ? path_delim + 1 : infile_path, name_len);
   }
   if (strlen(tree_title) == 0)
   {
      strncpy(tree_title, tree_name, STR_LENGTH);
   }
   if (strlen(outfile_path) == 0)
   {
      const Char_t *ext_delim  = strrchr(infile_path, '.');
      size_t name_len = ext_delim != NULL ? (ext_delim - infile_path)/sizeof(Char_t) : STR_LENGTH;

      strncpy(outfile_path, infile_path, name_len);
      strncat(outfile_path, ".root", 5);
   }

   TFile fout(outfile_path, "RECREATE");
   TTree tree(tree_name, tree_title);
   tree.ReadFile(infile_path);
   fout.Write();
   fout.Close();

   return 0;
}

Int_t main(Int_t argc, Char_t *argv[])
{
   if (argc < 2)
   {
      cerr << " !!! TOO FEW ARGUMENTS.\n !!! AT LEAST 1 ARGUMENT IS REQUIRED: 'INPUTFILEPATH'\n";

      return 1;
   }

   Char_t infile_path[STR_LENGTH];
   Char_t outfile_path[STR_LENGTH] = "";
   Char_t tree_name[STR_LENGTH]    = "";
   Char_t tree_title[STR_LENGTH]   = "";

   strncpy(infile_path, argv[1], STR_LENGTH);

   if (argc > 2) strncpy(tree_name, argv[2], STR_LENGTH);
   if (argc > 3) strncpy(outfile_path, argv[3], STR_LENGTH);
   if (argc > 4) strncpy(tree_title, argv[4], STR_LENGTH);

   return dat2root(infile_path, tree_name, outfile_path, tree_title);
}
