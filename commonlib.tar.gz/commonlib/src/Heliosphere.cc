#include "Heliosphere.hh"
#include "debug.hh"

ClassImp(Heliosphere::SolarWindSpeed)
ClassImp(Heliosphere::HMF)

using namespace std;

Heliosphere::SolarWindSpeed::SolarWindSpeed(Double_t VEq, Double_t VPol, Double_t TiltAngle, Double_t RTS, Double_t s, Double_t L, Double_t R, Double_t Theta, Double_t Phi) :
   fR(R), fTheta(Theta), fPhi(Phi),
   fVEq(VEq), fVPol(VPol), fTiltAngle(TiltAngle), fRTS(RTS), fs(s), fL(L),
   fRSun(0.005), fR0(1.), fRHP(121.),
   fRadFunc(NULL), fPolFunc(NULL), fRadPolFunc(NULL),
   fRadDivFunc(NULL), fPolDivFunc(NULL), fRadPolDivFunc(NULL)
{
   const UShort_t  npars = 6;
   const Char_t   *parname[npars] = { "VEq", "VPol", "alfa", "R_TS", "s", "L" };
   const Double_t  par[npars]     = { fVEq, fVPol, fTiltAngle, fRTS, fs, fL };

   fRadFunc = new TF1("f_sw_r", this, &SolarWindSpeed::Radial, fRSun, fRHP, npars, "SolarWindSpeed", "Radial");
   fRadFunc->SetTitle("Solar wind speed - Radial dependence;Radial distance [AU];V_{SW} [km/s]");
   fRadFunc->SetRange(fRSun, fRHP);
   fRadFunc->SetNpx(1000);
   for (UShort_t ipar = 0; ipar < npars; ++ipar)
   {
      fRadFunc->SetParName(ipar, parname[ipar]);
      fRadFunc->SetParameter(ipar, par[ipar]);
   }

   fPolFunc = new TF1("f_sw_theta", this, &SolarWindSpeed::Polar, 0., 180., npars, "SolarWindSpeed", "Polar");
   fPolFunc->SetTitle("Solar wind speed - Polar dependence;Heliographic latitude [deg];V_{SW} [km/s]");
   fPolFunc->SetRange(0., 180.);
   fPolFunc->SetNpx(1000);
   for (UShort_t ipar = 0; ipar < npars; ++ipar)
   {
      fPolFunc->SetParName(ipar, parname[ipar]);
      fPolFunc->SetParameter(ipar, par[ipar]);
   }

   fRadPolFunc = new TF2("f_sw_rtheta", this, &SolarWindSpeed::RadialPolar, fRSun, fRHP, 0., 180., npars, "SolarWindSpeed", "RadialPolar");
   fRadPolFunc->SetTitle("Solar wind speed - Radial vs polar dependence;Radial distance [AU];Heliographic latitude [deg];V_{SW} [km/s]");
   fRadPolFunc->SetRange(fRSun, 0., fRHP, 180.);
   fRadPolFunc->SetNpx(1000);
   fRadPolFunc->SetNpy(100);
   fRadPolFunc->SetContour(99);
   for (UShort_t ipar = 0; ipar < npars; ++ipar)
   {
      fRadPolFunc->SetParName(ipar, parname[ipar]);
      fRadPolFunc->SetParameter(ipar, par[ipar]);
   }

   fRadDivFunc = new TF1("f_divsw_r", this, &SolarWindSpeed::RadialDiv, fRSun, fRHP, npars, "SolarWindSpeed", "RadialDiv");
   fRadDivFunc->SetTitle("Solar wind divergence - Radial dependence;Radial distance [AU];\\nabla\\cdot V_{SW} [1/s]");
   fRadDivFunc->SetRange(fRSun, fRHP);
   fRadDivFunc->SetNpx(1000);
   for (UShort_t ipar = 0; ipar < npars; ++ipar)
   {
      fRadDivFunc->SetParName(ipar, parname[ipar]);
      fRadDivFunc->SetParameter(ipar, par[ipar]);
   }

   fPolDivFunc = new TF1("f_dvsw_theta", this, &SolarWindSpeed::PolarDiv, 0., 180., npars, "SolarWindSpeed", "PolarDiv");
   fPolDivFunc->SetTitle("Solar wind divergence - Polar dependence;Heliographic latitude [deg];\\nabla\\cdot V_{SW} [1/s]");
   fPolDivFunc->SetRange(0., 180.);
   fPolDivFunc->SetNpx(1000);
   for (UShort_t ipar = 0; ipar < npars; ++ipar)
   {
      fPolDivFunc->SetParName(ipar, parname[ipar]);
      fPolDivFunc->SetParameter(ipar, par[ipar]);
   }

   fRadPolDivFunc = new TF2("f_divsw_rtheta", this, &SolarWindSpeed::RadialPolarDiv, fRSun, fRHP, 0., 180., npars, "SolarWindSpeed", "RadialPolarDiv");
   fRadPolDivFunc->SetTitle("Solar wind divergence - Radial vs polar dependence;Radial distance [AU];Heliographic latitude [deg];\\nabla\\cdot V_{SW} [1/s]");
   fRadPolDivFunc->SetRange(fRSun, 0., fRHP, 180.);
   fRadPolDivFunc->SetNpx(1000);
   fRadPolDivFunc->SetNpy(100);
   fRadPolDivFunc->SetContour(99);
   for (UShort_t ipar = 0; ipar < npars; ++ipar)
   {
      fRadPolDivFunc->SetParName(ipar, parname[ipar]);
      fRadPolDivFunc->SetParameter(ipar, par[ipar]);
   }
}

Heliosphere::SolarWindSpeed::~SolarWindSpeed()
{
   if (fRadFunc != NULL) delete fRadFunc;
   if (fPolFunc != NULL) delete fPolFunc;
   if (fRadPolFunc != NULL) delete fRadPolFunc;

   if (fRadDivFunc != NULL) delete fRadDivFunc;
   if (fPolDivFunc != NULL) delete fPolDivFunc;
   if (fRadPolDivFunc != NULL) delete fRadPolDivFunc;
}

Double_t Heliosphere::SolarWindSpeed::GetSpeed(Double_t R, Double_t Theta, Double_t Phi)
{
   fR = R;
   fTheta = Theta;
   fPhi = Phi;

   return fR <= fRTS ? vr_inn(fR, fTheta) : vr_hs(fR, fTheta);
}

void Heliosphere::SolarWindSpeed::SetVEq(Double_t VEq)
{
   fVEq = VEq;
   update_parameter(0, fVEq);
}

void Heliosphere::SolarWindSpeed::SetVPol(Double_t VPol)
{
   fVPol = VPol;
   update_parameter(1, fVPol);
}

void Heliosphere::SolarWindSpeed::SetTiltAngle(Double_t TiltAngle)
{
   fTiltAngle = TiltAngle;
   update_parameter(2, fTiltAngle);
}

void Heliosphere::SolarWindSpeed::SetRTS(Double_t RTS)
{
   fRTS = RTS;
   update_parameter(3, fRTS);
}

/*
TH3 *Heliosphere::SolarWindSpeed::DrawPolarCone(Double_t Theta, Bool_t same)
{
   fTheta = Theta;

   Double_t ct  = cos(fTheta*TMath::DegToRad());
   Double_t ct2 = ct*ct;

   Double_t vmin = vr_inn(fRSun, 90.);
   Double_t vmax = vr_inn(fRTS, 0.);

   UShort_t ncolors = gStyle->GetNumberContours();

   UShort_t nbins = 100;
   Double_t dx    = 2.*fRHP/(nbins-1);
   TH3D *h3 = new TH3D(Form("h3_sw_cone%.0f", fTheta), Form("Solar wind speed - Cone at #theta = %.0f#circ", fTheta), nbins, -fRHP, fRHP, nbins, -fRHP, fRHP, nbins, -fRHP, fRHP);
   h3->SetXTitle("X [AU]");
   h3->SetYTitle("Y [AU]");
   h3->SetZTitle("Z [AU]");

   TObjArray *pms = new TObjArray(ncolors);
   pms->SetOwner();
   pms->SetName("polymarker");
   h3->GetListOfFunctions()->Add(pms);
   for (UShort_t icol = 0; icol < ncolors; ++icol)
   {
      TPolyMarker3D *pm3d = new TPolyMarker3D();
      pm3d->SetMarkerColor(gStyle->GetColorPalette(icol));
      pm3d->SetMarkerStyle(kFullCircle);
      pm3d->SetMarkerSize(1.);
      pms->AddAt(pm3d, icol);
   }
   h3->SetMinimum(vmin);
   h3->SetMaximum(vmax);
   h3->SetContour(ncolors);

   UInt_t nentries = 0;
   for (UShort_t ibin = 1; ibin <= nbins; ++ibin)
   {
      Double_t x = -fRHP + (ibin-0.5)*dx;

      for (UShort_t jbin = 1; jbin <= nbins; ++jbin)
      {
         Double_t y = -fRHP + (jbin-0.5)*dx;

         fR   = sqrt((x*x + y*y)/(1. - ct2));
         fPhi = atan2(y, x)*TMath::RadToDeg();

         if (fR >= fRSun && fR <= fRHP)
         {
            Double_t z = fR*ct;
            Double_t v = fR <= fRTS ? vr_inn(fR, fTheta) : vr_hs(fR, fTheta);

            Short_t icol = UShort_t(ncolors * (v - vmin) / (vmax - vmin));
            if (icol > ncolors - 1) icol = ncolors - 1;
            if (icol < 0) icol = 0;
            TPolyMarker3D *pm3d = (TPolyMarker3D *)pms->UncheckedAt(icol);
            pm3d->SetPoint(pm3d->GetLastPoint() + 1, x, y, z);

            ++nentries;
         }
      }
   }
   h3->SetEntries(nentries);

   h3->Draw(same ? "SAME" : "");
   if (!same)
   {
      dynamic_cast<THistPainter *>(h3->GetPainter())->PaintPalette();
      TPaletteAxis *palette = (TPaletteAxis *)h3->GetListOfFunctions()->At(0);
      palette->GetAxis()->SetTitle("V_{SW} [km/s]");
      palette->SetX1NDC(0.89);
      palette->SetX2NDC(0.92);
      palette->SetY1NDC(0.08);
      palette->SetY2NDC(0.90);
   }

   return h3;
}

TH2 *Heliosphere::SolarWindSpeed::DrawThetaSlice(Double_t Theta, Option_t *option)
{
   fTheta = Theta;

   Double_t ct  = cos(fTheta*TMath::DegToRad());
   Double_t ct2 = ct*ct;

   UShort_t nbins = 200;
   Double_t dx    = 2.*fRHP/(nbins-1);
   TH2D *h2 = new TH2D(Form("h2_sw_theta%.0f", fTheta), Form("Solar wind speed - Cone at #theta = %.0f#circ", fTheta), nbins, -fRHP, fRHP, nbins, -fRHP, fRHP);
   h2->SetXTitle("X [AU]");
   h2->SetYTitle("Y [AU]");
   h2->SetZTitle("V_{SW} [km/s]");
   for (UShort_t ibin = 1; ibin <= nbins; ++ibin)
   {
      Double_t x = -fRHP + (ibin-0.5)*dx;

      for (UShort_t jbin = 1; jbin <= nbins; ++jbin)
      {
         Double_t y = -fRHP + (jbin-0.5)*dx;

         fR   = sqrt((x*x + y*y)/(1. - ct2));
         fPhi = atan2(y, x)*TMath::RadToDeg();

         if (fR >= fRSun && fR <= fRHP)
         {
            Double_t v = fR <= fRTS ? vr_inn(fR, fTheta) : vr_hs(fR, fTheta);

            h2->SetBinContent(ibin, jbin, v);
         }
      }
   }

   h2->Draw(option);

   return h2;
}

TH2 *Heliosphere::SolarWindSpeed::DrawPhiSlice(Double_t Phi, Option_t *option)
{
   fPhi = Phi;

   Double_t tp  = tan(fPhi*TMath::DegToRad());
   Double_t tp2 = tp*tp;

   UShort_t nbins = 200;
   Double_t dx    = 2.*fRHP/(nbins-1);
   TH2D *h2 = new TH2D(Form("h2_sw_phi%.0f", fPhi), Form("Solar wind speed - Slice at #phi = %.0f#circ", fPhi), nbins, -fRHP, fRHP, nbins, -fRHP, fRHP);
   h2->SetXTitle("X [AU]");
   h2->SetYTitle("Z [AU]");
   h2->SetZTitle("V_{SW} [km/s]");
   for (UShort_t ibin = 1; ibin <= nbins; ++ibin)
   {
      Double_t x = -fRHP + (ibin-0.5)*dx;

      for (UShort_t jbin = 1; jbin <= nbins; ++jbin)
      {
         Double_t z = -fRHP + (jbin-0.5)*dx;

         fR     = sqrt(x*x*(1 + tp2) + z*z);
         fTheta = acos(z/fR)*TMath::RadToDeg();

         if (fR >= fRSun && fR <= fRHP)
         {
            Double_t v = fR <= fRTS ? vr_inn(fR, fTheta) : vr_hs(fR, fTheta);

            h2->SetBinContent(ibin, jbin, v);
         }
      }
   }

   h2->Draw(option);

   return h2;
}
*/

Double_t Heliosphere::SolarWindSpeed::Radial(Double_t *x, Double_t *par)
{
   fR = x[0];

   fVEq       = par[0];
   fVPol      = par[1];
   fTiltAngle = par[2];
   fRTS       = par[3];
   fs         = par[4];
   fL         = par[5];

   return fR <= fRTS ? vr_inn(fR, fTheta) : vr_hs(fR, fTheta);
}

Double_t Heliosphere::SolarWindSpeed::Polar(Double_t *x, Double_t *par)
{
   fTheta = x[0];

   fVEq       = par[0];
   fVPol      = par[1];
   fTiltAngle = par[2];
   fRTS       = par[3];
   fs         = par[4];
   fL         = par[5];

   return fR <= fRTS ? vr_inn(fR, fTheta) : vr_hs(fR, fTheta);
}

Double_t Heliosphere::SolarWindSpeed::RadialPolar(Double_t *x, Double_t *par)
{
   fR     = x[0];
   fTheta = x[1];

   fVEq       = par[0];
   fVPol      = par[1];
   fTiltAngle = par[2];
   fRTS       = par[3];
   fs         = par[4];
   fL         = par[5];

   return fR <= fRTS ? vr_inn(fR, fTheta) : vr_hs(fR, fTheta);
}

Double_t Heliosphere::SolarWindSpeed::RadialDiv(Double_t *x, Double_t *par)
{
   fR = x[0];

   fVEq       = par[0];
   fVPol      = par[1];
   fTiltAngle = par[2];
   fRTS       = par[3];
   fs         = par[4];
   fL         = par[5];

   return fR <= fRTS ? div_vr_inn(fR, fTheta) : div_vr_hs(fR, fTheta);
}

Double_t Heliosphere::SolarWindSpeed::PolarDiv(Double_t *x, Double_t *par)
{
   fTheta = x[0];

   fVEq       = par[0];
   fVPol      = par[1];
   fTiltAngle = par[2];
   fRTS       = par[3];
   fs         = par[4];
   fL         = par[5];

   return fR <= fRTS ? div_vr_inn(fR, fTheta) : div_vr_hs(fR, fTheta);
}

Double_t Heliosphere::SolarWindSpeed::RadialPolarDiv(Double_t *x, Double_t *par)
{
   fR     = x[0];
   fTheta = x[1];

   fVEq       = par[0];
   fVPol      = par[1];
   fTiltAngle = par[2];
   fRTS       = par[3];
   fs         = par[4];
   fL         = par[5];

   return fR <= fRTS ? div_vr_inn(fR, fTheta) : div_vr_hs(fR, fTheta);
}

Double_t Heliosphere::SolarWindSpeed::vr_r(Double_t r)
{
   return 1. - exp(40./3.*(fRSun - r)/fR0);
}

Double_t Heliosphere::SolarWindSpeed::vr_t(Double_t theta)
{
   Double_t sign = theta < 90. ? 1. : -1.;
   Double_t psi  = fTiltAngle + 15;

   return (fVEq + fVPol)*0.5 - sign*(fVPol - fVEq)*0.5*tanh(6.8*(theta - 90 + sign*psi)*TMath::DegToRad());
}

Double_t Heliosphere::SolarWindSpeed::vr_inn(Double_t r, Double_t theta)
{
   return vr_r(r) * vr_t(theta);
}

Double_t Heliosphere::SolarWindSpeed::vr_hs(Double_t r, Double_t theta)
{
   Double_t vr_ts = vr_inn(fRTS, theta);

   return  vr_ts/(2*fs) * (fs + 1 - (fs - 1)*tanh((r - fRTS)/fL));
}

Double_t Heliosphere::SolarWindSpeed::div_vr_r(Double_t r)
{
   return 2./r - exp(40./3.*(fRSun - r)/fR0)*(2./r - 40./3./fR0);
}

Double_t Heliosphere::SolarWindSpeed::div_vr_inn(Double_t r, Double_t theta)
{
   return div_vr_r(r) * vr_t(theta);
}

Double_t Heliosphere::SolarWindSpeed::div_vr_hs(Double_t r, Double_t theta)
{
   Double_t vr_ts = vr_inn(fRTS, theta);
   Double_t tgh   = tanh((r - fRTS)/fL);

   return  vr_ts/fs * ((fs + 1.)/r - (fs - 1.)/r*tgh - (fs - 1.)/(2*fL)*(1 - tgh*tgh));
}

void Heliosphere::SolarWindSpeed::update_parameter(UShort_t ipar, Double_t par)
{
   fRadFunc->SetParameter(ipar, par);
   fPolFunc->SetParameter(ipar, par);
   fRadPolFunc->SetParameter(ipar, par);

   fRadDivFunc->SetParameter(ipar, par);
   fPolDivFunc->SetParameter(ipar, par);
   fRadPolDivFunc->SetParameter(ipar, par);
}

Heliosphere::HMF::HMF() :
   fOmega(2.67e-6)
{
}
Heliosphere::HMF::HMF(Type FieldType, SolarWindSpeed *SolarWind, Double_t B0, Double_t delta, Double_t AlfvenRadius, Double_t R, Double_t Theta, Double_t Phi) :
   fR(R), fTheta(Theta), fPhi(Phi),
   fFieldType(FieldType),
   fB0(B0), fdelta(delta), fb(AlfvenRadius),
   fOmega(2.67e-6),
   fVSW(SolarWind),
   fMagFunc(NULL), fRadFunc(NULL), fPolFunc(NULL), fAziFunc(NULL)
{
   if (fFieldType == Fisk)
   {
      cerr << " !!! HMF::HMF-E-Fisk type not yet implemented. Class is not usable." << endl;
   }
   if (fVSW == NULL)
   {
      cerr << " !!! HMF::HMF-E-SolarWindSpeed object is NULL. Class is not usable." << endl;
   }

   fVSW->fR     = fR;
   fVSW->fTheta = fTheta;
   fVSW->fPhi   = fPhi;

   const UShort_t  nmaxpars = 3;
   const Char_t   *parname[nmaxpars] = { "B0", "deltam", "b" };
   const Double_t  par[nmaxpars]     = { fB0, fdelta, fb };

   UShort_t npars;
   if (fFieldType == Parker) npars = 1;
   else if (fFieldType == JokipiiKota) npars = 2;
   else if (fFieldType == SmithBieber) npars = 3;
   else if (fFieldType == Fisk) npars = 2;

   hmf[Parker][0] = &HMF::parker_radial;
   hmf[Parker][1] = &HMF::parker_polar;
   hmf[Parker][2] = &HMF::parker_azimuthal;

   hmf[JokipiiKota][0] = &HMF::jokipiikota_radial;
   hmf[JokipiiKota][1] = &HMF::jokipiikota_polar;
   hmf[JokipiiKota][2] = &HMF::jokipiikota_azimuthal;

   hmf[SmithBieber][0] = &HMF::smithbieber_radial;
   hmf[SmithBieber][1] = &HMF::smithbieber_polar;
   hmf[SmithBieber][2] = &HMF::smithbieber_azimuthal;

   hmf[Fisk][0] = NULL;
   hmf[Fisk][1] = NULL;
   hmf[Fisk][2] = NULL;

   fMagFunc = new TF2("f_hmf_r", this, &HMF::Magnitude, fVSW->fRSun+0.001, fVSW->fRHP, 0., 180., npars, "HMF", "Magnitude");
   fMagFunc->SetTitle("HMF magnitude - Radial vs polar dependence;Radial distance [AU];Heliographic latitude [deg];B [nT]");
   fMagFunc->SetRange(fVSW->fRSun+0.001, 0., fVSW->fRHP, 180.);
   fMagFunc->SetNpx(1000);
   fMagFunc->SetNpy(100);
   fMagFunc->SetContour(99);
   for (UShort_t ipar = 0; ipar < npars; ++ipar)
   {
      fMagFunc->SetParName(ipar, parname[ipar]);
      fMagFunc->SetParameter(ipar, par[ipar]);
   }

   fRadFunc = new TF2("f_hmf_r", this, &HMF::Radial, fVSW->fRSun+0.001, fVSW->fRHP, 0., 180., npars, "HMF", "Radial");
   fRadFunc->SetTitle("HMF radial component - Radial vs polar dependence;Radial distance [AU];Heliographic latitude [deg];B_{r} [nT]");
   fRadFunc->SetRange(fVSW->fRSun+0.001, 0., fVSW->fRHP, 180.);
   fRadFunc->SetNpx(1000);
   fRadFunc->SetNpy(100);
   fRadFunc->SetContour(99);
   for (UShort_t ipar = 0; ipar < npars; ++ipar)
   {
      fRadFunc->SetParName(ipar, parname[ipar]);
      fRadFunc->SetParameter(ipar, par[ipar]);
   }

   fPolFunc = new TF2("f_hmf_theta", this, &HMF::Polar, fVSW->fRSun+0.001, fVSW->fRHP, 0., 180., npars, "HMF", "Polar");
   fPolFunc->SetTitle("HMF polar component - Radial vs polar dependence;Radial distance [AU];Heliographic latitude [deg];B_{#theta} [nT]");
   fPolFunc->SetRange(fVSW->fRSun+0.001, 0., fVSW->fRHP, 180.);
   fPolFunc->SetNpx(1000);
   fPolFunc->SetNpy(100);
   fPolFunc->SetContour(99);
   for (UShort_t ipar = 0; ipar < npars; ++ipar)
   {
      fPolFunc->SetParName(ipar, parname[ipar]);
      fPolFunc->SetParameter(ipar, par[ipar]);
   }

   fAziFunc = new TF2("f_hmf_phi", this, &HMF::Azimuthal, fVSW->fRSun+0.001, fVSW->fRHP, 0., 180., npars, "HMF", "Azimuthal");
   fAziFunc->SetTitle("HMF azimuthal component - Radial vs polar dependence;Radial distance [AU];Heliographic latitude [deg];B_{#phi} [nT]");
   fAziFunc->SetRange(fVSW->fRSun+0.001, 0., fVSW->fRHP, 180.);
   fAziFunc->SetNpx(1000);
   fAziFunc->SetNpy(100);
   fAziFunc->SetContour(99);
   for (UShort_t ipar = 0; ipar < npars; ++ipar)
   {
      fAziFunc->SetParName(ipar, parname[ipar]);
      fAziFunc->SetParameter(ipar, par[ipar]);
   }
}
Heliosphere::HMF::~HMF()
{
   if (fMagFunc != NULL) delete fMagFunc;
   if (fRadFunc != NULL) delete fRadFunc;
   if (fPolFunc != NULL) delete fPolFunc;
   if (fAziFunc != NULL) delete fAziFunc;
}

void Heliosphere::HMF::SetType(Type FieldType)
{
   fFieldType = FieldType;
}
void Heliosphere::HMF::SetB0(Double_t B0)
{
   fB0 = B0;

   fRadFunc->SetParameter(0, fB0);
   fPolFunc->SetParameter(0, fB0);
   fAziFunc->SetParameter(0, fB0);
}
void Heliosphere::HMF::SetDelta(Double_t delta)
{
   fdelta = delta;

   fRadFunc->SetParameter(1, fdelta);
   fPolFunc->SetParameter(1, fdelta);
   fAziFunc->SetParameter(1, fdelta);
}
void Heliosphere::HMF::SetAlfvenRadius(Double_t AlfvenRadius)
{
   fb = AlfvenRadius;

   fRadFunc->SetParameter(2, fb);
   fPolFunc->SetParameter(2, fb);
   fAziFunc->SetParameter(2, fb);
}
/*
TH2 *HMF::DrawVectorField(Double_t Theta, Bool_t same = false)
{
   fTheta = Theta;

   Double_t st = sin(Theta*TMath::DegToRad());
   Double_t ct = sin(Theta*TMath::DegToRad());

   UShort_t nbins = 100;
   Double_t rmax  = fRHP;
   Double_t rmin  = fVSW->fRSun + 0.001;
   Double_t dx    = 2.*rmax/(nbins-1);
   Double_t dr    = (rmax - rmin)/(nbins - 1);

   TH3D *h3 = new TH3D("h3_hmf_vec", "HMF", nbins, -rmax, rmax, nbins, -rmax, rmax, nbins, -rmax, rmax);
   h3->SetXTitle("X [AU]");
   h3->SetYTitle("Y [AU]");
   h3->SetZTitle("Z [AU]");

   TObjArray *arr = new TObjArray(ncolors);
   arr->SetOwner();
   arr->SetName("fieldlines");
   h3->GetListOfFunctions()->Add(arr);

   UInt_t nentries = 0;
   for (fPhi = 0; fPhi < 360; fPhi += 30)
   {
      fR = rmin

      Double_t x1 = fR*st*cos(fPhi*TMath::DegToRad());
      Double_t y1 = fR*st*sin(fPhi*TMath::DegToRad());
      Double_t z1 = fR*ct;

      for (; fR <= rmax; fR += dr)
      {
         //~ Short_t icol = UShort_t(ncolors * (v - vmin) / (vmax - vmin));
         //~ if (icol > ncolors - 1) icol = ncolors - 1;
         //~ if (icol < 0) icol = 0;

         Double_t Br = ((*this).*(hmf[fFieldType][0]))();
         Double_t Bt = ((*this).*(hmf[fFieldType][1]))();
         Double_t Bp = ((*this).*(hmf[fFieldType][2]))();
         Double_t B  = sqrt(Br*Br + Bt*Bt + Bp*Bp);

         Double_t x2 = Br/B;
         Double_t y2 = Bt/B;
         Double_t z2 = Bp/B;

         Double_t x[2] = { x1, x2 };
         Double_t y[2] = { y1, y2 };
         Double_t z[2] = { z1, z2 };

         TPolyLine3D *pl3 = new TPolyLine3D(2, x, y, z);
         arr->Add(pl3);

         x1 = x2;
         y1 = y2;
         z1 = z2;

         ++nentries;
      }
   }
   h3->SetEntries(nentries);

   h3->Draw(same ? "SAME" : "");
   if (!same)
   {
      dynamic_cast<THistPainter *>(h3->GetPainter())->PaintPalette();
      TPaletteAxis *palette = (TPaletteAxis *)h3->GetListOfFunctions()->At(0);
      palette->GetAxis()->SetTitle("V_{SW} [km/s]");
      palette->SetX1NDC(0.89);
      palette->SetX2NDC(0.92);
      palette->SetY1NDC(0.08);
      palette->SetY2NDC(0.90);
   }

   return h3;
}

TH2 *Heliosphere::HMF::DrawThetaSlice(UShort_t icoo, Double_t Theta, Option_t *option)
{
   static const Char_t *name[4] = { "r", "theta", "phi", "mag" };
   static const Char_t *title[4] = { "radial component", "polar component", "azimuthal component", "magnitude" };

   fTheta    = Theta;
   fPolarity = fTheta > 90. - fVSW->fTiltAngle ? -1 : 1;

   Double_t ct  = cos(fTheta*TMath::DegToRad());
   Double_t ct2 = ct*ct;

   const Double_t &fRHP = fVSW->fRHP;

   UShort_t nbins = 200;
   Double_t rmax  = fRHP;
   Double_t rmin  = fVSW->fRSun + 0.001;
   Double_t dx    = 2.*rmax/(nbins-1);
   TH2D *h2 = new TH2D(Form("h2_hmf_%s_theta%.0f", name[icoo], fTheta), Form("HMF %s - Cone at #theta = %.0f#circ", title[icoo], fTheta), nbins, -rmax, rmax, nbins, -rmax, rmax);
   h2->SetXTitle("X [AU]");
   h2->SetYTitle("Y [AU]");
   h2->SetZTitle(Form("B%s [nT]", icoo == 0 ? "_{r}" : (icoo == 1 ? "_{#theta}" : (icoo == 2 ? "_{#phi}" : ""))));
   for (UShort_t ibin = 1; ibin <= nbins; ++ibin)
   {
      Double_t x = -rmax + (ibin-0.5)*dx;

      for (UShort_t jbin = 1; jbin <= nbins; ++jbin)
      {
         Double_t y = -rmax + (jbin-0.5)*dx;

         fR   = sqrt((x*x + y*y)/(1. - ct2));
         fPhi = atan2(y, x)*TMath::RadToDeg();

         if (fR >= rmin && fR <= rmax)
         {
            Double_t B;
            if (icoo < 3) B = ((*this).*(hmf[fFieldType][icoo]))();
            else
            {
               B = 0.;
               for (icoo = 0; icoo < 3; ++icoo)
               {
                  Double_t Bi = ((*this).*(hmf[fFieldType][icoo]))();
                  B += Bi*Bi;
               }
               B = sqrt(B);
            }

            h2->SetBinContent(ibin, jbin, B);
         }
      }
   }

   h2->Draw(option);

   return h2;
}

TH2 *Heliosphere::HMF::DrawPhiSlice(UShort_t icoo, Double_t Phi, Option_t *option)
{
   static const Char_t *name[4] = { "r", "theta", "phi", "mag" };
   static const Char_t *title[4] = { "radial component", "polar component", "azimuthal component", "magnitude" };

   fPhi = Phi;

   Double_t cp   = cos(fPhi*TMath::DegToRad());
   Double_t tp   = tan(fPhi*TMath::DegToRad());
   Double_t tp2  = tp*tp;
   Double_t alfa = acos(cos(fVSW->fTiltAngle*TMath::DegToRad())*cp)*TMath::RadToDeg();

   UShort_t nbins = 200;
   Double_t rmin  = fVSW->fRSun + 0.001;
   Double_t rmax  = 0.2;//fVSW->fRHP;
   Double_t dx    = 2.*rmax/(nbins-1);

   TH2D *h2 = new TH2D(Form("h2_hmf_%s_phi%.0f", name[icoo], fPhi), Form("HMF %s - Slice at #phi = %.0f#circ", title[icoo], fPhi), nbins, -rmax, rmax, nbins, -rmax, rmax);
   h2->SetXTitle("cos(#phi)X + sin(#phi)Y [AU]");
   h2->SetYTitle("Z [AU]");
   h2->SetZTitle(Form("B%s [nT]", icoo == 0 ? "_{r}" : (icoo == 1 ? "_{#theta}" : (icoo == 2 ? "_{#phi}" : ""))));

   for (UShort_t ibin = 1; ibin <= nbins; ++ibin)
   {
      Double_t x = (-rmax + (ibin-0.5)*dx)*cp;

      for (UShort_t jbin = 1; jbin <= nbins; ++jbin)
      {
         Double_t z = -rmax + (jbin-0.5)*dx;

         fR        = sqrt(x*x*(1 + tp2) + z*z);
         fTheta    = acos(z/fR)*TMath::RadToDeg();
         fPolarity = fTheta > (x/cp > 0. ? 90. - alfa : 90 + alfa) ? -1 : 1;

         if (fR >= rmin && fR <= rmax)
         {
            Double_t B;
            if (icoo < 3) B = ((*this).*(hmf[fFieldType][icoo]))();
            else
            {
               B = 0.;
               for (icoo = 0; icoo < 3; ++icoo)
               {
                  Double_t Bi = ((*this).*(hmf[fFieldType][icoo]))();
                  B += Bi*Bi;
               }
               B = sqrt(B);
            }

            h2->SetBinContent(ibin, jbin, B);
         }
      }
   }

   h2->Draw(option);

   return h2;
}
*/
Double_t Heliosphere::HMF::Magnitude(Double_t *x, Double_t *par)
{
   fR     = x[0];
   fTheta = x[1];

   fB0    = par[0];
   fdelta = par[1];
   fb     = par[2];

   fPolarity = fTheta > 90. - fVSW->fTiltAngle ? -1 : 1;

   Double_t Br = ((*this).*(hmf[fFieldType][0]))();
   Double_t Bt = ((*this).*(hmf[fFieldType][1]))();
   Double_t Bp = ((*this).*(hmf[fFieldType][2]))();

   return sqrt(Br*Br + Bt*Bt + Bp*Bp);
}
Double_t Heliosphere::HMF::Radial(Double_t *x, Double_t *par)
{
   fR     = x[0];
   fTheta = x[1];

   fB0    = par[0];
   fdelta = par[1];
   fb     = par[2];

   fPolarity = fTheta > 90. - fVSW->fTiltAngle ? -1 : 1;

   return ((*this).*(hmf[fFieldType][0]))();
}
Double_t Heliosphere::HMF::Polar(Double_t *x, Double_t *par)
{
   fR     = x[0];
   fTheta = x[1];

   fB0    = par[0];
   fdelta = par[1];
   fb     = par[2];

   fPolarity = fTheta > 90. - fVSW->fTiltAngle ? -1 : 1;

   return ((*this).*(hmf[fFieldType][1]))();
}
Double_t Heliosphere::HMF::Azimuthal(Double_t *x, Double_t *par)
{
   fR     = x[0];
   fTheta = x[1];

   fB0    = par[0];
   fdelta = par[1];
   fb     = par[2];

   fPolarity = fTheta > 90. - fVSW->fTiltAngle ? -1 : 1;

   return ((*this).*(hmf[fFieldType][2]))();
}

Double_t Heliosphere::HMF::parker_radial()
{
   return fB0 * pow(fVSW->fR0/fR, 2) * fPolarity;
}
Double_t Heliosphere::HMF::parker_polar()
{
   return 0.;
}
Double_t Heliosphere::HMF::parker_azimuthal()
{
   Double_t Vswr  = fVSW->GetSpeed(fR, fTheta, fPhi);
   Double_t tgpsi = fOmega * (fR - fVSW->fRSun)*sin(fTheta*TMath::DegToRad()) / Vswr;

   return - fB0 * pow(fVSW->fR0/fR, 2) * fPolarity * tgpsi;
}

Double_t Heliosphere::HMF::jokipiikota_radial()
{
   return fB0 * pow(fVSW->fR0/fR, 2) * fPolarity;
}
Double_t Heliosphere::HMF::jokipiikota_polar()
{
   return fB0 * pow(fVSW->fR0, 2) * fPolarity * fdelta / (fR * fVSW->fRSun * sin(fTheta*TMath::DegToRad()));
}
Double_t Heliosphere::HMF::jokipiikota_azimuthal()
{
   Double_t Vswr  = fVSW->GetSpeed(fR, fTheta, fPhi);
   Double_t tgpsi = fOmega * (fR - fVSW->fRSun)*sin(fTheta*TMath::DegToRad()) / Vswr;

   return - fB0 * pow(fVSW->fR0/fR, 2) * fPolarity * tgpsi;
}

Double_t Heliosphere::HMF::smithbieber_radial()
{
   return fB0 * pow(fVSW->fR0/fR, 2) * fPolarity;
}
Double_t Heliosphere::HMF::smithbieber_polar()
{
   return 0.;
}
Double_t Heliosphere::HMF::smithbieber_azimuthal()
{
   Double_t b     = fb*fVSW->fRSun;
   Double_t Vswr  = fVSW->GetSpeed(fR, fTheta, fPhi);
   Double_t Vswb  = fVSW->GetSpeed(b, fTheta, fPhi);
   Double_t tgpsi = (fOmega * (fR - b)*sin(fTheta*TMath::DegToRad()) - fR/b*Vswb*fdelta) / Vswr;

   return - fB0 * pow(fVSW->fR0/fR, 2) * fPolarity * tgpsi;
}

string Heliosphere::DataPath = "~/cernbox/AMS/data/heliosphere";
string Heliosphere::OMNIWebDateRange = "19650101_20171231";

TGraph *Heliosphere::GetTiltAngle(Long64_t begin_date, Long64_t end_date, Bool_t radial)
{
   Long64_t start_utime;
   Float_t alpha;

   TFile file(Form("%s/tilt_angle.root", DataPath.c_str()));
   TTree *tree = (TTree *)file.Get("tiltangle");
   tree->SetBranchAddress("start_utime", &start_utime);
   tree->SetBranchAddress(radial ? "R_av" : "L_av", &alpha);

   TGraph *g = new TGraph();
   g->SetTitle(Form("HCS tilt angle (%s model, WSO);;#alpha [deg]", radial ? "radial" : "line-of-sight"));
   UInt_t ipoint = 0;
   Long64_t last_start_utime = 0;
   for (Long64_t ientry = 0; ientry < tree->GetEntries(); ++ientry)
   {
      tree->GetEntry(ientry);

      if (start_utime < begin_date || start_utime > end_date)
      {
         last_start_utime = start_utime;
         continue;
      }

      g->SetPoint(ipoint++, last_start_utime > 0 ? 0.5*(last_start_utime + start_utime) : start_utime, alpha);

      last_start_utime = start_utime;
   }

   return g;
}

TGraph *Heliosphere::GetIMF(Long64_t begin_date, Long64_t end_date)
{
   /*UInt_t utime;
   Float_t B;
   UInt_t qual;

   TFile file(Form("%s/ace-imf-coord.root", DataPath.c_str()));
   TTree *tree = (TTree *)file.Get("imf");
   tree->SetBranchAddress("utime", &utime);
   tree->SetBranchAddress("B",     &B);
   tree->SetBranchAddress("qual",  &qual);

   TGraph *g = new TGraph();
   g->SetTitle("Interplanetary magnetic field (ACE);;B [nT]");
   UInt_t ipoint = 0;
   for (Long64_t ientry = 0; ientry < tree->GetEntries(); ++ientry)
   {
      tree->GetEntry(ientry);

      if (utime < begin_date || utime > end_date) continue;
      if (qual != 0) continue;

      g->SetPoint(ipoint++, utime, B);
   }*/

   Long64_t utime;
   Float_t IMF;

   TFile file(Form("%s/omniweb_%s_day_all.root", DataPath.c_str(), OMNIWebDateRange.c_str()));
   TTree *tree = (TTree *)file.Get("omni");
   tree->SetBranchAddress("utime", &utime);
   tree->SetBranchAddress("IMF",   &IMF);

   TGraph *g = new TGraph();
   g->SetTitle("Interplanetary magnetic field (OMNIWeb);;B [nT]");
   UInt_t ipoint = 0;
   for (Long64_t ientry = 0; ientry < tree->GetEntries(); ++ientry)
   {
      tree->GetEntry(ientry);

      if (utime < begin_date || utime > end_date) continue;
      if (IMF >= 999) continue;

      g->SetPoint(ipoint++, utime, IMF);
   }

   return g;
}

TGraph *Heliosphere::GetSWSpeed(Long64_t begin_date, Long64_t end_date)
{
   /*UInt_t utime;
   Float_t v;

   TFile file(Form("%s/ace-sw-coord.root", DataPath.c_str()));
   TTree *tree = (TTree *)file.Get("sw");
   tree->SetBranchAddress("utime", &utime);
   tree->SetBranchAddress("v",     &v);

   TGraph *g = new TGraph();
   g->SetTitle("Sloar wind speed (ACE);;V_{SW} [km/s]");
   UInt_t ipoint = 0;
   for (Long64_t ientry = 0; ientry < tree->GetEntries(); ++ientry)
   {
      tree->GetEntry(ientry);

      if (utime < begin_date || utime > end_date) continue;
      if (v <= 0) continue;

      g->SetPoint(ipoint++, utime, v);
   }*/

   Long64_t utime;
   Float_t SWv;

   TFile file(Form("%s/omniweb_%s_day_all.root", DataPath.c_str(), OMNIWebDateRange.c_str()));
   TTree *tree = (TTree *)file.Get("omni");
   tree->SetBranchAddress("utime", &utime);
   tree->SetBranchAddress("SWv",   &SWv);

   TGraph *g = new TGraph();
   g->SetTitle("Solar wind speed (OMNIWeb);;V_{SW} [km/s]");
   UInt_t ipoint = 0;
   for (Long64_t ientry = 0; ientry < tree->GetEntries(); ++ientry)
   {
      tree->GetEntry(ientry);

      if (utime < begin_date || utime > end_date) continue;
      if (SWv >= 999) continue;

      g->SetPoint(ipoint++, utime, SWv);
   }

   return g;
}

TMultiGraph *Heliosphere::GetPolarField(Long64_t begin_date, Long64_t end_date)
{
   Long64_t utime;
   Float_t B_avg;
   Float_t B_north;
   Float_t B_south;

   TFile file(Form("%s/polar_field.root", DataPath.c_str()));
   TTree *tree = (TTree *)file.Get("polar");
   tree->SetBranchAddress("utime", &utime);
   tree->SetBranchAddress("B_avf", &B_avg);
   tree->SetBranchAddress("B_nf", &B_north);
   tree->SetBranchAddress("B_sf", &B_south);

   TGraph *ga = new TGraph();
   ga->SetTitle("Average Sun's polar magnetic field (WSO);;B_{Avg} [#muT]");
   TGraph *gn = new TGraph();
   gn->SetTitle("Sun's North pole magnetic field (WSO);;B_{N} [#muT]");
   TGraph *gs = new TGraph();
   gs->SetTitle("Sun's South pole magnetic field (WSO);;B_{S} [#muT]");
   UInt_t ipoint = 0;
   for (Long64_t ientry = 0; ientry < tree->GetEntries(); ++ientry)
   {
      tree->GetEntry(ientry);

      if (utime < begin_date || utime > end_date) continue;

      ga->SetPoint(ipoint, utime, B_avg);
      gn->SetPoint(ipoint, utime, B_north);
      gs->SetPoint(ipoint++, utime, B_south);
   }

   TMultiGraph *mg = new TMultiGraph();
   mg->Add(ga);
   mg->Add(gn);
   mg->Add(gs);

   return mg;
}

TGraphErrors *Heliosphere::GetSunspotNumber(const Char_t *type, Long64_t begin_date, Long64_t end_date, Bool_t only_definitive)
{
   Long64_t utime;
   Float_t ssn_avg, ssn_std;
   Int_t nobs;
   UChar_t ok;

   TFile file(Form("%s/%s_sunspot_number.root", DataPath.c_str(), type));
   TTree *tree = (TTree *)file.Get(Form("ssn_%s", type));
   tree->SetBranchAddress("utime", &utime);
   tree->SetBranchAddress("ssn_avg", &ssn_avg);
   tree->SetBranchAddress("ssn_std", &ssn_std);
   tree->SetBranchAddress("nobs", &nobs);
   tree->SetBranchAddress("ok", &ok);

   TGraphErrors *g = new TGraphErrors();
   g->SetTitle(Form("%c%s sunspot number (WDC-SILSO);;SSN", toupper(type[0]), &type[1]));
   UInt_t ipoint = 0;
   for (Long64_t ientry = 0; ientry < tree->GetEntries(); ++ientry)
   {
      tree->GetEntry(ientry);

      if (utime < begin_date || utime > end_date) continue;
      if (!ok && only_definitive) continue;
      if (nobs <= 0) continue;

      g->SetPoint(ipoint, utime, ssn_avg);
      g->SetPointError(ipoint++, 0., ssn_std);
   }

   return g;
}

TMultiGraph *Heliosphere::GetHemisphericSunspotNumber(const Char_t *type, Long64_t begin_date, Long64_t end_date, Bool_t only_definitive)
{
   Long64_t utime;
   Float_t ssn_north, ssn_north_std;
   Float_t ssn_south, ssn_south_std;
   Int_t nobs_north, nobs_south;
   UChar_t ok;

   TFile file(Form("%s/%s_hemispheric_sunspot_number.root", DataPath.c_str(), type));
   TTree *tree = (TTree *)file.Get(Form("ssn_hem_%s", type));
   tree->SetBranchAddress("utime", &utime);
   tree->SetBranchAddress("ssn_north", &ssn_north);
   tree->SetBranchAddress("ssn_north_std", &ssn_north_std);
   tree->SetBranchAddress("nobs_north", &nobs_north);
   tree->SetBranchAddress("ssn_south", &ssn_south);
   tree->SetBranchAddress("ssn_south_std", &ssn_south_std);
   tree->SetBranchAddress("nobs_south", &nobs_south);
   tree->SetBranchAddress("ok", &ok);

   TGraphErrors *gn = new TGraphErrors();
   gn->SetTitle("Daily North sunspot number (WDC-SILSO);;SSN_{North}");
   TGraphErrors *gs = new TGraphErrors();
   gs->SetTitle("Daily South sunspot number (WDC-SILSO);;SSN_{Sorth}");
   UInt_t ipoint_north = 0, ipoint_south = 0;
   for (Long64_t ientry = 0; ientry < tree->GetEntries(); ++ientry)
   {
      tree->GetEntry(ientry);

      if (utime < begin_date || utime > end_date) continue;
      if (!ok && only_definitive) continue;

      if (!only_definitive || nobs_north > 0)
      {
         gn->SetPoint(ipoint_north, utime, ssn_north);
         gn->SetPointError(ipoint_north++, 0., ssn_north_std);
      }

      if (!only_definitive || nobs_south > 0)
      {
         gs->SetPoint(ipoint_south, utime, ssn_south);
         gs->SetPointError(ipoint_south++, 0., ssn_south_std);
      }
   }

   TMultiGraph *mg = new TMultiGraph();
   mg->Add(gn);
   mg->Add(gs);

   return mg;
}

TGraphErrors *Heliosphere::GetSILSOPredictedSunspotNumber(const Char_t *type, Long64_t begin_date, Long64_t end_date)
{
   Long64_t utime;
   Float_t ssn_avg, ssn_std;

   TFile file(Form("%s/silso_ssn_predicted.root", DataPath.c_str()));
   TTree *tree = (TTree *)file.Get(Form("ssn_%s", type));
   tree->SetBranchAddress("utime", &utime);
   tree->SetBranchAddress("ssn_avg", &ssn_avg);
   tree->SetBranchAddress("ssn_std", &ssn_std);

   TGraphErrors *g = new TGraphErrors();
   g->SetTitle(Form("12-months predicted monthly sunspot number (%s, WDC-SILSO);;SSN", type));
   UInt_t ipoint = 0;
   for (Long64_t ientry = 0; ientry < tree->GetEntries(); ++ientry)
   {
      tree->GetEntry(ientry);

      if (utime < begin_date || utime > end_date) continue;

      g->SetPoint(ipoint, utime, ssn_avg);
      g->SetPointError(ipoint++, 0., ssn_std);
   }

   return g;
}

TGraphAsymmErrors *Heliosphere::GetNOAAPredictedSunspotNumber(Long64_t begin_date, Long64_t end_date)
{
   Long64_t utime;
   Float_t ssn_avg, ssn_low, ssn_high;

   TFile file(Form("%s/noaa_ssn_radioflux_prediction.root", DataPath.c_str()));
   TTree *tree = (TTree *)file.Get("noaa");
   tree->SetBranchAddress("utime", &utime);
   tree->SetBranchAddress("ssn_avg", &ssn_avg);
   tree->SetBranchAddress("ssn_low", &ssn_low);
   tree->SetBranchAddress("ssn_high", &ssn_high);

   TGraphAsymmErrors *g = new TGraphAsymmErrors();
   g->SetTitle("Predicted monthly sunspot number (NOAA);;SSN");
   UInt_t ipoint = 0;
   for (Long64_t ientry = 0; ientry < tree->GetEntries(); ++ientry)
   {
      tree->GetEntry(ientry);

      if (utime < begin_date || utime > end_date) continue;
      if (ssn_avg == -1. || ssn_low == -1. || ssn_high == -1.) continue;

      g->SetPoint(ipoint, utime, ssn_avg);
      g->SetPointError(ipoint++, 0., 0., ssn_avg - ssn_low, ssn_high - ssn_avg);
   }

   return g;
}

TGraphAsymmErrors *Heliosphere::GetNOAAPredictedRadioFlux(Long64_t begin_date, Long64_t end_date)
{
   Long64_t utime;
   Float_t radio_avg, radio_low, radio_high;

   TFile file(Form("%s/noaa_radio_radioflux_prediction.root", DataPath.c_str()));
   TTree *tree = (TTree *)file.Get("noaa");
   tree->SetBranchAddress("utime", &utime);
   tree->SetBranchAddress("radio_avg", &radio_avg);
   tree->SetBranchAddress("radio_low", &radio_low);
   tree->SetBranchAddress("radio_high", &radio_high);

   TGraphAsymmErrors *g = new TGraphAsymmErrors();
   g->SetTitle("Predicted monthly 10.7cm radio flux (NOAA);;F10.7 [10^{-22} W/m^{2}/Hz]");
   UInt_t ipoint = 0;
   for (Long64_t ientry = 0; ientry < tree->GetEntries(); ++ientry)
   {
      tree->GetEntry(ientry);

      if (utime < begin_date || utime > end_date) continue;
      if (radio_avg == -1. || radio_low == -1. || radio_high == -1.) continue;

      g->SetPoint(ipoint, utime, radio_avg);
      g->SetPointError(ipoint++, 0., 0., radio_avg - radio_low, radio_high - radio_avg);
   }

   return g;
}

const Char_t * const Heliosphere::SunspotNumber::fPeriodName[Heliosphere::SunspotNumber::nPeriods] = { "daily", "monthly" };
const Char_t * const Heliosphere::SunspotNumber::fPeriodTitle[Heliosphere::SunspotNumber::nPeriods] = { "Daily", "Monthly" };

Heliosphere::SunspotNumber::SunspotNumber(Type type, Period period) :
   fFile(NULL), fTree(NULL), fType(type), fPeriod(period)
{
   Char_t path[256];
   if (fType == Total)
   {
      snprintf(path, 256, "%s/%s_sunspot_number.root", DataPath.c_str(), fPeriodName[fPeriod]);
   }
   else
   {
      snprintf(path, 256, "%s/%s_hemispheric_sunspot_number.root", DataPath.c_str(), fPeriodName[fPeriod]);
   }
   fFile = new TFile(path);

   snprintf(path, 256, "ssn_%s", fPeriodName[fPeriod]);
   fTree = (TTree *)fFile->Get(path);
}

Heliosphere::SunspotNumber::~SunspotNumber()
{
   if (fFile != NULL) delete fFile;
}

TGraphErrors *Heliosphere::SunspotNumber::GetTotal(Long64_t begin_date, Long64_t end_date, Bool_t only_definitive, ErrorType err)
{
   Long64_t utime;
   Float_t ssn_avg, ssn_std;
   Int_t nobs;
   UChar_t ok;

   fTree->ResetBranchAddresses();
   fTree->SetBranchAddress("utime", &utime);
   fTree->SetBranchAddress("ssn_avg", &ssn_avg);
   fTree->SetBranchAddress("ssn_std", &ssn_std);
   fTree->SetBranchAddress("nobs", &nobs);
   fTree->SetBranchAddress("ok", &ok);

   Char_t title[256];
   snprintf(title, 256, "%s sunspot number (WDC-SILSO);;SSN", fPeriodTitle[fPeriod]);

   TGraphErrors *g = new TGraphErrors();
   g->SetTitle(title);

   UInt_t ipoint = 0;
   for (Long64_t ientry = 0; ientry < fTree->GetEntries(); ++ientry)
   {
      fTree->GetEntry(ientry);

      if (utime < begin_date || utime > end_date) continue;
      if (!ok && only_definitive) continue;
      if (nobs <= 0) continue;

      g->SetPoint(ipoint, utime, ssn_avg);
      g->SetPointError(ipoint++, 0., err == StdDev ? ssn_std : ssn_std/sqrt(nobs));
   }

   return g;
}

TGraphErrors *Heliosphere::SunspotNumber::GetTotalAverage(vector< pair<time_t, time_t> > &ranges, Bool_t only_definitive, ErrorType err)
{
   Long64_t utime;
   Float_t ssn_avg, ssn_std;
   Int_t nobs;
   UChar_t ok;

   fTree->ResetBranchAddresses();
   fTree->SetBranchAddress("utime", &utime);
   fTree->SetBranchAddress("ssn_avg", &ssn_avg);
   fTree->SetBranchAddress("ssn_std", &ssn_std);
   fTree->SetBranchAddress("nobs", &nobs);
   fTree->SetBranchAddress("ok", &ok);

   Char_t title[256];
   snprintf(title, 256, "%s sunspot number (WDC-SILSO);;SSN", fPeriodTitle[fPeriod]);

   TGraphErrors *g = new TGraphErrors(ranges.size());
   g->SetTitle(title);

   Long64_t ientry = 0;
   for (UShort_t irange = 0; irange < ranges.size(); ++irange)
   {
      time_t t1 = ranges[irange].first;
      time_t t2 = ranges[irange].second;

      Double_t mean = 0., sigma = 0.;
      UInt_t n = 0, ntotobs = 0;
      for ( ; ientry < fTree->GetEntries(); ++ientry)
      {
         fTree->GetEntry(ientry);

         if (utime < t1) continue;
         if (!ok && only_definitive) continue;
         if (nobs <= 0) continue;
         if (utime >= t2) break;

         mean += ssn_avg;
         sigma += nobs*ssn_std*ssn_std;
         ntotobs += nobs;
         ++n;
      }

      if (n > 0)
      {
         g->SetPoint(irange, 0.5*(t1+t2), mean/n);
         g->SetPointError(irange, 0., err == StdDev ? sqrt(sigma/ntotobs) : sqrt(sigma/ntotobs/ntotobs));
      }
      else
      {
         g->SetPoint(irange, 0.5*(t1+t2), 0.);
         g->SetPointError(irange, 0., 0.);
      }
   }

   return g;
}

TMultiGraph *Heliosphere::SunspotNumber::GetHemispheric(Long64_t begin_date, Long64_t end_date, Bool_t only_definitive, ErrorType err)
{
   Long64_t utime;
   Float_t ssn_north, ssn_north_std;
   Float_t ssn_south, ssn_south_std;
   Int_t nobs_north, nobs_south;
   UChar_t ok;

   fTree->ResetBranchAddresses();
   fTree->SetBranchAddress("utime", &utime);
   fTree->SetBranchAddress("ssn_north", &ssn_north);
   fTree->SetBranchAddress("ssn_north_std", &ssn_north_std);
   fTree->SetBranchAddress("nobs_north", &nobs_north);
   fTree->SetBranchAddress("ssn_south", &ssn_south);
   fTree->SetBranchAddress("ssn_south_std", &ssn_south_std);
   fTree->SetBranchAddress("nobs_south", &nobs_south);
   fTree->SetBranchAddress("ok", &ok);

   Char_t title[256];

   TGraphErrors *gn = new TGraphErrors();
   snprintf(title, 256, "%s North sunspot number (WDC-SILSO);;SSN_{North}", fPeriodTitle[fPeriod]);
   gn->SetTitle(title);

   TGraphErrors *gs = new TGraphErrors();
   snprintf(title, 256, "%s South sunspot number (WDC-SILSO);;SSN_{South}", fPeriodTitle[fPeriod]);
   gs->SetTitle(title);

   UInt_t ipoint_north = 0, ipoint_south = 0;
   for (Long64_t ientry = 0; ientry < fTree->GetEntries(); ++ientry)
   {
      fTree->GetEntry(ientry);

      if (utime < begin_date || utime > end_date) continue;
      if (!ok && only_definitive) continue;

      if (nobs_north > 0)
      {
         gn->SetPoint(ipoint_north, utime, ssn_north);
         gn->SetPointError(ipoint_north++, 0., err == StdDev ? ssn_north_std : ssn_north_std/sqrt(nobs_north));
      }

      if (nobs_south > 0)
      {
         gs->SetPoint(ipoint_south, utime, ssn_south);
         gs->SetPointError(ipoint_south++, 0., err == StdDev ? ssn_south_std : ssn_south_std/sqrt(nobs_south));
      }
   }

   TMultiGraph *mg = new TMultiGraph();
   mg->Add(gn);
   mg->Add(gs);

   return mg;
}

TMultiGraph *Heliosphere::SunspotNumber::GetHemisphericAverage(vector< pair<time_t, time_t> > &ranges, Bool_t only_definitive, ErrorType err)
{
   Long64_t utime;
   Float_t ssn_north, ssn_north_std;
   Float_t ssn_south, ssn_south_std;
   Int_t nobs_north, nobs_south;
   UChar_t ok;

   fTree->ResetBranchAddresses();
   fTree->SetBranchAddress("utime", &utime);
   fTree->SetBranchAddress("ssn_north", &ssn_north);
   fTree->SetBranchAddress("ssn_north_std", &ssn_north_std);
   fTree->SetBranchAddress("nobs_north", &nobs_north);
   fTree->SetBranchAddress("ssn_south", &ssn_south);
   fTree->SetBranchAddress("ssn_south_std", &ssn_south_std);
   fTree->SetBranchAddress("nobs_south", &nobs_south);
   fTree->SetBranchAddress("ok", &ok);

   Char_t title[256];

   TGraphErrors *gn = new TGraphErrors(ranges.size());
   snprintf(title, 256, "%s North sunspot number (WDC-SILSO);;SSN_{North}", fPeriodTitle[fPeriod]);
   gn->SetTitle(title);

   TGraphErrors *gs = new TGraphErrors(ranges.size());
   snprintf(title, 256, "%s South sunspot number (WDC-SILSO);;SSN_{South}", fPeriodTitle[fPeriod]);
   gs->SetTitle(title);

   Long64_t ientry = 0;
   for (UShort_t irange = 0; irange < ranges.size(); ++irange)
   {
      time_t t1 = ranges[irange].first;
      time_t t2 = ranges[irange].second;

      Double_t mean_north = 0., sigma_north = 0.;
      Double_t mean_south = 0., sigma_south = 0.;
      UInt_t n_north = 0, ntotobs_north = 0;
      UInt_t n_south = 0, ntotobs_south = 0;
      for ( ; ientry < fTree->GetEntries(); ++ientry)
      {
         fTree->GetEntry(ientry);

         if (utime < t1) continue;
         if (!ok && only_definitive) continue;
         if (utime >= t2) break;

         if (nobs_north > 0)
         {
            mean_north += ssn_north;
            sigma_north += nobs_north*ssn_north_std*ssn_north_std;
            ntotobs_north += nobs_north;
            ++n_north;
         }

         if (nobs_south > 0)
         {
            mean_south += ssn_south;
            sigma_south += nobs_south*ssn_south_std*ssn_south_std;
            ntotobs_south += nobs_south;
            ++n_south;
         }
      }

      if (n_north > 0)
      {
         gn->SetPoint(irange, 0.5*(t1+t2), mean_north/n_north);
         gn->SetPointError(irange, 0., err == StdDev ? sqrt(sigma_north/ntotobs_north) : sqrt(sigma_north/ntotobs_north/ntotobs_north));
      }
      else
      {
         gn->SetPoint(irange, 0.5*(t1+t2), 0.);
         gn->SetPointError(irange, 0., 0.);
      }

      if (n_south > 0)
      {
         gs->SetPoint(irange, 0.5*(t1+t2), mean_south/n_south);
         gs->SetPointError(irange, 0., err == StdDev ? sqrt(sigma_south/ntotobs_south) : sqrt(sigma_south/ntotobs_south/ntotobs_south));
      }
      else
      {
         gs->SetPoint(irange, 0.5*(t1+t2), 0.);
         gs->SetPointError(irange, 0., 0.);
      }
   }

   TMultiGraph *mg = new TMultiGraph();
   mg->Add(gn);
   mg->Add(gs);

   return mg;
}

TMultiGraph *Heliosphere::GetSunMagneticFieldComponents(Long64_t begin_date, Long64_t end_date)
{
   Int_t utime;
   Float_t north_field;
   Float_t north_field_err;
   Float_t south_field;
   Float_t south_field_err;
   Float_t axial_dipole;
   Float_t axial_dipole_err;
   Float_t equatorial_dipole;
   Float_t equatorial_dipole_err;

   TFile file(Form("%s/field_components.root", DataPath.c_str()));
   TTree *tree = (TTree *)file.Get("magfield");
   tree->SetBranchAddress("utime", &utime);
   tree->SetBranchAddress("north_field", &north_field);
   tree->SetBranchAddress("north_field_err", &north_field_err);
   tree->SetBranchAddress("south_field", &south_field);
   tree->SetBranchAddress("south_field_err", &south_field_err);
   tree->SetBranchAddress("axial_dipole", &axial_dipole);
   tree->SetBranchAddress("axial_dipole_err", &axial_dipole_err);
   tree->SetBranchAddress("equatorial_dipole", &equatorial_dipole);
   tree->SetBranchAddress("equatorial_dipole_err", &equatorial_dipole_err);

   TGraphErrors *gn = new TGraphErrors();
   gn->SetTitle("Daily North magnetic field (Sun et al, 2015, ApJ, 798);;B_{North} [G]");
   TGraphErrors *gs = new TGraphErrors();
   gs->SetTitle("Daily South magnetic field (Sun et al, 2015, ApJ, 798);;B_{South} [G]");
   TGraphErrors *ga = new TGraphErrors();
   ga->SetTitle("Daily axial dipole magnitude (Sun et al, 2015, ApJ, 798);;Axial dipole [G]");
   TGraphErrors *ge = new TGraphErrors();
   ge->SetTitle("Daily equatorial dipole magnitude (Sun et al, 2015, ApJ, 798);;Equatorial dipole [G]");
   UInt_t ipointf = 0, ipointd = 0;
   for (Long64_t ientry = 0; ientry < tree->GetEntries(); ++ientry)
   {
      tree->GetEntry(ientry);

      if (utime < begin_date || utime > end_date) continue;

      gn->SetPoint(ipointf, utime, north_field);
      gn->SetPointError(ipointf, 0., north_field_err);
      gs->SetPoint(ipointf, utime, south_field);
      gs->SetPointError(ipointf, 0., south_field_err);
      ++ipointf;

      if (axial_dipole <= -999.) continue;

      ga->SetPoint(ipointd, utime, TMath::Abs(axial_dipole));
      ga->SetPointError(ipointd, 0., axial_dipole_err);
      ge->SetPoint(ipointd, utime, equatorial_dipole);
      ge->SetPointError(ipointd, 0., equatorial_dipole_err);
      ++ipointd;
   }

   TMultiGraph *mg = new TMultiGraph();
   mg->Add(gn);
   mg->Add(gs);
   mg->Add(ga);
   mg->Add(ge);

   return mg;
}
