#include "Spline.hh"
#include "debug.hh"

static Char_t *copy_string(const Char_t *str)
{
   Char_t *_string = NULL;
   size_t len = str != NULL ? strlen(str) : 0;
   if (len > 0)
   {
      _string = new Char_t[len + 1];
      snprintf(_string, len + 1, "%s", str);
   }

   return _string;
}

ClassImp(Spline)

using namespace std;

Spline::Spline() :
   _nnodes(0), _xn(NULL), _yn(NULL),
   _gamma(0),
   _type(Normal),
   _func(NULL), _first_powerlaw(NULL), _last_powerlaw(NULL),
   _hist(NULL), _graph(NULL)
{
   _call_spline[0][0] = &Spline::_spline;
   _call_spline[0][1] = &Spline::_spline_logx;
   _call_spline[0][2] = &Spline::_spline_logy;
   _call_spline[0][3] = &Spline::_spline_loglog;
   _call_spline[1][0] = &Spline::_spline_powerlaw;
   _call_spline[1][1] = &Spline::_spline_powerlaw_logx;
   _call_spline[1][2] = &Spline::_spline_powerlaw_logy;
   _call_spline[1][3] = &Spline::_spline_powerlaw_loglog;
   _call_spline[2][0] = &Spline::_spline_ams15;
   _call_spline[2][1] = &Spline::_spline_ams15_logx;
   _call_spline[2][2] = &Spline::_spline_ams15_logy;
   _call_spline[2][3] = &Spline::_spline_ams15_loglog;

   Double_t ams15_pars[] = { 17900, -2.804, 375, 0.1, 0.001 };
   _set_ams15_parameters(ams15_pars);
}

Spline::Spline(const Char_t *Name, UShort_t nNodes, UShort_t Type, Double_t *NodesX, Double_t *NodesY, Double_t FirstDerivative, Double_t LastDerivative, Double_t Gamma) :
   _nnodes(nNodes), _xn(NULL), _yn(NULL),
   _gamma(Gamma),
   _type(Type),
   _func(NULL), _first_powerlaw(NULL), _last_powerlaw(NULL),
   _hist(NULL), _graph(NULL)
{
   _update_type();

   _call_spline[0][0] = &Spline::_spline;
   _call_spline[0][1] = &Spline::_spline_logx;
   _call_spline[0][2] = &Spline::_spline_logy;
   _call_spline[0][3] = &Spline::_spline_loglog;
   _call_spline[1][0] = &Spline::_spline_powerlaw;
   _call_spline[1][1] = &Spline::_spline_powerlaw_logx;
   _call_spline[1][2] = &Spline::_spline_powerlaw_logy;
   _call_spline[1][3] = &Spline::_spline_powerlaw_loglog;
   _call_spline[2][0] = &Spline::_spline_ams15;
   _call_spline[2][1] = &Spline::_spline_ams15_logx;
   _call_spline[2][2] = &Spline::_spline_ams15_logy;
   _call_spline[2][3] = &Spline::_spline_ams15_loglog;

   _func = new TF1(Name, this, 0, 0, 2*_nnodes + 2);
   _func->SetNpx(1000);
   _func->SetParName(0, (_type & PowerLaw) || (_type & AMS15) ? "gb" : "b1");
   _func->SetParName(1, _type & PowerLaw ? "ge" : "e1");
   for (UShort_t inode = 0; inode < _nnodes; ++inode)
   {
      _func->SetParName(2 + inode, Form("x%02u", inode));
      _func->SetParName(2 + _nnodes + inode, Form("y%02u", inode));
   }

   _set_x_nodes(NodesX);
   _set_y_nodes(NodesY, NULL, NULL);

   if (_type & PowerLaw && NodesX != NULL && NodesY != NULL) _set_spectral_indices(FirstDerivative, LastDerivative, 0, 0, 0, 0);
   else if (!(_type & PowerLaw)) _set_derivatives(FirstDerivative, LastDerivative);

   Double_t ams15_pars[] = { 17900, -2.804, 375, 0.1, 0.001 };
   _set_ams15_parameters(ams15_pars);
   //~ if (_type & AMS15) _set_ams15_boundary_conditions();

   //~ SetXNodes(NodesX);
   //~ SetYNodes(NodesY);
}

Spline::Spline(const Spline &sp)
{
   _nnodes = sp._nnodes;

   _xn = new Double_t[_nnodes];
   _yn = new Double_t[_nnodes];
   for (UShort_t inode = 0; inode < _nnodes; ++inode)
   {
      _xn[inode] = sp._xn[inode];
      _yn[inode] = sp._yn[inode];
   }

   _b1    = sp._b1;
   _e1    = sp._e1;
   _A     = sp._A;
   _B     = sp._B;
   _gb    = sp._gb;
   _ge    = sp._ge;
   _gamma = sp._gamma;

   for (UShort_t ipar = 0; ipar < 5; ++ipar)
   {
      _ams15_pars[ipar] = sp._ams15_pars[ipar];
   }
   _ams15_flux  = sp._ams15_flux;
   _ams15_deriv = sp._ams15_deriv;

   _type        = sp._type;
   _is_powerlaw = sp._is_powerlaw;
   _log_type    = sp._log_type;

   Double_t xmin, xmax;
   sp._func->GetRange(xmin, xmax);
   _func = new TF1("", this, xmin, xmax, sp._func->GetNpar());
   _func->SetNpx(sp._func->GetNpx());
   for (UShort_t ipar = 0; ipar < _func->GetNpar(); ++ipar)
   {
      _func->SetParameter(ipar, sp._func->GetParameter(ipar));
      _func->SetParError(ipar, sp._func->GetParError(ipar));
      _func->SetParName(ipar, copy_string(sp._func->GetParName(ipar)));
      Double_t pmin, pmax;
      sp._func->GetParLimits(ipar, pmin, pmax);
      _func->SetParLimits(ipar, pmin, pmax);
   }

   if (sp._first_powerlaw != NULL)
   {
      _first_powerlaw = (TF1 *)sp._first_powerlaw->IsA()->New();
      sp._first_powerlaw->Copy(*_first_powerlaw);
   }
   if (sp._last_powerlaw != NULL)
   {
      _last_powerlaw = (TF1 *)sp._last_powerlaw->IsA()->New();
      sp._last_powerlaw->Copy(*_last_powerlaw);
   }
   _hist = sp._hist;
   _graph = sp._graph;

   _call_spline[0][0] = &Spline::_spline;
   _call_spline[0][1] = &Spline::_spline_logx;
   _call_spline[0][2] = &Spline::_spline_logy;
   _call_spline[0][3] = &Spline::_spline_loglog;
   _call_spline[1][0] = &Spline::_spline_powerlaw;
   _call_spline[1][1] = &Spline::_spline_powerlaw_logx;
   _call_spline[1][2] = &Spline::_spline_powerlaw_logy;
   _call_spline[1][3] = &Spline::_spline_powerlaw_loglog;
   _call_spline[2][0] = &Spline::_spline_ams15;
   _call_spline[2][1] = &Spline::_spline_ams15_logx;
   _call_spline[2][2] = &Spline::_spline_ams15_logy;
   _call_spline[2][3] = &Spline::_spline_ams15_loglog;
}

Spline::~Spline()
{
   if (_xn != NULL) delete[] _xn;
   if (_yn != NULL) delete[] _yn;

   if (_func != NULL) delete _func;
   if (_first_powerlaw != NULL) delete _first_powerlaw;
   if (_last_powerlaw != NULL) delete _last_powerlaw;
}

void Spline::Rebuild()
{
   _update_type();

   Char_t name[256] = "";
   if (_func != NULL)
   {
      snprintf(name, 256, "%s", _func->GetName());
      delete _func;
   }
   _func = new TF1(name, this, 0, 0, 2*_nnodes + 2);
   _func->SetNpx(1000);
   _func->SetParName(0, (_type & PowerLaw) || (_type & AMS15) ? "gb" : "b1");
   _func->SetParName(1, _type & PowerLaw ? "ge" : "e1");
   for (UShort_t inode = 0; inode < _nnodes; ++inode)
   {
      _func->SetParName(2 + inode, Form("x%02u", inode));
      _func->SetParName(2 + _nnodes + inode, Form("y%02u", inode));
   }

   _set_x_nodes(_xn);
   _set_y_nodes(_yn, NULL, NULL);

   if (_type & PowerLaw) _set_spectral_indices(_gb, _ge, 0, 0, 0, 0);
   else _set_derivatives(_b1, _e1);

   if (_type & AMS15) _set_ams15_boundary_conditions();
}

Double_t Spline::operator()(Double_t *x, Double_t *par)
{
   Double_t f = ((*this).*(_call_spline[_is_powerlaw][_log_type]))(x, par);
   if (_type & Rescaled) f /= pow(x[0], _gamma);

   return f;
}

Double_t Spline::Eval(Double_t x)
{
   return (*this)(&x, _func->GetParameters());
}

void Spline::SetXNodes(Double_t *xn)
{
   if (xn != NULL)
   {
      _set_x_nodes(xn);

      if (_type & AMS15) _set_ams15_boundary_conditions();
   }
}
void Spline::SetYNodes(Double_t *yn, Double_t *yn_min, Double_t *yn_max)
{
   if (yn != NULL)
   {
      _set_y_nodes(yn, yn_min, yn_max);

      if (_type & AMS15) _set_ams15_boundary_conditions();
   }
}
void Spline::SetNodes(Double_t *xn, Double_t *yn, Double_t *yn_min, Double_t *yn_max)
{
   if (xn != NULL) _set_x_nodes(xn);
   if (yn != NULL) _set_y_nodes(yn, yn_min, yn_max);

   if ((xn != NULL || yn != NULL) && (_type & AMS15)) _set_ams15_boundary_conditions();
}
void Spline::NormalizeNodes()
{
   for (UShort_t inode = 0; inode < _nnodes; ++inode)
   {
      _xn[inode] = _func->GetParameter(2 + inode);
      _yn[inode] = _func->GetParameter(2 + _nnodes + inode);
   }
}

void Spline::SetFirstDerivative(Double_t b1)
{
   _set_first_derivative(b1);
}
void Spline::SetLastDerivative(Double_t e1)
{
   if (_type & AMS15) cerr << FG_RED << " !!! Spline type is AMS15: cannot set last derivative" << RESET << endl;
   else _set_last_derivative(e1);
}
void Spline::SetDerivatives(Double_t b1, Double_t e1)
{
   SetFirstDerivative(b1);
   SetLastDerivative(e1);
}

void Spline::SetFirstSpectralIndex(Double_t gb, Double_t gbmin, Double_t gbmax)
{
   _set_first_spectral_index(gb, gbmin, gbmax);
}
void Spline::SetLastSpectralIndex(Double_t ge, Double_t gemin, Double_t gemax)
{
   if (_type & AMS15) cerr << FG_RED << " !!! Spline type is AMS15: cannot set last spectral index" << RESET << endl;
   else _set_last_spectral_index(ge, gemin, gemax);
}
void Spline::SetSpectralIndices(Double_t gb, Double_t ge, Double_t gbmin, Double_t gbmax, Double_t gemin, Double_t gemax)
{
   SetFirstSpectralIndex(gb, gbmin, gbmax);
   SetLastSpectralIndex(ge, gemin, gemax);
}

void Spline::SetRescalingGamma(Double_t gamma)
{
   _type |= Rescaled;
   _gamma = gamma;
}

void Spline::SetAMS15Parameters(Double_t *par)
{
   _set_ams15_parameters(par);
   _set_ams15_boundary_conditions();
}

void Spline::GetNodesFromHistogram(TH1 *hist, UShort_t nnodes, Double_t *&xn, Double_t *&yn, Int_t &first_bin, Int_t &last_bin, UShort_t type)
{
   Int_t nbins = hist->GetNbinsX();
   if (first_bin < 0) first_bin = 1;
   if (last_bin < 0)  last_bin  = nbins;
   first_bin = TMath::Max(first_bin, hist->FindFirstBinAbove(0));
   last_bin  = TMath::Min(last_bin, hist->FindLastBinAbove(0));
   Double_t x1 = 0.5*(hist->GetXaxis()->GetBinCenterLog(first_bin) + hist->GetXaxis()->GetBinCenterLog(first_bin + 1));
   Double_t xN = 0.5*(hist->GetXaxis()->GetBinCenterLog(last_bin - 1) + hist->GetXaxis()->GetBinCenterLog(last_bin));

   for (UShort_t inode = 0; inode < nnodes; ++inode)
   {
      if (type & LogX)
      {
         xn[inode] = x1 * pow(xN/x1, inode/Double_t(nnodes-1)); // nodes uniform in log(x)
      }
      else
      {
         xn[inode] = x1 + inode/Double_t(nnodes-1)*(xN-x1); // nodes uniform in linear(x)
      }
      yn[inode] = hist->GetBinContent(hist->FindBin(xn[inode]));
   }
}

Spline *Spline::BuildFromHistogram(TH1 *hist, const Char_t *name, UShort_t nnodes, UShort_t type, Double_t b1, Double_t e1, Int_t first_bin, Int_t last_bin)
{
   Int_t nbins = hist->GetNbinsX();

   Double_t *xn = new Double_t[nnodes];
   Double_t *yn = new Double_t[nnodes];
   GetNodesFromHistogram(hist, nnodes, xn, yn, first_bin, last_bin, type);

   if (TMath::IsNaN(b1))
   {
      UInt_t bin = TMath::Max(1, hist->FindBin(xn[0]));
      b1 = (hist->GetBinContent(bin + 1) - hist->GetBinContent(bin)) / (hist->GetXaxis()->GetBinCenterLog(bin + 1) - hist->GetXaxis()->GetBinCenterLog(bin));
      if (type & PowerLaw || type & AMS15) b1 = b1 * xn[0] / yn[0]; // transform derivative in spectral index
   }
   if (TMath::IsNaN(e1))
   {
      UInt_t bin = TMath::Min(nbins, hist->FindBin(xn[nnodes - 1]));
      e1 = (hist->GetBinContent(bin) - hist->GetBinContent(bin-1)) / (hist->GetXaxis()->GetBinCenterLog(bin) - hist->GetXaxis()->GetBinCenterLog(bin-1));
      if (type & PowerLaw) e1 = e1 * xn[nnodes-1] / yn[nnodes-1]; // transform derivative in spectral index
   }

   Spline *spline = new Spline(name, nnodes, type, xn, yn, b1, e1);
   spline->_hist = hist;

   TF1 *func = spline->GetTF1Pointer();
   func->SetRange(hist->GetBinLowEdge(first_bin), hist->GetBinLowEdge(last_bin + 1));

   delete[] xn;
   delete[] yn;

   return spline;
}

void Spline::GetNodesFromGraph(TGraph *graph, UShort_t nnodes, Double_t *&xn, Double_t *&yn, Int_t &first_bin, Int_t &last_bin, UShort_t type)
{
   Int_t nbins = graph->GetN();

   if (first_bin < 0) first_bin = 0;
   if (last_bin < 0)  last_bin  = nbins-1;

   Int_t i;
   for (i = 0; i < nbins; ++i)
   {
      if (graph->GetX()[i] > 0) break;
   }
   first_bin = TMath::Max(first_bin, i);

   for (i = nbins - 1; i >= 0; --i)
   {
      if (graph->GetX()[i] > 0) break;
   }
   last_bin  = TMath::Min(last_bin, i);

   Double_t x1 = 0.5*(graph->GetX()[first_bin] + graph->GetX()[first_bin + 1]);
   Double_t xN = 0.5*(graph->GetX()[last_bin - 1] + graph->GetX()[last_bin]);

   for (UShort_t inode = 0; inode < nnodes; ++inode)
   {
      if (type & LogX)
      {
         xn[inode] = x1 * pow(xN/x1, inode/Double_t(nnodes-1)); // nodes uniform in log(x)
      }
      else
      {
         xn[inode] = x1 + inode/Double_t(nnodes-1)*(xN-x1); // nodes uniform in linear(x)
      }
      yn[inode] = graph->Eval(xn[inode]);
   }
}

Spline *Spline::BuildFromGraph(TGraph *graph, const Char_t *name, UShort_t nnodes, UShort_t type, Double_t b1, Double_t e1, Int_t first_bin, Int_t last_bin)
{
   Int_t nbins = graph->GetN();

   Double_t *xn = new Double_t[nnodes];
   Double_t *yn = new Double_t[nnodes];
   GetNodesFromGraph(graph, nnodes, xn, yn, first_bin, last_bin, type);

   if (TMath::IsNaN(b1))
   {
      Int_t i;
      for (i = 0; i < nbins; ++i)
      {
         if (graph->GetX()[i] > xn[0]) break;
      }
      UInt_t bin = TMath::Max(0, i-1);
      b1 = (graph->GetY()[bin + 1] - graph->GetY()[bin]) / (graph->GetX()[bin + 1] - graph->GetX()[bin]);
      if (type & PowerLaw || type & AMS15) b1 = b1 * xn[0] / yn[0]; // transform derivative in spectral index
   }
   if (TMath::IsNaN(e1))
   {
      Int_t i;
      for (i = nbins-1; i >= 0; --i)
      {
         if (graph->GetX()[i] < xn[nnodes-1]) break;
      }
      UInt_t bin = TMath::Min(nbins-1, i+1);
      e1 = (graph->GetY()[bin] - graph->GetY()[bin-1]) / (graph->GetX()[bin] - graph->GetX()[bin-1]);
      if (type & PowerLaw) e1 = e1 * xn[nnodes-1] / yn[nnodes-1]; // transform derivative in spectral index
   }

   Spline *spline = new Spline(name, nnodes, type, xn, yn, b1, e1);
   spline->_graph = graph;

   TF1 *func = spline->GetTF1Pointer();
   func->SetRange(graph->GetX()[first_bin], graph->GetX()[last_bin + 1]);

   delete[] xn;
   delete[] yn;

   return spline;
}

TSpline3 *Spline::GetSpline()
{
   // update internal variables
   Eval(0);

   TSpline3 *sp3 = new TSpline3("sp3", _xn, _yn, _nnodes, "b1e1", _b1, _e1);

   return sp3;
}

TF1 *Spline::GetFirstPowerLaw()
{
   if (_first_powerlaw == NULL)
   {
      _first_powerlaw = new TF1(Form("%s_fpl", _func->GetName()), "[0]*pow(x,[1])");
      _first_powerlaw->SetNpx(1000);
      Double_t x1, x2;
      _func->GetRange(x1, x2);
      _first_powerlaw->SetRange(x1, x2);
   }
   _first_powerlaw->SetParameters(_A, _gb);

   return _first_powerlaw;
}
TF1 *Spline::GetLastPowerLaw()
{
   if (_last_powerlaw == NULL)
   {
      _last_powerlaw = new TF1(Form("%s_lpl", _func->GetName()), "[0]*pow(x,[1])");
      _last_powerlaw->SetNpx(1000);
      Double_t x1, x2;
      _func->GetRange(x1, x2);
      _last_powerlaw->SetRange(x1, x2);
   }
   _last_powerlaw->SetParameters(_B, _ge);

   return _last_powerlaw;
}

void Spline::Print()
{
   cout << Form("[%p] Type = ", this);
   if (_type == 0) cout << "Normal";
   else
   {
      Bool_t pipe = false;
      const Char_t *name[5] = { "LogX", "LogY", "PowerLaw", "Rescaled", "AMS15" };
      for (UShort_t itype = 0; itype < 5; ++itype)
      {
         if (_type & (1 << itype))
         {
            if (pipe) cout << "|";
            cout << name[itype];
            if ((1 << itype) == Spline::Rescaled) cout << Form("(%.2f)", _gamma);
            pipe = true;
         }
      }
   }
   cout << Form("; %u nodes = {", _nnodes);
   for (UShort_t inode = 0; inode < _nnodes; ++inode)
   {
      if (inode > 0) cout << ",";
      cout << Form(" { %.3f, %.6f }", _xn[inode], _yn[inode]);
   }
   cout << " }\n";

   TF1 *f = _func;
   if (f == NULL) return;
   Double_t x1, x2;
   f->GetRange(x1, x2);
   cout << Form("   [%p] %s : %s; Npar=%2u; Ndim=%u; Range=(%+12.6g,%+12.6g)\n", f, f->GetName(), f->GetTitle(), f->GetNpar(), f->GetNdim(), x1, x2);
   cout << Form("       Nfitpoints=%3u, Nfreepar=%2u; NDF=%3u, Chi2=%12.6e, Prob=%12.6e\n", f->GetNumberFitPoints(), f->GetNumberFreeParameters(), f->GetNDF(), f->GetChisquare(), f->GetProb());
   for (UShort_t ipar = 0; ipar < f->GetNpar(); ++ipar)
   {
      Double_t pl, ph;
      f->GetParLimits(ipar, pl, ph);
      Bool_t fixed = pl*ph != 0. && pl >= ph;
      Bool_t bound = pl < ph;
      cout << Form("        Par %2u\t%15s = %25s %s\n", ipar, f->GetParName(ipar),
         (fixed || f->GetParError(ipar) == 0.) ? Form("%.6f", f->GetParameter(ipar)) : Form("%.6f +/- %.6f", f->GetParameter(ipar), f->GetParError(ipar)),
         fixed ? "" : (bound ? Form("[%.6f, %.6f]", pl, ph) : "[-inf, +inf]"));
   }
}

void Spline::_update_type()
{
   if ((_type & PowerLaw) && (_type & AMS15))
   {
      cerr << FG_RED << " !!! Spline type cannot be PowerLaw and AMS15 at the same time: removing PowerLaw" << RESET << endl;
      _type &= ~PowerLaw;
   }

   _is_powerlaw = (_type & PowerLaw) ? 1 : ((_type & AMS15) ? 2 : 0);
   _log_type    = _type & LogLog;
}

Double_t Spline::_spline(Double_t *x, Double_t *par)
{
   /*
   Parameters:
      par[0,1] = { b1, e1 } = first derivative at first and last node
      par[2, ..., 2+_nnodes-1] = xn = X of nodes (fix)
      par[2+_nnodes, ..., 2+2*_nnodes-1] = yn = Y of nodes
   */

   _b1 = par[0];
   _e1 = par[1];

   for (UShort_t inode = 0; inode < _nnodes; ++inode)
   {
      _xn[inode] = par[2 + inode];
      _yn[inode] = par[2 + _nnodes + inode];
   }

   TSpline3 sp3("sp3", _xn, _yn, _nnodes, "b1e1", _b1, _e1);

   return sp3.Eval(x[0]);
}

Double_t Spline::_spline_logx(Double_t *x, Double_t *par)
{
   /*
   Parameters:
      par[0,1] = { b1, e1 } = first derivative at first and last node
      par[2, ..., 2+_nnodes-1] = xn = X of nodes (fix)
      par[2+_nnodes, ..., 2+2*_nnodes-1] = yn = Y of nodes
   */

   _b1 = par[0]*par[2];
   _e1 = par[1]*par[1+_nnodes];

   for (UShort_t inode = 0; inode < _nnodes; ++inode)
   {
      _xn[inode] = log(par[2 + inode]);
      _yn[inode] = par[2 + _nnodes + inode];
   }

   TSpline3 sp3("sp3", _xn, _yn, _nnodes, "b1e1", _b1, _e1);

   return sp3.Eval(log(x[0]));
}

Double_t Spline::_spline_logy(Double_t *x, Double_t *par)
{
   /*
   Parameters:
      par[0,1] = { b1, e1 } = first derivative at first and last node
      par[2, ..., 2+_nnodes-1] = xn = X of nodes (fix)
      par[2+_nnodes, ..., 2+2*_nnodes-1] = yn = Y of nodes
   */

   _b1 = par[0]/par[2+_nnodes];
   _e1 = par[1]/par[1+2*_nnodes];

   for (UShort_t inode = 0; inode < _nnodes; ++inode)
   {
      _xn[inode] = par[2 + inode];
      _yn[inode] = log(par[2 + _nnodes + inode]);
   }

   TSpline3 sp3("sp3", _xn, _yn, _nnodes, "b1e1", _b1, _e1);

   return exp(sp3.Eval(x[0]));
}

Double_t Spline::_spline_loglog(Double_t *x, Double_t *par)
{
   /*
   Parameters:
      par[0,1] = { b1, e1 } = first derivative at first and last node
      par[2, ..., 2+_nnodes-1] = xn = X of nodes (fix)
      par[2+_nnodes, ..., 2+2*_nnodes-1] = yn = Y of nodes
   */

   _b1 = par[0]*par[2]/par[2+_nnodes];
   _e1 = par[1]*par[1+_nnodes]/par[1+2*_nnodes];

   for (UShort_t inode = 0; inode < _nnodes; ++inode)
   {
      _xn[inode] = log(par[2 + inode]);
      _yn[inode] = log(par[2 + _nnodes + inode]);
   }

   TSpline3 sp3("sp3", _xn, _yn, _nnodes, "b1e1", _b1, _e1);

   return exp(sp3.Eval(log(x[0])));
}

Double_t Spline::_spline_powerlaw(Double_t *x, Double_t *par)
{
   /*
   Parameters:
      par[0,1] = { gb, ge } = spectral indices at first and last node
      par[2, ..., 2+_nnodes-1] = xn = X of nodes (fix)
      par[2+_nnodes, ..., 2+2*_nnodes-1] = yn = Y of nodes
   */

   _gb = par[0];
   _ge = par[1];

   for (UShort_t inode = 0; inode < _nnodes; ++inode)
   {
      _xn[inode] = par[2 + inode];
      _yn[inode] = par[2 + _nnodes + inode];
   }

   _b1 = _gb*_yn[0]/_xn[0];
   _e1 = _ge*_yn[_nnodes-1]/_xn[_nnodes-1];
   _A  = _yn[0]*pow(fabs(_xn[0]), -_gb);
   _B  = _yn[_nnodes-1]*pow(fabs(_xn[_nnodes-1]), -_ge);

   TSpline3 sp3("sp3", _xn, _yn, _nnodes, "b1e1", _b1, _e1);

   Double_t xx = x[0];

   return xx < _xn[0] ? _A*pow(fabs(xx), _gb) : (_xn[0] <= xx && xx < _xn[_nnodes-1] ? sp3.Eval(xx) : _B*pow(fabs(xx), _ge));
}

Double_t Spline::_spline_powerlaw_logx(Double_t *x, Double_t *par)
{
   /*
   Parameters:
      par[0,1] = { b1, e1 } = first derivative at first and last node
      par[2, ..., 2+_nnodes-1] = xn = X of nodes (fix)
      par[2+_nnodes, ..., 2+2*_nnodes-1] = yn = Y of nodes
   */

   _gb = par[0];
   _ge = par[1];

   for (UShort_t inode = 0; inode < _nnodes; ++inode)
   {
      _xn[inode] = log(par[2 + inode]);
      _yn[inode] = par[2 + _nnodes + inode];
   }

   _b1 = _gb*_yn[0];
   _e1 = _ge*_yn[_nnodes-1];
   _A  = _yn[0]*exp(-_gb*_xn[0]);
   _B  = _yn[_nnodes-1]*exp(-_ge*_xn[_nnodes-1]);

   TSpline3 sp3("sp3", _xn, _yn, _nnodes, "b1e1", _b1, _e1);

   Double_t lnx = log(x[0]);

   return lnx < _xn[0] ? _A*exp(_gb*lnx) : (_xn[0] <= lnx && lnx < _xn[_nnodes-1] ? sp3.Eval(lnx) : _B*exp(_ge*lnx));
}

Double_t Spline::_spline_powerlaw_logy(Double_t *x, Double_t *par)
{
   /*
   Parameters:
      par[0,1] = { b1, e1 } = first derivative at first and last node
      par[2, ..., 2+_nnodes-1] = xn = X of nodes (fix)
      par[2+_nnodes, ..., 2+2*_nnodes-1] = yn = Y of nodes
   */

   _gb = par[0];
   _ge = par[1];

   for (UShort_t inode = 0; inode < _nnodes; ++inode)
   {
      _xn[inode] = par[2 + inode];
      _yn[inode] = log(par[2 + _nnodes + inode]);
   }

   _b1 = _gb/_xn[0];
   _e1 = _ge/_xn[_nnodes-1];
   _A  = par[2 + _nnodes]*pow(fabs(_xn[0]), -_gb);
   _B  = par[1 + 2*_nnodes]*pow(fabs(_xn[_nnodes-1]), -_ge);

   TSpline3 sp3("sp3", _xn, _yn, _nnodes, "b1e1", _b1, _e1);

   Double_t xx = x[0];

   return xx < _xn[0] ? _A*pow(fabs(xx), _gb) : (_xn[0] <= xx && xx < _xn[_nnodes-1] ? exp(sp3.Eval(xx)) : _B*pow(fabs(xx), _ge));
}

Double_t Spline::_spline_powerlaw_loglog(Double_t *x, Double_t *par)
{
   /*
   Parameters:
      par[0,1] = { b1, e1 } = first derivative at first and last node
      par[2, ..., 2+_nnodes-1] = xn = X of nodes (fix)
      par[2+_nnodes, ..., 2+2*_nnodes-1] = yn = Y of nodes
   */

   _gb = par[0];
   _ge = par[1];

   for (UShort_t inode = 0; inode < _nnodes; ++inode)
   {
      _xn[inode] = log(par[2 + inode]);
      _yn[inode] = log(par[2 + _nnodes + inode]);
   }

   _b1 = _gb;
   _e1 = _ge;
   _A  = par[2 + _nnodes]*exp(-_gb*_xn[0]);
   _B  = par[1 + 2*_nnodes]*exp(-_ge*_xn[_nnodes-1]);

   TSpline3 sp3("sp3", _xn, _yn, _nnodes, "b1e1", _b1, _e1);

   Double_t lnx = log(x[0]);

   return lnx < _xn[0] ? _A*exp(_gb*lnx) : (_xn[0] <= lnx && lnx < _xn[_nnodes-1] ? exp(sp3.Eval(lnx)) : _B*exp(_ge*lnx));
}

Double_t Spline::_spline_ams15(Double_t *x, Double_t *par)
{
   /*
   Parameters:
      par[0,1] = { gb, ge } = spectral indices at first and last node
      par[2, ..., 2+_nnodes-1] = xn = X of nodes (fix)
      par[2+_nnodes, ..., 2+2*_nnodes-1] = yn = Y of nodes
   */

   _gb = par[0];
   _e1 = par[1];

   for (UShort_t inode = 0; inode < _nnodes; ++inode)
   {
      _xn[inode] = par[2 + inode];
      _yn[inode] = par[2 + _nnodes + inode];
   }

   _A  = _yn[0]*pow(_xn[0], -_gb);
   _b1 = _gb*_yn[0]/_xn[0];

   TSpline3 sp3("sp3", _xn, _yn, _nnodes, "b1e1", _b1, _e1);

   Double_t xx = x[0];

   return xx < _xn[0] ? _A*pow(xx, _gb) : (_xn[0] <= xx && xx < _xn[_nnodes-1] ? sp3.Eval(xx) : _calc_ams15_flux(xx));
}

Double_t Spline::_spline_ams15_logx(Double_t *x, Double_t *par)
{
   /*
   Parameters:
      par[0,1] = { b1, e1 } = first derivative at first and last node
      par[2, ..., 2+_nnodes-1] = xn = X of nodes (fix)
      par[2+_nnodes, ..., 2+2*_nnodes-1] = yn = Y of nodes
   */

   _gb = par[0];
   _e1 = par[1]*par[1 + _nnodes];

   for (UShort_t inode = 0; inode < _nnodes; ++inode)
   {
      _xn[inode] = log(par[2 + inode]);
      _yn[inode] = par[2 + _nnodes + inode];
   }

   _b1 = _gb*_yn[0];
   _A  = _yn[0]*exp(-_gb*_xn[0]);

   TSpline3 sp3("sp3", _xn, _yn, _nnodes, "b1e1", _b1, _e1);

   Double_t lnx = log(x[0]);

   return lnx < _xn[0] ? _A*exp(_gb*lnx) : (_xn[0] <= lnx && lnx < _xn[_nnodes-1] ? sp3.Eval(lnx) : _calc_ams15_flux(x[0]));
}

Double_t Spline::_spline_ams15_logy(Double_t *x, Double_t *par)
{
   /*
   Parameters:
      par[0,1] = { b1, e1 } = first derivative at first and last node
      par[2, ..., 2+_nnodes-1] = xn = X of nodes (fix)
      par[2+_nnodes, ..., 2+2*_nnodes-1] = yn = Y of nodes
   */

   _gb = par[0];
   _e1 = par[1]/par[1 + 2*_nnodes];

   for (UShort_t inode = 0; inode < _nnodes; ++inode)
   {
      _xn[inode] = par[2 + inode];
      _yn[inode] = log(par[2 + _nnodes + inode]);
   }

   _b1 = _gb/_xn[0];
   _A  = par[2 + _nnodes]*pow(_xn[0], -_gb);

   TSpline3 sp3("sp3", _xn, _yn, _nnodes, "b1e1", _b1, _e1);

   Double_t xx = x[0];

   return xx < _xn[0] ? _A*pow(xx, _gb) : (_xn[0] <= xx && xx < _xn[_nnodes-1] ? exp(sp3.Eval(xx)) : _calc_ams15_flux(xx));
}

Double_t Spline::_spline_ams15_loglog(Double_t *x, Double_t *par)
{
   /*
   Parameters:
      par[0,1] = { b1, e1 } = first derivative at first and last node
      par[2, ..., 2+_nnodes-1] = xn = X of nodes (fix)
      par[2+_nnodes, ..., 2+2*_nnodes-1] = yn = Y of nodes
   */

   _gb = par[0];
   _e1 = par[1]*par[1 + _nnodes]/par[1 + 2*_nnodes];

   for (UShort_t inode = 0; inode < _nnodes; ++inode)
   {
      _xn[inode] = log(par[2 + inode]);
      _yn[inode] = log(par[2 + _nnodes + inode]);
   }

   _b1 = _gb;
   _A  = par[2 + _nnodes]*exp(-_gb*_xn[0]);

   TSpline3 sp3("sp3", _xn, _yn, _nnodes, "b1e1", _b1, _e1);

   Double_t lnx = log(x[0]);

   return lnx < _xn[0] ? _A*exp(_gb*lnx) : (_xn[0] <= lnx && lnx < _xn[_nnodes-1] ? exp(sp3.Eval(lnx)) : _calc_ams15_flux(x[0]));
}

Double_t Spline::_calc_ams15_flux(Double_t x)
{
   _ams15_flux = _ams15_pars[0] * TMath::Power(x, _ams15_pars[1]) * TMath::Power(1. + TMath::Power(x/_ams15_pars[2], _ams15_pars[3]/_ams15_pars[4]), _ams15_pars[4]);

   return _ams15_flux;
}

void Spline::_calc_ams15_deriv(Double_t x)
{
   Double_t y = TMath::Power(x/_ams15_pars[2], _ams15_pars[3]/_ams15_pars[4]);
   _ams15_deriv = _ams15_flux / x * (_ams15_pars[1] + _ams15_pars[3] * y/(1. + y));
}

// compute AMS15 flux and derivative at last node position and
// fix value of last node and its derivative
void Spline::_set_ams15_boundary_conditions()
{
   UShort_t inode = _nnodes - 1;

   Double_t x = _xn[_nnodes - 1];
   _calc_ams15_flux(x);
   _calc_ams15_deriv(x);

   _yn[inode] = _ams15_flux;
   _func->FixParameter(2 + _nnodes + inode, _yn[inode]);

   _e1 = _ams15_deriv;
   _func->FixParameter(1, _e1);
}

void Spline::_set_ams15_parameters(Double_t *par)
{
   for (UShort_t ipar = 0; ipar < 5; ++ipar) _ams15_pars[ipar] = par[ipar];
}

void Spline::_set_x_nodes(Double_t *xn)
{
   if (_xn != NULL && _xn != xn) delete[] _xn;
   if (_xn == NULL) _xn = new Double_t[_nnodes];
   Double_t *yn = (_hist != NULL || _graph != NULL) ? new Double_t[_nnodes] : NULL;
   
   if (xn == NULL) return;
   
   for (UShort_t inode = 0; inode < _nnodes; ++inode)
   {
      _xn[inode] = xn[inode];
      if (_hist != NULL) yn[inode] = _hist->GetBinContent(_hist->FindBin(_xn[inode]));
      else if (_graph != NULL) yn[inode] = _graph->Eval(_xn[inode]);

      _func->FixParameter(2 + inode, _xn[inode]);
   }
   if (yn != NULL)
   {
      _set_y_nodes(yn, NULL, NULL);
      delete[] yn;
   }

   _func->SetRange(_xn[0], _xn[_nnodes-1]);
}

void Spline::_set_y_nodes(Double_t *yn, Double_t *yn_min, Double_t *yn_max)
{
   if (_yn != NULL && _yn != yn) delete[] _yn;
   if (_yn == NULL) _yn = new Double_t[_nnodes];

   if (yn == NULL) return;

   for (UShort_t inode = 0; inode < _nnodes; ++inode)
   {
      _yn[inode] = yn[inode];

      _func->SetParameter(2 + _nnodes + inode, _yn[inode]);
      _func->SetParLimits(2 + _nnodes + inode, yn_min != NULL ? yn_min[inode] : _yn[inode] - 0.9*fabs(_yn[inode]), yn_max != NULL ? yn_max[inode] : _yn[inode] + 0.9*fabs(_yn[inode]));
   }
}

void Spline::_set_first_derivative(Double_t b1)
{
   _b1 = b1;
   _func->SetParameter(0, _b1);
}

void Spline::_set_last_derivative(Double_t e1)
{
   _e1 = e1;
   _func->SetParameter(1, _e1);
}

void Spline::_set_derivatives(Double_t b1, Double_t e1)
{
   _set_first_derivative(b1);
   _set_last_derivative(e1);
}

void Spline::_set_first_spectral_index(Double_t gb, Double_t gbmin, Double_t gbmax)
{
   if (!(_type & AMS15)) _type |= PowerLaw;
   _update_type();

   _gb = gb;
   _A  = _yn[0] * pow(_xn[0], -_gb);
   _b1 = _gb * _yn[0] / _xn[0];

   _func->SetParameter(0, _gb);
   if (gbmin != gbmax) _func->SetParLimits(0, gbmin, gbmax);
}

void Spline::_set_last_spectral_index(Double_t ge, Double_t gemin, Double_t gemax)
{
   _type |= PowerLaw;
   _update_type();

   _ge = ge;
   _B  = _yn[_nnodes - 1] * pow(_xn[_nnodes - 1], -_ge);
   _e1 = _ge * _yn[_nnodes - 1] / _xn[_nnodes - 1];

   _func->SetParameter(1, _ge);
    if (gemin != gemax) _func->SetParLimits(1, gemin, gemax);
}

void Spline::_set_spectral_indices(Double_t gb, Double_t ge, Double_t gbmin, Double_t gbmax, Double_t gemin, Double_t gemax)
{
   _set_first_spectral_index(gb, gbmin, gbmax);
   _set_last_spectral_index(ge, gemin, gemax);
}
