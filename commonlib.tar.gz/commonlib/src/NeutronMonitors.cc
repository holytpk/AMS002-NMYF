#include "NeutronMonitors.hh"
#include "DateTimeTools.hh"

/// =====================================
/// BEGIN NeutronMonitors::YieldFunctions
/// =====================================

namespace NMYF = NeutronMonitors::YieldFunctions;

Double_t NMYF::Models::Koldobskiy19Parametrization(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy)
{
   // ln(Y) = aX^3 + bX^2 + cX + d, in 3 different ranges of kinetic energy per nucleon
   // X = 0.5*ln(T^2 + 1.876*T) = ln(p/A); p = momentum, A = mass number
   // NB: [Y] = (m^2 sr)/nucleon in Koldobskiy et al (2019), so it must be multiplied by the mass number
   // [Ei] = GeV/n
   // [ai] = [bi] = [ci] = [di] = unitless

   Double_t Tn1 = par[0];
   Double_t Tn2 = par[1];
   // ai = par[2 + (i-1)*4]
   // bi = par[3 + (i-1)*4]
   // ci = par[4 + (i-1)*4]
   // di = par[5 + (i-1)*4]

   Double_t Tn = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::KINETICPERNUCLEON);

   Double_t lnpn  = 0.5*log(Tn*Tn + 1.876*Tn);
   UShort_t shift = 2 + (Tn/Tn1 > 1.)*4 + (Tn/Tn2 > 1)*4;
   Double_t lnY   = par[shift]*lnpn*lnpn*lnpn + par[shift+1]*lnpn*lnpn + par[shift+2]*lnpn + par[shift+3];

   return exp(lnY)*Particle::A[particle];
}

Double_t NMYF::Models::CaballeroLopezMoraal12HParametrization(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy)
{
   // Double power law
   // Y(p) = R^g2*(R0^a+R^a)^((g1-g2)/a)
   // [R0] = GV
   // [a] = [g1] = [g2] = unitless

   Double_t R0 = par[0];
   Double_t a  = par[1];
   Double_t g1 = par[2];
   Double_t g2 = par[3];

   Double_t R = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::RIGIDITY);

   Double_t Y = pow(R, g2)*pow(pow(R0, a)+pow(R, a), (g1-g2)/a);

   return Y;
}

Double_t NMYF::Models::CaballeroLopezMoraal12HeParametrization(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy)
{
   // Product of two double power laws
   // Y(He) = Y(p) * R^g2*(R0^a+R^a)^((g1-g2)/a)
   // NB:
   // [R0] = GV
   // [a] = [g1] = [g2] = unitless

   Double_t R0p  = par[0];
   Double_t ap   = par[1];
   Double_t g1p  = par[2];
   Double_t g2p  = par[3];
   Double_t R0He = par[4];
   Double_t aHe  = par[5];
   Double_t g1He = par[6];
   Double_t g2He = par[7];

   Double_t R = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::RIGIDITY);

   Double_t Y = pow(R, g2p)*pow(pow(R0p, ap)+pow(R, ap), (g1p-g2p)/ap) * pow(R, g2He)*pow(pow(R0He, aHe)+pow(R, aHe), (g1He-g2He)/aHe);

   return Y;
}

Double_t NMYF::FittingModel(Double_t *x, Double_t *par)
{
   /// parameters:
   ///    0  = NMYF::Type; fixed during fit
   ///    1  = Energy::Type; fixed during fit
   ///    2  = Particle::Type; fixed during fit
   ///    3  = N: yield function normalization [(m^2 sr)/particle]; free during fit
   ///    4- = parameters used by the YF formula; free during fit

   Double_t xx = x[0];

   NMYF::Type      yf_model = cast(par[0]);
   Energy::Type    energy   = Energy::cast(par[1]);
   Particle::Type  particle = Particle::cast(par[2]);

   Double_t N = par[3];

   return N * Info[yf_model].Model(xx, &par[4], particle, energy);
}

TF1 *NMYF::CreateFunction(const Char_t *name, Double_t min_ene, Double_t max_ene, NMYF::Type yf_model, Particle::Type particle, Energy::Type energy)
{
   TF1 *f_yf = new TF1(name, FittingModel, min_ene, max_ene, 4 + Info[yf_model].nParameters);

   f_yf->SetParName(0, "yf_model");
   f_yf->FixParameter(0, yf_model);

   f_yf->SetParName(1, "energytype");
   f_yf->FixParameter(1, energy);

   f_yf->SetParName(2, "particle");
   f_yf->FixParameter(2, particle);

   f_yf->SetParName(3, "norm");
   f_yf->SetParameter(3, Info[yf_model].Normalization);
   f_yf->SetParLimits(3, Info[yf_model].Normalization < 1. ? 0.01 : 5.,
      Info[yf_model].Normalization < 1. ? 1. : (Info[yf_model].Normalization < 1e4 ? 1e5 : (Info[yf_model].Normalization < 1e5 ? 1e5 : 1e6)));

   for (UShort_t ipar = 0; ipar < Info[yf_model].nParameters; ++ipar)
   {
      f_yf->SetParName(4 + ipar, Info[yf_model].Parameter[ipar].Name);
      f_yf->SetParameter(4 + ipar, Info[yf_model].Parameter[ipar].Med);
      f_yf->SetParLimits(4 + ipar, Info[yf_model].Parameter[ipar].Min, Info[yf_model].Parameter[ipar].Max);
   }

   return f_yf;
}

NMYF::Model::Model(const Char_t *name, Double_t min_ene, Double_t max_ene, NMYF::Type yf_model, Particle::Type particle, Energy::Type energy) :
   _yf_model(yf_model), _energy(energy), _particle(particle)
{
   _func = new TF1(name, this, min_ene, max_ene, Info[_yf_model].nParameters + 1);

   _func->SetParName(0, "norm");
   _func->SetParameter(0, Info[_yf_model].Normalization);
   _func->SetParLimits(0, Info[_yf_model].Normalization < 1. ? 0.01 : 5.,
      Info[_yf_model].Normalization < 1. ? 1. : (Info[_yf_model].Normalization < 1e4 ? 1e5 : (Info[_yf_model].Normalization < 1e5 ? 1e5 : 1e6)));

   for (UShort_t ipar = 0; ipar < Info[_yf_model].nParameters; ++ipar)
   {
      _func->SetParName(1 + ipar, Info[_yf_model].Parameter[ipar].Name);
      _func->SetParameter(1 + ipar, Info[_yf_model].Parameter[ipar].Med);
      _func->SetParLimits(1 + ipar, Info[_yf_model].Parameter[ipar].Min, Info[_yf_model].Parameter[ipar].Max);
   }

   _func->SetNpx(200);
}

Double_t NMYF::Model::operator()(Double_t *x, Double_t *par)
{
   /// parameters:
   ///    0     = N: yield function normalization [(m^2 sr)/particle]
   ///    1-end = parameters used by the YF formula

   Double_t xx = x[0];

   return par[0] * Info[_yf_model].Model(xx, &par[1], _particle, _energy);
}

TF1 *NMYF::Model::CreateFunction(const Char_t *name, Double_t min_ene, Double_t max_ene, NMYF::Type yf_model, Particle::Type particle, Energy::Type energy)
{
   Model *m = new Model(name, min_ene, max_ene, yf_model, particle, energy);
   return m->GetTF1Pointer();
}

/// ===================================
/// END NeutronMonitors::YieldFunctions
/// ===================================



/// ======================================
/// BEGIN NeutronMonitors::SolarModulation
/// ======================================

TGraphErrors *NeutronMonitors::SolarModulation::GetPhiGraph(UInt_t firstdate, UInt_t lastdate)
{
   TGraphErrors *g_phi = new TGraphErrors(nYears*12);
   g_phi->SetName("g_nm_phi");
   gROOT->Append(g_phi);

   UShort_t ipoint = 0;
   for (UInt_t iyear = 0; iyear < nYears; ++iyear)
   {
      for (UInt_t imonth = 0; imonth < 12; ++imonth)
      {
         UInt_t date1 = (FirstYear + iyear)*100 + imonth + 1;
         UInt_t date2 = imonth < 11 ? (FirstYear + iyear)*100 + imonth + 2 : (FirstYear + iyear + 1)*100 + 1;
         if (firstdate != 0 && date1 < firstdate) continue;
         if (lastdate != 0 && date2 > lastdate) break;

         time_t x1 = DateTimeTools::StringToUTCTime(Form("%d", date1), "%Y%m");
         time_t x2 = DateTimeTools::StringToUTCTime(Form("%d", date2), "%Y%m");

         Double_t x  = (x1 + x2) / 2.;
         Double_t dx = (x2 - x1) / 2.;

         g_phi->SetPoint(ipoint, x, Parameter[iyear][imonth]*1e-3);
         g_phi->SetPointError(ipoint, dx, ParameterUncertainty[iyear][imonth]*1e-3);

         ++ipoint;
      }
   }
   g_phi->Set(ipoint);

   return g_phi;
}

/// ====================================
/// END NeutronMonitors::SolarModulation
/// ====================================
