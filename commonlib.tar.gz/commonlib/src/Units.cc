#include "Units.hh"
#include "debug.hh"

const UShort_t _STR_LENGTH = 128;

static Double_t kin2rig(Double_t T, Double_t M, Double_t Z, Double_t A)
{
   return TMath::Sqrt(T * (T + 2*M)) / Z;
}
static Double_t kin2mom(Double_t T, Double_t M, Double_t Z, Double_t A)
{
   return TMath::Sqrt(T * (T + 2*M));
}
static Double_t kin2tot(Double_t T, Double_t M, Double_t Z, Double_t A)
{
   return T + M;
}
static Double_t kin2nuc(Double_t T, Double_t M, Double_t Z, Double_t A)
{
   return T/A;
}

static Double_t rig2kin(Double_t R, Double_t M, Double_t Z, Double_t A)
{
   return TMath::Sqrt(R*Z*R*Z + M*M) - M;
}
static Double_t rig2mom(Double_t R, Double_t M, Double_t Z, Double_t A)
{
   return R*Z;
}
static Double_t rig2tot(Double_t R, Double_t M, Double_t Z, Double_t A)
{
   return TMath::Sqrt(R*R*Z*Z + M*M);
}
static Double_t rig2nuc(Double_t R, Double_t M, Double_t Z, Double_t A)
{
   return (TMath::Sqrt(R*R*Z*Z + M*M) - M) / A;
}

static Double_t mom2rig(Double_t P, Double_t M, Double_t Z, Double_t A)
{
   return P/Z;
}
static Double_t mom2kin(Double_t P, Double_t M, Double_t Z, Double_t A)
{
   return TMath::Sqrt(P*P + M*M) - M;
}
static Double_t mom2tot(Double_t P, Double_t M, Double_t Z, Double_t A)
{
   return TMath::Sqrt(P*P + M*M);
}
static Double_t mom2nuc(Double_t P, Double_t M, Double_t Z, Double_t A)
{
   return (TMath::Sqrt(P*P + M*M) - M) / A;
}

static Double_t tot2rig(Double_t E, Double_t M, Double_t Z, Double_t A)
{
   return TMath::Sqrt(E*E - M*M) / Z;
}
static Double_t tot2mom(Double_t E, Double_t M, Double_t Z, Double_t A)
{
   return TMath::Sqrt(E*E - M*M);
}
static Double_t tot2kin(Double_t E, Double_t M, Double_t Z, Double_t A)
{
   return E - M;
}
static Double_t tot2nuc(Double_t E, Double_t M, Double_t Z, Double_t A)
{
   return (E - M) / A;
}

static Double_t nuc2rig(Double_t Tn, Double_t M, Double_t Z, Double_t A)
{
   return TMath::Sqrt(Tn*A * (Tn*A + 2*M)) /Z;
}
static Double_t nuc2mom(Double_t Tn, Double_t M, Double_t Z, Double_t A)
{
   return TMath::Sqrt(Tn*A * (Tn*A + 2*M));
}
static Double_t nuc2tot(Double_t Tn, Double_t M, Double_t Z, Double_t A)
{
   return Tn*A + M;
}
static Double_t nuc2kin(Double_t Tn, Double_t M, Double_t Z, Double_t A)
{
   return Tn*A;
}

typedef Double_t (ene_conv_func)(Double_t, Double_t, Double_t, Double_t);
static const ene_conv_func *convert_energy[Energy::nENERGYs][Energy::nENERGYs] = {
   { NULL,    nuc2mom, nuc2kin, nuc2rig, nuc2tot },
   { mom2nuc, NULL,    mom2kin, mom2rig, mom2tot },
   { kin2nuc, kin2mom, NULL,    kin2rig, kin2tot },
   { rig2nuc, rig2mom, rig2kin, NULL,    rig2tot },
   { tot2nuc, tot2mom, tot2kin, tot2rig, NULL }
};

static Double_t kin2rig_jacobian(Double_t T, Double_t M, Double_t Z, Double_t A)
{
   return Z * TMath::Sqrt(T * (T + 2*M)) / (T + M);
}
static Double_t kin2mom_jacobian(Double_t T, Double_t M, Double_t Z, Double_t A)
{
   return TMath::Sqrt(T * (T + 2*M)) / (T + M);
}
static Double_t kin2tot_jacobian(Double_t T, Double_t M, Double_t Z, Double_t A)
{
   return 1.;
}
static Double_t kin2nuc_jacobian(Double_t T, Double_t M, Double_t Z, Double_t A)
{
   return A;
}

static Double_t rig2kin_jacobian(Double_t R, Double_t M, Double_t Z, Double_t A)
{
   return TMath::Sqrt(R*Z*R*Z + M*M) / (R*Z*Z);
}
static Double_t rig2mom_jacobian(Double_t R, Double_t M, Double_t Z, Double_t A)
{
   return 1/Z;
}
static Double_t rig2tot_jacobian(Double_t R, Double_t M, Double_t Z, Double_t A)
{
   return TMath::Sqrt(R*Z*R*Z + M*M) / (R*Z*Z);
}
static Double_t rig2nuc_jacobian(Double_t R, Double_t M, Double_t Z, Double_t A)
{
   return A/Z * TMath::Sqrt(R*Z*R*Z + M*M) / (R*Z);
}

static Double_t mom2rig_jacobian(Double_t P, Double_t M, Double_t Z, Double_t A)
{
   return Z;
}
static Double_t mom2kin_jacobian(Double_t P, Double_t M, Double_t Z, Double_t A)
{
   return TMath::Sqrt(P*P + M*M) / P;
}
static Double_t mom2tot_jacobian(Double_t P, Double_t M, Double_t Z, Double_t A)
{
   return TMath::Sqrt(P*P + M*M) / P;
}
static Double_t mom2nuc_jacobian(Double_t P, Double_t M, Double_t Z, Double_t A)
{
   return A * TMath::Sqrt(P*P + M*M) / P;
}

static Double_t tot2rig_jacobian(Double_t E, Double_t M, Double_t Z, Double_t A)
{
   return Z * E / TMath::Sqrt(E*E - M*M);
}
static Double_t tot2mom_jacobian(Double_t E, Double_t M, Double_t Z, Double_t A)
{
   return E / TMath::Sqrt(E*E - M*M);
}
static Double_t tot2kin_jacobian(Double_t E, Double_t M, Double_t Z, Double_t A)
{
   return 1.;
}
static Double_t tot2nuc_jacobian(Double_t E, Double_t M, Double_t Z, Double_t A)
{
   return A;
}

static Double_t nuc2rig_jacobian(Double_t Tn, Double_t M, Double_t Z, Double_t A)
{
   return Z/A * TMath::Sqrt(Tn*A * (Tn*A + 2*M)) / (Tn*A + M);
}
static Double_t nuc2mom_jacobian(Double_t Tn, Double_t M, Double_t Z, Double_t A)
{
   return 1./A * TMath::Sqrt(Tn*A * (Tn*A + 2*M)) / (Tn*A + M);
}
static Double_t nuc2tot_jacobian(Double_t Tn, Double_t M, Double_t Z, Double_t A)
{
   return 1./A;
}
static Double_t nuc2kin_jacobian(Double_t Tn, Double_t M, Double_t Z, Double_t A)
{
   return 1./A;
}

typedef Double_t (ene_jacobian_conv_func)(Double_t, Double_t, Double_t, Double_t);
static const ene_jacobian_conv_func *convert_energy_jacobian[Energy::nENERGYs][Energy::nENERGYs] = {
   { NULL,             nuc2mom_jacobian, nuc2kin_jacobian, nuc2rig_jacobian, nuc2tot_jacobian },
   { mom2nuc_jacobian, NULL,             mom2kin_jacobian, mom2rig_jacobian, mom2tot_jacobian },
   { kin2nuc_jacobian, kin2mom_jacobian, NULL,             kin2rig_jacobian, kin2tot_jacobian },
   { rig2nuc_jacobian, rig2mom_jacobian, rig2kin_jacobian, NULL,             rig2tot_jacobian },
   { tot2nuc_jacobian, tot2mom_jacobian, tot2kin_jacobian, tot2rig_jacobian, NULL }
};

static Double_t kin2beta(Double_t T, Double_t M, Double_t Z, Double_t A)
{
   return TMath::Sqrt(T*(T + 2*M)) / (T + M);
}
static Double_t rig2beta(Double_t R, Double_t M, Double_t Z, Double_t A)
{
   return R*Z / TMath::Sqrt(R*Z*R*Z + M*M);
}
static Double_t mom2beta(Double_t P, Double_t M, Double_t Z, Double_t A)
{
   return P / TMath::Sqrt(P*P + M*M);
}
static Double_t tot2beta(Double_t E, Double_t M, Double_t Z, Double_t A)
{
   return TMath::Sqrt(E*E - M*M) / E;
}
static Double_t nuc2beta(Double_t Tn, Double_t M, Double_t Z, Double_t A)
{
   return TMath::Sqrt(Tn*A*(Tn*A + 2*M)) / (Tn*A + M);
}

typedef Double_t (beta_conv_func)(Double_t, Double_t, Double_t, Double_t);
static const beta_conv_func *convert_beta[Energy::nENERGYs] = { nuc2beta, mom2beta, kin2beta, rig2beta, tot2beta };

static Double_t kin2gamma(Double_t T, Double_t M, Double_t Z, Double_t A)
{
   return (T + M) / M;
}
static Double_t rig2gamma(Double_t R, Double_t M, Double_t Z, Double_t A)
{
   return TMath::Sqrt(R*Z*R*Z + M*M) / M;
}
static Double_t mom2gamma(Double_t P, Double_t M, Double_t Z, Double_t A)
{
   return TMath::Sqrt(P*P + M*M) / M;
}
static Double_t tot2gamma(Double_t E, Double_t M, Double_t Z, Double_t A)
{
   return E / M;
}
static Double_t nuc2gamma(Double_t Tn, Double_t M, Double_t Z, Double_t A)
{
   return (Tn*A + M) / M;
}

typedef Double_t (gamma_conv_func)(Double_t, Double_t, Double_t, Double_t);
static const gamma_conv_func *convert_gamma[Energy::nENERGYs] = { nuc2gamma, mom2gamma, kin2gamma, rig2gamma, tot2gamma };

Energy::Type Energy::FromName(const Char_t *name)
{
   Type energy = nENERGYs;
   size_t len = strlen(name);

   for (UShort_t iene = 0; iene < nENERGYs; ++iene)
   {
      if (!strncmp(name, Name[iene], len))
      {
         energy = cast(iene);
         break;
      }
   }

   return energy;
}

Energy::Type Energy::FromTitle(const Char_t *title)
{
   Type energy = nENERGYs;
   size_t len = strlen(title);

   for (UShort_t iene = 0; iene < nENERGYs; ++iene)
   {
      if (!strncmp(title, Title[iene], len))
      {
         energy = cast(iene);
         break;
      }
   }

   return energy;
}

Energy::Type Energy::FromTitleShort(const Char_t *title)
{
   Type energy = nENERGYs;
   size_t len = strlen(title);

   for (UShort_t iene = 0; iene < nENERGYs; ++iene)
   {
      if (!strncmp(title, TitleShort[iene], len))
      {
         energy = cast(iene);
         break;
      }
   }

   return energy;
}

Energy::Type Energy::FromUnitName(const Char_t *unit)
{
   Type energy = nENERGYs;
   size_t len = strlen(unit);

   for (UShort_t iene = 0; iene < nENERGYs; ++iene)
   {
      if (!strncmp(unit, UnitName[iene], len))
      {
         energy = cast(iene);
         break;
      }
   }

   return energy;
}

Energy::Type Energy::FromSymbol(const Char_t *symbol)
{
   Type energy = nENERGYs;
   size_t len = strlen(symbol);

   for (UShort_t iene = 0; iene < nENERGYs; ++iene)
   {
      if (!strncmp(symbol, Symbol[iene], len))
      {
         energy = cast(iene);
         break;
      }
   }

   return energy;
}

Particle::Type Particle::FromName(const Char_t *name)
{
   Type particle = nPARTICLEs;
   size_t len = strlen(name);

   for (UShort_t ipart = 0; ipart < nPARTICLEs; ++ipart)
   {
      if (!strncmp(name, Name[ipart], len))
      {
         particle = cast(ipart);
         break;
      }
   }

   return particle;
}

Particle::Type Particle::FromSymbol(const Char_t *symbol)
{
   Type particle = nPARTICLEs;
   size_t len = strlen(symbol);

   for (UShort_t ipart = 0; ipart < nPARTICLEs; ++ipart)
   {
      if (!strncmp(symbol, Symbol[ipart], len))
      {
         particle = cast(ipart);
         break;
      }
   }

   return particle;
}

Particle::Type Particle::FromChargeMassNumber(Double_t Zel, Double_t Ael)
{
   Type particle = nPARTICLEs;

   for (UShort_t ipart = 0; ipart < nPARTICLEs; ++ipart)
   {
      if (Zel == Z[ipart] && Ael == A[ipart])
      {
         particle = cast(ipart);
         break;
      }
   }

   return particle;
}

//~ #ifndef HEP_SYSTEM_OF_UNITS_H
SIPrefix::Type SIPrefix::FromName(const Char_t *name)
{
   Type prefix = nPREFIXs;
   size_t len = strlen(name);

   for (UShort_t ipfx = 0; ipfx < nPREFIXs; ++ipfx)
   {
      if (!strncmp(name, Name[ipfx], len))
      {
         prefix = cast(ipfx);
         break;
      }
   }

   return prefix;
}

SIPrefix::Type SIPrefix::FromSymbol(const Char_t *symbol)
{
   Type prefix = nPREFIXs;
   size_t len = strlen(symbol);

   for (UShort_t ipfx = 0; ipfx < nPREFIXs; ++ipfx)
   {
      if (!strncmp(symbol, Symbol[ipfx], len))
      {
         prefix = cast(ipfx);
         break;
      }
   }

   return prefix;
}

Bool_t Unit::ParseEnergyUnit(const Char_t *energy_unit, Energy::Type &energy_type, SIPrefix::Type &energy_prefix)
{
   const Char_t *pos;

   energy_type = Energy::nENERGYs;
   for (UShort_t ienetype = 0; ienetype < Energy::nENERGYs; ++ienetype)
   {
      pos = strstr(energy_unit, Energy::UnitName[ienetype]);
      if (pos != NULL)
      {
         energy_type = Energy::cast(ienetype);
         break;
      }
   }
   if (energy_type == Energy::nENERGYs) return false;

   if (pos == energy_unit)
   {
      energy_prefix = SIPrefix::NONE;
   }
   else
   {
      energy_prefix = SIPrefix::nPREFIXs;
      for (UShort_t ipfx = 1; ipfx < SIPrefix::nPREFIXs; ++ipfx)
      {
         if (!strncmp(energy_unit, SIPrefix::Symbol[ipfx], pos - energy_unit))
         {
            energy_prefix = SIPrefix::cast(ipfx);
            break;
         }
      }
   }

   return energy_prefix != SIPrefix::nPREFIXs;
}

Bool_t Unit::ParseDifferentialFluxUnit(const Char_t *flux_unit, Energy::Type &flux_energy_type, SIPrefix::Type &flux_energy_prefix, SIPrefix::Type &flux_length_prefix)
{
   TString units(flux_unit);
   TString tok;
   Ssiz_t from = 0;
   flux_energy_type = Energy::nENERGYs;
   while (units.Tokenize(tok, from, " "))
   {
      if (tok.Length() == 0) continue;

      if (flux_energy_type == Energy::nENERGYs)
      {
         if (ParseEnergyUnit(tok.Data(), flux_energy_type, flux_energy_prefix)) continue;
      }
      else if (tok.Length() == 1)
      {
         flux_length_prefix = SIPrefix::NONE;
      }
      else
      {
         flux_length_prefix = SIPrefix::nPREFIXs;
         for (UShort_t ipfx = 1; ipfx < SIPrefix::nPREFIXs; ++ipfx)
         {
            tok.Remove(1);
            if (!strncmp(tok.Data(), SIPrefix::Symbol[ipfx], 2))
            {
               flux_length_prefix = SIPrefix::cast(ipfx);
               break;
            }
         }
      }
   }

   return (flux_energy_type != Energy::nENERGYs && flux_energy_prefix != SIPrefix::nPREFIXs && flux_length_prefix != SIPrefix::nPREFIXs);
}

Bool_t Unit::ParseIntegralFluxUnit(const Char_t *flux_unit, SIPrefix::Type &flux_length_prefix)
{
   size_t unit_len = strlen(flux_unit);
   if (unit_len == 1)
   {
      flux_length_prefix = SIPrefix::NONE;
   }
   else
   {
      flux_length_prefix = SIPrefix::nPREFIXs;
      for (UShort_t ipfx = 1; ipfx < SIPrefix::nPREFIXs; ++ipfx)
      {
         if (!strncmp(flux_unit, SIPrefix::Symbol[ipfx], unit_len - 1))
         {
            flux_length_prefix = SIPrefix::cast(ipfx);
            break;
         }
      }
   }

   return flux_length_prefix != SIPrefix::nPREFIXs;
}

Char_t *Unit::GetEnergyLabelNew(Energy::Type energy_type, SIPrefix::Type energy_prefix)
{
   size_t len = strlen(Energy::Title[energy_type]) + strlen(SIPrefix::Symbol[energy_prefix]) + strlen(Energy::UnitName[energy_type]) + 4;
   Char_t *label = new Char_t[len];
   snprintf(label, len, "%s [%s%s]", Energy::Title[energy_type], SIPrefix::Symbol[energy_prefix], Energy::UnitName[energy_type]);

   return label;
}
Char_t *Unit::GetEnergyLabelNew(const Char_t *energy_unit)
{
   Energy::Type enetype;
   SIPrefix::Type enepfx;
   if (!Unit::ParseEnergyUnit(energy_unit, enetype, enepfx)) return NULL;

   return GetEnergyLabelNew(enetype, enepfx);
}
const Char_t *Unit::GetEnergyLabel(Energy::Type energy_type, SIPrefix::Type energy_prefix)
{
   static Char_t label[_STR_LENGTH];
   snprintf(label, _STR_LENGTH, "%s [%s%s]", Energy::Title[energy_type], SIPrefix::Symbol[energy_prefix], Energy::UnitName[energy_type]);

   return label;
}
const Char_t *Unit::GetEnergyLabel(const Char_t *energy_unit)
{
   Energy::Type enetype;
   SIPrefix::Type enepfx;
   if (!Unit::ParseEnergyUnit(energy_unit, enetype, enepfx)) return NULL;

   return GetEnergyLabel(enetype, enepfx);
}

Char_t *Unit::GetDifferentialFluxLabelNew(Energy::Type flux_energy_type, SIPrefix::Type flux_energy_prefix, SIPrefix::Type flux_length_prefix)
{
   size_t len = strlen(SIPrefix::Symbol[flux_length_prefix]) + strlen(SIPrefix::Symbol[flux_energy_prefix]) + strlen(Energy::UnitName[flux_energy_type]) + 23;
   Char_t *label = new Char_t[len];
   snprintf(label, len, "Flux [1/(%sm^{2} sr s %s%s)]", SIPrefix::Symbol[flux_length_prefix], SIPrefix::Symbol[flux_energy_prefix], Energy::UnitName[flux_energy_type]);

   return label;
}
Char_t *Unit::GetDifferentialFluxLabelNew(const Char_t *flux_unit)
{
   Energy::Type fluxenetype;
   SIPrefix::Type fluxenepfx;
   SIPrefix::Type fluxlengthpfx;
   if (!Unit::ParseDifferentialFluxUnit(flux_unit, fluxenetype, fluxenepfx, fluxlengthpfx)) return NULL;

   return GetDifferentialFluxLabelNew(fluxenetype, fluxenepfx, fluxlengthpfx);
}
const Char_t *Unit::GetDifferentialFluxLabel(Energy::Type flux_energy_type, SIPrefix::Type flux_energy_prefix, SIPrefix::Type flux_length_prefix)
{
   static Char_t label[_STR_LENGTH];
   snprintf(label, _STR_LENGTH, "Flux [1/(%sm^{2} sr s %s%s)]", SIPrefix::Symbol[flux_length_prefix], SIPrefix::Symbol[flux_energy_prefix], Energy::UnitName[flux_energy_type]);

   return label;
}
const Char_t *Unit::GetDifferentialFluxLabel(const Char_t *flux_unit)
{
   Energy::Type fluxenetype;
   SIPrefix::Type fluxenepfx;
   SIPrefix::Type fluxlengthpfx;
   if (!Unit::ParseDifferentialFluxUnit(flux_unit, fluxenetype, fluxenepfx, fluxlengthpfx)) return NULL;

   return GetDifferentialFluxLabel(fluxenetype, fluxenepfx, fluxlengthpfx);
}

Char_t *Unit::GetIntegralFluxLabelNew(SIPrefix::Type flux_length_prefix)
{
   size_t len = strlen(SIPrefix::Symbol[flux_length_prefix]) + 22;
   Char_t *label = new Char_t[len];
   snprintf(label, len, "Flux [1/(%sm^{2} sr s)]", SIPrefix::Symbol[flux_length_prefix]);

   return label;
}
Char_t *Unit::GetIntegralFluxLabelNew(const Char_t *flux_unit)
{
   SIPrefix::Type fluxlengthpfx;
   if (!Unit::ParseIntegralFluxUnit(flux_unit, fluxlengthpfx)) return NULL;

   return GetIntegralFluxLabelNew(fluxlengthpfx);
}
const Char_t *Unit::GetIntegralFluxLabel(SIPrefix::Type flux_length_prefix)
{
   static Char_t label[_STR_LENGTH];
   snprintf(label, _STR_LENGTH, "Flux [1/(%sm^{2} sr s)]", SIPrefix::Symbol[flux_length_prefix]);

   return label;
}
const Char_t *Unit::GetIntegralFluxLabel(const Char_t *flux_unit)
{
   SIPrefix::Type fluxlengthpfx;
   if (!Unit::ParseIntegralFluxUnit(flux_unit, fluxlengthpfx)) return NULL;

   return GetIntegralFluxLabel(fluxlengthpfx);
}

Double_t Unit::ConvertEnergyType(Double_t energy, Particle::Type particle, Energy::Type from_energy_type, SIPrefix::Type from_energy_prefix, Energy::Type to_energy_type)
{
   if (from_energy_type != to_energy_type)
   {
      energy = convert_energy[from_energy_type][to_energy_type](energy, Particle::Mass[particle]*SIPrefix::BaseEnergyFactor/SIPrefix::Factor[from_energy_prefix], Particle::Z[particle], Particle::A[particle]);
   }

   return energy;
}
void Unit::ConvertEnergyType(Energy::Range range, Particle::Type particle, Energy::Type from_energy_type, SIPrefix::Type from_energy_prefix, Energy::Type to_energy_type)
{
   if (from_energy_type != to_energy_type)
   {
      range[0] = convert_energy[from_energy_type][to_energy_type](range[0], Particle::Mass[particle]*SIPrefix::BaseEnergyFactor/SIPrefix::Factor[from_energy_prefix], Particle::Z[particle], Particle::A[particle]);
      range[1] = convert_energy[from_energy_type][to_energy_type](range[1], Particle::Mass[particle]*SIPrefix::BaseEnergyFactor/SIPrefix::Factor[from_energy_prefix], Particle::Z[particle], Particle::A[particle]);
   }
}

Double_t Unit::EnergyJacobian(Double_t energy, Particle::Type particle, Energy::Type from_energy_type, SIPrefix::Type from_energy_prefix, Energy::Type to_energy_type)
{
   Double_t jacobian = 1.;
   if (from_energy_type != to_energy_type)
   {
      jacobian = convert_energy_jacobian[from_energy_type][to_energy_type](energy, Particle::Mass[particle]*SIPrefix::BaseEnergyFactor/SIPrefix::Factor[from_energy_prefix], Particle::Z[particle], Particle::A[particle]);
   }

   return jacobian;
}

Double_t Unit::Beta(Double_t energy, Particle::Type particle, Energy::Type energy_type, SIPrefix::Type energy_prefix)
{
   return convert_beta[energy_type](energy, Particle::Mass[particle]*SIPrefix::BaseEnergyFactor/SIPrefix::Factor[energy_prefix], Particle::Z[particle], Particle::A[particle]);
}
Double_t Unit::Beta(Double_t energy, Double_t A, Double_t Z, Energy::Type energy_type, SIPrefix::Type energy_prefix)
{
   return convert_beta[energy_type](energy, A*Particle::Mass[Particle::PROTON]*SIPrefix::BaseEnergyFactor/SIPrefix::Factor[energy_prefix], Z, A);
}

Double_t Unit::Beta(Double_t gamma)
{
   return TMath::Sqrt(1. - 1./(gamma*gamma));
}

Double_t Unit::Gamma(Double_t energy, Particle::Type particle, Energy::Type energy_type, SIPrefix::Type energy_prefix)
{
   return convert_gamma[energy_type](energy, Particle::Mass[particle]*SIPrefix::BaseEnergyFactor/SIPrefix::Factor[energy_prefix], Particle::Z[particle], Particle::A[particle]);
}

Double_t Unit::Gamma(Double_t beta)
{
   return 1./TMath::Sqrt(1. - beta*beta);
}

Double_t Unit::ConvertEnergy(Double_t energy, SIPrefix::Type from_energy_prefix, SIPrefix::Type to_energy_prefix)
{
   return energy / (SIPrefix::Factor[to_energy_prefix]/SIPrefix::Factor[from_energy_prefix]);
}
void Unit::ConvertEnergy(Energy::Range range, SIPrefix::Type from_energy_prefix, SIPrefix::Type to_energy_prefix)
{
   range[0] /= (SIPrefix::Factor[to_energy_prefix]/SIPrefix::Factor[from_energy_prefix]);
   range[1] /= (SIPrefix::Factor[to_energy_prefix]/SIPrefix::Factor[from_energy_prefix]);
}

Double_t Unit::ConvertEnergy(Double_t energy, const Char_t *from_energy_unit, const Char_t *to_energy_unit, Particle::Type particle)
{
   Energy::Type from_energy_type;
   SIPrefix::Type from_energy_prefix;
   if (!ParseEnergyUnit(from_energy_unit, from_energy_type, from_energy_prefix)) return -DBL_MAX;

   Energy::Type to_energy_type;
   SIPrefix::Type to_energy_prefix;
   if (!ParseEnergyUnit(to_energy_unit, to_energy_type, to_energy_prefix)) return -DBL_MAX;

   if (from_energy_type != to_energy_type) energy = Unit::ConvertEnergyType(energy, particle, from_energy_type, from_energy_prefix, to_energy_type);
   if (from_energy_prefix != to_energy_prefix) energy = Unit::ConvertEnergy(energy, from_energy_prefix, to_energy_prefix);

   return energy;
}
Bool_t Unit::ConvertEnergy(Energy::Range range, const Char_t *from_energy_unit, const Char_t *to_energy_unit, Particle::Type particle)
{
   Energy::Type from_energy_type;
   SIPrefix::Type from_energy_prefix;
   if (!ParseEnergyUnit(from_energy_unit, from_energy_type, from_energy_prefix)) return false;

   Energy::Type to_energy_type;
   SIPrefix::Type to_energy_prefix;
   if (!ParseEnergyUnit(to_energy_unit, to_energy_type, to_energy_prefix)) return false;

   if (from_energy_type != to_energy_type) Unit::ConvertEnergyType(range, particle, from_energy_type, from_energy_prefix, to_energy_type);
   if (from_energy_prefix != to_energy_prefix) Unit::ConvertEnergy(range, from_energy_prefix, to_energy_prefix);

   return true;
}

Double_t Unit::ConvertDifferentialFluxType(Double_t flux, Double_t energy, Particle::Type particle, Energy::Type from_energy_type, SIPrefix::Type from_energy_prefix, Energy::Type to_energy_type)
{
   if (from_energy_type != to_energy_type && energy > 0.)
   {
      flux *= convert_energy_jacobian[from_energy_type][to_energy_type](energy, Particle::Mass[particle]*SIPrefix::BaseEnergyFactor/SIPrefix::Factor[from_energy_prefix], Particle::Z[particle], Particle::A[particle]);
   }

   return flux;
}
Double_t Unit::ConvertDifferentialFluxType(Double_t flux, Energy::Range range, Particle::Type particle, Energy::Type from_energy_type, SIPrefix::Type from_energy_prefix, Energy::Type to_energy_type)
{
   if (from_energy_type != to_energy_type && range[1] > 0.)
   {
      Double_t new_range[2] = {
         convert_energy[from_energy_type][to_energy_type](range[0], Particle::Mass[particle]*SIPrefix::BaseEnergyFactor/SIPrefix::Factor[from_energy_prefix], Particle::Z[particle], Particle::A[particle]),
         convert_energy[from_energy_type][to_energy_type](range[1], Particle::Mass[particle]*SIPrefix::BaseEnergyFactor/SIPrefix::Factor[from_energy_prefix], Particle::Z[particle], Particle::A[particle])
      };
      flux *= (range[1] - range[0]) / (new_range[1] - new_range[0]);
   }

   return flux;
}

Double_t Unit::ConvertDifferentialFlux(Double_t flux, SIPrefix::Type from_flux_energy_prefix, SIPrefix::Type from_flux_length_prefix, SIPrefix::Type to_flux_energy_prefix, SIPrefix::Type to_flux_length_prefix)
{
   return flux * (SIPrefix::Factor[to_flux_energy_prefix]/SIPrefix::Factor[from_flux_energy_prefix]) *
      (SIPrefix::Factor[to_flux_length_prefix]/SIPrefix::Factor[from_flux_length_prefix])*(SIPrefix::Factor[to_flux_length_prefix]/SIPrefix::Factor[from_flux_length_prefix]);
}
Double_t Unit::ConvertDifferentialFlux(Double_t flux, const Char_t *from_flux_unit, const Char_t *to_flux_unit)
{
   Energy::Type from_energy_type;
   SIPrefix::Type from_energy_prefix;
   SIPrefix::Type from_length_prefix;
   if (!ParseDifferentialFluxUnit(from_flux_unit, from_energy_type, from_energy_prefix, from_length_prefix)) return -DBL_MAX;

   Energy::Type to_energy_type;
   SIPrefix::Type to_energy_prefix;
   SIPrefix::Type to_length_prefix;
   if (!ParseDifferentialFluxUnit(to_flux_unit, to_energy_type, to_energy_prefix, to_length_prefix)) return -DBL_MAX;

   if (from_energy_type != to_energy_type)
   {
      std::cerr << Form(" !!! Warning: Unit::ConvertDifferentialFlux: '%s' and '%s' have different energy types, but this method is supposed to only change the scale\n", from_flux_unit, to_flux_unit) << std::flush;
   }
   if (from_energy_prefix != to_energy_prefix || from_length_prefix != to_length_prefix) flux = ConvertDifferentialFlux(flux, from_energy_prefix, from_length_prefix, to_energy_prefix, to_length_prefix);

   return flux;
}
Double_t Unit::ConvertDifferentialFlux(Double_t flux, Energy::Range range, const Char_t *from_flux_unit, const Char_t *to_flux_unit, Particle::Type particle)
{
   Energy::Type from_energy_type;
   SIPrefix::Type from_energy_prefix;
   SIPrefix::Type from_length_prefix;
   if (!ParseDifferentialFluxUnit(from_flux_unit, from_energy_type, from_energy_prefix, from_length_prefix)) return -DBL_MAX;

   Energy::Type to_energy_type;
   SIPrefix::Type to_energy_prefix;
   SIPrefix::Type to_length_prefix;
   if (!ParseDifferentialFluxUnit(to_flux_unit, to_energy_type, to_energy_prefix, to_length_prefix)) return -DBL_MAX;

   if (from_energy_type != to_energy_type) flux = ConvertDifferentialFluxType(flux, range, particle, from_energy_type, from_energy_prefix, to_energy_type);
   if (from_energy_prefix != to_energy_prefix || from_length_prefix != to_length_prefix) flux = ConvertDifferentialFlux(flux, from_energy_prefix, from_length_prefix, to_energy_prefix, to_length_prefix);

   return flux;
}
Double_t Unit::ConvertDifferentialFlux(Double_t flux, Double_t energy, const Char_t *from_flux_unit, const Char_t *to_flux_unit, Particle::Type particle)
{
   Energy::Type from_energy_type;
   SIPrefix::Type from_energy_prefix;
   SIPrefix::Type from_length_prefix;
   if (!ParseDifferentialFluxUnit(from_flux_unit, from_energy_type, from_energy_prefix, from_length_prefix)) return -DBL_MAX;

   Energy::Type to_energy_type;
   SIPrefix::Type to_energy_prefix;
   SIPrefix::Type to_length_prefix;
   if (!ParseDifferentialFluxUnit(to_flux_unit, to_energy_type, to_energy_prefix, to_length_prefix)) return -DBL_MAX;

   if (from_energy_type != to_energy_type) flux = ConvertDifferentialFluxType(flux, energy, particle, from_energy_type, from_energy_prefix, to_energy_type);
   if (from_energy_prefix != to_energy_prefix || from_length_prefix != to_length_prefix) flux = ConvertDifferentialFlux(flux, from_energy_prefix, from_length_prefix, to_energy_prefix, to_length_prefix);

   return flux;
}

Double_t Unit::ConvertIntegralFlux(Double_t flux, SIPrefix::Type from_flux_length_prefix, SIPrefix::Type to_flux_length_prefix)
{
   return flux * (SIPrefix::Factor[to_flux_length_prefix]/SIPrefix::Factor[from_flux_length_prefix])*(SIPrefix::Factor[to_flux_length_prefix]/SIPrefix::Factor[from_flux_length_prefix]);
}
Double_t Unit::ConvertIntegralFlux(Double_t flux, const Char_t *from_flux_unit, const Char_t *to_flux_unit)
{
   SIPrefix::Type from_length_prefix;
   if (!ParseIntegralFluxUnit(from_flux_unit, from_length_prefix)) return -DBL_MAX;

   SIPrefix::Type to_length_prefix;
   if (!ParseIntegralFluxUnit(to_flux_unit, to_length_prefix)) return -DBL_MAX;

   if (from_length_prefix != to_length_prefix) flux = ConvertIntegralFlux(flux, from_length_prefix, to_length_prefix);

   return flux;
}
//~ #endif

static Double_t magnitude_order(Double_t x)
{
   return floor(log10(fabs(x))) + 1;
}

UShort_t Format::SignificantDigits = 2;

static Int_t precision_magnitude(Double_t x)
{
   /// http://stackoverflow.com/questions/31886619/how-many-sig-figs-in-a-double

   Int_t m = floor(log10(fabs(x)));

   Int_t i;
   for (i = m; i > -26; i--)
   {
      Double_t pow10i = pow(10., i);
      Double_t y = round(x / pow10i) * pow10i;
      if (fabs(x - y) < fabs(x) * 10. * DBL_EPSILON) break;
   }

   return i;
}

std::string Format::ToPrecision(Double_t num, UInt_t ndigits)
{
   /// http://stackoverflow.com/questions/202302/rounding-to-an-arbitrary-number-of-significant-digits

   if (num == 0.)
   {
      return "0";
   }

   Double_t mo        = magnitude_order(num);
   Int_t power        = ndigits - (Int_t)mo;
   Double_t magnitude = pow(10., power);
   Long64_t shifted   = round(num*magnitude);

   std::ostringstream oss;
   if (ndigits > oss.precision())
   {
      oss << std::setprecision(ndigits);
   }
   oss << shifted/magnitude;

   return oss.str();
}

std::string Format::ToPrecision(Double_t val, Double_t err)
{
   Int_t mov  = magnitude_order(val);
   Int_t pmv  = precision_magnitude(val);

   Int_t moe  = magnitude_order(err);
   Int_t pme  = precision_magnitude(err);
   Int_t nsde = moe - pme;
   if (nsde > SignificantDigits)
   {
      pme += nsde - SignificantDigits;
   }

   Int_t ndigits = mov - pme;
   if (ndigits < 0)
   {
      ndigits = SignificantDigits;
   }

   std::string str = ToPrecision(val, (UInt_t)ndigits);
   if (str.find('.') != std::string::npos && pmv > pme)
   {
      str.insert(str.size(), pmv - pme, '0');
   }

   return str;
}

std::string Format::Measurement(Double_t val, Double_t err, UShort_t latex)
{
   Int_t mov = magnitude_order(val);
   Int_t pmv = precision_magnitude(val);

   std::string str;
   if (err > 0.)
   {
//~ PRINT_VARIABLE(mov)
//~ PRINT_VARIABLE(pmv)
      Int_t moe  = magnitude_order(err);
      Int_t pme  = precision_magnitude(err);
      Int_t nsde = moe - pme;
//~ PRINT_VARIABLE(moe)
//~ PRINT_VARIABLE(pme)
//~ PRINT_VARIABLE(nsde)
      if (nsde > SignificantDigits)
      {
         pme += nsde - SignificantDigits;
         nsde = SignificantDigits;
      }
//~ PRINT_VARIABLE(pme)
//~ PRINT_VARIABLE(nsde)
      Int_t ndigits = mov - pme;
      if (ndigits < 0)
      {
         ndigits = SignificantDigits;
      }
//~ PRINT_VARIABLE(ndigits)
      str = ToPrecision(val, (UInt_t)ndigits);
//~ PRINT_VARIABLE(pmv - pme)
      if (str.find('.') != std::string::npos && pmv > pme)
      {
         str.insert(str.size(), pmv - pme, '0');
      }

      if (latex)
      {
         str += " #pm ";
      }
      else
      {
         str += " +/- ";
      }
      str += ToPrecision(err, (UInt_t)nsde);
   }
   else
   {
      str = ToPrecision(val, val);
   }

   return str;
}

std::string Format::Measurement(Double_t val, Double_t lerr, Double_t uerr, UShort_t latex)
{
   Int_t mov = magnitude_order(val);
   Int_t pmv = precision_magnitude(val);

   Int_t moe  = std::min(lerr > 0. ? magnitude_order(lerr) : 26, uerr > 0. ? magnitude_order(uerr) : 26);
   Int_t pme  = std::min(lerr > 0. ? precision_magnitude(lerr) : 26, uerr > 0. ? precision_magnitude(uerr) : 26);
   Int_t nsde = moe - pme;
   if (nsde > SignificantDigits)
   {
      pme += nsde - SignificantDigits;
      nsde = SignificantDigits;
   }

   Int_t ndigits = mov - pme;
   if (ndigits < 0)
   {
      ndigits = SignificantDigits;
   }

   std::string str = ToPrecision(val, (UInt_t)ndigits);
   if (str.find('.') != std::string::npos && pmv > pme)
   {
      str.insert(str.size(), pmv - pme, '0');
   }

   if (latex == 0)
   {
      str += " -" + ToPrecision(lerr, (UInt_t)nsde);
      str += " +" + ToPrecision(uerr, (UInt_t)nsde);
   }
   else if (latex == 1)
   {
      str += " #splitline{+" + ToPrecision(uerr, (UInt_t)nsde) + "}{-" + ToPrecision(lerr, (UInt_t)nsde) + "}";
   }
   else
   {
      str += "^{+" + ToPrecision(uerr, (UInt_t)nsde) + "}_{-" + ToPrecision(lerr, (UInt_t)nsde) + "}";
   }

   return str;
}
