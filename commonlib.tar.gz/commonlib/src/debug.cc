#include "debug.hh"

using namespace std;

ULong64_t Debug::_debug = Debug::NO;
TStopwatch Debug::_watch;

Bool_t Debug::Enabled(DebugFlag flag) { return _debug & flag; }
void Debug::Enable(DebugFlag flag) { _debug |= flag; }
void Debug::Disable(DebugFlag flag) { _debug &= ~flag; }
ULong64_t Debug::Get() { return _debug; }
void Debug::Set(ULong64_t debug) { _debug = debug; }

void Debug::StartWatch() { _watch.Start(true); }
void Debug::StopWatch() { _watch.Stop(); }
Double_t Debug::CPUTime() { return _watch.CpuTime(); }
Double_t Debug::RealTime() { return _watch.RealTime(); }

void Debug::PrintError(const Char_t *class_name, const Char_t *func_name, const Char_t *format, ...)
{
   if (class_name && strlen(class_name) > 0) fprintf(stderr, "%s !!! %s::%s-E-", FG_RED_B, class_name, func_name);
   else fprintf(stderr, "%s !!! %s-E-", FG_RED_B, func_name);
   va_list args;
   va_start(args, format);
   vfprintf(stderr, format, args);
   va_end(args);
   fprintf(stderr, ".%s\n", RESET);
   fflush(stderr);
}

void Debug::dump_var(const Char_t *name, time_t value)
{
   Char_t str[20];
   strftime(str, 20, "%Y-%m-%d %H:%M:%S", gmtime(&value));
   printf(" ??? %s = %ld (%s)\n", name, value, str);
}

void Debug::dump_var(const Char_t *name, tm &tms)
{
   static Char_t str[20];
   strftime(str, 20, "%F %T", &tms);
   printf(" ??? %s = %s\n", name, str);
}

void Debug::dump_var(const Char_t *name, Long64_t value)
{
   printf(" ??? %s = %lld\n", name, value);
}

void Debug::dump_var(const Char_t *name, ULong64_t value)
{
   printf(" ??? %s = %llu\n", name, value);
}

void Debug::dump_var(const Char_t *name, Int_t value)
{
   printf(" ??? %s = %d\n", name, value);
}

void Debug::dump_var(const Char_t *name, UInt_t value)
{
   printf(" ??? %s = %u\n", name, value);
}

void Debug::dump_var(const Char_t *name, const time_t *array, ULong64_t size)
{
   for (ULong64_t i = 0; i < size; ++i)
   {
      printf(" ??? %s[%llu] = %ld\n", name, i, array[i]);
      fflush(stdout);
   }
}

void Debug::dump_var(const Char_t *name, const Long64_t *array, ULong64_t size)
{
   for (ULong64_t i = 0; i < size; ++i)
   {
      printf(" ??? %s[%llu] = %lld\n", name, i, array[i]);
      fflush(stdout);
   }
}

void Debug::dump_var(const Char_t *name, const ULong64_t *array, ULong64_t size)
{
   for (ULong64_t i = 0; i < size; ++i)
   {
      printf(" ??? %s[%llu] = %llu\n", name, i, array[i]);
      fflush(stdout);
   }
}

void Debug::dump_var(const Char_t *name, const Int_t *array, ULong64_t size)
{
   for (ULong64_t i = 0; i < size; ++i)
   {
      printf(" ??? %s[%llu] = %d\n", name, i, array[i]);
      fflush(stdout);
   }
}

void Debug::dump_var(const Char_t *name, const UInt_t *array, ULong64_t size)
{
   for (ULong64_t i = 0; i < size; ++i)
   {
      printf(" ??? %s[%llu] = %u\n", name, i, array[i]);
      fflush(stdout);
   }
}

void Debug::dump_var(const Char_t *name, const UShort_t *array, ULong64_t size)
{
   for (ULong64_t i = 0; i < size; ++i)
   {
      printf(" ??? %s[%llu] = %u\n", name, i, array[i]);
      fflush(stdout);
   }
}

void Debug::dump_var(const Char_t *name, const Long64_t **array, ULong64_t size1, ULong64_t size2)
{
   for (ULong64_t i = 0; i < size1; ++i)
   {
      for (ULong64_t j = 0; j < size2; ++j)
      {
         printf(" ??? %s[%llu][%llu] = %lld\n", name, i, j, array[i][j]);
         fflush(stdout);
      }
   }
}

void Debug::dump_var(const Char_t *name, const ULong64_t **array, ULong64_t size1, ULong64_t size2)
{
   for (ULong64_t i = 0; i < size1; ++i)
   {
      for (ULong64_t j = 0; j < size2; ++j)
      {
         printf(" ??? %s[%llu][%llu] = %llu\n", name, i, j, array[i][j]);
         fflush(stdout);
      }
   }
}

void Debug::dump_var(const Char_t *name, const Int_t **array, ULong64_t size1, ULong64_t size2)
{
   for (ULong64_t i = 0; i < size1; ++i)
   {
      for (ULong64_t j = 0; j < size2; ++j)
      {
         printf(" ??? %s[%llu][%llu] = %d\n", name, i, j, array[i][j]);
         fflush(stdout);
      }
   }
}

void Debug::dump_var(const Char_t *name, const UInt_t **array, ULong64_t size1, ULong64_t size2)
{
   for (ULong64_t i = 0; i < size1; ++i)
   {
      for (ULong64_t j = 0; j < size2; ++j)
      {
         printf(" ??? %s[%llu][%llu] = %u\n", name, i, j, array[i][j]);
         fflush(stdout);
      }
   }
}

void Debug::dump_var(const Char_t *name, Double_t value)
{
   printf(" ??? %s = %f\n", name, value);
}

void Debug::dump_var(const Char_t *name, const Double_t *array, ULong64_t size)
{
   for (ULong64_t i = 0; i < size; ++i)
   {
      printf(" ??? %s[%llu] = %g\n", name, i, array[i]);
      fflush(stdout);
   }
}

void Debug::dump_var(const Char_t *name, const Float_t *array, ULong64_t size)
{
   for (ULong64_t i = 0; i < size; ++i)
   {
      printf(" ??? %s[%llu] = %g\n", name, i, array[i]);
      fflush(stdout);
   }
}

void Debug::dump_var(const Char_t *name, const Double_t **array, ULong64_t size1, ULong64_t size2)
{
   for (ULong64_t i = 0; i < size1; ++i)
   {
      for (ULong64_t j = 0; j < size2; ++j)
      {
         printf(" ??? %s[%llu][%llu] = %f\n", name, i, j, array[i][j]);
         fflush(stdout);
      }
   }
}

void Debug::dump_var(const Char_t *name, const Float_t **array, ULong64_t size1, ULong64_t size2)
{
   for (ULong64_t i = 0; i < size1; ++i)
   {
      for (ULong64_t j = 0; j < size2; ++j)
      {
         printf(" ??? %s[%llu][%llu] = %f\n", name, i, j, array[i][j]);
         fflush(stdout);
      }
   }
}

void Debug::dump_var(const Char_t *name, Char_t *value)
{
   printf(" ??? %s = %s\n", name, value);
}

void Debug::dump_var(const Char_t *name, const Char_t **array, ULong64_t size)
{
   for (ULong64_t i = 0; i < size; ++i)
   {
      printf(" ??? %s[%llu] = %s\n", name, i, array[i]);
      fflush(stdout);
   }
}

void Debug::dump_var(const Char_t *name, const Char_t ***array, ULong64_t size1, ULong64_t size2)
{
   for (ULong64_t i = 0; i < size1; ++i)
   {
      for (ULong64_t j = 0; j < size2; ++j)
      {
         printf(" ??? %s[%llu][%llu] = %s\n", name, i, j, array[i][j]);
         fflush(stdout);
      }
   }
}

void Debug::dump_var(const Char_t *name, string value)
{
   printf(" ??? %s = %s\n", name, value.c_str());
}

void Debug::dump_var(const Char_t *name, const string *array, ULong64_t size)
{
   for (ULong64_t i = 0; i < size; ++i)
   {
      printf(" ??? %s[%llu] = %s\n", name, i, array[i].c_str());
      fflush(stdout);
   }
}

void Debug::dump_var(const Char_t *name, const string **array, ULong64_t size1, ULong64_t size2)
{
   for (ULong64_t i = 0; i < size1; ++i)
   {
      for (ULong64_t j = 0; j < size2; ++j)
      {
         printf(" ??? %s[%llu][%llu] = %s\n", name, i, j, array[i][j].c_str());
         fflush(stdout);
      }
   }
}
