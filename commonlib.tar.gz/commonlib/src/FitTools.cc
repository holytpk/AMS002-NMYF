#include "FitTools.hh"
#include "HistTools.hh"
#include "debug.hh"

#include "TParameter.h"
#include "RVersion.h"

using namespace std;

// code from $ROOTSYS/hist/hist/src/HFitInterface.cxx, needed by FillLogData
bool AdjustError(const ROOT::Fit::DataOptions &option, double &error, double value = 1)
{
   if (error <= 0)
   {
      if (option.fUseEmpty || (option.fErrors1 && abs(value) > 0)) error = 1.;
      else return false;
   }
   else if (option.fErrors1) error = 1;

   return true;
}

// same code as in $ROOTSYS/hist/hist/src/HFitInterface.cxx, but uses the log-center of the bin
// remove some safety checks and comments
void FillLogData(ROOT::Fit::BinData &dv, const TH1 *hfit, TF1 *func = 0)
{
   const ROOT::Fit::DataOptions &fitOpt = dv.Opt();
   bool useBinEdges = fitOpt.fIntegral || fitOpt.fBinVolume;

   int hxfirst = hfit->GetXaxis()->GetFirst();
   int hxlast  = hfit->GetXaxis()->GetLast();

   int hyfirst = hfit->GetYaxis()->GetFirst();
   int hylast  = hfit->GetYaxis()->GetLast();

   int hzfirst = hfit->GetZaxis()->GetFirst();
   int hzlast  = hfit->GetZaxis()->GetLast();

   const ROOT::Fit::DataRange &range = dv.Range();

   int n = (hxlast - hxfirst + 1) * (hylast - hyfirst + 1) * (hzlast - hzfirst + 1);

   int hdim = hfit->GetDimension();
   int ndim = hdim;
   if (func != 0 && func->GetNdim() == hdim - 1) ndim = hdim - 1;
   dv.Initialize(n, ndim);

   double x[3];
   double s[3];

   int binx = 0;
   int biny = 0;
   int binz = 0;

   const TAxis *xaxis = hfit->GetXaxis();
   const TAxis *yaxis = hfit->GetYaxis();
   const TAxis *zaxis = hfit->GetZaxis();

   for (binx = hxfirst; binx <= hxlast; ++binx)
   {
      if (useBinEdges)
      {
         x[0] = xaxis->GetBinLowEdge(binx);
         s[0] = xaxis->GetBinUpEdge(binx);
      }
      else x[0] = xaxis->GetBinCenterLog(binx);


      for (biny = hyfirst; biny <= hylast; ++biny)
      {
         if (useBinEdges)
         {
            x[1] = yaxis->GetBinLowEdge(biny);
            s[1] = yaxis->GetBinUpEdge(biny);
         }
         else x[1] = yaxis->GetBinCenterLog(biny);

         for (binz = hzfirst; binz <= hzlast; ++binz)
         {
            if (useBinEdges)
            {
               x[2] = zaxis->GetBinLowEdge(binz);
               s[2] = zaxis->GetBinUpEdge(binz);
            }
            else x[2] = zaxis->GetBinCenterLog(binz);

            if (func != 0)
            {
               TF1::RejectPoint(false);
               (*func)(&x[0]);
               if (TF1::RejectedPoint()) continue;
            }

            double value = hfit->GetBinContent(binx, biny, binz);
            double error = hfit->GetBinError(binx, biny, binz);
            if (!AdjustError(fitOpt, error, value)) continue;

            if (ndim == hdim -1)
            {
               if (hdim == 2) dv.Add(x, x[1], yaxis->GetBinWidth(biny) / error);
               if (hdim == 3) dv.Add(x, x[2], zaxis->GetBinWidth(binz) / error);
            }
            else
            {
               dv.Add(x, value, error);
               if (useBinEdges)
               {
                  dv.AddBinUpEdge(s);
               }
            }
         }
      }
   }
}

FitTools::GlobalChi2::GlobalChi2(vector<ROOT::Math::IMultiGenFunction *> &f_chi2s, vector< vector<Int_t> > &par_indices)
{
   _f_chi2s     = f_chi2s;
   _par_indices = par_indices;

   for (UShort_t ichi2 = 0; ichi2 < _f_chi2s.size(); ++ichi2)
   {
      _pars.push_back(new Double_t[_par_indices[ichi2].size()]);
   }
}

Double_t FitTools::GlobalChi2::operator() (const Double_t *par) const
{
   Double_t chi2 = 0.;

   for (UShort_t ichi2 = 0; ichi2 < _f_chi2s.size(); ++ichi2)
   {
      for (UShort_t ipar = 0; ipar < _par_indices[ichi2].size(); ++ipar)
      {
         _pars[ichi2][ipar] = par[_par_indices[ichi2][ipar]];
      }

      chi2 += (*_f_chi2s[ichi2])(_pars[ichi2]);
   }

   return chi2;
}

Double_t FitTools::GlobalChi2::operator() (UShort_t ichi2, const Double_t *par) const
{
   for (UShort_t ipar = 0; ipar < _par_indices[ichi2].size(); ++ipar)
   {
      _pars[ichi2][ipar] = par[_par_indices[ichi2][ipar]];
   }

   return (*_f_chi2s[ichi2])(_pars[ichi2]);
}

UInt_t FitTools::GlobalChi2::DataSize()
{
   UInt_t datasize = 0;
   for (UShort_t ichi2 = 0; ichi2 < _f_chi2s.size(); ++ichi2)
   {
      //~ datasize += dynamic_cast<ROOT::Fit::Chi2Function *>(_f_chi2s[ichi2])->Data().DataSize();
      datasize += dynamic_cast<ROOT::Fit::Chi2Function *>(_f_chi2s[ichi2])->Data().Size();
   }

   return datasize;
}

void FitTools::GlobalChi2::Print()
{
   for (UShort_t ichi2 = 0; ichi2 < _f_chi2s.size(); ++ichi2)
   {
      #if ROOT_VERSION_CODE >= ROOT_VERSION(5,34,36)
      // GetFunction method supported only from ROOT 5.34/36
      //~ ROOT::Math::WrappedMultiTF1 *mf = (ROOT::Math::WrappedMultiTF1 *)&dynamic_cast<ROOT::Fit::Chi2Function *>(_f_chi2s[ichi2])->ModelFunction();
      const ROOT::Math::WrappedMultiTF1 *mf = dynamic_cast<const ROOT::Math::WrappedMultiTF1 *>(&dynamic_cast<ROOT::Fit::Chi2Function *>(_f_chi2s[ichi2])->ModelFunction());
      const TF1 *func = mf->GetFunction();
      #else
      const TF1 *func = NULL;
      #endif

      cout << Form(" %02u) f_chi2 = %p, f = %p\n", ichi2, _f_chi2s[ichi2], func);
      if (func) func->Print();

      cout << Form("     parindex: %2u parameters {", (UShort_t)_par_indices[ichi2].size());
      for (UShort_t ipar = 0; ipar < _par_indices[ichi2].size(); ++ipar)
      {
         cout << Form(" %2u", _par_indices[ichi2][ipar]);
      }
      cout << " }\n";
   }
}

FitTools::ModelWithShift::ModelWithShift(TF1 *model, Double_t shift) : _model(model), _shift(shift)
{
   _shift *= 1e3; // [TV] -> [GV]
}

Double_t FitTools::ModelWithShift::operator()(Double_t *x, Double_t *par) const
{
   x[0] *= _shift/(x[0] + _shift);

   return _model->EvalPar(x, par);
}

TF1 *FitTools::CreateModelWithShift(TF1 *fit_model, Double_t shift)
{
   Double_t enemin, enemax;
   fit_model->GetRange(enemin, enemax);

   TF1 *fit_model_shift = new TF1(Form("%s_shift%c", fit_model->GetName(), shift > 0. ? 'p' : 'm'), ModelWithShift(fit_model, shift), enemin, enemax, fit_model->GetNpar());
   for (UShort_t ipar = 0; ipar < fit_model->GetNpar(); ++ipar)
   {
      Double_t pl, ph;
      Double_t p = fit_model->GetParameter(ipar);
      fit_model->GetParLimits(ipar, pl, ph);
      Bool_t fixed = HistTools::IsParameterFixed(fit_model, ipar);
      Bool_t bound = HistTools::IsParameterBound(fit_model, ipar);
      if (!fixed)
      {
         fit_model_shift->SetParameter(ipar, p);
         if (bound) fit_model_shift->SetParLimits(ipar, pl, ph);
      }
      else
      {
         fit_model_shift->FixParameter(ipar, p);
      }
      fit_model_shift->SetParName(ipar, fit_model->GetParName(ipar));
   }

   return fit_model_shift;
}

FitTools::ModelPlusError::ModelPlusError(TF1 *model, TGraph *error, Double_t sign) : _model(model), _error(error), _sign(sign)
{
   _modmodel = ModulationModels::cast(_model->GetParameter(0));
   _energy   = Energy::cast(_model->GetParameter(1));
   _particle = Particle::cast(_model->GetParameter(2));
}

Double_t FitTools::ModelPlusError::operator()(Double_t *x, Double_t *par) const
{
   return _model->EvalPar(x, par)*(1. + _sign*ModulationModels::Apply[_modmodel](x[0], _error, par, _particle, _energy));
}

TF1 *FitTools::CreateModelPlusError(TF1 *fit_model, TGraph *error, Double_t sign)
{
   Double_t enemin, enemax;
   fit_model->GetRange(enemin, enemax);

   TF1 *fit_model_error = new TF1(Form("%s_err%c", fit_model->GetName(), sign > 0. ? 'p' : 'm'), FitTools::ModelPlusError(fit_model, error, sign), enemin, enemax, fit_model->GetNpar());
   fit_model_error->SetNpx(fit_model->GetNpx());
   for (UShort_t ipar = 0; ipar < fit_model->GetNpar(); ++ipar)
   {
      Double_t pl, ph;
      Double_t p = fit_model->GetParameter(ipar);
      fit_model->GetParLimits(ipar, pl, ph);
      Bool_t fixed = HistTools::IsParameterFixed(fit_model, ipar);
      Bool_t bound = HistTools::IsParameterBound(fit_model, ipar);
      if (!fixed)
      {
         fit_model_error->SetParameter(ipar, p);
         if (bound) fit_model_error->SetParLimits(ipar, pl, ph);
      }
      else
      {
         fit_model_error->FixParameter(ipar, p);
      }
      fit_model_error->SetParName(ipar, fit_model->GetParName(ipar));
   }

   return fit_model_error;
}

void FitTools::PrintParamSettings(ROOT::Fit::Fitter &fitter)
{
   const ROOT::Fit::FitConfig &config = fitter.Config();
   UShort_t npars = config.NPar();
   cout << Form("ROOT::Fit::FitConfig::ParameterSettings: %u parameters", npars) << endl;
   for (UShort_t ipar = 0; ipar < npars; ++ipar)
   {
      const ROOT::Fit::ParameterSettings &setting = config.ParSettings(ipar);

      Bool_t fixed  = setting.IsFixed();
      Bool_t lbound = setting.HasLowerLimit();
      Bool_t ubound = setting.HasUpperLimit();
      Double_t pl = setting.LowerLimit();
      Double_t ph = setting.UpperLimit();
      cout << Form("    Par %02u\t%15s = %25s %s\n", ipar, setting.Name().c_str(),
         Format::ToPrecision(setting.Value(), 4u).c_str(),
         fixed ? "" : Form("[%s, %s]", lbound ? Format::ToPrecision(pl, 4u).c_str() : "-inf", ubound ? Format::ToPrecision(ph, 4u).c_str() : "+inf"));
   }
}

// Minimize a parabola on the given graph range (errors are not taken into account)
Double_t FitTools::MinimizeParabola(TGraph *g, UInt_t first_point, UInt_t last_point, Double_t &a, Double_t &b, Double_t &c)
{
   // matrix elements
   Double_t N  = 0.; // sum_i 1
   Double_t Y0 = 0.; // sum_i yi
   Double_t Y1 = 0.; // sum_i xi*yi
   Double_t Y2 = 0.; // sum_i xi^2*yi
   Double_t X1 = 0.; // sum_i xi
   Double_t X2 = 0.; // sum_i xi^2
   Double_t X3 = 0.; // sum_i xi^3
   Double_t X4 = 0.; // sum_i xi^4
   for (UInt_t ipoint = first_point; ipoint <= last_point; ++ipoint)
   {
      Double_t x = g->GetX()[ipoint];
      Double_t y = g->GetY()[ipoint];

      ++N;
      Y0 += y;
      Y1 += x*y;
      Y2 += x*x*y;
      X1 += x;
      X2 += x*x;
      X3 += x*x*x;
      X4 += x*x*x*x;
   }

   // minors
   Double_t M11 = X2*X4 - X3*X3;
   Double_t M12 = X1*X4 - X3*X2;
   Double_t M13 = X1*X3 - X2*X2;
   Double_t M22 =  N*X4 - X2*X2;
   Double_t M23 =  N*X3 - X1*X2;
   Double_t M33 =  N*X2 - X1*X1;

   Double_t det = N*M11 - X1*M12 + X2*M13;

   c = ( M11*Y0 - M12*Y1 + M13*Y2) / det;
   b = (-M12*Y0 + M22*Y1 - M23*Y2) / det;
   a = ( M13*Y0 - M23*Y1 + M33*Y2) / det;

   Double_t chi2 = 0.;
   for (UInt_t ipoint = first_point; ipoint <= last_point; ++ipoint)
   {
      Double_t x = g->GetX()[ipoint];
      Double_t y = g->GetY()[ipoint];

      chi2 += TMath::Power(y - (a*x*x + b*x + c), 2.);
   }

   return chi2;
}

void FitTools::SetCommonFitterOptions(ROOT::Fit::Fitter &fitter)
{
   //~ fitter.Config().MinimizerOptions().SetPrecision(1e-6);
   fitter.Config().MinimizerOptions().SetMaxIterations(5e4);
   fitter.Config().MinimizerOptions().SetMaxFunctionCalls(5e4);
   fitter.Config().MinimizerOptions().SetTolerance(0.005);
   //~ fitter.Config().MinimizerOptions().SetStrategy(2);
   fitter.Config().MinimizerOptions().SetPrintLevel(-1);
}

// from generic TF1 to Fitter
void FitTools::CopyParameters(TF1 *f_fit, ROOT::Fit::Fitter &fitter)
{
   fitter.Config().SetParamsSettings(f_fit->GetNpar(), f_fit->GetParameters());
   for (UShort_t ipar = 0; ipar < f_fit->GetNpar(); ++ipar)
   {
      Double_t pl, ph;
      f_fit->GetParLimits(ipar, pl, ph);
      Bool_t fixed = HistTools::IsParameterFixed(f_fit, ipar);
      Bool_t bound = HistTools::IsParameterBound(f_fit, ipar);
      if (!fixed)
      {
         fitter.Config().ParSettings(ipar).Release();
         if (bound) fitter.Config().ParSettings(ipar).SetLimits(pl, ph);
      }
      else
      {
         fitter.Config().ParSettings(ipar).Fix();
      }
      fitter.Config().ParSettings(ipar).SetName(f_fit->GetParName(ipar));
   }
}

// from ModulationModels TF1 to Fitter
void FitTools::CopyParameters(TF1 *f_fit, UShort_t nlisfluxes, UShort_t nmodfluxes, ROOT::Fit::Fitter &fitter, Int_t **par_index)
{
   ModulationModels::Type modmodel = ModulationModels::cast(f_fit->GetParameter(0));
   LISModels::Type        lismodel = LISModels::cast(f_fit->GetParameter(3));

   UShort_t nmodpars    = ModulationModels::Info[modmodel].nParameters;
   UShort_t nlispars    = LISModels::Info[lismodel].nParameters;
   UShort_t nlisfitpars = 4 + nlispars;
   UShort_t nmodfitpars = 5 + nmodpars + nlispars;
   UShort_t nfreepars   = nmodpars*nmodfluxes + nlispars + 1;
   UShort_t ntotpars    = 4 + nfreepars;

   Double_t *params = new Double_t[ntotpars];
   for (UShort_t ipar = 0; ipar < 4; ++ipar)
   {
      params[ipar] = f_fit->GetParameter(ipar); // fix
   }
   for (UShort_t iflux = 0; iflux < nmodfluxes; ++iflux)
   {
      for (UShort_t ipar = 0; ipar < nmodpars; ++ipar) // free
      {
         params[4 + iflux*nmodpars + ipar] = f_fit->GetParameter(4 + ipar);
      }
   }
   for (UShort_t ipar = 0; ipar <= nlispars; ++ipar) // free
   {
      params[4 + nmodpars*nmodfluxes + ipar] = f_fit->GetParameter(4 + nmodpars + ipar);
   }

   fitter.Config().SetParamsSettings(ntotpars, params);
   for (UShort_t ipar = 0; ipar < 4; ++ipar)
   {
      fitter.Config().ParSettings(ipar).Fix();
   }
   fitter.Config().ParSettings(0).SetName("modmodel");
   fitter.Config().ParSettings(1).SetName("energy");
   fitter.Config().ParSettings(2).SetName("particle");
   fitter.Config().ParSettings(3).SetName("lismodel");
   for (UShort_t iflux = 0; iflux < nmodfluxes; ++iflux)
   {
      for (UShort_t ipar = 0; ipar < nmodpars; ++ipar)
      {
         Double_t pl, ph;
         f_fit->GetParLimits(4 + ipar, pl, ph);
         Bool_t fixed = HistTools::IsParameterFixed(f_fit, 4 + ipar);
         Bool_t bound = HistTools::IsParameterBound(f_fit, 4 + ipar);
         if (!fixed)
         {
            fitter.Config().ParSettings(4 + iflux*nmodpars + ipar).Release();
            if (bound) fitter.Config().ParSettings(4 + iflux*nmodpars + ipar).SetLimits(pl, ph);
         }
         else
         {
            fitter.Config().ParSettings(4 + iflux*nmodpars + ipar).Fix();
         }
         fitter.Config().ParSettings(4 + iflux*nmodpars + ipar).SetName(Form("%s_%03u", f_fit->GetParName(4 + ipar), iflux));
      }
   }
   for (UShort_t ipar = 0; ipar <= nlispars; ++ipar)
   {
      Double_t pl, ph;
      f_fit->GetParLimits(4 + nmodpars + ipar, pl, ph);
      Bool_t fixed = HistTools::IsParameterFixed(f_fit, 4 + nmodpars + ipar);
      Bool_t bound = HistTools::IsParameterBound(f_fit, 4 + nmodpars + ipar);
      if (!fixed)
      {
         fitter.Config().ParSettings(4 + nmodfluxes*nmodpars + ipar).Release();
         if (bound) fitter.Config().ParSettings(4 + nmodfluxes*nmodpars + ipar).SetLimits(pl, ph);
      }
      else
      {
         fitter.Config().ParSettings(4 + nmodfluxes*nmodpars + ipar).Fix();
      }
      fitter.Config().ParSettings(4 + nmodfluxes*nmodpars + ipar).SetName(f_fit->GetParName(4 + nmodpars + ipar));
   }

   delete [] params;

   UShort_t idataset = 0;
   for (UShort_t iflux = 0; iflux < nlisfluxes; ++iflux, ++idataset)
   {
      par_index[idataset] = new Int_t[nlisfitpars];

      par_index[idataset][0] = 3;
      par_index[idataset][1] = 1;
      par_index[idataset][2] = 2;
      for (UShort_t ipar = 0; ipar < nlispars + 1; ++ipar)
      {
         par_index[idataset][3 + ipar] = 4 + nmodpars*nmodfluxes + ipar;
      }
   }
   for (UShort_t iflux = 0; iflux < nmodfluxes; ++iflux, ++idataset)
   {
      par_index[idataset] = new Int_t[nmodfitpars];

      for (UShort_t ipar = 0; ipar < 4; ++ipar)
      {
         par_index[idataset][ipar] = ipar;
      }
      for (UShort_t ipar = 0; ipar < nmodpars; ++ipar)
      {
         par_index[idataset][4 + ipar] = 4 + iflux*nmodpars + ipar;
      }
      for (UShort_t ipar = 0; ipar < nlispars + 1; ++ipar)
      {
         par_index[idataset][4 + nmodpars + ipar] = 4 + nmodfluxes*nmodpars + ipar;
      }
   }
}

// from ModulationModels TF1 to Fitter
void FitTools::CopyParameters(ModulationModels::ForceField *ffa, TF1 *f_fit, UShort_t nlisfluxes, UShort_t nmodfluxes, ROOT::Fit::Fitter &fitter, Int_t **par_index)
{
   UShort_t nmodpars    = ffa->GetNModulationParameters();
   UShort_t nlispars    = ffa->GetNLISParameters();
   UShort_t nlisfitpars = nlispars;
   UShort_t nmodfitpars = nmodpars + nlispars;
   UShort_t nfreepars   = nmodpars*nmodfluxes + nlispars;
   UShort_t ntotpars    = nfreepars;

   Double_t *params = new Double_t[ntotpars];
   for (UShort_t iflux = 0; iflux < nmodfluxes; ++iflux)
   {
      for (UShort_t ipar = 0; ipar < nmodpars; ++ipar)
      {
         params[iflux*nmodpars + ipar] = f_fit->GetParameter(ipar);
      }
   }
   for (UShort_t ipar = 0; ipar < nlispars; ++ipar)
   {
      params[nmodpars*nmodfluxes + ipar] = f_fit->GetParameter(nmodpars + ipar);
   }

   fitter.Config().SetParamsSettings(ntotpars, params);
   for (UShort_t iflux = 0; iflux < nmodfluxes; ++iflux)
   {
      for (UShort_t ipar = 0; ipar < nmodpars; ++ipar)
      {
         Double_t pl, ph;
         f_fit->GetParLimits(ipar, pl, ph);
         Bool_t fixed = HistTools::IsParameterFixed(f_fit, ipar);
         Bool_t bound = HistTools::IsParameterBound(f_fit, ipar);
         if (!fixed)
         {
            fitter.Config().ParSettings(iflux*nmodpars + ipar).Release();
            if (bound) fitter.Config().ParSettings(iflux*nmodpars + ipar).SetLimits(pl, ph);
         }
         else
         {
            fitter.Config().ParSettings(iflux*nmodpars + ipar).Fix();
         }
         fitter.Config().ParSettings(iflux*nmodpars + ipar).SetName(Form("%s_%03u", f_fit->GetParName(ipar), iflux));
      }
   }
   for (UShort_t ipar = 0; ipar < nlispars; ++ipar)
   {
      Double_t pl, ph;
      f_fit->GetParLimits(nmodpars + ipar, pl, ph);
      Bool_t fixed = HistTools::IsParameterFixed(f_fit, nmodpars + ipar);
      Bool_t bound = HistTools::IsParameterBound(f_fit, nmodpars + ipar);
      if (!fixed)
      {
         fitter.Config().ParSettings(nmodfluxes*nmodpars + ipar).Release();
         if (bound) fitter.Config().ParSettings(nmodfluxes*nmodpars + ipar).SetLimits(pl, ph);
      }
      else
      {
         fitter.Config().ParSettings(nmodfluxes*nmodpars + ipar).Fix();
      }
      fitter.Config().ParSettings(nmodfluxes*nmodpars + ipar).SetName(f_fit->GetParName(nmodpars + ipar));
   }

   delete [] params;

   UShort_t idataset = 0;
   for (UShort_t iflux = 0; iflux < nlisfluxes; ++iflux, ++idataset)
   {
      par_index[idataset] = new Int_t[nlisfitpars];
      for (UShort_t ipar = 0; ipar < nlispars; ++ipar)
      {
         par_index[idataset][ipar] = nmodpars*nmodfluxes + ipar;
      }
   }
   for (UShort_t iflux = 0; iflux < nmodfluxes; ++iflux, ++idataset)
   {
      par_index[idataset] = new Int_t[nmodfitpars];
      for (UShort_t ipar = 0; ipar < nmodpars; ++ipar)
      {
         par_index[idataset][ipar] = iflux*nmodpars + ipar;
      }
      for (UShort_t ipar = 0; ipar < nlispars; ++ipar)
      {
         par_index[idataset][nmodpars + ipar] = nmodfluxes*nmodpars + ipar;
      }
   }
}

// from ModulationModels TF1 to LISModels TF1
void FitTools::CopyParameters(TF1 *f_mod, TF1 *f_lis)
{
   ModulationModels::Type modmodel = ModulationModels::cast(f_mod->GetParameter(0));
   LISModels::Type        lismodel = LISModels::cast(f_mod->GetParameter(3));

   UShort_t mod_offset = 4 + ModulationModels::Info[modmodel].nParameters;
   UShort_t lis_offset = 3;

   for (UShort_t ipar = 0; ipar < LISModels::Info[lismodel].nParameters + 1; ++ipar)
   {
      Double_t pl, ph;
      Double_t p = f_mod->GetParameter(mod_offset + ipar);
      f_mod->GetParLimits(mod_offset + ipar, pl, ph);
      Bool_t fixed = HistTools::IsParameterFixed(f_mod, mod_offset + ipar);
      Bool_t bound = HistTools::IsParameterBound(f_mod, mod_offset + ipar);
      if (!fixed)
      {
         f_lis->ReleaseParameter(lis_offset + ipar);
         f_lis->SetParameter(lis_offset + ipar, p);
         if (bound) f_lis->SetParLimits(lis_offset + ipar, pl, ph);
         f_lis->SetParError(lis_offset + ipar, f_mod->GetParError(mod_offset + ipar));
      }
      else
      {
         f_lis->FixParameter(lis_offset + ipar, p);
      }
   }
}

void FitTools::GetFitRange(TObject *obj, TF1 *f_fit, Bool_t use_range, Double_t &enemin, Double_t &enemax)
{
   Double_t xmin, xmax;
   if (use_range)
   {
      f_fit->GetRange(xmin, xmax);
   }
   else
   {
      if (HistTools::IsHist(obj)) HistTools::GetRange(HistTools::ToHist(obj), xmin, xmax);
      else HistTools::GetRange(HistTools::ToGraph(obj), xmin, xmax);
   }
   if (enemin == DBL_MIN) enemin = xmin;
   if (enemax == DBL_MAX) enemax = xmax;
}

void FitTools::GetFitRange(TObjArray &arr, TF1 *f_fit, Bool_t use_range, vector<Double_t> &enemin, vector<Double_t> &enemax, Double_t &minrange, Double_t &maxrange)
{
   Double_t xmin, xmax;
   if (use_range)
   {
      f_fit->GetRange(xmin, xmax);
      for (UShort_t idataset = 0; idataset < arr.GetEntries(); ++idataset)
      {
         if (enemin[idataset] == DBL_MIN) enemin[idataset] = xmin;
         if (enemax[idataset] == DBL_MAX) enemax[idataset] = xmax;
      }
      minrange = xmin;
      maxrange = xmax;
   }
   else
   {
      minrange = DBL_MAX;
      maxrange = -DBL_MAX;
      for (UShort_t idataset = 0; idataset < arr.GetEntries(); ++idataset)
      {
         TObject *obj = arr[idataset];
         if (HistTools::IsHist(obj)) HistTools::GetRange(HistTools::ToHist(obj), xmin, xmax);
         else HistTools::GetRange(HistTools::ToGraph(obj), xmin, xmax);
         if (enemin[idataset] == DBL_MIN) enemin[idataset] = xmin;
         if (enemax[idataset] == DBL_MAX) enemax[idataset] = xmax;

         if (xmin < minrange) minrange = xmin;
         if (xmax > maxrange) maxrange = xmax;
      }
   }
}

void FitTools::GetFitRange(TObjArray &lis, TObjArray &mod, TF1 *f_fit, Bool_t use_range, vector<FitTools::EnergyRange> &range, Double_t &minrange, Double_t &maxrange)
{
   Double_t xmin, xmax;
   UShort_t idataset = 0;
   if (use_range)
   {
      f_fit->GetRange(xmin, xmax);
      for (UShort_t iflux; iflux < lis.GetEntries(); ++iflux, ++idataset)
      {
         if (range[idataset].Min == DBL_MIN) range[idataset].Min = xmin;
         if (range[idataset].Max == DBL_MAX) range[idataset].Max = xmax;
      }
      for (UShort_t iflux; iflux < mod.GetEntries(); ++iflux, ++idataset)
      {
         if (range[idataset].Min == DBL_MIN) range[idataset].Min = xmin;
         if (range[idataset].Max == DBL_MAX) range[idataset].Max = xmax;
      }
      minrange = xmin;
      maxrange = xmax;
   }
   else
   {
      minrange = DBL_MAX;
      maxrange = -DBL_MAX;
      for (UShort_t iflux = 0; iflux < lis.GetEntries(); ++iflux, ++idataset)
      {
         TObject *obj = lis[iflux];
         if (HistTools::IsHist(obj)) HistTools::GetRange(HistTools::ToHist(obj), xmin, xmax);
         else HistTools::GetRange(HistTools::ToGraph(obj), xmin, xmax);
         if (range[idataset].Min == DBL_MIN) range[idataset].Min = xmin;
         if (range[idataset].Max == DBL_MAX) range[idataset].Max = xmax;
         if (xmin < minrange) minrange = xmin;
         if (xmax > maxrange) maxrange = xmax;
      }
      for (UShort_t iflux = 0; iflux < mod.GetEntries(); ++iflux, ++idataset)
      {
         TObject *obj = mod[iflux];
         if (HistTools::IsHist(obj)) HistTools::GetRange(HistTools::ToHist(obj), xmin, xmax);
         else HistTools::GetRange(HistTools::ToGraph(obj), xmin, xmax);
         if (range[idataset].Min == DBL_MIN) range[idataset].Min = xmin;
         if (range[idataset].Max == DBL_MAX) range[idataset].Max = xmax;
         if (xmin < minrange) minrange = xmin;
         if (xmax > maxrange) maxrange = xmax;
      }
   }
}

// Get chi2 between f_fit and obj
Double_t FitTools::GetChiSquare(TObject *obj, TF1 *f_fit, Option_t *option, Double_t enemin, Double_t enemax)
{
   TH1 *hist = NULL;
   TGraph *graph = NULL;
   if (HistTools::IsHist(obj)) hist = HistTools::ToHist(obj);
   else if (HistTools::IsGraph(obj)) graph = HistTools::ToGraph(obj);
   else
   {
      cerr << FG_RED_B << Form(" !!! GetChiSquare-E-Unsupported class '%s' for obj '%s'", obj->ClassName(), obj->GetName()) << RESET << endl;

      return -1.;
   }

   TString stropt(option);

   Bool_t use_range = stropt.Contains("R");
   GetFitRange(obj, f_fit, use_range, enemin, enemax);

   ROOT::Fit::DataOptions opt;
   opt.fIntegral    = hist != NULL && stropt.Contains("I");
   opt.fUseRange    = use_range;
   opt.fCoordErrors = false;
   opt.fUseEmpty    = false;
   opt.fBinVolume   = false;

   ROOT::Fit::DataRange range(enemin, enemax);
   ROOT::Fit::BinData   data(opt, range);
   if (hist != NULL) FillLogData(data, hist);
   else ROOT::Fit::FillData(data, graph);

   ROOT::Math::WrappedMultiTF1 wf(*f_fit);
   ROOT::Fit::Chi2Function     chi2fit(data, wf);

   return chi2fit(f_fit->GetParameters());
}

// Fit obj with f_fit
void FitTools::Fit(TObject *obj, TF1 *f_fit, Option_t *option, ROOT::Fit::Fitter &fitter, Double_t enemin, Double_t enemax, UShort_t nfits)
{
   TH1 *hist = NULL;
   TGraph *graph = NULL;
   if (HistTools::IsHist(obj)) hist = HistTools::ToHist(obj);
   else if (HistTools::IsGraph(obj)) graph = HistTools::ToGraph(obj);
   else
   {
      cerr << FG_RED_B << Form(" !!! Fit-E-Unsupported class '%s' for obj '%s'", obj->ClassName(), obj->GetName()) << RESET << endl;

      return;
   }

   TString stropt(option);

   Bool_t use_range = stropt.Contains("R");
   GetFitRange(obj, f_fit, use_range, enemin, enemax);

   fitter.Config().SetMinosErrors(stropt.Contains("E"));

   ROOT::Fit::DataOptions opt;
   opt.fIntegral    = hist != NULL && stropt.Contains("I");
   opt.fUseRange    = use_range;
   opt.fCoordErrors = false;
   opt.fUseEmpty    = false;
   opt.fBinVolume   = false;

   ROOT::Fit::DataRange range(enemin, enemax);
   ROOT::Fit::BinData   data(opt, range);
   if (hist != NULL) FillLogData(data, hist);
   else ROOT::Fit::FillData(data, graph);

   ROOT::Math::WrappedMultiTF1 wf(*f_fit);
   ROOT::Fit::Chi2Function     chi2fit(data, wf);

   CopyParameters(f_fit, fitter);
   //~ PrintParamSettings(fitter);

   for (UShort_t ifit = 0; ifit < nfits; ++ifit)
   {
      fitter.FitFCN(fitter.Config().NPar(), chi2fit, 0, data.Size(), true);
   }

   f_fit->SetFitResult(fitter.Result());
   f_fit->SetRange(enemin, enemax);
}

// Get chi2 between f_fit and all objs
Double_t FitTools::GetCombinedChiSquare(TObjArray &arr, TF1 *f_fit, Option_t *option, vector<Double_t> &enemin, vector<Double_t> &enemax, vector<Double_t> &chi2norm)
{
   for (UShort_t iobj = 0; iobj < arr.GetEntries(); ++iobj)
   {
      TObject *obj = arr[iobj];
      if (!HistTools::IsHist(obj) && !HistTools::IsGraph(obj))
      {
         cerr << FG_RED_B << Form(" !!! GetCombinedChiSquare-E-Unsupported class '%s' for obj '%s'", obj->ClassName(), obj->GetName()) << RESET << endl;

         return -1.;
      }
   }

   if (enemin.empty()) enemin.assign(arr.GetEntries(), DBL_MIN);
   if (enemax.empty()) enemax.assign(arr.GetEntries(), DBL_MAX);
   if ((UInt_t)arr.GetEntries() != enemin.size() || (UInt_t)arr.GetEntries() != enemax.size())
   {
      cerr << FG_RED_B << Form(" !!! GetCombinedChiSquare-E-Size mismatch among arr (%u), enemin (%lu) and enemax (%lu)", (UInt_t)arr.GetEntries(), enemin.size(), enemax.size()) << RESET << endl;

      return -1.;
   }

   UShort_t ndatasets = arr.GetEntries();

   TString stropt(option);

   Bool_t use_range = stropt.Contains("R");
   Double_t rangemin, rangemax;
   GetFitRange(arr, f_fit, use_range, enemin, enemax, rangemin, rangemax);

   /// array of objects needed to create the combined fit
   ROOT::Math::WrappedMultiTF1 **wmf      = new ROOT::Math::WrappedMultiTF1 *[ndatasets];
   ROOT::Fit::DataRange         *range    = new ROOT::Fit::DataRange[ndatasets];
   ROOT::Fit::BinData          **data     = new ROOT::Fit::BinData *[ndatasets];
   ROOT::Fit::Chi2Function     **chi2func = new ROOT::Fit::Chi2Function *[ndatasets];

   /// set fit options
   ROOT::Fit::DataOptions opt;
   opt.fIntegral    = stropt.Contains("I");
   opt.fUseRange    = use_range;
   opt.fCoordErrors = false;
   opt.fUseEmpty    = false;
   opt.fBinVolume   = false;

   UShort_t data_size = 0;
   for (UShort_t idataset = 0; idataset < ndatasets; ++idataset)
   {
      TObject *obj = arr[idataset];

      /// set fit energy range
      range[idataset].SetRange(enemin[idataset], enemax[idataset]);

      /// create data structure
      data[idataset] = new ROOT::Fit::BinData(opt, range[idataset]);
      if (HistTools::IsHist(obj)) FillLogData(*data[idataset], HistTools::ToHist(obj));
      else
      {
         data[idataset]->Opt().fIntegral = false;
         ROOT::Fit::FillData(*data[idataset], HistTools::ToGraph(obj));
      }
      data_size += data[idataset]->Size();

      /// create chi2 function
      wmf[idataset]      = new ROOT::Math::WrappedMultiTF1(*f_fit, 1);
      chi2func[idataset] = new ROOT::Fit::Chi2Function(*data[idataset], *wmf[idataset]);
   }

   Double_t chi2 = 0.;
   for (UShort_t idataset = 0; idataset < ndatasets; ++idataset)
   {
      chi2norm[idataset] = (*chi2func[idataset])(f_fit->GetParameters()) / data[idataset]->Size();

      chi2 += (*chi2func[idataset])(f_fit->GetParameters());
   }
   chi2 /= data_size;

   return chi2;
}

// Fit all objs in arr with f_fit
void FitTools::FitCombinedData(TObjArray &arr, TF1 *f_fit, Option_t *option, vector<Double_t> &enemin, vector<Double_t> &enemax, vector<Double_t> &chi2norm, ROOT::Fit::Fitter &fitter, UShort_t nfits)
{
   for (UShort_t iobj = 0; iobj < arr.GetEntries(); ++iobj)
   {
      TObject *obj = arr[iobj];
      if (!HistTools::IsHist(obj) && !HistTools::IsGraph(obj))
      {
         cerr << FG_RED_B << Form(" !!! FitCombinedData-E-Unsupported class '%s' for obj '%s'", obj->ClassName(), obj->GetName()) << RESET << endl;

         return;
      }
   }

   if (enemin.empty()) enemin.assign(arr.GetEntries(), DBL_MIN);
   if (enemax.empty()) enemax.assign(arr.GetEntries(), DBL_MAX);
   if ((UInt_t)arr.GetEntries() != enemin.size() || (UInt_t)arr.GetEntries() != enemax.size())
   {
      cerr << FG_RED_B << Form(" !!! FitCombinedData-E-Size mismatch among arr (%u), enemin (%lu) and enemax (%lu)", (UInt_t)arr.GetEntries(), enemin.size(), enemax.size()) << RESET << endl;

      return;
   }

   UShort_t ndatasets = arr.GetEntries();

   TString stropt(option);

   Bool_t use_range = stropt.Contains("R");
   Double_t rangemin, rangemax;
   GetFitRange(arr, f_fit, use_range, enemin, enemax, rangemin, rangemax);

   /// array of objects needed to create the combined fit
   ROOT::Math::WrappedMultiTF1 **wmf      = new ROOT::Math::WrappedMultiTF1 *[ndatasets];
   ROOT::Fit::DataRange         *range    = new ROOT::Fit::DataRange[ndatasets];
   ROOT::Fit::BinData          **data     = new ROOT::Fit::BinData *[ndatasets];
   ROOT::Fit::Chi2Function     **chi2func = new ROOT::Fit::Chi2Function *[ndatasets];

   /// input for GlobalChi2
   vector<ROOT::Math::IMultiGenFunction *> f_chi2s;
   vector< vector<Int_t> > par_indices;

   /// number of fit parameters
   UShort_t ntotpars  = f_fit->GetNpar();

   /// set parameters
   CopyParameters(f_fit, fitter);

   /// set parameters indices
   Int_t *lispar_index = new Int_t[ntotpars];
   for (UShort_t ipar = 0; ipar < ntotpars; ++ipar)
   {
      lispar_index[ipar] = ipar;
   }

   /// set fit options
   fitter.Config().SetMinosErrors(stropt.Contains("E"));
   ROOT::Fit::DataOptions opt;
   opt.fIntegral    = stropt.Contains("I");
   opt.fUseRange    = use_range;
   opt.fCoordErrors = false;
   opt.fUseEmpty    = false;
   opt.fBinVolume   = false;

   UShort_t data_size = 0;
   for (UShort_t idataset = 0; idataset < ndatasets; ++idataset)
   {
      TObject *obj = arr[idataset];

      /// set fit energy range
      range[idataset].SetRange(enemin[idataset], enemax[idataset]);

      /// create data structure
      data[idataset] = new ROOT::Fit::BinData(opt, range[idataset]);
      if (HistTools::IsHist(obj)) FillLogData(*data[idataset], HistTools::ToHist(obj));
      else
      {
         data[idataset]->Opt().fIntegral = false;
         ROOT::Fit::FillData(*data[idataset], HistTools::ToGraph(obj));
      }
      data_size += data[idataset]->Size();

      /// create parameters index vector
      par_indices.push_back(vector<Int_t>(lispar_index, lispar_index + ntotpars));

      /// create chi2 function
      wmf[idataset]      = new ROOT::Math::WrappedMultiTF1(*f_fit, 1);
      chi2func[idataset] = new ROOT::Fit::Chi2Function(*data[idataset], *wmf[idataset]);
      f_chi2s.push_back(chi2func[idataset]);
   }

   GlobalChi2 global_chi2(f_chi2s, par_indices);

   /// fit
   for (UShort_t ifit = 0; ifit < nfits; ++ifit)
   {
      fitter.FitFCN(ntotpars, global_chi2, 0, data_size, true);
   }

   for (UShort_t idataset = 0; idataset < ndatasets; ++idataset)
   {
      chi2norm[idataset] = global_chi2(idataset, fitter.Result().GetParams()) / data[idataset]->Size();
   }

   f_fit->SetFitResult(fitter.Result());
}

// Fit all objs in lis with f_fit (no modulation) and all objs in mod with f_fit (modulation)
void FitTools::FitCombinedLISData(TObjArray &lis, TObjArray &mod, TF1 *f_fit, Option_t *option, vector<FitTools::EnergyRange> &enerange, vector<Double_t> &chi2norm, vector<TF1 *> &fits,
   ROOT::Fit::Fitter &fitter, UShort_t nfits)
{
   UShort_t nlisfluxes = lis.GetEntries();
   UShort_t nmodfluxes = mod.GetEntries();
   UShort_t ndatasets  = nlisfluxes + nmodfluxes;

   TString stropt(option);
   stropt.ToUpper();

   ModulationModels::Type modmodel = ModulationModels::cast(f_fit->GetParameter(0));
   Energy::Type           energy   = Energy::cast(f_fit->GetParameter(1));
   Particle::Type         particle = Particle::cast(f_fit->GetParameter(2));
   LISModels::Type        lismodel = LISModels::cast(f_fit->GetParameter(3));

   UShort_t nmodpars    = ModulationModels::Info[modmodel].nParameters;
   UShort_t nlispars    = LISModels::Info[lismodel].nParameters;
   UShort_t nlisfitpars = 4 + nlispars;
   UShort_t nmodfitpars = 5 + nmodpars + nlispars;
   UShort_t nfreepars   = nmodpars*nmodfluxes + nlispars + 1;
   UShort_t ntotpars    = 4 + nfreepars;

   for (UShort_t iobj = 0; iobj < nlisfluxes; ++iobj)
   {
      TObject *obj = lis[iobj];
      if (!HistTools::IsHist(obj) && !HistTools::IsGraph(obj))
      {
         cerr << FG_RED_B << Form(" !!! FitCombinedLISData-E-Unsupported class '%s' for obj '%s'", obj->ClassName(), obj->GetName()) << RESET << endl;

         return;
      }
   }
   for (UShort_t iobj = 0; iobj < nmodfluxes; ++iobj)
   {
      TObject *obj = mod[iobj];
      if (!HistTools::IsHist(obj) && !HistTools::IsGraph(obj))
      {
         cerr << FG_RED_B << Form(" !!! FitCombinedLISData-E-Unsupported class '%s' for obj '%s'", obj->ClassName(), obj->GetName()) << RESET << endl;

         return;
      }
   }

   if (enerange.empty()) enerange.assign(ndatasets, EnergyRange{ DBL_MIN, DBL_MAX });
   if (enerange.size() != ndatasets)
   {
      cerr << FG_RED_B << Form(" !!! FitCombinedLISData-E-Size mismatch among lis (%u), mod (%u) and range (%lu)",
         nlisfluxes, nmodfluxes, enerange.size()) << RESET << endl;

      return;
   }

   Bool_t use_range = stropt.Contains("R");
   Double_t rangemin, rangemax;
   GetFitRange(lis, mod, f_fit, use_range, enerange, rangemin, rangemax);

   /// array of objects needed to create the combined fit
   ROOT::Math::WrappedMultiTF1 **wmf      = new ROOT::Math::WrappedMultiTF1 *[ndatasets];
   ROOT::Fit::DataRange         *range    = new ROOT::Fit::DataRange[ndatasets];
   ROOT::Fit::BinData          **data     = new ROOT::Fit::BinData *[ndatasets];
   ROOT::Fit::Chi2Function     **chi2func = new ROOT::Fit::Chi2Function *[ndatasets];

   /// input for GlobalChi2
   vector<ROOT::Math::IMultiGenFunction *> f_chi2s;
   vector< vector<Int_t> > par_indices;

   /// set parameters and indices
   Int_t **par_index = new Int_t *[ndatasets]();
   CopyParameters(f_fit, nlisfluxes, nmodfluxes, fitter, par_index);

   /// set fit options
   fitter.Config().SetMinosErrors(stropt.Contains("E"));
   ROOT::Fit::DataOptions opt;
   opt.fIntegral    = stropt.Contains("I");
   opt.fUseRange    = use_range;
   opt.fCoordErrors = false;
   opt.fUseEmpty    = false;
   opt.fBinVolume   = false;

   UShort_t data_size = 0;
   UShort_t idataset = 0;

   for (UShort_t iflux = 0; iflux < nlisfluxes; ++iflux, ++idataset)
   {
      TObject *obj = lis[iflux];

      /// set fit energy range
      range[idataset].SetRange(enerange[idataset].Min, enerange[idataset].Max);

      /// create data structure
      data[idataset] = new ROOT::Fit::BinData(opt, range[idataset]);
      if (HistTools::IsHist(obj)) FillLogData(*data[idataset], HistTools::ToHist(obj));
      else
      {
         data[idataset]->Opt().fIntegral = false;
         ROOT::Fit::FillData(*data[idataset], HistTools::ToGraph(obj));
      }
      data_size += data[idataset]->Size();

      /// create parameters index vector
      par_indices.push_back(vector<Int_t>(par_index[idataset], par_index[idataset] + nlisfitpars));

      /// create chi2 function
      fits[idataset] = LISModels::CreateFunction(Form("f_lis_%s_combfit_%02u", LISModels::Info[lismodel].Name, iflux),
         enerange[idataset].Min, enerange[idataset].Max, lismodel, particle, energy);
      CopyParameters(f_fit, fits[idataset]);
      wmf[idataset]      = new ROOT::Math::WrappedMultiTF1(*fits[idataset], 1);
      chi2func[idataset] = new ROOT::Fit::Chi2Function(*data[idataset], *wmf[idataset]);
      f_chi2s.push_back(chi2func[idataset]);
   }

   for (UShort_t iflux = 0; iflux < nmodfluxes; ++iflux, ++idataset)
   {
      TObject *obj = mod[iflux];

      /// set fit energy range
      range[idataset].SetRange(enerange[idataset].Min, enerange[idataset].Max);

      /// create data structure
      data[idataset] = new ROOT::Fit::BinData(opt, range[idataset]);
      if (HistTools::IsHist(obj)) FillLogData(*data[idataset], HistTools::ToHist(obj));
      else
      {
         data[idataset]->Opt().fIntegral = false;
         ROOT::Fit::FillData(*data[idataset], HistTools::ToGraph(obj));
      }
      data_size += data[idataset]->Size();

      /// create parameters index vector
      par_indices.push_back(vector<Int_t>(par_index[idataset], par_index[idataset] + nmodfitpars));

      /// create chi2 function
      TF1 *f = (TF1*)f_fit->IsA()->New();
      f_fit->Copy(*f);
      f->SetName(Form("f_modlis_%s_%s_combfit_%02u", ModulationModels::Info[modmodel].Name, LISModels::Info[lismodel].Name, iflux));
      f->SetRange(enerange[idataset].Min, enerange[idataset].Max);
      fits[idataset]     = f;
      wmf[idataset]      = new ROOT::Math::WrappedMultiTF1(*f, 1);
      chi2func[idataset] = new ROOT::Fit::Chi2Function(*data[idataset], *wmf[idataset]);
      f_chi2s.push_back(chi2func[idataset]);
   }

   GlobalChi2 global_chi2(f_chi2s, par_indices);

   /// fit
   for (UShort_t ifit = 0; ifit < nfits; ++ifit)
   {
      fitter.FitFCN(ntotpars, global_chi2, 0, data_size, true);
   }

   for (idataset = 0; idataset < ndatasets; ++idataset)
   {
      chi2norm[idataset] = global_chi2(idataset, fitter.Result().GetParams()) / data[idataset]->Size();
      fits[idataset]->SetFitResult(fitter.Result(), par_index[idataset]);
   }

   f_fit->SetFitResult(fitter.Result(), par_index[nlisfluxes]);
}

void FitTools::FitCombinedLISData(ModulationModels::ForceField *ffa, TObjArray &lis, TObjArray &mod, Option_t *option, vector<FitTools::EnergyRange> &enerange, vector<Double_t> &chi2norm, vector<TF1 *> &fits,
   ROOT::Fit::Fitter &fitter, UShort_t nfits)
{
   UShort_t nlisfluxes = lis.GetEntries();
   UShort_t nmodfluxes = mod.GetEntries();
   UShort_t ndatasets  = nlisfluxes + nmodfluxes;

   TF1 *f_fit = ffa->GetTF1Pointer();

   TString stropt(option);
   stropt.ToUpper();

   UShort_t nmodpars    = ffa->GetNModulationParameters();
   UShort_t nlispars    = ffa->GetNLISParameters();
   UShort_t nlisfitpars = nlispars;
   UShort_t nmodfitpars = nmodpars + nlispars;
   UShort_t nfreepars   = nmodpars*nmodfluxes + nlispars;
   UShort_t ntotpars    = nfreepars;

   for (UShort_t iobj = 0; iobj < nlisfluxes; ++iobj)
   {
      TObject *obj = lis[iobj];
      if (!HistTools::IsHist(obj) && !HistTools::IsGraph(obj))
      {
         cerr << FG_RED_B << Form(" !!! FitCombinedLISData-E-Unsupported class '%s' for obj '%s'", obj->ClassName(), obj->GetName()) << RESET << endl;

         return;
      }
   }
   for (UShort_t iobj = 0; iobj < nmodfluxes; ++iobj)
   {
      TObject *obj = mod[iobj];
      if (!HistTools::IsHist(obj) && !HistTools::IsGraph(obj))
      {
         cerr << FG_RED_B << Form(" !!! FitCombinedLISData-E-Unsupported class '%s' for obj '%s'", obj->ClassName(), obj->GetName()) << RESET << endl;

         return;
      }
   }

   if (enerange.empty()) enerange.assign(ndatasets, EnergyRange{ DBL_MIN, DBL_MAX });
   if (enerange.size() != ndatasets)
   {
      cerr << FG_RED_B << Form(" !!! FitCombinedLISData-E-Size mismatch among lis (%u), mod (%u) and range (%lu)",
         nlisfluxes, nmodfluxes, enerange.size()) << RESET << endl;

      return;
   }

   Bool_t use_range = stropt.Contains("R");
   Double_t rangemin, rangemax;
   GetFitRange(lis, mod, f_fit, use_range, enerange, rangemin, rangemax);

   /// array of objects needed to create the combined fit
   ROOT::Math::WrappedMultiTF1 **wmf      = new ROOT::Math::WrappedMultiTF1 *[ndatasets];
   ROOT::Fit::DataRange         *range    = new ROOT::Fit::DataRange[ndatasets];
   ROOT::Fit::BinData          **data     = new ROOT::Fit::BinData *[ndatasets];
   ROOT::Fit::Chi2Function     **chi2func = new ROOT::Fit::Chi2Function *[ndatasets];

   /// input for GlobalChi2
   vector<ROOT::Math::IMultiGenFunction *> f_chi2s;
   vector< vector<Int_t> > par_indices;

   /// set parameters and indices
   Int_t **par_index = new Int_t *[ndatasets]();
   CopyParameters(ffa, f_fit, nlisfluxes, nmodfluxes, fitter, par_index);

   /// set fit options
   fitter.Config().SetMinosErrors(stropt.Contains("E"));
   ROOT::Fit::DataOptions opt;
   opt.fIntegral    = stropt.Contains("I");
   opt.fUseRange    = use_range;
   opt.fCoordErrors = false;
   opt.fUseEmpty    = false;
   opt.fBinVolume   = false;

   UShort_t data_size = 0;
   UShort_t idataset  = 0;

   for (UShort_t iflux = 0; iflux < nlisfluxes; ++iflux, ++idataset)
   {
      TObject *obj = lis[iflux];

      /// set fit energy range
      range[idataset].SetRange(enerange[idataset].Min, enerange[idataset].Max);

      /// create data structure
      data[idataset] = new ROOT::Fit::BinData(opt, range[idataset]);
      if (HistTools::IsHist(obj)) FillLogData(*data[idataset], HistTools::ToHist(obj));
      else
      {
         data[idataset]->Opt().fIntegral = false;
         ROOT::Fit::FillData(*data[idataset], HistTools::ToGraph(obj));
      }
      data_size += data[idataset]->Size();

      /// create parameters index vector
      par_indices.push_back(vector<Int_t>(par_index[idataset], par_index[idataset] + nlisfitpars));

      /// create chi2 function
      fits[idataset] = (TF1*)ffa->GetLISPointer()->IsA()->New();
      ffa->GetLISPointer()->Copy(*fits[idataset]);
      fits[idataset]->SetName(Form("f_lis_combfit_%02u", iflux));

      wmf[idataset]      = new ROOT::Math::WrappedMultiTF1(*fits[idataset], 1);
      chi2func[idataset] = new ROOT::Fit::Chi2Function(*data[idataset], *wmf[idataset]);
      f_chi2s.push_back(chi2func[idataset]);
   }

   for (UShort_t iflux = 0; iflux < nmodfluxes; ++iflux, ++idataset)
   {
      TObject *obj = mod[iflux];

      /// set fit energy range
      range[idataset].SetRange(enerange[idataset].Min, enerange[idataset].Max);

      /// create data structure
      data[idataset] = new ROOT::Fit::BinData(opt, range[idataset]);
      if (HistTools::IsHist(obj)) FillLogData(*data[idataset], HistTools::ToHist(obj));
      else
      {
         data[idataset]->Opt().fIntegral = false;
         ROOT::Fit::FillData(*data[idataset], HistTools::ToGraph(obj));
      }
      data_size += data[idataset]->Size();

      /// create parameters index vector
      par_indices.push_back(vector<Int_t>(par_index[idataset], par_index[idataset] + nmodfitpars));

      /// create chi2 function
      TF1 *f = (TF1*)f_fit->IsA()->New();
      f_fit->Copy(*f);
      f->SetName(Form("f_modlis_ffa_combfit_%02u", iflux));
      fits[idataset]     = f;

      wmf[idataset]      = new ROOT::Math::WrappedMultiTF1(*f, 1);
      chi2func[idataset] = new ROOT::Fit::Chi2Function(*data[idataset], *wmf[idataset]);
      f_chi2s.push_back(chi2func[idataset]);
   }

   GlobalChi2 global_chi2(f_chi2s, par_indices);
   /// fit
   for (UShort_t ifit = 0; ifit < nfits; ++ifit)
   {
      fitter.FitFCN(ntotpars, global_chi2, 0, data_size, true);
   }

   for (idataset = 0; idataset < ndatasets; ++idataset)
   {
      chi2norm[idataset] = global_chi2(idataset, fitter.Result().GetParams()) / data[idataset]->Size();
      fits[idataset]->SetFitResult(fitter.Result(), par_index[idataset]);
   }

   f_fit->SetFitResult(fitter.Result(), par_index[nlisfluxes]);
}

// Fit all objs in lis with f_fit (no modulation) and all objs in mod with f_fit (modulation); apply 1/x -> 1/x + 1/shift
void FitTools::FitCombinedLISDataWithShift(TObjArray &lis, TObjArray &mod, TF1 *f_fit, Double_t shift, Option_t *option, vector<FitTools::EnergyRange> &enerange, vector<Double_t> &chi2norm, vector<TF1 *> &fits,
   ROOT::Fit::Fitter &fitter, UShort_t nfits)
{
   UShort_t nlisfluxes = lis.GetEntries();
   UShort_t nmodfluxes = mod.GetEntries();
   UShort_t ndatasets  = nlisfluxes + nmodfluxes;

   TString stropt(option);
   stropt.ToUpper();

   ModulationModels::Type modmodel = ModulationModels::cast(f_fit->GetParameter(0));
   Energy::Type           energy   = Energy::cast(f_fit->GetParameter(1));
   Particle::Type         particle = Particle::cast(f_fit->GetParameter(2));
   LISModels::Type        lismodel = LISModels::cast(f_fit->GetParameter(3));

   UShort_t nmodpars    = ModulationModels::Info[modmodel].nParameters;
   UShort_t nlispars    = LISModels::Info[lismodel].nParameters;
   UShort_t nlisfitpars = 4 + nlispars;
   UShort_t nmodfitpars = 5 + nmodpars + nlispars;
   UShort_t nfreepars   = nmodpars*nmodfluxes + nlispars + 1;
   UShort_t ntotpars    = 4 + nfreepars;

   for (UShort_t iobj = 0; iobj < nlisfluxes; ++iobj)
   {
      TObject *obj = lis[iobj];
      if (!HistTools::IsHist(obj) && !HistTools::IsGraph(obj))
      {
         cerr << FG_RED_B << Form(" !!! FitCombinedLISDataWithShift-E-Unsupported class '%s' for obj '%s'", obj->ClassName(), obj->GetName()) << RESET << endl;

         return;
      }
   }
   for (UShort_t iobj = 0; iobj < nmodfluxes; ++iobj)
   {
      TObject *obj = mod[iobj];
      if (!HistTools::IsHist(obj) && !HistTools::IsGraph(obj))
      {
         cerr << FG_RED_B << Form(" !!! FitCombinedLISDataWithShift-E-Unsupported class '%s' for obj '%s'", obj->ClassName(), obj->GetName()) << RESET << endl;

         return;
      }
   }

   if (enerange.empty()) enerange.assign(ndatasets, EnergyRange{ DBL_MIN, DBL_MAX });
   if (enerange.size() != ndatasets)
   {
      cerr << FG_RED_B << Form(" !!! FitCombinedLISDataWithShift-E-Size mismatch among lis (%u), mod (%u) and range (%lu)",
         nlisfluxes, nmodfluxes, enerange.size()) << RESET << endl;

      return;
   }

   Bool_t use_range = stropt.Contains("R");
   Double_t rangemin, rangemax;
   GetFitRange(lis, mod, f_fit, use_range, enerange, rangemin, rangemax);

   /// array of objects needed to create the combined fit
   ROOT::Math::WrappedMultiTF1 **wmf      = new ROOT::Math::WrappedMultiTF1 *[ndatasets];
   ROOT::Fit::DataRange         *range    = new ROOT::Fit::DataRange[ndatasets];
   ROOT::Fit::BinData          **data     = new ROOT::Fit::BinData *[ndatasets];
   ROOT::Fit::Chi2Function     **chi2func = new ROOT::Fit::Chi2Function *[ndatasets];

   /// input for GlobalChi2
   vector<ROOT::Math::IMultiGenFunction *> f_chi2s;
   vector< vector<Int_t> > par_indices;

   /// set parameters and indices
   Int_t **par_index = new Int_t *[ndatasets]();
   CopyParameters(f_fit, nlisfluxes, nmodfluxes, fitter, par_index);

   /// set fit options
   fitter.Config().SetMinosErrors(stropt.Contains("E"));
   ROOT::Fit::DataOptions opt;
   opt.fIntegral    = stropt.Contains("I");
   opt.fUseRange    = use_range;
   opt.fCoordErrors = false;
   opt.fUseEmpty    = false;
   opt.fBinVolume   = false;

   UShort_t data_size = 0;
   UShort_t idataset = 0;

   for (UShort_t iflux = 0; iflux < nlisfluxes; ++iflux, ++idataset)
   {
      TObject *obj = lis[iflux];

      /// set fit energy range
      range[idataset].SetRange(enerange[idataset].Min, enerange[idataset].Max);

      /// create data structure
      data[idataset] = new ROOT::Fit::BinData(opt, range[idataset]);
      if (HistTools::IsHist(obj)) FillLogData(*data[idataset], HistTools::ToHist(obj));
      else
      {
         data[idataset]->Opt().fIntegral = false;
         ROOT::Fit::FillData(*data[idataset], HistTools::ToGraph(obj));
      }
      data_size += data[idataset]->Size();

      /// create parameters index vector
      par_indices.push_back(vector<Int_t>(par_index[idataset], par_index[idataset] + nlisfitpars));

      /// create chi2 function

      TF1 *f = LISModels::CreateFunction(Form("f_lis_%s_combfit_%02u", LISModels::Info[lismodel].Name, iflux),
         enerange[idataset].Min, enerange[idataset].Max, lismodel, particle, energy);
      CopyParameters(f_fit, f);
      fits[idataset]     = CreateModelWithShift(f, shift);
      wmf[idataset]      = new ROOT::Math::WrappedMultiTF1(*fits[idataset], 1);
      chi2func[idataset] = new ROOT::Fit::Chi2Function(*data[idataset], *wmf[idataset]);
      f_chi2s.push_back(chi2func[idataset]);
   }

   for (UShort_t iflux = 0; iflux < nmodfluxes; ++iflux, ++idataset)
   {
      TObject *obj = mod[iflux];

      /// set fit energy range
      range[idataset].SetRange(enerange[idataset].Min, enerange[idataset].Max);

      /// create data structure
      data[idataset] = new ROOT::Fit::BinData(opt, range[idataset]);
      if (HistTools::IsHist(obj)) FillLogData(*data[idataset], HistTools::ToHist(obj));
      else
      {
         data[idataset]->Opt().fIntegral = false;
         ROOT::Fit::FillData(*data[idataset], HistTools::ToGraph(obj));
      }
      data_size += data[idataset]->Size();

      /// create parameters index vector
      par_indices.push_back(vector<Int_t>(par_index[idataset], par_index[idataset] + nmodfitpars));

      /// create chi2 function
      TF1 *f = (TF1*)f_fit->IsA()->New();
      f_fit->Copy(*f);
      f->SetName(Form("f_modlis_%s_%s_combfit_%02u", ModulationModels::Info[modmodel].Name, LISModels::Info[lismodel].Name, iflux));
      fits[idataset]     = f;
      wmf[idataset]      = new ROOT::Math::WrappedMultiTF1(*f, 1);
      chi2func[idataset] = new ROOT::Fit::Chi2Function(*data[idataset], *wmf[idataset]);
      f_chi2s.push_back(chi2func[idataset]);
   }

   GlobalChi2 global_chi2(f_chi2s, par_indices);

   /// fit
   for (UShort_t ifit = 0; ifit < nfits; ++ifit)
   {
      fitter.FitFCN(ntotpars, global_chi2, 0, data_size, true);
   }

   for (idataset = 0; idataset < ndatasets; ++idataset)
   {
      chi2norm[idataset] = global_chi2(idataset, fitter.Result().GetParams()) / data[idataset]->Size();
      fits[idataset]->SetFitResult(fitter.Result(), par_index[idataset]);
   }

   f_fit->SetFitResult(fitter.Result(), par_index[nlisfluxes]);
}

// Fit all objs in lis with f_fit (no modulation) and all objs in mod with f_fit (modulation)
FitTools::GlobalChi2 *FitTools::BuildGlobalChi2(TObjArray &lis, TObjArray &mod, TF1 *f_fit, Option_t *option, vector<FitTools::EnergyRange> &enerange, ROOT::Fit::Fitter &fitter)
{
   UShort_t nlisfluxes = lis.GetEntries();
   UShort_t nmodfluxes = mod.GetEntries();
   UShort_t ndatasets  = nlisfluxes + nmodfluxes;

   TString stropt(option);
   stropt.ToUpper();

   ModulationModels::Type modmodel = ModulationModels::cast(f_fit->GetParameter(0));
   Energy::Type           energy   = Energy::cast(f_fit->GetParameter(1));
   Particle::Type         particle = Particle::cast(f_fit->GetParameter(2));
   LISModels::Type        lismodel = LISModels::cast(f_fit->GetParameter(3));

   UShort_t nmodpars    = ModulationModels::Info[modmodel].nParameters;
   UShort_t nlispars    = LISModels::Info[lismodel].nParameters;
   UShort_t nlisfitpars = 4 + nlispars;
   UShort_t nmodfitpars = 5 + nmodpars + nlispars;

   for (UShort_t iobj = 0; iobj < nlisfluxes; ++iobj)
   {
      TObject *obj = lis[iobj];
      if (!HistTools::IsHist(obj) && !HistTools::IsGraph(obj))
      {
         cerr << FG_RED_B << Form(" !!! BuildGlobalChi2-E-Unsupported class '%s' for obj '%s'", obj->ClassName(), obj->GetName()) << RESET << endl;

         return NULL;
      }
   }
   for (UShort_t iobj = 0; iobj < nmodfluxes; ++iobj)
   {
      TObject *obj = mod[iobj];
      if (!HistTools::IsHist(obj) && !HistTools::IsGraph(obj))
      {
         cerr << FG_RED_B << Form(" !!! BuildGlobalChi2-E-Unsupported class '%s' for obj '%s'", obj->ClassName(), obj->GetName()) << RESET << endl;

         return NULL;
      }
   }

   if (enerange.empty()) enerange.assign(ndatasets, EnergyRange{ DBL_MIN, DBL_MAX });
   if (enerange.size() != ndatasets)
   {
      cerr << FG_RED_B << Form(" !!! BuildGlobalChi2-E-Size mismatch among lis (%u), mod (%u) and range (%lu)",
         nlisfluxes, nmodfluxes, enerange.size()) << RESET << endl;

      return NULL;
   }

   Bool_t use_range = stropt.Contains("R");
   Double_t rangemin, rangemax;
   GetFitRange(lis, mod, f_fit, use_range, enerange, rangemin, rangemax);

   /// array of objects needed to create the combined fit
   ROOT::Math::WrappedMultiTF1 **wmf      = new ROOT::Math::WrappedMultiTF1 *[ndatasets];
   ROOT::Fit::DataRange         *range    = new ROOT::Fit::DataRange[ndatasets];
   ROOT::Fit::BinData          **data     = new ROOT::Fit::BinData *[ndatasets];
   ROOT::Fit::Chi2Function     **chi2func = new ROOT::Fit::Chi2Function *[ndatasets];

   /// input for GlobalChi2
   vector<ROOT::Math::IMultiGenFunction *> f_chi2s;
   vector< vector<Int_t> > par_indices;

   /// set parameters and indices
   Int_t **par_index = new Int_t *[ndatasets]();
   CopyParameters(f_fit, nlisfluxes, nmodfluxes, fitter, par_index);

   /// set fit options
   ROOT::Fit::DataOptions opt;
   opt.fIntegral    = stropt.Contains("I");
   opt.fUseRange    = use_range;
   opt.fCoordErrors = false;
   opt.fUseEmpty    = false;
   opt.fBinVolume   = false;

   UShort_t idataset = 0;
   for (UShort_t iflux = 0; iflux < nlisfluxes; ++iflux, ++idataset)
   {
      TObject *obj = lis[iflux];

      /// set fit energy range
      range[idataset].SetRange(enerange[idataset].Min, enerange[idataset].Max);

      /// create data structure
      data[idataset] = new ROOT::Fit::BinData(opt, range[idataset]);
      if (HistTools::IsHist(obj)) FillLogData(*data[idataset], HistTools::ToHist(obj));
      else
      {
         data[idataset]->Opt().fIntegral = false;
         ROOT::Fit::FillData(*data[idataset], HistTools::ToGraph(obj));
      }

      /// create parameters index vector
      par_indices.push_back(vector<Int_t>(par_index[idataset], par_index[idataset] + nlisfitpars));

      /// create chi2 function
      TF1 *f = LISModels::CreateFunction(Form("f_lis_%s_combfit_%02u", LISModels::Info[lismodel].Name, iflux),
         enerange[idataset].Min, enerange[idataset].Max, lismodel, particle, energy);
      CopyParameters(f_fit, f);
      wmf[idataset]      = new ROOT::Math::WrappedMultiTF1(*f, 1);
      chi2func[idataset] = new ROOT::Fit::Chi2Function(*data[idataset], *wmf[idataset]);
      f_chi2s.push_back(chi2func[idataset]);
   }

   for (UShort_t iflux = 0; iflux < nmodfluxes; ++iflux, ++idataset)
   {
      TObject *obj = mod[iflux];

      /// set fit energy range
      range[idataset].SetRange(enerange[idataset].Min, enerange[idataset].Max);

      /// create data structure
      data[idataset] = new ROOT::Fit::BinData(opt, range[idataset]);
      if (HistTools::IsHist(obj)) FillLogData(*data[idataset], HistTools::ToHist(obj));
      else
      {
         data[idataset]->Opt().fIntegral = false;
         ROOT::Fit::FillData(*data[idataset], HistTools::ToGraph(obj));
      }

      /// create parameters index vector
      par_indices.push_back(vector<Int_t>(par_index[idataset], par_index[idataset] + nmodfitpars));

      /// create chi2 function
      TF1 *f = (TF1*)f_fit->IsA()->New();
      f_fit->Copy(*f);
      f->SetName(Form("f_modlis_%s_%s_combfit_%02u", ModulationModels::Info[modmodel].Name, LISModels::Info[lismodel].Name, iflux));
      f->SetRange(enerange[idataset].Min, enerange[idataset].Max);
      wmf[idataset]      = new ROOT::Math::WrappedMultiTF1(*f, 1);
      chi2func[idataset] = new ROOT::Fit::Chi2Function(*data[idataset], *wmf[idataset]);
      f_chi2s.push_back(chi2func[idataset]);
   }

   GlobalChi2 *global_chi2 = new GlobalChi2(f_chi2s, par_indices);

   return global_chi2;
}

void FitTools::FitResult::Copy(FitResult *obj, Bool_t copy_result)
{
   Particle = obj->Particle;
   Energy   = obj->Energy;

   Dataset  = obj->Dataset;
   Data     = obj->Data;
   Range[0] = obj->Range[0];
   Range[1] = obj->Range[1];

   if (copy_result)
   {
      const_cast<ROOT::Fit::FitResult &>(Fitter.Result()) = obj->Fitter.Result();
      Fitter.Config().SetFromFitResult(Fitter.Result());

      FitModel = obj->FitModel;
      Chi2Norm = obj->Chi2Norm;

      residuals_computed    = obj->residuals_computed;
      model_errors_computed = obj->model_errors_computed;

      if (model_errors_computed)
      {
         ConfidenceInterval = obj->ConfidenceInterval;
         FitError           = obj->FitError;
      }
      if (residuals_computed)
      {
         FitRatio    = obj->FitRatio;
         FitResidual = obj->FitResidual;
      }
   }
}

void FitTools::FitResult::Fit(Option_t *option, UShort_t nfits)
{
   FitTools::SetCommonFitterOptions(Fitter);
   FitTools::Fit(Data, FitModel, option, Fitter, Range[0], Range[1], nfits);
   FitModel->GetRange(Range[0], Range[1]);

   Chi2Norm = Fitter.Result().Chi2() / Fitter.Result().Ndf();

   residuals_computed    = false;
   model_errors_computed = false;
}

void FitTools::FitResult::RescaleDataErrors()
{
   Double_t chi2_corr = TMath::Sqrt(Fitter.Result().Chi2() / Fitter.Result().Ndf());
   for (UShort_t ibin = 1; ibin <= Data->GetNbinsX(); ++ibin)
   {
      Double_t dy = Data->GetBinError(ibin);
      Data->SetBinError(ibin, dy*chi2_corr);
   }
}

void FitTools::FitResult::ComputeResiduals(Bool_t use_range, Bool_t use_integral, Bool_t is_log, Double_t confint, Bool_t force)
{
   if (!force && residuals_computed) return;

   FitRatio = (TH1D *)HistTools::GetResiduals(Data, FitModel, "_fitratio", use_range, use_integral, is_log, 5, 1, confint, &Fitter);
   HistTools::CopyStyle(Data, FitRatio);

   FitResidual = (TH1D *)HistTools::GetResiduals(Data, FitModel, "_fitresidual", use_range, use_integral, is_log, 1, 0, confint, &Fitter);
   HistTools::CopyStyle(Data, FitResidual);

   residuals_computed = true;
}

void FitTools::FitResult::ComputeModelErrors(Bool_t use_range, Bool_t use_integral, Bool_t is_log, Double_t confint, Bool_t force)
{
   if (!force && model_errors_computed) return;

   ConfidenceInterval = (TH1D *)HistTools::GetFitError(Data, FitModel, "_confint", use_range, use_integral, is_log, 10, DBL_MAX, confint, &Fitter);
   #if ROOT_VERSION_CODE >= ROOT_VERSION(5,34,36)
   // SetFillColorAlpha method supported only from ROOT 5.34/36
   if (gStyle->GetCanvasPreferGL()) ConfidenceInterval->SetFillColorAlpha(kRed, 0.5);
   else ConfidenceInterval->SetFillColor(kRed - 9);
   #else
   ConfidenceInterval->SetFillColor(kRed - 9);
   #endif
   ConfidenceInterval->SetLineColor(kGray + 1);
   ConfidenceInterval->SetFillStyle(1001);
   ConfidenceInterval->SetMarkerSize(0);

   FitError = (TH1D *)HistTools::GetFitError(Data, FitModel, "_fiterr", use_range, use_integral, is_log, 11, 0., confint, &Fitter);
   #if ROOT_VERSION_CODE >= ROOT_VERSION(5,34,36)
   // SetFillColorAlpha method supported only from ROOT 5.34/36
   if (gStyle->GetCanvasPreferGL()) FitError->SetFillColorAlpha(kRed, 0.5);
   else FitError->SetFillColor(kRed - 9);
   #else
   FitError->SetFillColor(kRed - 9);
   #endif
   FitError->SetLineColor(kGray + 1);
   FitError->SetFillStyle(1001);
   FitError->SetMarkerSize(0);

   model_errors_computed = true;
}

TDirectory *FitTools::FitResult::Write(const Char_t *dirname)
{
   TDirectory *cwd = gDirectory;
   TDirectory *dir = cwd->mkdir(dirname);
   dir->cd();

   TH1F *hpx = new TH1F("", "", FitModel->GetNpx(), HistTools::BuildLogBins(Range[0], Range[1], FitModel->GetNpx()));
   hpx->SetDirectory(NULL);

   TParameter<int>    pi;
   TParameter<double> pd;

   pi.SetVal(Particle);
   pi.Write("Particle");

   pi.SetVal(Energy);
   pi.Write("Energy");

   pi.SetVal(Dataset->Experiment->Type);
   pi.Write("Experiment");

   UShort_t idataset = Experiments::iDataset(Dataset);
   pi.SetVal(idataset);
   pi.Write("Dataset");

   pi.SetVal(Experiments::iMeasurement(Dataset->Experiment->Type, idataset, Data));
   pi.Write("Measurement");

   pd.SetVal(Range[0]);
   pd.Write("Range1");

   pd.SetVal(Range[1]);
   pd.Write("Range2");

   Data->Write("Data");

   FitModel->SetParent(hpx);
   FitModel->Write("FitModel");
   FitModel->SetParent(NULL);

   pd.SetVal(Chi2Norm);
   pd.Write("Chi2Norm");

   ConfidenceInterval->Write("ConfidenceInterval");
   FitRatio->Write("FitRatio");
   FitResidual->Write("FitResidual");
   FitError->Write("FitError");

   cwd->cd();

   delete hpx;

   return dir;
}

void FitTools::FitResult::Read()
{
   TParameter<int>    *pi;
   TParameter<double> *pd;

   gDirectory->GetObject("Particle", pi);
   Particle = Particle::cast(pi->GetVal());

   gDirectory->GetObject("Energy", pi);
   Energy = Energy::cast(pi->GetVal());

   gDirectory->GetObject("Experiment", pi);
   UShort_t iexperiment = pi->GetVal();

   gDirectory->GetObject("Dataset", pi);
   UShort_t idataset = pi->GetVal();

   Dataset = &Experiments::Info[iexperiment].Dataset[idataset];

   gDirectory->GetObject("Range1", pd);
   Range[0] = pd->GetVal();

   gDirectory->GetObject("Range2", pd);
   Range[1] = pd->GetVal();

   gDirectory->GetObject("Chi2Norm", pd);
   Chi2Norm = pd->GetVal();

   gDirectory->GetObject("Data", Data);
   gDirectory->GetObject("ConfidenceInterval", ConfidenceInterval);
   gDirectory->GetObject("FitRatio", FitRatio);
   gDirectory->GetObject("FitResidual", FitResidual);
   gDirectory->GetObject("FitError", FitError);
   gDirectory->GetObject("FitModel", FitModel);

   TH1F *hpx = new TH1F("", "", FitModel->GetNpx(), HistTools::BuildLogBins(Range[0], Range[1], FitModel->GetNpx()));
   hpx->SetDirectory(NULL);
   FitModel->SetParent(hpx);
}

void FitTools::LISFitResult::Copy(LISFitResult *obj)
{
   Particle = obj->Particle;
   Energy   = obj->Energy;
   LISModel = obj->LISModel;

   Dataset  = obj->Dataset;
   Data     = obj->Data;
   Range[0] = obj->Range[0];
   Range[1] = obj->Range[1];

   const_cast<ROOT::Fit::FitResult &>(Fitter.Result()) = obj->Fitter.Result();
   Fitter.Config().SetFromFitResult(Fitter.Result());

   ConfidenceInterval = obj->ConfidenceInterval;
   FitRatio           = obj->FitRatio;
   FitResidual        = obj->FitResidual;
   FitError           = obj->FitError;
}

void FitTools::LISFitResult::Fit(Option_t *option, UShort_t nfits)
{
   FitTools::SetCommonFitterOptions(Fitter);
   FitTools::Fit(Data, FitModel, option, Fitter, Range[0], Range[1], nfits);
   FitModel->GetRange(Range[0], Range[1]);

   residuals_computed    = false;
   model_errors_computed = false;
}

void FitTools::LISFitResult::RescaleDataErrors()
{
   Double_t chi2_corr = TMath::Sqrt(Fitter.Result().Chi2() / Fitter.Result().Ndf());
   for (UShort_t ibin = 1; ibin <= Data->GetNbinsX(); ++ibin)
   {
      Double_t dy = Data->GetBinError(ibin);
      Data->SetBinError(ibin, dy*chi2_corr);
   }
}

void FitTools::LISFitResult::ComputeResiduals(Bool_t use_range, Bool_t use_integral, Bool_t is_log, Double_t confint)
{
   if (residuals_computed) return;

   FitRatio = (TH1D *)HistTools::GetResiduals(Data, FitModel, "_fitratio", use_range, use_integral, is_log, 5, 1, confint, &Fitter);
   HistTools::CopyStyle(Data, FitRatio);

   FitResidual = (TH1D *)HistTools::GetResiduals(Data, FitModel, "_fitresidual", use_range, use_integral, is_log, 1, 0, confint, &Fitter);
   HistTools::CopyStyle(Data, FitResidual);

   residuals_computed = true;
}

void FitTools::LISFitResult::ComputeModelErrors(Bool_t use_range, Bool_t use_integral, Bool_t is_log, Double_t confint)
{
   if (model_errors_computed) return;

   ConfidenceInterval = (TH1D *)HistTools::GetFitError(Data, FitModel, "_confint", use_range, use_integral, is_log, 10, DBL_MAX, confint, &Fitter);
   #if ROOT_VERSION_CODE >= ROOT_VERSION(5,34,36)
   // SetFillColorAlpha method supported only from ROOT 5.34/36
   if (gStyle->GetCanvasPreferGL()) ConfidenceInterval->SetFillColorAlpha(kRed, 0.5);
   else ConfidenceInterval->SetFillColor(kRed - 9);
   #else
   ConfidenceInterval->SetFillColor(kRed - 9);
   #endif
   ConfidenceInterval->SetLineColor(kGray + 1);
   ConfidenceInterval->SetFillStyle(1001);
   ConfidenceInterval->SetMarkerSize(0);

   FitError = (TH1D *)HistTools::GetFitError(Data, FitModel, "_fiterr", use_range, use_integral, is_log, 11, 0., confint, &Fitter);
   #if ROOT_VERSION_CODE >= ROOT_VERSION(5,34,36)
   // SetFillColorAlpha method supported only from ROOT 5.34/36
   if (gStyle->GetCanvasPreferGL()) FitError->SetFillColorAlpha(kRed, 0.5);
   else FitError->SetFillColor(kRed - 9);
   #else
   FitError->SetFillColor(kRed - 9);
   #endif
   FitError->SetLineColor(kGray + 1);
   FitError->SetFillStyle(1001);
   FitError->SetMarkerSize(0);

   model_errors_computed = true;
}

void FitTools::SplineFitResult::Copy(SplineFitResult &obj)
{
   Particle = obj.Particle;
   Energy   = obj.Energy;

   Dataset  = obj.Dataset;
   Data     = obj.Data;
   Range[0] = obj.Range[0];
   Range[1] = obj.Range[1];

   SplineModel = obj.SplineModel;

   const_cast<ROOT::Fit::FitResult &>(Fitter.Result()) = obj.Fitter.Result();
   Fitter.Config().SetFromFitResult(Fitter.Result());

   ConfidenceInterval = obj.ConfidenceInterval;
   FitRatio           = obj.FitRatio;
   FitResidual        = obj.FitResidual;
   FitError           = obj.FitError;
}

void FitTools::SplineFitResult::Fit(Option_t *option, UShort_t nfits)
{
   FitTools::SetCommonFitterOptions(Fitter);
   FitTools::Fit(Data, SplineModel->GetTF1Pointer(), option, Fitter, Range[0], Range[1], nfits);
   SplineModel->GetTF1Pointer()->GetRange(Range[0], Range[1]);

   residuals_computed    = false;
   model_errors_computed = false;
}

void FitTools::SplineFitResult::RescaleDataErrors()
{
   Double_t chi2_corr = TMath::Sqrt(Fitter.Result().Chi2() / Fitter.Result().Ndf());
   for (UShort_t ibin = 1; ibin <= Data->GetNbinsX(); ++ibin)
   {
      Double_t dy = Data->GetBinError(ibin);
      Data->SetBinError(ibin, dy*chi2_corr);
   }
}

void FitTools::SplineFitResult::ComputeResiduals(Bool_t use_range, Bool_t use_integral, Bool_t is_log, Double_t confint)
{
   if (residuals_computed) return;

   TF1 *f_fit = SplineModel->GetTF1Pointer();

   FitRatio = (TH1D *)HistTools::GetResiduals(Data, f_fit, "_fitratio", use_range, use_integral, is_log, 5, 1, confint, &Fitter);
   HistTools::CopyStyle(Data, FitRatio);

   FitResidual = (TH1D *)HistTools::GetResiduals(Data, f_fit, "_fitresidual", use_range, use_integral, is_log, 1, 0, confint, &Fitter);
   HistTools::CopyStyle(Data, FitResidual);

   residuals_computed = true;
}

void FitTools::SplineFitResult::ComputeModelErrors(Bool_t use_range, Bool_t use_integral, Bool_t is_log, Double_t confint)
{
   if (model_errors_computed) return;

   TF1 *f_fit = SplineModel->GetTF1Pointer();

   ConfidenceInterval = (TH1D *)HistTools::GetFitError(Data, f_fit, "_confint", use_range, use_integral, is_log, 10, DBL_MAX, confint, &Fitter);
   #if ROOT_VERSION_CODE >= ROOT_VERSION(5,34,36)
   // SetFillColorAlpha method supported only from ROOT 5.34/36
   if (gStyle->GetCanvasPreferGL()) ConfidenceInterval->SetFillColorAlpha(kRed, 0.5);
   else ConfidenceInterval->SetFillColor(kRed - 9);
   #else
   ConfidenceInterval->SetFillColor(kRed - 9);
   #endif
   ConfidenceInterval->SetLineColor(kGray + 1);
   ConfidenceInterval->SetFillStyle(1001);
   ConfidenceInterval->SetMarkerSize(0);

   FitError = (TH1D *)HistTools::GetFitError(Data, f_fit, "_fiterr", use_range, use_integral, is_log, 11, 0., confint, &Fitter);
   #if ROOT_VERSION_CODE >= ROOT_VERSION(5,34,36)
   // SetFillColorAlpha method supported only from ROOT 5.34/36
   if (gStyle->GetCanvasPreferGL()) FitError->SetFillColorAlpha(kRed, 0.5);
   else FitError->SetFillColor(kRed - 9);
   #else
   FitError->SetFillColor(kRed - 9);
   #endif
   FitError->SetLineColor(kGray + 1);
   FitError->SetFillStyle(1001);
   FitError->SetMarkerSize(0);

   model_errors_computed = true;
}

void FitTools::CombinedLISFitResult::Copy(CombinedLISFitResult *obj)
{
   Particle        = obj->Particle;
   Energy          = obj->Energy;
   LISModel        = obj->LISModel;
   ModulationModel = obj->ModulationModel;

   LowEnergyDataset  = obj->LowEnergyDataset;
   LowEnergyData     = obj->LowEnergyData;
   LowEnergyRange[0] = obj->LowEnergyRange[0];
   LowEnergyRange[1] = obj->LowEnergyRange[1];

   HighEnergyDataset  = obj->HighEnergyDataset;
   HighEnergyData     = obj->HighEnergyData;
   HighEnergyRange[0] = obj->HighEnergyRange[0];
   HighEnergyRange[1] = obj->HighEnergyRange[1];

   GlobalChi2Norm     = obj->GlobalChi2Norm;
   LowEnergyChi2Norm  = obj->LowEnergyChi2Norm;
   HighEnergyChi2Norm = obj->HighEnergyChi2Norm;

   FitModel           = obj->FitModel;
   LISParametersIndex = obj->LISParametersIndex;

   const_cast<ROOT::Fit::FitResult &>(Fitter.Result()) = obj->Fitter.Result();
   Fitter.Config().SetFromFitResult(Fitter.Result());

   LowEnergyModel              = obj->LowEnergyModel;
   LowEnergyConfidenceInterval = obj->LowEnergyConfidenceInterval;
   LowEnergyFitRatio           = obj->LowEnergyFitRatio;
   LowEnergyFitResidual        = obj->LowEnergyFitResidual;
   LowEnergyFitError           = obj->LowEnergyFitError;

   HighEnergyModel              = obj->HighEnergyModel;
   HighEnergyConfidenceInterval = obj->HighEnergyConfidenceInterval;
   HighEnergyFitRatio           = obj->HighEnergyFitRatio;
   HighEnergyFitResidual        = obj->HighEnergyFitResidual;
   HighEnergyFitError           = obj->HighEnergyFitError;
}

void FitTools::CombinedLISFitResult::Fit(Option_t *option, UShort_t nfits)
{
   TObjArray lis(1);
   lis.Add(LowEnergyData);

   TObjArray mod(1);
   mod.Add(HighEnergyData);

   vector<FitTools::EnergyRange> range(2);
   range[0].Min = LowEnergyRange[0];
   range[0].Max = LowEnergyRange[1];
   range[1].Min = HighEnergyRange[0];
   range[1].Max = HighEnergyRange[1];

   vector<Double_t> chi2norm(2);
   vector<TF1 *> fits(2, (TF1 *)NULL);

   FitTools::SetCommonFitterOptions(Fitter);
   FitTools::FitCombinedLISData(lis, mod, FitModel, option, range, chi2norm, fits, Fitter, nfits);

   GlobalChi2Norm     = Fitter.Result().Chi2() / Fitter.Result().Ndf();
   LowEnergyChi2Norm  = chi2norm[0];
   HighEnergyChi2Norm = chi2norm[1];

   LowEnergyRange[0] = range[0].Min;
   LowEnergyRange[1] = range[0].Max;

   HighEnergyRange[0] = range[1].Min;
   HighEnergyRange[1] = range[1].Max;

   LowEnergyModel  = fits[0];
   HighEnergyModel = fits[1];

   residuals_computed    = false;
   model_errors_computed = false;
}

void FitTools::CombinedLISFitResult::FitWithShift(Double_t shift, Option_t *option, UShort_t nfits)
{
   TObjArray lis(1);
   lis.Add(LowEnergyData);

   TObjArray mod(1);
   mod.Add(HighEnergyData);

   vector<FitTools::EnergyRange> range(2);
   range[0].Min = LowEnergyRange[0];
   range[0].Max = LowEnergyRange[1];
   range[1].Min = HighEnergyRange[0];
   range[1].Max = HighEnergyRange[1];

   vector<Double_t> chi2norm(2);
   vector<TF1 *> fits(2, (TF1 *)NULL);

   FitTools::SetCommonFitterOptions(Fitter);
   FitTools::FitCombinedLISDataWithShift(lis, mod, FitModel, shift, option, range, chi2norm, fits, Fitter, nfits);

   GlobalChi2Norm     = Fitter.Result().Chi2() / Fitter.Result().Ndf();
   LowEnergyChi2Norm  = chi2norm[0];
   HighEnergyChi2Norm = chi2norm[1];

   LowEnergyRange[0] = range[0].Min;
   LowEnergyRange[1] = range[0].Max;

   HighEnergyRange[0] = range[1].Min;
   HighEnergyRange[1] = range[1].Max;

   LowEnergyModel  = fits[0];
   HighEnergyModel = fits[1];

   residuals_computed    = false;
   model_errors_computed = false;
}

void FitTools::CombinedLISFitResult::RescaleDataErrors(Bool_t global)
{
   Double_t chi2_corr;

   if (global) chi2_corr = TMath::Sqrt(GlobalChi2Norm);
   else chi2_corr = TMath::Sqrt(LowEnergyChi2Norm);
   for (UShort_t ibin = 1; ibin <= LowEnergyData->GetNbinsX(); ++ibin)
   {
      Double_t dy = LowEnergyData->GetBinError(ibin);
      LowEnergyData->SetBinError(ibin, dy*chi2_corr);
   }

   if (!global) chi2_corr = TMath::Sqrt(HighEnergyChi2Norm);
   for (UShort_t ibin = 1; ibin <= HighEnergyData->GetNbinsX(); ++ibin)
   {
      Double_t dy = HighEnergyData->GetBinError(ibin);
      HighEnergyData->SetBinError(ibin, dy*chi2_corr);
   }
}

void FitTools::CombinedLISFitResult::ComputeResiduals(Bool_t use_range, Bool_t use_integral, Bool_t is_log, Double_t confint, Bool_t force)
{
   if (!force && residuals_computed) return;

   LowEnergyFitRatio = (TH1D *)HistTools::GetResiduals(LowEnergyData, LowEnergyModel, "_fitratio", use_range, use_integral, is_log, 5, 1, confint, &Fitter);
   HistTools::CopyStyle(LowEnergyData, LowEnergyFitRatio);

   LowEnergyFitResidual = (TH1D *)HistTools::GetResiduals(LowEnergyData, LowEnergyModel, "_fitresidual", use_range, use_integral, is_log, 1, 0, confint, &Fitter);
   HistTools::CopyStyle(LowEnergyData, LowEnergyFitResidual);

   HighEnergyFitRatio = (TH1D *)HistTools::GetResiduals(HighEnergyData, HighEnergyModel, "_fitratio", use_range, use_integral, is_log, 5, 1, confint, &Fitter);
   HistTools::CopyStyle(HighEnergyData, HighEnergyFitRatio);

   HighEnergyFitResidual = (TH1D *)HistTools::GetResiduals(HighEnergyData, HighEnergyModel, "_fitresidual", use_range, use_integral, is_log, 1, 0, confint, &Fitter);
   HistTools::CopyStyle(HighEnergyData, HighEnergyFitResidual);

   residuals_computed = true;
}

void FitTools::CombinedLISFitResult::ComputeModelErrors(Bool_t use_range, Bool_t use_integral, Bool_t is_log, Double_t confint, Bool_t force)
{
   static Double_t last_cl = 0.;

   if (!force && model_errors_computed && confint == last_cl) return;

   last_cl = confint;

   LowEnergyConfidenceInterval = (TH1D *)HistTools::GetFitError(LowEnergyData, LowEnergyModel, "_confint", use_range, use_integral, is_log, 10, DBL_MAX, confint, &Fitter, LISParametersIndex);
   #if ROOT_VERSION_CODE >= ROOT_VERSION(5,34,36)
   // SetFillColorAlpha method supported only from ROOT 5.34/36
   if (gStyle->GetCanvasPreferGL()) LowEnergyConfidenceInterval->SetFillColorAlpha(kRed, 0.5);
   else LowEnergyConfidenceInterval->SetFillColor(kRed - 9);
   #else
   LowEnergyConfidenceInterval->SetFillColor(kRed - 9);
   #endif
   LowEnergyConfidenceInterval->SetLineColor(kRed - 9);
   LowEnergyConfidenceInterval->SetFillStyle(1001);
   LowEnergyConfidenceInterval->SetMarkerSize(0);

   LowEnergyFitError = (TH1D *)HistTools::GetFitError(LowEnergyData, LowEnergyModel, "_fiterr", use_range, use_integral, is_log, 11, 0., confint, &Fitter, LISParametersIndex);
   #if ROOT_VERSION_CODE >= ROOT_VERSION(5,34,36)
   // SetFillColorAlpha method supported only from ROOT 5.34/36
   if (gStyle->GetCanvasPreferGL()) LowEnergyFitError->SetFillColorAlpha(kRed, 0.5);
   else LowEnergyFitError->SetFillColor(kRed - 9);
   #else
   LowEnergyFitError->SetFillColor(kRed - 9);
   #endif
   LowEnergyFitError->SetLineColor(kRed - 9);
   LowEnergyFitError->SetFillStyle(1001);
   LowEnergyFitError->SetMarkerSize(0);

   HighEnergyConfidenceInterval = (TH1D *)HistTools::GetFitError(HighEnergyData, HighEnergyModel, "_confint", use_range, use_integral, is_log, 10, DBL_MAX, confint, &Fitter);
   #if ROOT_VERSION_CODE >= ROOT_VERSION(5,34,36)
   // SetFillColorAlpha method supported only from ROOT 5.34/36
   if (gStyle->GetCanvasPreferGL()) HighEnergyConfidenceInterval->SetFillColorAlpha(kRed, 0.5);
   else HighEnergyConfidenceInterval->SetFillColor(kRed - 9);
   #else
   HighEnergyConfidenceInterval->SetFillColor(kRed - 9);
   #endif
   HighEnergyConfidenceInterval->SetLineColor(kRed - 9);
   HighEnergyConfidenceInterval->SetFillStyle(1001);
   HighEnergyConfidenceInterval->SetMarkerSize(0);

   HighEnergyFitError = (TH1D *)HistTools::GetFitError(HighEnergyData, HighEnergyModel, "_fiterr", use_range, use_integral, is_log, 11, 0., confint, &Fitter);
   #if ROOT_VERSION_CODE >= ROOT_VERSION(5,34,36)
   // SetFillColorAlpha method supported only from ROOT 5.34/36
   if (gStyle->GetCanvasPreferGL()) HighEnergyFitError->SetFillColorAlpha(kRed, 0.5);
   else HighEnergyFitError->SetFillColor(kRed - 9);
   #else
   HighEnergyFitError->SetFillColor(kRed - 9);
   #endif
   HighEnergyFitError->SetLineColor(kRed - 9);
   HighEnergyFitError->SetFillStyle(1001);
   HighEnergyFitError->SetMarkerSize(0);

   model_errors_computed = true;
}

void FitTools::CombinedLISFitResult::Print(std::ostream &out)
{
   PRINT_VARIABLE(Particle)
   PRINT_VARIABLE(Energy)
   PRINT_VARIABLE(LISModel)
   PRINT_POINTER(LowEnergyDataset)
   PRINT_POINTER_NAME(LowEnergyData)
   PRINT_VARIABLE_ARRAY(LowEnergyRange,2)
   PRINT_POINTER(HighEnergyDataset)
   PRINT_POINTER_NAME(HighEnergyData)
   PRINT_VARIABLE_ARRAY(HighEnergyRange,2)
   PRINT_POINTER_NAME(LowEnergyModel)
   PRINT_POINTER_NAME(LowEnergyFitResidual)
   PRINT_POINTER_NAME(LowEnergyFitError)
   PRINT_POINTER_NAME(HighEnergyModel)
   PRINT_POINTER_NAME(HighEnergyFitResidual)
   PRINT_POINTER_NAME(HighEnergyFitError)
}

// Write the content of the object to the current directory
TDirectory *FitTools::CombinedLISFitResult::Write(const Char_t *dirname)
{
   TDirectory *cwd = gDirectory;
   TDirectory *dir = cwd->mkdir(dirname);
   dir->cd();

   TH1F *hpx = new TH1F("", "", FitModel->GetNpx(), HistTools::BuildLogBins(LowEnergyRange[0], HighEnergyRange[1], FitModel->GetNpx()));
   hpx->SetDirectory(NULL);

   TParameter<int>    pi;
   TParameter<double> pd;

   pi.SetVal(Particle);
   pi.Write("Particle");

   pi.SetVal(Energy);
   pi.Write("Energy");

   pi.SetVal(LISModel);
   pi.Write("LISModel");

   pi.SetVal(ModulationModel);
   pi.Write("ModulationModel");

   pi.SetVal(LowEnergyDataset->Experiment->Type);
   pi.Write("LowEnergyExperiment");

   UShort_t idataset = Experiments::iDataset(LowEnergyDataset);
   pi.SetVal(idataset);
   pi.Write("LowEnergyDataset");

   pi.SetVal(Experiments::iMeasurement(LowEnergyDataset->Experiment->Type, idataset, LowEnergyData));
   pi.Write("LowEnergyMeasurement");

   pd.SetVal(LowEnergyRange[0]);
   pd.Write("LowEnergyRange1");

   pd.SetVal(LowEnergyRange[1]);
   pd.Write("LowEnergyRange2");

   LowEnergyData->Write("LowEnergyData");

   pi.SetVal(HighEnergyDataset->Experiment->Type);
   pi.Write("HighEnergyExperiment");

   idataset = Experiments::iDataset(HighEnergyDataset);
   pi.SetVal(idataset);
   pi.Write("HighEnergyDataset");

   pi.SetVal(Experiments::iMeasurement(HighEnergyDataset->Experiment->Type, idataset, HighEnergyData));
   pi.Write("HighEnergyMeasurement");

   pd.SetVal(HighEnergyRange[0]);
   pd.Write("HighEnergyRange1");

   pd.SetVal(HighEnergyRange[1]);
   pd.Write("HighEnergyRange2");

   HighEnergyData->Write("HighEnergyData");

   FitModel->SetParent(hpx);
   FitModel->Write("FitModel");
   FitModel->SetParent(NULL);

   pd.SetVal(GlobalChi2Norm);
   pd.Write("GlobalChi2Norm");

   pd.SetVal(LowEnergyChi2Norm);
   pd.Write("LowEnergyChi2Norm");

   pd.SetVal(HighEnergyChi2Norm);
   pd.Write("HighEnergyChi2Norm");

   LowEnergyModel->SetParent(hpx);
   LowEnergyModel->Write("LowEnergyModel");
   LowEnergyModel->SetParent(NULL);

   LowEnergyConfidenceInterval->Write("LowEnergyConfidenceInterval");
   LowEnergyFitRatio->Write("LowEnergyFitRatio");
   LowEnergyFitResidual->Write("LowEnergyFitResidual");
   LowEnergyFitError->Write("LowEnergyFitError");

   HighEnergyModel->SetParent(hpx);
   HighEnergyModel->Write("HighEnergyModel");
   HighEnergyModel->SetParent(NULL);

   HighEnergyConfidenceInterval->Write("HighEnergyConfidenceInterval");
   HighEnergyFitRatio->Write("HighEnergyFitRatio");
   HighEnergyFitResidual->Write("HighEnergyFitResidual");
   HighEnergyFitError->Write("HighEnergyFitError");

   cwd->cd();

   delete hpx;

   return dir;
}
