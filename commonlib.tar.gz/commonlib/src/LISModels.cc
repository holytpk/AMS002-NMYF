#include "LISModels.hh"
#include "debug.hh"

#include "TSpline.h"

using namespace std;

string LISModels::Models::Galprop::DataPath = "/home/genesys87/cernbox/AMS/data/galprop/spectra";

vector<Double_t> galprop_kin[LISModels::Models::Galprop::nTypes][LISModels::Models::Galprop::nMaxModels][Particle::nPARTICLEs];
vector<Double_t> galprop_kinlog[LISModels::Models::Galprop::nTypes][LISModels::Models::Galprop::nMaxModels][Particle::nPARTICLEs];
vector<Double_t> galprop_flux[LISModels::Models::Galprop::nTypes][LISModels::Models::Galprop::nMaxModels][Particle::nPARTICLEs];
vector<Double_t> galprop_fluxlog[LISModels::Models::Galprop::nTypes][LISModels::Models::Galprop::nMaxModels][Particle::nPARTICLEs];

Double_t g_my_model(Double_t *x, Double_t *par)
{
   // Corti, 2015 (Three power laws with smooth transitions)
   // {1 + [R/Rb1 (1 + (R/Rb2)^(delta2/s2))^s2]^(delta1/s1)}^s1

   Double_t Rb1 = par[0]; // first rigidity break
   Double_t Dg1 = par[1]; // first delta gamma
   Double_t s1  = par[2]; // first smoothness
   Double_t Rb2 = par[3]; // second rigidity break
   Double_t Dg2 = par[4]; // second delta gamma
   Double_t s2  = par[5]; // second smoothness

   Double_t R = x[0];

   return 1. + TMath::Power(R/Rb1 * TMath::Power(1. + TMath::Power(R/Rb2, Dg2/s2), s2), Dg1/s1);
}

Double_t g_my_model_derivative(Double_t *x, Double_t *par)
{
   // Corti, 2015 (Three power laws with smooth transitions)
   // {1 + [R/Rb1 (1 + (R/Rb2)^(delta2/s2))^s2]^(delta1/s1)}^s1

   Double_t Rb1 = par[0]; // first rigidity break
   Double_t Dg1 = par[1]; // first delta gamma
   Double_t s1  = par[2]; // first smoothness
   Double_t Rb2 = par[3]; // second rigidity break
   Double_t Dg2 = par[4]; // second delta gamma
   Double_t s2  = par[5]; // second smoothness

   Double_t R = x[0];

   Double_t x1 = R/Rb1;
   Double_t x2 = R/Rb2;
   Double_t a1 = Dg1/s1;
   Double_t a2 = Dg2/s2;
   Double_t y1 = TMath::Power(x1, a1);
   Double_t y2 = TMath::Power(x2, a2);

   return a1 * y1 * TMath::Power(1. + y2, s2*a1) / R * (1. + Dg2 * y2 / (1. + y2));
}

Int_t find_nearest(Double_t energy, vector<Double_t> &bins)
{
   Int_t ibin  = 0;
   Int_t count = bins.size();
   Int_t first = 0, step;
   while (count > 0)
   {
      ibin = first;
      step = count/2;
      ibin += step;
      if (bins[ibin] < energy)
      {
         first = ++ibin;
         count -= step + 1;
      }
      else
      {
         count = step;
      }
   }

   return ibin;
}

Double_t LISModels::Models::PowerLawKin(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy)
{
   // Simple power law in kinetic energy
   // dJ/dT = N T^{-gamma}
   // [T] = GeV
   // [N] = (m^2 sr s GeV^{1-gamma})^{-1}
   // [gamma] = unitless

   Double_t gamma = par[0];

   Double_t T = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::KINETIC);
   Double_t J = Unit::EnergyJacobian(T, particle, Energy::KINETIC, SIPrefix::GIGA, energy);

   return J * TMath::Power(T, -gamma);
}

Double_t LISModels::Models::PowerLawRig(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy)
{
   // Simple power law in rigidity
   // dJ/dR = N R^{-gamma}
   // [R] = GV
   // [N] = (m^2 sr s GV^{1-gamma})^{-1}
   // [gamma] = unitless

   Double_t gamma = par[0];

   Double_t R = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::RIGIDITY);
   Double_t J = Unit::EnergyJacobian(R, particle, Energy::RIGIDITY, SIPrefix::GIGA, energy);

   return J * TMath::Power(R, -gamma);
}

Double_t LISModels::Models::BESS07(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy)
{
   // Shikaze et al, 2007 (BESS collaboration)
   // dJ/dT = N beta^{gamma2} R^{-gamma1}
   // [T] = GeV
   // [R] = GV
   // [N] = (m^2 sr s GeV^{1-gamma1})^{-1}
   // [gamma1] = [gamma2] = unitless

   Double_t gamma1 = par[0];
   Double_t gamma2 = par[1];

   Double_t T = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::KINETIC);
   Double_t R = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::RIGIDITY);
   Double_t J = Unit::EnergyJacobian(T, particle, Energy::KINETIC, SIPrefix::GIGA, energy);

   Double_t beta = Unit::Beta(R, particle, Energy::RIGIDITY, SIPrefix::GIGA);

   return J * TMath::Power(beta, gamma2) * TMath::Power(R, -gamma1);
}

Double_t LISModels::Models::BPH00U05(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy)
{
   // Burger et al, 2000 (as used in Usoskin et al, 2005)
   // dJ/dT = N R^{-gamma1}/(1 + N2 R^{-gamma2})
   // [T] = GeV
   // [R] = GV
   // [N] = (m^2 sr s GeV^{1-gamma1})^{-1}
   // [N2] = GV^{gamma2}
   // [gamma1] = [gamma2] = unitless

   Double_t gamma1 = par[0];
   Double_t N2     = par[1];
   Double_t gamma2 = par[2];

   Double_t T = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::KINETIC);
   Double_t R = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::RIGIDITY);
   Double_t J = Unit::EnergyJacobian(T, particle, Energy::KINETIC, SIPrefix::GIGA, energy);

   return J * TMath::Power(R, -gamma1) / (1. + N2 * TMath::Power(R, -gamma2));
}

Double_t LISModels::Models::GMS75(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy)
{
   // Garcia-Munoz et al, 1975 [in the paper: flux in (m^2 sr s MeV)^{-1} and energy in MeV]
   // dJ/dT = N (T + N2 e^{-a T})^{-gamma}
   // [T] = GeV
   // [N] = (m^2 sr s GeV^{1-gamma})^{-1}
   // [N2] = GeV
   // [a] = GeV^{-1}
   // [gamma] = unitless

   Double_t N2    = par[0];
   Double_t a     = par[1];
   Double_t gamma = par[2];

   Double_t T = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::KINETIC);
   Double_t J = Unit::EnergyJacobian(T, particle, Energy::KINETIC, SIPrefix::GIGA, energy);

   return J * TMath::Power(T + N2 * TMath::Exp(-a*T), -gamma);
}

Double_t LISModels::Models::WH03U05(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy)
{
   // Webber and Higbie, 2003 (as used in Usoskin et al, 2005)
   // dJ/dT = N T^{-gamma1} / (1 + N2 T^{-gamma2} + N3 T^{-gamma3})
   // [T] = GeV
   // [N] = (m^2 sr s GeV^{1-gamma1})^{-1}
   // [gamma1] = [gamma2] = [gamma3] = unitless
   // [N2] = GeV^{gamma2}
   // [N3] = GeV^{gamma3}

   Double_t gamma1 = par[0];
   Double_t N2     = par[1];
   Double_t gamma2 = par[2];
   Double_t N3     = par[3];
   Double_t gamma3 = par[4];

   Double_t T = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::KINETIC);
   Double_t J = Unit::EnergyJacobian(T, particle, Energy::KINETIC, SIPrefix::GIGA, energy);

   return J * TMath::Power(T, -gamma1) / (1. + N2 * TMath::Power(T, -gamma2) + N3 * TMath::Power(T, -gamma3));
}

Double_t LISModels::Models::L04(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy)
{
   // Langner, 2004 (as used in Usoskin et al, 2005) [in the paper: flux in (m^2 sr s MeV)^{-1} and energy in GeV]
   // dJ/dT = Galprop parametrization
   // [T] = GeV
   // [N] = (m^2 sr s GeV)^{-1}
   // [a] = [N2] = [gamma] = unitless

   Double_t a     = par[0];
   Double_t N2    = par[1];
   Double_t gamma = par[2];

   Double_t c = (2*gamma - TMath::Log(N2))/3.;
   Double_t b = 2*(gamma - c);

   Double_t T = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::KINETIC);
   Double_t J = Unit::EnergyJacobian(T, particle, Energy::KINETIC, SIPrefix::GIGA, energy);

   if (T < 1.)
   {
      return J * N2 * TMath::Exp(-a*TMath::Log(T)*TMath::Log(T) - b*TMath::Sqrt(T));
   }
   else
   {
      return J * TMath::Power(T, -gamma) * TMath::Exp(-c/T);
   }
}

/*Double_t LISModels::Models::WH09M14(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy)
{
   // Webber and Higbie, 2009 (as used in Maurin et al, 2014) [energy in MeV in the paper]
   // dJ/dT = MCDM parametrization
   // [T] = GeV
   // [N] = (m^2 sr s GeV)^{-1}
   // [a1] = [b1] = [c1] = [d1] = [a2] = [b2] = [d2] = unitless

   const Double_t ln10 = TMath::Ln10();

   Double_t a1 = par[0];
   Double_t b1 = par[1];
   Double_t c1 = par[2];
   Double_t d1 = par[3];
   Double_t a2 = par[4];
   Double_t b2 = par[5];
   Double_t d2 = par[6];

   Double_t c2 = c1 + (a2 - a1)*6*ln10*TMath::Log(3*ln10) + 1.5*(b2 - b1)*ln10*TMath::Sqrt(3*ln10) - 1.5*(d2 - d1)/ln10;
   Double_t N2 = TMath::Exp((a2 - a1)*TMath::Log(3*ln10)*(2 + TMath::Log(3*ln10)) + 1.5*(b2 - b1)*TMath::Sqrt(3*ln10) - 0.25*(d2 - d1)/(ln10*ln10));

   Double_t T = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::KINETIC);
   Double_t J = Unit::EnergyJacobian(T, particle, Energy::KINETIC, SIPrefix::GIGA, energy);

   Double_t lnT = TMath::Log(T*1e3); // T [GeV] -> [MeV]

   if (T > 1.)
   {
      return J * TMath::Exp(-a1*TMath::Log(lnT)*TMath::Log(lnT) - b1*TMath::Sqrt(lnT) - c1/lnT - d1/(lnT*lnT));
   }
   else
   {
      return J * N2*TMath::Exp(-a2*TMath::Log(lnT)*TMath::Log(lnT) - b2*TMath::Sqrt(lnT) - c2/lnT - d2/(lnT*lnT));
   }
}*/

Double_t LISModels::Models::BO11M14(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy)
{
   // O'Neill, 2010 (as used in Maurin et al, 2014)
   // dJ/dT = N beta^{-gamma2} E^{-gamma1}
   // [T] = GeV
   // [E] = GeV
   // [N] = (m^2 sr s GeV^{1-gamma1})^{-1}
   // [gamma1] = [gamma2] = unitless

   Double_t gamma1 = par[0];
   Double_t gamma2 = par[1];

   Double_t T = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::KINETIC);
   Double_t E = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::TOTAL);
   Double_t J = Unit::EnergyJacobian(T, particle, Energy::KINETIC, SIPrefix::GIGA, energy);

   Double_t beta = Unit::Beta(E, particle, Energy::TOTAL, SIPrefix::GIGA);

   return J * TMath::Power(beta, -gamma2) * TMath::Power(E, -gamma1);
}

Double_t LISModels::Models::M14(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy)
{
   // Maurin et al, 2014 (variation of Shikaze et al, 2007)
   // dJ/dT = N beta^{gamma2} R^{-gamma1}
   // [T] = GeV
   // [R] = GV
   // [N] = (m^2 sr s GeV^{1-gamma1})^{-1}
   // [gamma1] = [gamma2] = unitless

   Double_t gamma1 = par[0];
   Double_t gamma2 = par[1];

   Double_t T = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::KINETIC);
   Double_t R = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::RIGIDITY);
   Double_t J = Unit::EnergyJacobian(T, particle, Energy::KINETIC, SIPrefix::GIGA, energy);

   Double_t beta = Unit::Beta(R, particle, Energy::RIGIDITY, SIPrefix::GIGA);

   return J * TMath::Power(beta, gamma2)*TMath::Power(R, -gamma1);
}

Double_t LISModels::Models::AMS15(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy)
{
   // Aguilar et al, 2015 (AMS-02 proton paper)
   // dJ/dR = N (R/45)^{-gamma} (1 + (R/R0)^{deltagamma/s})^{s}
   // [R] = GV
   // [N] = (m^2 sr s GV)^{-1}
   // [gamma] = [deltagamma] = [s] = unitless
   // [R0] = GV

   Double_t gamma      = par[0];
   Double_t R0         = par[1];
   Double_t deltagamma = par[2];
   Double_t s          = par[3];

   Double_t R = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::RIGIDITY);
   Double_t J = Unit::EnergyJacobian(R, particle, Energy::RIGIDITY, SIPrefix::GIGA, energy);

   return J * TMath::Power(R/45., -gamma) * TMath::Power(1. + TMath::Power(R/R0, deltagamma/s), s);
}

Double_t LISModels::Models::AMS15V1(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy)
{
   // Aguilar et al, 2015 (AMS-02 proton paper), combined with Voyager 1
   // dJ/dR = N / (1 + e^{-(ln(x)-mu)/sigma})^{1/rho} (R/45)^{gamma} (1 + (R/R0)^{deltagamma/s})^{s}
   // [R] = GV
   // [N] = (m^2 sr s GV)^{-1}
   // [gamma] = [deltagamma] = [s] = unitless
   // [R0] = GV
   // [mu] = [sigma] = [rho] = unitless

   Double_t gamma      = par[0];
   Double_t R0         = par[1];
   Double_t deltagamma = par[2];
   Double_t s          = par[3];
   Double_t mu         = par[4];
   Double_t sigma      = par[5];
   Double_t rho        = par[6];

   Double_t R = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::RIGIDITY);
   //~ Double_t T = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::KINETIC);
   //~ Double_t beta = Unit::Beta(R, particle, Energy::RIGIDITY, SIPrefix::GIGA);
   Double_t J = Unit::EnergyJacobian(R, particle, Energy::RIGIDITY, SIPrefix::GIGA, energy);

   return J / TMath::Power(1. + TMath::Exp(-(TMath::Log(R) - mu)/sigma), 1./rho) * TMath::Power(R/45., gamma) * TMath::Power(1. + TMath::Power(R/R0, deltagamma/s), s);
   //~ return J / TMath::Power(1. + TMath::Power(T/mu, sigma), rho) * TMath::Power(T, gamma) * TMath::Power(1. + TMath::Power(R/R0, deltagamma/s), s);
}

Double_t LISModels::Models::AMS15BESS07(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy)
{
   // Aguilar et al, 2015 + Shikaze et al, 2007
   // dJ/dR = N beta^{gamma2} (R/45)^{-gamma} (1 + (R/R0)^{deltagamma/s})^{s}
   // [R] = GV
   // [N] = (m^2 sr s GV)^{-1}
   // [gamma] = [deltagamma] = [s] = [gamma2] = unitless
   // [R0] = GV

   Double_t gamma      = par[0];
   Double_t R0         = par[1];
   Double_t deltagamma = par[2];
   Double_t s          = par[3];
   Double_t gamma2     = par[4];

   Double_t R = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::RIGIDITY);
   Double_t J = Unit::EnergyJacobian(R, particle, Energy::RIGIDITY, SIPrefix::GIGA, energy);

   Double_t beta = Unit::Beta(R, particle, Energy::RIGIDITY, SIPrefix::GIGA);
   Double_t T  = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::KINETIC);
   Double_t JT = Unit::EnergyJacobian(T, particle, Energy::KINETIC, SIPrefix::GIGA, energy);

   return J * JT*TMath::Power(beta, gamma2) * TMath::Power(R/45., -gamma) * TMath::Power(1. + TMath::Power(R/R0, deltagamma/s), s);
}

Double_t LISModels::Models::AMS15BPH00U05(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy)
{
   // Aguilar et al, 2015 + Burger et al, 2000 (as used in Usoskin et al, 2005)
   // dJ/dR = N / (1 + N2 R^{-gamma2}) (R/45)^{-gamma} (1 + (R/R0)^{deltagamma/s})^{s}
   // [R] = GV
   // [N] = (m^2 sr s GV)^{-1}
   // [gamma] = [deltagamma] = [s] = [gamma2] = unitless
   // [R0] = GV
   // [N2] = GV^{gamma2}

   Double_t gamma      = par[0];
   Double_t R0         = par[1];
   Double_t deltagamma = par[2];
   Double_t s          = par[3];
   Double_t N2         = par[4];
   Double_t gamma2     = par[5];

   Double_t R = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::RIGIDITY);
   Double_t J = Unit::EnergyJacobian(R, particle, Energy::RIGIDITY, SIPrefix::GIGA, energy);
   Double_t T  = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::KINETIC);
   Double_t JT = Unit::EnergyJacobian(T, particle, Energy::KINETIC, SIPrefix::GIGA, energy);

   return J * JT/(1. + N2 * TMath::Power(R, -gamma2)) * TMath::Power(R/45., -gamma) * TMath::Power(1. + TMath::Power(R/R0, deltagamma/s), s);
}

Double_t LISModels::Models::AMS15GMS75(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy)
{
   // Aguilar et al, 2015 + Garcia-Munoz et al, 1975 [in the paper: flux in (m^2 sr s MeV)^{-1} and energy in MeV]
   // dJ/dR = N (1 + N2/T e^{-a T})^{-gamma} (R/45)^{-gamma} (1 + (R/R0)^{deltagamma/s})^{s}
   // [R] = GV
   // [N] = (m^2 sr s GV)^{-1}
   // [gamma] = [deltagamma] = [s] = unitless
   // [R0] = GV
   // [N2] = GeV
   // [a] = GeV^{-1}

   Double_t gamma      = par[0];
   Double_t R0         = par[1];
   Double_t deltagamma = par[2];
   Double_t s          = par[3];
   Double_t N2         = par[4];
   Double_t a          = par[5];

   Double_t R = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::RIGIDITY);
   Double_t J = Unit::EnergyJacobian(R, particle, Energy::RIGIDITY, SIPrefix::GIGA, energy);
   Double_t T  = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::KINETIC);
   Double_t JT = Unit::EnergyJacobian(T, particle, Energy::KINETIC, SIPrefix::GIGA, energy);

   return J * JT*TMath::Power(1. + N2/T * TMath::Exp(-a*T), -gamma) * TMath::Power(R/45., -gamma) * TMath::Power(1. + TMath::Power(R/R0, deltagamma/s), s);
}

Double_t LISModels::Models::AMS15WH03U05(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy)
{
   // Aguilar et al, 2015 + Webber and Higbie, 2003 (as used in Usoskin et al, 2005)
   // dJ/dR = N / (1 + N2 T^{-gamma2} + N3 T^{-gamma3}) (R/45)^{-gamma} (1 + (R/R0)^{deltagamma/s})^{s}
   // [R] = GV
   // [N] = (m^2 sr s GV)^{-1}
   // [gamma] = [deltagamma] = [s] = [gamma2] = [gamma3] = unitless
   // [R0] = GV
   // [N2] = GeV^{gamma2}
   // [N3] = GeV^{gamma3}

   Double_t gamma      = par[0];
   Double_t R0         = par[1];
   Double_t deltagamma = par[2];
   Double_t s          = par[3];
   Double_t N2         = par[4];
   Double_t gamma2     = par[5];
   Double_t N3         = par[6];
   Double_t gamma3     = par[7];

   Double_t R = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::RIGIDITY);
   Double_t J = Unit::EnergyJacobian(R, particle, Energy::RIGIDITY, SIPrefix::GIGA, energy);
   Double_t T  = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::KINETIC);
   Double_t JT = Unit::EnergyJacobian(T, particle, Energy::KINETIC, SIPrefix::GIGA, energy);

   return J * JT/(1. + N2 * TMath::Power(T, -gamma2) + N3 * TMath::Power(T, -gamma3)) * TMath::Power(R/45., -gamma) * TMath::Power(1. + TMath::Power(R/R0, deltagamma/s), s);
}

Double_t LISModels::Models::AMS15L04(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy)
{
   // Aguilar et al, 2015 + Langner, 2004 (as used in Usoskin et al, 2005) [in the paper: flux in (m^2 sr s MeV)^{-1} and energy in GeV]
   // dJ/dR = N (Galprop parametrization) (R/45)^{-gamma} (1 + (R/R0)^{deltagamma/s})^{s}
   // [R] = GV
   // [N] = (m^2 sr s GV)^{-1}
   // [gamma] = [deltagamma] = [s] = [a] = [N2] = unitless
   // [R0] = GV

   Double_t gamma      = par[0];
   Double_t R0         = par[1];
   Double_t deltagamma = par[2];
   Double_t s          = par[3];
   Double_t a          = par[4];
   Double_t N2         = par[5];

   Double_t R = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::RIGIDITY);
   Double_t J = Unit::EnergyJacobian(R, particle, Energy::RIGIDITY, SIPrefix::GIGA, energy);
   Double_t T  = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::KINETIC);
   Double_t JT = Unit::EnergyJacobian(T, particle, Energy::KINETIC, SIPrefix::GIGA, energy);

   Double_t c = (2*gamma - TMath::Log(N2))/3.;
   Double_t b = 2*(gamma - c);

   Double_t gtf;
   if (T < 1.)
   {
      gtf = N2 * TMath::Exp(-a*TMath::Log(T)*TMath::Log(T) - b*TMath::Sqrt(T)) / TMath::Power(T, -gamma);
   }
   else
   {
      gtf = TMath::Exp(-c/T);
   }

   return J * JT*gtf * TMath::Power(R/45., -gamma) * TMath::Power(1. + TMath::Power(R/R0, deltagamma/s), s);
}

Double_t LISModels::Models::ThreePowerLawRig(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy)
{
   // Corti, 2015 (Three power laws with smooth transitions)
   // dJ/dR = 2-nodes loglog spline with power law extrapolation + N R^gamma {1 + [R/Rb1 (1 + (R/Rb2)^(delta2/s2))^s2]^(delta1/s1)}^s1
   // [R] = GV
   // [N] = (m^2 sr s GV^{1+gamma})^{-1} = 1 (fixed by spline last node)
   // [gamma] = [delta1] = [s1] = [delta2] = [s2] = unitless
   // [Rb1] = [Rb2] = GV

   Double_t gb     = par[0];
   Double_t x0     = par[1]; // fixed
   Double_t x1     = par[2]; // fixed
   Double_t y0     = par[3];
   Double_t y1     = par[4];
   Double_t ge     = par[5];
   Double_t s1     = par[8];

   Double_t R = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::RIGIDITY);
   Double_t J = Unit::EnergyJacobian(R, particle, Energy::RIGIDITY, SIPrefix::GIGA, energy);

   Double_t F;
   if (R < x0)
   {
      F = y0*TMath::Power(x0, -gb) * TMath::Power(R, gb);
   }
   else if (x0 <= R && R < x1)
   {
      Double_t xn[2] = { log(x0), log(x1) };
      Double_t yn[2] = { log(y0), log(y1) };
      TSpline3 sp3("sp3", xn, yn, 2, "b1e1", gb, ge);
      F = exp(sp3.Eval(log(R)));
   }
   else
   {
      Double_t g1       = g_my_model(&x1, &par[6]);
      Double_t g1_deriv = g_my_model_derivative(&x1, &par[6]);

      Double_t gamma1 = ge - x1*s1/g1*g1_deriv;
      Double_t N      = y1 * TMath::Power(x1, -gamma1) * TMath::Power(g1, -s1);

      Double_t g = g_my_model(&R, &par[6]);

      F = N * TMath::Power(R, gamma1) * TMath::Power(g, s1);
   }

   return J * F;
}

Double_t LISModels::Models::Corti16(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy)
{
   // Corti, 2015 (Three power laws with smooth transitions)
   // dJ/dR =  N / (1 + e^{-(ln(x)-mu)/sigma})^{1/rho} R^gamma {1 + [R/Rb1 (1 + (R/Rb2)^(delta2/s2))^s2]^(delta1/s1)}^s1
   // [R] = GV
   // [N] = (m^2 sr s GV^{1+gamma})^{-1} = 1 (fixed by spline last node)
   // [gamma] = [delta1] = [s1] = [delta2] = [s2] = unitless
   // [Rb1] = [Rb2] = GV

   Double_t mu    = par[0];
   Double_t sigma = par[1];
   Double_t rho   = par[2];
   Double_t g1    = par[3];
   Double_t s1    = par[6];

   Double_t R = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::RIGIDITY);
   Double_t J = Unit::EnergyJacobian(R, particle, Energy::RIGIDITY, SIPrefix::GIGA, energy);

   Double_t g = g_my_model(&R, &par[4]);

   return J / TMath::Power(1. + TMath::Exp(-(TMath::Log(R) - mu)/sigma), 1./rho) * TMath::Power(R, g1) * TMath::Power(g, s1);
}

Double_t LISModels::Models::Vos15(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy)
{
   // Vos (2015)
   // dJ/dT = N/beta^2 T^gamma1 ((T^s-Tb^s)/(1+Tb^s)^((gamma2-gamma1)/s)",
   // [T] = GeV
   // [N] = (m^2 sr s GeV^{1-gamma1})^{-1}
   // [gamma1] = [gamma2] = [s] = unitless
   // [Tb] = GeV

   Double_t gamma1 = par[0];
   Double_t gamma2 = par[1];
   Double_t s      = par[2];
   Double_t Tb     = par[3];

   Double_t T = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::KINETIC);
   Double_t J = Unit::EnergyJacobian(T, particle, Energy::KINETIC, SIPrefix::GIGA, energy);

   Double_t beta = Unit::Beta(T, particle, Energy::KINETIC, SIPrefix::GIGA);

   return J * TMath::Power(T, gamma1) / (beta*beta) * TMath::Power((TMath::Power(T, s) + TMath::Power(Tb, s)) / (1. + TMath::Power(Tb, s)), (gamma2 - gamma1)/s);
}

Double_t LISModels::Models::BON14(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy)
{
   // Badhwar - O'Neill, 2014
   // dJ/dT = N (35 + 0.938)^{gamma}/beta(35) beta^{delta} (Tn + 0.938)^{-gamma}
   // [Tn] = GeV/n
   // [N] = (m^2 sr s GeV)^{-1}
   // [gamma] = [delta] = unitless

   const Double_t m = Particle::Mass[Particle::PROTON]/Unit::GeV;

   Double_t gamma = par[0];
   Double_t delta = par[1];

   Double_t Tn = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::KINETICPERNUCLEON);
   Double_t J  = Unit::EnergyJacobian(Tn, particle, Energy::KINETICPERNUCLEON, SIPrefix::GIGA, energy);

   Double_t beta = Unit::Beta(Tn, particle, Energy::KINETICPERNUCLEON, SIPrefix::GIGA);

   Double_t Tn_ref   = 35.;
   Double_t beta_ref = Unit::Beta(Tn_ref, particle, Energy::KINETICPERNUCLEON, SIPrefix::GIGA);

   return J * TMath::Power(beta, delta) / beta_ref * TMath::Power((Tn + m)/(Tn_ref + m), -gamma);
}

Double_t LISModels::Models::Ghelfi16(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy)
{
   // Ghelfi et al, 2016
   // log10(dJ/dTn) = spline parametrization
   // [Tn] = GeV/n
   // [N] = (m^2 sr s GeV)^{-1}

   const Double_t Tn_thr = 800.;

   Double_t norm2 = par[15];
   Double_t gamma = par[16];
   //~ Double_t gamma = par[14];

   //~ Double_t c14 = -TMath::Log10(Tn_thr)*gamma;
   //~ for (UShort_t i = 1; i <= 13; ++i)
   //~ {
      //~ c14 -= i*par[i];
   //~ }
   //~ c14 /= 14.;

   Double_t Tn = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::KINETICPERNUCLEON);
   Double_t J  = Unit::EnergyJacobian(Tn, particle, Energy::KINETICPERNUCLEON, SIPrefix::GIGA, energy);

   x = TMath::Log10(Tn)/TMath::Log10(Tn_thr);
   Double_t lflux = 0.;
   if (Tn >= Tn_thr)
   {
      //~ for (UShort_t i = 0; i <= 13; ++i)
      //~ {
         //~ lflux += par[i];
      //~ }
      //~ lflux += c14 - gamma*TMath::Log10(Tn/Tn_thr);
      lflux = norm2 - gamma*TMath::Log10(Tn/Tn_thr);
   }
   else
   {
      //~ for (UShort_t i = 0; i <= 13; ++i)
      for (UShort_t i = 0; i <= 14; ++i)
      {
         lflux += par[i] * TMath::Power(x, i);
      }
      //~ lflux += c14 * TMath::Power(x, 14.);
   }

   return J * TMath::Power(10., lflux);
}

Double_t LISModels::Models::Bisschoff16(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy)
{
   // Bisschoff & Potgieter, 2016
   // dJ/dT = N/beta^2 T^gamma1 ((T^s-Tb^s)/(1+Tb^s)^((gamma2-gamma1)/s)",
   // [T] = GeV
   // [N] = (m^2 sr s GeV^{1-gamma1})^{-1}
   // [gamma1] = [gamma2] = [s] = unitless
   // [Tb] = GeV

   Double_t gamma1 = par[0];
   Double_t gamma2 = par[1];
   Double_t s      = par[2];
   Double_t Tb     = par[3];

   Double_t T = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::KINETICPERNUCLEON);
   Double_t J = Unit::EnergyJacobian(T, particle, Energy::KINETICPERNUCLEON, SIPrefix::GIGA, energy);

   Double_t beta = Unit::Beta(T, particle, Energy::KINETICPERNUCLEON, SIPrefix::GIGA);

   return J * TMath::Power(T, gamma1) / (beta*beta) * TMath::Power((TMath::Power(T, s) + TMath::Power(Tb, s)) / (1. + TMath::Power(Tb, s)), (gamma2 - gamma1)/s);
}

Double_t LISModels::Models::Herbst17(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy)
{
   // Herbst et al, 2017 [original flux in 1/(m^2 sr s MeV), energy in GeV (?)]
   // dJ/dT = Galprop parametrization
   // [T] = GeV
   // [N] = (m^2 sr s GeV)^{-1}
   // [a] = [N2] = [gamma] = unitless

   Double_t a     = par[0];
   Double_t N2    = par[1];
   Double_t gamma = par[2];

   const Double_t Tb  = 1.4;
   const Double_t lTb = TMath::Log(Tb);

   Double_t c = Tb/3. * ((2.-lTb)*gamma - (4.-lTb)*a*lTb - TMath::Log(N2));
   Double_t b = 2./TMath::Sqrt(Tb) * (gamma - c/Tb - 2.*a*lTb);

   Double_t T = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::KINETIC);
   Double_t J = Unit::EnergyJacobian(T, particle, Energy::KINETIC, SIPrefix::GIGA, energy);

   if (T < Tb)
   {
      return J * N2 * TMath::Exp(-a*TMath::Log(T)*TMath::Log(T) - b*TMath::Sqrt(T));
   }
   else
   {
      return J * TMath::Power(T, -gamma) * TMath::Exp(-c/T);
   }
}

Double_t LISModels::Models::SmoothPLRig3(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy)
{
   // Corti, 2018 (Three power laws with smooth transitions)
   // dJ/dR =  N R^gamma0 [1+(R/R1)^s1]^{Delta1/s1} [1+(R/R2)^s2]^{Delta2/s2}
   // [R] = GV
   // [N] = (m^2 sr s GV)^{-1}
   // [gamma0] = [Delta1] = [s1] = [Delta2] = [s2] = unitless
   // [R1] = [R2] = GV

   Double_t gamma0   = par[0];
   Double_t Rb[2]    = { par[1], par[4] };
   Double_t s[2]     = { par[2], par[5] };
   Double_t Delta[2] = { par[3], par[6] };

   Double_t R = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::RIGIDITY);
   Double_t J = Unit::EnergyJacobian(R, particle, Energy::RIGIDITY, SIPrefix::GIGA, energy);

   Double_t pl = TMath::Power(R, gamma0);
   for (UShort_t i = 0; i < 2; ++i)
   {
      pl *= TMath::Power(1. + TMath::Power(R/Rb[i], s[i]), Delta[i]/s[i]);
   }

   return J * pl;
}

Double_t LISModels::Models::SmoothPLRig4(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy)
{
   // Corti, 2018 (Four power laws with smooth transitions)
   // dJ/dR =  N R^gamma0 [1+(R/R1)^s1]^{Delta1/s1} [1+(R/R2)^s2]^{Delta2/s2} [1+(R/R3)^s3]^{Delta3/s3}
   // [R] = GV
   // [N] = (m^2 sr s GV)^{-1}
   // [gamma0] = [Delta1] = [s1] = [Delta2] = [s2] = [Delta3] = [s3] = unitless
   // [R1] = [R2] = [R3] = GV

   Double_t gamma0   = par[0];
   Double_t Rb[3]    = { par[1], par[4], par[7] };
   Double_t s[3]     = { par[2], par[5], par[8] };
   Double_t Delta[3] = { par[3], par[6], par[9] };

   Double_t R = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::RIGIDITY);
   Double_t J = Unit::EnergyJacobian(R, particle, Energy::RIGIDITY, SIPrefix::GIGA, energy);

   Double_t pl = TMath::Power(R, gamma0);
   for (UShort_t i = 0; i < 3; ++i)
   {
      //~ pl *= TMath::Power(1. + TMath::Power(R/Rb[i], s[i]), Delta[i]/s[i]);
      pl *= TMath::Power((TMath::Power(R, s[i]) + TMath::Power(Rb[i], s[i]))/(1. + TMath::Power(Rb[i], s[i])), Delta[i]/s[i]);
   }

   return J * pl;
}

Double_t LISModels::Models::SmoothPLRig4Log(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy)
{
   // Corti, 2018 (Four power laws with smooth transitions)
   // dJ/dR =  N R^gamma0 [1+(R/R1)^s1]^{Delta1/s1} [1+(R/R2)^s2]^{Delta2/s2} [1+(R/R3)^s3]^{Delta3/s3}
   // [R] = GV
   // [N] = (m^2 sr s GV)^{-1}
   // [gamma0] = [Delta1] = [s1] = [Delta2] = [s2] = [Delta3] = [s3] = unitless
   // [R1] = [R2] = [R3] = GV

   Double_t gamma0   = par[0];
   Double_t Rb[3]    = { pow(10, par[1]), pow(10, par[4]), par[7] };
   Double_t s[3]     = { pow(10, par[2]), pow(10, par[5]), pow(10, par[8]) };
   //~ Double_t gamma[3] = { par[3], par[6], par[9] };
   //~ Double_t Delta[3] = { gamma[0]-gamma0, gamma[1]-gamma[0], gamma[2]-gamma[1] };
   Double_t Delta[3] = { par[3], par[6], par[9] };

   Double_t R = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::RIGIDITY);
   Double_t J = Unit::EnergyJacobian(R, particle, Energy::RIGIDITY, SIPrefix::GIGA, energy);

   Double_t pl = TMath::Power(R, gamma0);
   for (UShort_t i = 0; i < 3; ++i)
   {
      //~ pl *= TMath::Power(1. + TMath::Power(R/Rb[i], s[i]), Delta[i]/s[i]);
      pl *= TMath::Power((TMath::Power(R, s[i]) + TMath::Power(Rb[i], s[i]))/(1. + TMath::Power(Rb[i], s[i])), Delta[i]/s[i]);
   }

   return J * pl;
}

Double_t LISModels::Models::GalpropKinNuc(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy)
{
   // Interpolated GALPROP output in kinetic energy per nucleon
   // dJ/dTn = N * Interpolate Galprop output
   // [Tn] = GeV/n
   // [N] = (m^2 sr s GeV/n)^{-1}

   UShort_t igalprop = par[0];
   UShort_t imodel   = par[1];

   Double_t Tn = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::KINETICPERNUCLEON);
   Double_t J  = Unit::EnergyJacobian(Tn, particle, Energy::KINETICPERNUCLEON, SIPrefix::GIGA, energy);

   Double_t lnTn = log(Tn);
//~ static Long64_t count = 0;
//~ cout << Form("[%07lld] Kin=%9.4f (%+6.2f);", count++, T, lnT) << flush;

   // find closest bin of galprop_kin to T and interpolate galprop_flux with a power law
   vector<Double_t> &kinlog  = galprop_kinlog[igalprop][imodel][particle];
   vector<Double_t> &fluxlog = galprop_fluxlog[igalprop][imodel][particle];
//~ cout << Form(" kinlog: %p; fluxlog: %p;", &kinlog, &fluxlog) << flush;
   Int_t nbins = kinlog.size();
   Int_t bin   = find_nearest(lnTn, kinlog);
//~ cout << Form(" Bin=%2d (%9.4f);", bin, galprop_kin[LISModels::Models::Galprop::BMP55][imodel][particle][bin]) << flush;
   Int_t bin1, bin2;
   if (lnTn <= kinlog[bin] && bin > 0)
   {
      bin1 = bin - 1;
      bin2 = bin;
   }
   else if (bin == nbins)
   {
      bin1 = bin - 2;
      bin2 = bin - 1;
   }
   else
   {
      bin1 = bin;
      bin2 = bin + 1;
   }
//~ cout << Form(" [%2d,%2d];", bin1, bin2) << flush;
   Double_t x1 = kinlog[bin1];
//~ cout << Form(" x1=%+6.2f (%11.5e);", x1, TMath::Exp(x1)) << flush;
   Double_t x2 = kinlog[bin2];
//~ cout << Form(" x2=%+6.2f (%11.5e);", x2, TMath::Exp(x2)) << flush;
   Double_t y1 = fluxlog[bin1];
//~ cout << Form(" y1=%+6.2f (%11.5e);", y1, TMath::Exp(y1)) << flush;
   Double_t y2 = fluxlog[bin2];
//~ cout << Form(" y2=%+6.2f (%11.5e);", y2, TMath::Exp(y2)) << flush;
//~ cout << Form(" lnT-x1=%+6.2f;", lnT - x1) << flush;
//~ cout << Form(" Flux=%11.5e (%11.5e)", TMath::Exp(y1 + (lnT - x1) * ((y2 - y1) / (x2 - x1))), galprop_flux[LISModels::Models::Galprop::BMP55][imodel][particle][bin]) << endl;
   return J * TMath::Exp(y1 + (lnTn - x1) * ((y2 - y1) / (x2 - x1)));
}

Double_t LISModels::Models::GTF::PowerLawKin(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy)
{
   // Simple power law in kinetic energy
   // GTF = 1

   Double_t T = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::KINETIC);
   Double_t J = Unit::EnergyJacobian(T, particle, Energy::KINETIC, SIPrefix::GIGA, energy);

   return J;
}

Double_t LISModels::Models::GTF::PowerLawRig(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy)
{
   // Simple power law in rigidity
   // GTF = 1

   Double_t R = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::RIGIDITY);
   Double_t J = Unit::EnergyJacobian(R, particle, Energy::RIGIDITY, SIPrefix::GIGA, energy);

   return J ;
}

Double_t LISModels::Models::GTF::BESS07(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy)
{
   // Shikaze et al, 2007 (BESS collaboration)
   // GTF = beta^{gamma2}
   // [T] = GeV
   // [gamma2] = unitless

   Double_t gamma2 = par[1];

   Double_t T = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::KINETIC);
   Double_t J = Unit::EnergyJacobian(T, particle, Energy::KINETIC, SIPrefix::GIGA, energy);

   Double_t beta = Unit::Beta(T, particle, Energy::KINETIC, SIPrefix::GIGA);

   return J * TMath::Power(beta, gamma2);
}

Double_t LISModels::Models::GTF::BPH00U05(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy)
{
   // Burger et al, 2000 (as used in Usoskin et al, 2005)
   // GTF = 1/(1 + N2 R^{-gamma2})
   // [R] = GV
   // [N2] = GV^{gamma2}
   // [gamma2] = unitless

   Double_t N2     = par[1];
   Double_t gamma2 = par[2];

   Double_t T = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::KINETIC);
   Double_t R = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::RIGIDITY);
   Double_t J = Unit::EnergyJacobian(T, particle, Energy::KINETIC, SIPrefix::GIGA, energy);

   return J / (1. + N2 * TMath::Power(R, -gamma2));
}

Double_t LISModels::Models::GTF::GMS75(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy)
{
   // Garcia-Munoz et al, 1975 [in the paper: flux in (m^2 sr s MeV)^{-1} and energy in MeV]
   // GTF = (1 + N2/T e^{-a T})^{-gamma}
   // [T] = GeV
   // [N2] = GeV
   // [a] = GeV^{-1}
   // [gamma] = unitless

   Double_t N2    = par[0];
   Double_t a     = par[1];
   Double_t gamma = par[2];

   Double_t T = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::KINETIC);
   Double_t J = Unit::EnergyJacobian(T, particle, Energy::KINETIC, SIPrefix::GIGA, energy);

   return J * TMath::Power(1. + N2/T * TMath::Exp(-a*T), -gamma);
}

Double_t LISModels::Models::GTF::WH03U05(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy)
{
   // Webber and Higbie, 2003 (as used in Usoskin et al, 2005)
   // GTF = 1 / (1 + N2 T^{-gamma2} + N3 T^{-gamma3})
   // [T] = GeV
   // [gamma2] = [gamma3] = unitless
   // [N2] = GeV^{gamma2}
   // [N3] = GeV^{gamma3}

   Double_t N2     = par[1];
   Double_t gamma2 = par[2];
   Double_t N3     = par[3];
   Double_t gamma3 = par[4];

   Double_t T = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::KINETIC);
   Double_t J = Unit::EnergyJacobian(T, particle, Energy::KINETIC, SIPrefix::GIGA, energy);

   return J / (1. + N2 * TMath::Power(T, -gamma2) + N3 * TMath::Power(T, -gamma3));
}

Double_t LISModels::Models::GTF::L04(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy)
{
   // Langner, 2004 (as used in Usoskin et al, 2005) [in the paper: flux in (m^2 sr s MeV)^{-1} and energy in GeV]
   // GTF = Galprop parametrization
   // [T] = GeV
   // [a] = [N2] = [gamma] = unitless

   Double_t a     = par[0];
   Double_t N2    = par[1];
   Double_t gamma = par[2];

   Double_t c = (2*gamma - TMath::Log(N2))/3.;
   Double_t b = 2*(gamma - c);

   Double_t T = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::KINETIC);
   Double_t J = Unit::EnergyJacobian(T, particle, Energy::KINETIC, SIPrefix::GIGA, energy);

   if (T < 1.)
   {
      return J * N2 * TMath::Exp(-a*TMath::Log(T)*TMath::Log(T) - b*TMath::Sqrt(T)) / TMath::Power(T, -gamma);
   }
   else
   {
      return J * TMath::Exp(-c/T);
   }
}

Double_t LISModels::Models::GTF::BO11M14(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy)
{
   // O'Neill, 2010 (as used in Maurin et al, 2014)
   // GTF = beta^{-gamma2}
   // [T] = GeV
   // [gamma2] = unitless

   Double_t gamma2 = par[1];

   Double_t T = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::KINETIC);
   Double_t E = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::TOTAL);
   Double_t J = Unit::EnergyJacobian(T, particle, Energy::KINETIC, SIPrefix::GIGA, energy);

   Double_t beta = Unit::Beta(E, particle, Energy::TOTAL, SIPrefix::GIGA);

   return J * TMath::Power(beta, -gamma2);
}

Double_t LISModels::Models::GTF::M14(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy)
{
   // Maurin et al, 2014 (variation of Shikaze et al, 2007)
   // GTF = beta^{gamma2}
   // [T] = GeV
   // [gamma2] = unitless

   Double_t gamma2 = par[1];

   Double_t T = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::KINETIC);
   Double_t J = Unit::EnergyJacobian(T, particle, Energy::KINETIC, SIPrefix::GIGA, energy);

   Double_t beta = Unit::Beta(T, particle, Energy::KINETIC, SIPrefix::GIGA);

   return J * TMath::Power(beta, gamma2);
}

Double_t LISModels::Models::GTF::AMS15(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy)
{
   // Aguilar et al, 2015 (AMS-02 proton paper)
   // GTF = 1

   return 1.;
}

Double_t LISModels::Models::GTF::AMS15V1(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy)
{
   // Aguilar et al, 2015 (AMS-02 proton paper), combined with Voyager 1
   // GTF = 1 / (1 + e^{-(ln(x)-mu)/sigma})^{1/rho}
   // [R] = GV

   Double_t mu         = par[4];
   Double_t sigma      = par[5];
   Double_t rho        = par[6];

   Double_t R = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::RIGIDITY);
   Double_t J = Unit::EnergyJacobian(R, particle, Energy::RIGIDITY, SIPrefix::GIGA, energy);

   return J / TMath::Power(1. + TMath::Exp(-(TMath::Log(R) - mu)/sigma), 1./rho);
}

Double_t LISModels::Models::GTF::AMS15BESS07(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy)
{
   // Aguilar et al, 2015 + Shikaze et al, 2007
   // GTF = beta^{gamma2}
   // [gamma2] = unitless

   Double_t gamma2 = par[4];

   Double_t R = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::RIGIDITY);
   Double_t J = Unit::EnergyJacobian(R, particle, Energy::RIGIDITY, SIPrefix::GIGA, energy);
   //~ Double_t T  = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::KINETIC);
   Double_t JT = 1.;//Unit::EnergyJacobian(T, particle, Energy::KINETIC, SIPrefix::GIGA, energy);

   Double_t beta = Unit::Beta(R, particle, Energy::RIGIDITY, SIPrefix::GIGA);

   return J * JT*TMath::Power(beta, gamma2);
}

Double_t LISModels::Models::GTF::AMS15BPH00U05(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy)
{
   // Aguilar et al, 2015 + Burger et al, 2000 (as used in Usoskin et al, 2005)
   // GTF = 1 / (1 + N2 R^{-gamma2})
   // [R] = GV
   // [gamma2] = unitless
   // [N2] = GV^{gamma2}

   Double_t N2     = par[4];
   Double_t gamma2 = par[5];

   Double_t R = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::RIGIDITY);
   Double_t J = Unit::EnergyJacobian(R, particle, Energy::RIGIDITY, SIPrefix::GIGA, energy);
   //~ Double_t T  = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::KINETIC);
   Double_t JT = 1.;//Unit::EnergyJacobian(T, particle, Energy::KINETIC, SIPrefix::GIGA, energy);

   return J * JT/(1. + N2 * TMath::Power(R, -gamma2));
}

Double_t LISModels::Models::GTF::AMS15GMS75(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy)
{
   // Aguilar et al, 2015 + Garcia-Munoz et al, 1975 [in the paper: flux in (m^2 sr s MeV)^{-1} and energy in MeV]
   // GTF = (1 + N2/T e^{-a T})^{-gamma}
   // [T] = GeV
   // [gamma] = unitless
   // [N2] = GeV
   // [a] = GeV^{-1}

   Double_t gamma = par[0];
   Double_t N2    = par[4];
   Double_t a     = par[5];

   Double_t R = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::RIGIDITY);
   Double_t J = Unit::EnergyJacobian(R, particle, Energy::RIGIDITY, SIPrefix::GIGA, energy);
   Double_t T  = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::KINETIC);
   Double_t JT = 1.;//Unit::EnergyJacobian(T, particle, Energy::KINETIC, SIPrefix::GIGA, energy);

   return J * JT*TMath::Power(1. + N2/T * TMath::Exp(-a*T), -gamma);
}

Double_t LISModels::Models::GTF::AMS15WH03U05(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy)
{
   // Aguilar et al, 2015 + Webber and Higbie, 2003 (as used in Usoskin et al, 2005)
   // GTF = 1 / (1 + N2 T^{-gamma2} + N3 T^{-gamma3})
   // [T] = GeV
   // [gamma2] = [gamma3] = unitless
   // [N2] = GeV^{gamma2}
   // [N3] = GeV^{gamma3}

   Double_t N2     = par[4];
   Double_t gamma2 = par[5];
   Double_t N3     = par[6];
   Double_t gamma3 = par[7];

   Double_t R = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::RIGIDITY);
   Double_t J = Unit::EnergyJacobian(R, particle, Energy::RIGIDITY, SIPrefix::GIGA, energy);
   Double_t T  = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::KINETIC);
   Double_t JT = 1.;//Unit::EnergyJacobian(T, particle, Energy::KINETIC, SIPrefix::GIGA, energy);

   return J * JT/(1. + N2 * TMath::Power(T, -gamma2) + N3 * TMath::Power(T, -gamma3));
}

Double_t LISModels::Models::GTF::AMS15L04(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy)
{
   // Aguilar et al, 2015 + Langner, 2004 (as used in Usoskin et al, 2005) [in the paper: flux in (m^2 sr s MeV)^{-1} and energy in GeV]
   // GTF = Galprop parametrization
   // [T] = GeV
   // [a] = [N2] = [gamma] = unitless

   Double_t gamma = par[0];
   Double_t a     = par[4];
   Double_t N2    = par[5];

   Double_t R = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::RIGIDITY);
   Double_t J = Unit::EnergyJacobian(R, particle, Energy::RIGIDITY, SIPrefix::GIGA, energy);
   Double_t T  = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::KINETIC);
   Double_t JT = 1.;//Unit::EnergyJacobian(T, particle, Energy::KINETIC, SIPrefix::GIGA, energy);

   Double_t c = (2*gamma - TMath::Log(N2))/3.;
   Double_t b = 2*(gamma - c);

   Double_t gtf;
   if (T < 1.)
   {
      gtf = N2 * TMath::Exp(-a*TMath::Log(T)*TMath::Log(T) - b*TMath::Sqrt(T)) / TMath::Power(T, -gamma);
   }
   else
   {
      gtf = TMath::Exp(-c/T);
   }

   return J *JT*gtf;
}

Double_t LISModels::Models::GTF::ThreePowerLawRig(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy)
{
   // Corti, 2015 (Three power laws with smooth transitions)
   // GTF = {1 + [R/Rb1 (1 + (R/Rb2)^(delta2/s2))^s2]^(-delta1/s1)}^s1
   // [R] = GV
   // [delta1] = [s1] = [delta2] = [s2] = unitless
   // [Rb1] = [Rb2] = GV

   Double_t Rb1    = par[1];
   Double_t delta1 = par[2];
   Double_t s1     = par[3];
   Double_t Rb2    = par[4];
   Double_t delta2 = par[5];
   Double_t s2     = par[6];

   Double_t R = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::RIGIDITY);
   Double_t J = Unit::EnergyJacobian(R, particle, Energy::RIGIDITY, SIPrefix::GIGA, energy);

   return J * TMath::Power(1. + TMath::Power(R/Rb1 * TMath::Power(1. + TMath::Power(R/Rb2, delta2/s2), s2), -delta1/s1), s1);
}

Double_t LISModels::Models::GTF::Corti16(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy)
{
   // Corti, 2015 (Three power laws with smooth transitions)
   // GTF = {1 + [R/Rb1 (1 + (R/Rb2)^(delta2/s2))^s2]^(-delta1/s1)}^s1
   // [R] = GV
   // [delta1] = [s1] = [delta2] = [s2] = unitless
   // [Rb1] = [Rb2] = GV

   Double_t Rb1    = par[1];
   Double_t delta1 = par[2];
   Double_t s1     = par[3];
   Double_t Rb2    = par[4];
   Double_t delta2 = par[5];
   Double_t s2     = par[6];

   Double_t R = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::RIGIDITY);
   Double_t J = Unit::EnergyJacobian(R, particle, Energy::RIGIDITY, SIPrefix::GIGA, energy);

   return J * TMath::Power(1. + TMath::Power(R/Rb1 * TMath::Power(1. + TMath::Power(R/Rb2, delta2/s2), s2), -delta1/s1), s1);
}

Double_t LISModels::Models::GTF::Vos15(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy)
{
   // Vos (2015)
   // GTF = 1/beta^2 T^(gamma1-gamma2) ((T^s-Tb^s)/(1+Tb^s)^((gamma2-gamma1)/s)
   // [T] = GeV
   // [N] = (m^2 sr s GeV^{1-gamma1})^{-1}
   // [gamma1] = [gamma2] = [s] = unitless
   // [Tb] = GeV

   Double_t gamma1 = par[0];
   Double_t gamma2 = par[1];
   Double_t s      = par[2];
   Double_t Tb     = par[4];

   Double_t T = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::KINETIC);
   Double_t J = Unit::EnergyJacobian(T, particle, Energy::KINETIC, SIPrefix::GIGA, energy);

   Double_t beta = Unit::Beta(T, particle, Energy::KINETIC, SIPrefix::GIGA);

   return J * TMath::Power(T, gamma1-gamma2) / (beta*beta) * TMath::Power((TMath::Power(T, s) + TMath::Power(Tb, s)) / (1. + TMath::Power(Tb, s)), (gamma2 - gamma1)/s);
}

Double_t LISModels::Models::GTF::BON14(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy)
{
   // Badhwar - O'Neill, 2014
   // GTF = beta^{delta}
   // [Tn] = GeV/n
   // [delta] = unitless

   Double_t delta = par[1];

   Double_t Tn = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::KINETICPERNUCLEON);
   Double_t J  = Unit::EnergyJacobian(Tn, particle, Energy::KINETICPERNUCLEON, SIPrefix::GIGA, energy);

   Double_t beta = Unit::Beta(Tn, particle, Energy::KINETICPERNUCLEON, SIPrefix::GIGA);

   return J * TMath::Power(beta, delta);
}

Double_t LISModels::Models::GTF::Ghelfi16(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy)
{
   // Ghelfi et al, 2016
   // log10(dJ/dTn) = spline parametrization
   // [Tn] = GeV/n
   // [N] = (m^2 sr s GeV)^{-1}

   const Double_t Tn_thr = 800.;

   Double_t gamma = par[16];
   //~ Double_t gamma = par[14];

   //~ Double_t c14 = -TMath::Log10(Tn_thr)*gamma;
   //~ for (UShort_t i = 1; i <= 13; ++i)
   //~ {
      //~ c14 -= i*par[i];
   //~ }
   //~ c14 /= 14.;

   Double_t Tn = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::KINETICPERNUCLEON);
   Double_t J  = Unit::EnergyJacobian(Tn, particle, Energy::KINETICPERNUCLEON, SIPrefix::GIGA, energy);

   x = TMath::Log10(Tn)/TMath::Log10(Tn_thr);
   Double_t lflux = 0.;
   if (Tn < Tn_thr)
   {
      lflux = gamma*TMath::Log10(Tn/Tn_thr);
      for (UShort_t i = 0; i <= 14; ++i)
      //~ for (UShort_t i = 0; i <= 13; ++i)
      {
         lflux += par[i] * (TMath::Power(x, i) - 1.);
      }
      //~ lflux += c14 * (TMath::Power(x, 14.) - 1.);
   }

   return J * TMath::Power(10., lflux);
}

Double_t LISModels::Models::GTF::Bisschoff16(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy)
{
   // Bisschoff & Potgieter, 2016
   // GTF = 1/beta^2 T^(gamma1-gamma2) ((T^s-Tb^s)/(1+Tb^s)^((gamma2-gamma1)/s)
   // [T] = GeV
   // [N] = (m^2 sr s GeV^{1-gamma1})^{-1}
   // [gamma1] = [gamma2] = [s] = unitless
   // [Tb] = GeV

   Double_t gamma1 = par[0];
   Double_t gamma2 = par[1];
   Double_t s      = par[2];
   Double_t Tb     = par[4];

   Double_t T = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::KINETIC);
   Double_t J = Unit::EnergyJacobian(T, particle, Energy::KINETIC, SIPrefix::GIGA, energy);

   Double_t beta = Unit::Beta(T, particle, Energy::KINETIC, SIPrefix::GIGA);

   return J * TMath::Power(T, gamma1-gamma2) / (beta*beta) * TMath::Power((TMath::Power(T, s) + TMath::Power(Tb, s)) / (1. + TMath::Power(Tb, s)), (gamma2 - gamma1)/s);
}

Double_t LISModels::Models::GTF::Herbst17(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy)
{
   // Herbst et al, 2017 [original flux in 1/(m^2 sr s MeV), energy in GeV (?)]
   // GTF = Galprop parametrization
   // [T] = GeV
   // [a] = [N2] = [gamma] = unitless

   Double_t a     = par[0];
   Double_t N2    = par[1];
   Double_t gamma = par[2];

   const Double_t Tb  = 1.4;
   const Double_t lTb = TMath::Log(Tb);

   Double_t c = Tb/3. * ((2.-lTb)*gamma - (4.-lTb)*a*lTb - TMath::Log(N2));
   Double_t b = 2./TMath::Sqrt(Tb) * (gamma - c/Tb - 2.*a*lTb);

   Double_t T = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::KINETIC);
   Double_t J = Unit::EnergyJacobian(T, particle, Energy::KINETIC, SIPrefix::GIGA, energy);

   if (T < Tb)
   {
      return J * N2 * TMath::Exp(-a*TMath::Log(T)*TMath::Log(T) - b*TMath::Sqrt(T)) / TMath::Power(T, -gamma);
   }
   else
   {
      return J * TMath::Exp(-c/T);
   }
}

Double_t LISModels::Models::GTF::SmoothPLRig3(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy)
{
   // Corti, 2018 (Three power laws with smooth transitions)
   // dJ/dR = [1+(R/R1)^s1]^{Delta1/s1} [1+(R/R2)^s2]^{Delta2/s2} / (R/R1)^s1 / (R/R2)^s2
   // [R] = GV
   // [Delta1] = [s1] = [Delta2] = [s2] = unitless
   // [R1] = [R2] = GV

   Double_t Rb[2]    = { par[1], par[4] };
   Double_t s[2]     = { par[2], par[5] };
   Double_t Delta[2] = { par[3], par[6] };

   Double_t R = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::RIGIDITY);
   Double_t J = Unit::EnergyJacobian(R, particle, Energy::RIGIDITY, SIPrefix::GIGA, energy);

   Double_t pl = 1.;
   for (UShort_t i = 0; i < 2; ++i)
   {
      pl *= TMath::Power(1. + TMath::Power(R/Rb[i], -s[i]), Delta[i]/s[i]);
   }

   return J * pl;
}

Double_t LISModels::Models::GTF::SmoothPLRig4(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy)
{
   // Corti, 2018 (Four power laws with smooth transitions)
   // dJ/dR =  N [1+(R/R1)^s1]^{Delta1/s1} [1+(R/R2)^s2]^{Delta2/s2} [1+(R/R3)^s3]^{Delta3/s3} / (R/R1)^s1 / (R/R2)^s2 / (R/R3)^s3
   // [R] = GV
   // [Delta1] = [s1] = [Delta2] = [s2] = [Delta3] = [s3] = unitless
   // [R1] = [R2] = [R3] = GV

   Double_t Rb[3]    = { par[1], par[4], par[7] };
   Double_t s[3]     = { par[2], par[5], par[8] };
   Double_t Delta[3] = { par[3], par[6], par[9] };

   Double_t R = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::RIGIDITY);
   Double_t J = Unit::EnergyJacobian(R, particle, Energy::RIGIDITY, SIPrefix::GIGA, energy);

   Double_t pl = 1.;
   for (UShort_t i = 0; i < 3; ++i)
   {
      pl *= TMath::Power(1. + TMath::Power(R/Rb[i], -s[i]), Delta[i]/s[i]);
   }

   return J * pl;
}

Double_t LISModels::Models::GTF::SmoothPLRig4Log(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy)
{
   // Corti, 2018 (Four power laws with smooth transitions)
   // dJ/dR =  N [1+(R/R1)^s1]^{Delta1/s1} [1+(R/R2)^s2]^{Delta2/s2} [1+(R/R3)^s3]^{Delta3/s3} / (R/R1)^s1 / (R/R2)^s2 / (R/R3)^s3
   // [R] = GV
   // [Delta1] = [s1] = [Delta2] = [s2] = [Delta3] = [s3] = unitless
   // [R1] = [R2] = [R3] = GV

   Double_t gamma0   = par[0];
   Double_t Rb[3]    = { pow(10, par[1]), pow(10, par[4]), par[7] };
   Double_t s[3]     = { pow(10, par[2]), pow(10, par[5]), pow(10, par[8]) };
   //~ Double_t gamma[3] = { par[3], par[6], par[9] };
   //~ Double_t Delta[3] = { gamma[0]-gamma0, gamma[1]-gamma[0], gamma[2]-gamma[1] };
   Double_t Delta[3] = { par[3], par[6], par[9] };

   Double_t R = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::RIGIDITY);
   Double_t J = Unit::EnergyJacobian(R, particle, Energy::RIGIDITY, SIPrefix::GIGA, energy);

   Double_t pl = 1.;
   for (UShort_t i = 0; i < 3; ++i)
   {
      pl *= TMath::Power(1. + TMath::Power(R/Rb[i], -s[i]), Delta[i]/s[i]);
   }

   return J * pl;
}

Double_t LISModels::Models::GTF::GalpropKinNuc(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy)
{
   // Galprop 55 BMP (Kunz, 2015)
   // GTF = Interpolate Galprop output / Tn^{-gamma}
   // [T] = GeV/n

   UShort_t igalprop = par[0];
   UShort_t imodel   = par[1];

   Double_t Tn = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::KINETICPERNUCLEON);
   Double_t J  = Unit::EnergyJacobian(Tn, particle, Energy::KINETICPERNUCLEON, SIPrefix::GIGA, energy);

   Double_t lnTn = log(Tn);

   // find closest bin of galprop_kin to T and interpolate galprop_flux with a power law
   vector<Double_t> &kinlog  = galprop_kinlog[igalprop][imodel][particle];
   vector<Double_t> &fluxlog = galprop_fluxlog[igalprop][imodel][particle];
   Int_t nbins = kinlog.size();
   Int_t bin   = find_nearest(lnTn, kinlog);
   Int_t bin1, bin2;
   if (lnTn <= kinlog[bin] && bin > 0)
   {
      bin1 = bin - 1;
      bin2 = bin;
   }
   else if (bin == nbins)
   {
      bin1 = bin - 2;
      bin2 = bin - 1;
   }
   else
   {
      bin1 = bin;
      bin2 = bin + 1;
   }
   Double_t x1 = kinlog[bin1];
   Double_t x2 = kinlog[bin2];
   Double_t y1 = fluxlog[bin1];
   Double_t y2 = fluxlog[bin2];

   Double_t gamma = -(fluxlog[nbins-1] - fluxlog[nbins-2]) / (kinlog[nbins-1] - kinlog[nbins-2]);
   Double_t norm  = galprop_flux[igalprop][imodel][particle][nbins-1] / TMath::Power(galprop_kin[igalprop][imodel][particle][nbins-1], -gamma);

   return J * TMath::Exp(y1 + (lnTn - x1) * ((y2 - y1) / (x2 - x1))) / TMath::Power(Tn, -gamma) / norm;
}

Double_t LISModels::FittingModel(Double_t *x, Double_t *par)
{
   /// parameters:
   ///    0  = LISModels::Type; fixed during fit
   ///    1  = Energy::Type; fixed during fit
   ///    2  = Particle::Type; fixed during fit
   ///    3  = N: flux normalization [(GeV/GV s m^2 sr)^{-1}]; free during fit
   ///    4- = parameters used by the LIS formula; free during fit

   Double_t xx = x[0];

   LISModels::Type lismodel = cast(par[0]);
   Energy::Type    energy   = Energy::cast(par[1]);
   Particle::Type  particle = Particle::cast(par[2]);

   Double_t N = par[3];

   return N * Info[lismodel].Model(xx, &par[4], particle, energy);
}

Double_t LISModels::FittingGTF(Double_t *x, Double_t *par)
{
   /// parameters:
   ///    0  = LISModels::Type; fixed during fit
   ///    1  = Energy::Type; fixed during fit
   ///    2  = Particle::Type; fixed during fit
   ///    3  = N: flux normalization [(GeV/GV s m^2 sr)^{-1}]; free during fit
   ///    4- = parameters used by the LIS formula; free during fit

   Double_t xx = x[0];

   LISModels::Type lismodel = cast(par[0]);
   Energy::Type    energy   = Energy::cast(par[1]);
   Particle::Type  particle = Particle::cast(par[2]);

   return Info[lismodel].GTF(xx, &par[3], particle, energy);
}

TF1 *LISModels::CreateFunction(const Char_t *name, Double_t min_ene, Double_t max_ene, LISModels::Type lismodel, Particle::Type particle, Energy::Type energy, Bool_t fixlis)
{
   TF1 *f_lis = new TF1(name, FittingModel, min_ene, max_ene, 4 + Info[lismodel].nParameters);

   f_lis->SetParName(0, "lismodel");
   f_lis->FixParameter(0, lismodel);

   f_lis->SetParName(1, "energytype");
   f_lis->FixParameter(1, energy);

   f_lis->SetParName(2, "particle");
   f_lis->FixParameter(2, particle);

   f_lis->SetParName(3, "norm");
   if (fixlis)
   {
      f_lis->FixParameter(3, Info[lismodel].Normalization);
   }
   else
   {
      f_lis->SetParameter(3, Info[lismodel].Normalization);
      f_lis->SetParLimits(3, Info[lismodel].Normalization < 1. ? 0.01 : 5.,
         Info[lismodel].Normalization < 1. ? 1. : (Info[lismodel].Normalization < 1e4 ? 1e5 : (Info[lismodel].Normalization < 1e5 ? 1e5 : 1e6)));
   }

   for (UShort_t ipar = 0; ipar < Info[lismodel].nParameters; ++ipar)
   {
      f_lis->SetParName(4 + ipar, Info[lismodel].Parameter[ipar].Name);
      if ((lismodel == AMS15V1 && ((fixlis % 2 == 1 && 0 <= ipar && ipar <= 3) || (fixlis / 2 > 0 && ipar >= 3))) || fixlis)
      {
         f_lis->FixParameter(4 + ipar, Info[lismodel].Parameter[ipar].Med);
      }
      else
      {
         f_lis->SetParameter(4 + ipar, Info[lismodel].Parameter[ipar].Med);
         f_lis->SetParLimits(4 + ipar, Info[lismodel].Parameter[ipar].Min, Info[lismodel].Parameter[ipar].Max);
      }
   }

   return f_lis;
}

LISModels::Model::Model(const Char_t *name, Double_t min_ene, Double_t max_ene, LISModels::Type lismodel, Particle::Type particle, Energy::Type energy, Bool_t fixlis) :
   _lismodel(lismodel), _energy(energy), _particle(particle)
{
   _func = new TF1(name, this, min_ene, max_ene, Info[_lismodel].nParameters + 1);

   _func->SetParName(0, "norm");
   if (fixlis)
   {
      _func->FixParameter(0, Info[_lismodel].Normalization);
   }
   else
   {
      _func->SetParameter(0, Info[_lismodel].Normalization);
      _func->SetParLimits(0, Info[_lismodel].Normalization < 1. ? 0.01 : 5.,
         Info[_lismodel].Normalization < 1. ? 1. : (Info[_lismodel].Normalization < 1e4 ? 1e5 : (Info[_lismodel].Normalization < 1e5 ? 1e5 : 1e6)));
   }

   for (UShort_t ipar = 0; ipar < Info[_lismodel].nParameters; ++ipar)
   {
      _func->SetParName(1 + ipar, Info[_lismodel].Parameter[ipar].Name);
      if (fixlis)
      {
         _func->FixParameter(1 + ipar, Info[_lismodel].Parameter[ipar].Med);
      }
      else
      {
         _func->SetParameter(1 + ipar, Info[_lismodel].Parameter[ipar].Med);
         _func->SetParLimits(1 + ipar, Info[_lismodel].Parameter[ipar].Min, Info[_lismodel].Parameter[ipar].Max);
      }
   }

   _func->SetNpx(200);
}

Double_t LISModels::Model::operator()(Double_t *x, Double_t *par)
{
   /// parameters:
   ///    0     = N: flux normalization [(GeV/GV s m^2 sr)^{-1}]
   ///    1-end = parameters used by the LIS formula

   Double_t xx = x[0];

   return par[0] * Info[_lismodel].Model(xx, &par[1], _particle, _energy);
}

TF1 *LISModels::Model::CreateFunction(const Char_t *name, Double_t min_ene, Double_t max_ene, LISModels::Type lismodel, Particle::Type particle, Energy::Type energy, Bool_t fixlis)
{
   Model *m = new Model(name, min_ene, max_ene, lismodel, particle, energy, fixlis);
   return m->GetTF1Pointer();
}

TF1 *LISModels::CreateGTFFunction(const Char_t *name, Double_t min_ene, Double_t max_ene, LISModels::Type lismodel, Particle::Type particle, Energy::Type energy, Bool_t fixlis)
{
   TF1 *f_lis = new TF1(name, FittingGTF, min_ene, max_ene, 3 + Info[lismodel].nParameters);

   f_lis->SetParName(0, "lismodel");
   f_lis->FixParameter(0, lismodel);

   f_lis->SetParName(1, "energytype");
   f_lis->FixParameter(1, energy);

   f_lis->SetParName(2, "particle");
   f_lis->FixParameter(2, particle);

   for (UShort_t ipar = 0; ipar < Info[lismodel].nParameters; ++ipar)
   {
      f_lis->SetParName(3 + ipar, Info[lismodel].Parameter[ipar].Name);
      if (fixlis)
      {
         f_lis->FixParameter(3 + ipar, Info[lismodel].Parameter[ipar].Med);
      }
      else
      {
         f_lis->SetParameter(3 + ipar, Info[lismodel].Parameter[ipar].Med);
         f_lis->SetParLimits(3 + ipar, Info[lismodel].Parameter[ipar].Min, Info[lismodel].Parameter[ipar].Max);
      }
   }

   return f_lis;
}

TF1 *LISModels::CreateGalpropModel(const Char_t *name, Double_t min_ene, Double_t max_ene, LISModels::Models::Galprop::Type galprop, UShort_t imodel, Particle::Type particle, Energy::Type energy, Bool_t fixlis)
{
   LISModels::Type lismodel = cast(LISModels::GALPROP55BMP + galprop);

   TF1 *f_lis = new TF1(name, FittingModel, min_ene, max_ene, 4 + Info[lismodel].nParameters);

   f_lis->SetParName(0, "lismodel");
   f_lis->FixParameter(0, lismodel);

   f_lis->SetParName(1, "energytype");
   f_lis->FixParameter(1, energy);

   f_lis->SetParName(2, "particle");
   f_lis->FixParameter(2, particle);

   f_lis->SetParName(3, "norm");
   if (fixlis)
   {
      f_lis->FixParameter(3, Info[lismodel].Normalization);
   }
   else
   {
      f_lis->SetParameter(3, Info[lismodel].Normalization);
      f_lis->SetParLimits(3, 0., Info[lismodel].Normalization < 1 ? 1. : (Info[lismodel].Normalization < 1e5 ? 1e5 : 1e6));
   }

   f_lis->SetParName(4, Info[lismodel].Parameter[0].Name);
   f_lis->FixParameter(4, galprop);

   f_lis->SetParName(5, Info[lismodel].Parameter[1].Name);
   f_lis->FixParameter(5, imodel);

   return f_lis;
}

const ParameterInfo *LISModels::GetSpectralIndexParInfo(LISModels::Type lismodel)
{
   const ParameterInfo *parinfo = NULL;

   if (lismodel < LISModels::GALPROP55BMP)
   {
      const ModelInfo &lisinfo = Info[lismodel];

      for (UShort_t ipar = 0; ipar < lisinfo.nParameters; ++ipar)
      {
         parinfo = &lisinfo.Parameter[ipar];

         const Char_t *p = strstr(parinfo->Name, "gamma1");
         if (p == NULL) p = strstr(parinfo->Name, "gamma");
         if (p != NULL) break;
      }
   }

   return parinfo;
}

const ParameterInfo *LISModels::GetGalpropSpectralIndexParInfo(LISModels::Type lismodel, UShort_t imodel)
{
   static ParameterInfo *parinfo = new ParameterInfo;

   if (lismodel >= LISModels::GALPROP55BMP)
   {
      UShort_t galprop = LISModels::cast(LISModels::GALPROP55BMP) - LISModels::cast(lismodel);
      UShort_t ipar;
      for (ipar = 0; ipar < LISModels::Models::Galprop::nParameters[galprop]; ++ipar)
      {
         const ParameterInfo *parinfo = &LISModels::Models::Galprop::Info[galprop][ipar];

         const Char_t *p = strstr(parinfo->Name, "alpha1");
         if (p == NULL) p = strstr(parinfo->Name, "alpha");
         if (p == NULL) p = strstr(parinfo->Title, "irst spectral index");
         if (p == NULL) p = strstr(parinfo->Title, "pectral index");
         if (p != NULL) break;
      }
      if (ipar != LISModels::Models::Galprop::nParameters[galprop])
      {
         const ParameterInfo *info = &LISModels::Models::Galprop::Info[galprop][ipar];
         *parinfo = *info;
         parinfo->Med = LISModels::Models::Galprop::Parameter[galprop][imodel][ipar];

         return parinfo;
      }
      else return NULL;
   }
   else return NULL;
}

void LISModels::LoadGalpropModels(LISModels::Models::Galprop::Type galprop, Particle::Type particle)
{
   for (UShort_t imodel = 0; imodel < LISModels::Models::Galprop::nModels[galprop]; ++imodel)
   {
      Char_t path[256];
      snprintf(path, 256, "%s/%s_%u/%s", LISModels::Models::Galprop::DataPath.c_str(), LISModels::Models::Galprop::DataPrefix[galprop], imodel, Particle::Name[particle]);

      ifstream data_file;
      data_file.open(path);
      if (!data_file.is_open())
      {
         cerr << FG_RED_B << Form(" !!! LISModels::LoadGalpropModels-E-Data file '%s' not found", path) << RESET << endl;
         continue;
      }

      galprop_kin[galprop][imodel][particle].clear();
      galprop_kinlog[galprop][imodel][particle].clear();
      galprop_flux[galprop][imodel][particle].clear();
      galprop_fluxlog[galprop][imodel][particle].clear();

      //~ cout << " ### GALPROP model " << imodel << endl;
      //~ cout << "galprop_kin = " << &galprop_kin[galprop][imodel][particle] << endl
           //~ << "galprop_kinlog = " << &galprop_kinlog[galprop][imodel][particle] << endl
           //~ << "galprop_flux = " << &galprop_flux[galprop][imodel][particle] << endl
           //~ << "galprop_fluxlog = " << &galprop_fluxlog[galprop][imodel][particle] << endl;

      Double_t ene;
      Double_t flux;
      while (true)
      {
         data_file >> ene >> flux;

         if (data_file.eof()) break;

         galprop_kin[galprop][imodel][particle].push_back(ene);
         galprop_kinlog[galprop][imodel][particle].push_back(log(ene));
         galprop_flux[galprop][imodel][particle].push_back(flux);
         galprop_fluxlog[galprop][imodel][particle].push_back(log(flux));
      }

      data_file.close();

      //~ cout << endl << endl;
   }

   //~ for (UShort_t ibin = 0; ibin < galprop_kin[galprop][0][particle].size(); ++ibin)
   //~ {
      //~ cout << Form("[%02u] { %9.4f, %11.6e } { %+6.2f, %+6.2f}", ibin,
         //~ galprop_kin[galprop][0][particle][ibin], galprop_flux[galprop][0][particle][ibin],
         //~ galprop_kinlog[galprop][0][particle][ibin], galprop_fluxlog[galprop][0][particle][ibin]) << endl;
   //~ }
   //~ cout << endl;
}

TGraph *LISModels::GetGalpropModelGraph(LISModels::Models::Galprop::Type galprop, UShort_t imodel, Particle::Type particle)
{
   LISModels::Type lismodel = cast(LISModels::GALPROP55BMP + galprop);

   Char_t name[100];
   snprintf(name, 100, "g_%s_%02u_%s", LISModels::Info[lismodel].Name, imodel, Particle::Name[particle]);

   TGraph *g = (TGraph *)gROOT->FindObject(name);
   if (g == NULL)
   {
      vector<Double_t> &kin  = galprop_kin[galprop][imodel][particle];
      vector<Double_t> &flux = galprop_flux[galprop][imodel][particle];

      g = new TGraph(kin.size());
      for (UShort_t ipoint = 0; ipoint < kin.size(); ++ipoint)
      {
         g->SetPoint(ipoint, kin[ipoint], flux[ipoint]);
      }
   }

   return g;
}
