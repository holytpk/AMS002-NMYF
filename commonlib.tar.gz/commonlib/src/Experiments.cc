#include "Experiments.hh"
#include "HistTools.hh"
#include "debug.hh"

using namespace std;

const UInt_t PATH_LENGTH = 256;
const UInt_t NAME_LENGTH = 256;

template <class T>
void convert_flux_energy(T *obj, const Experiments::DatasetInfo &dataset, Energy::Type energy, SIPrefix::Type energy_prefix = SIPrefix::GIGA, SIPrefix::Type area_prefix = SIPrefix::NONE)
{
   Energy::Type   exp_energy   = dataset.Energy;
   SIPrefix::Type exp_ene_pfx  = dataset.EnergyPrefix;
   SIPrefix::Type exp_area_pfx = dataset.AreaPrefix;

   HistTools::TransformEnergyAndDifferentialFlux(obj, dataset.Particle[0], exp_energy, exp_ene_pfx, exp_energy, exp_ene_pfx, exp_area_pfx,
      energy, energy_prefix, energy, energy_prefix, area_prefix);

   string name = obj->GetName();
   size_t p1 = name.find(Energy::Name[exp_energy]);
   obj->SetName(name.replace(p1, strlen(Energy::Name[exp_energy]), Energy::Name[energy]).c_str());
}
template void convert_flux_energy(TH1 *, const Experiments::DatasetInfo &, Energy::Type, SIPrefix::Type, SIPrefix::Type);
template void convert_flux_energy(TGraph *, const Experiments::DatasetInfo &, Energy::Type, SIPrefix::Type, SIPrefix::Type);

TGraphAsymmErrors *hist2graph(TH1 *hist)
{
   Char_t name[NAME_LENGTH];
   snprintf(name, NAME_LENGTH, "%s", hist->GetName());
   name[0] = 'g';
   TGraphAsymmErrors *graph = new TGraphAsymmErrors(hist);
   graph->SetName(name);
   graph->SetTitle(Form("%s;%s;%s", hist->GetTitle(), hist->GetXaxis()->GetTitle(), hist->GetYaxis()->GetTitle()));
   gROOT->Append(graph);
   HistTools::ResetStyle(graph);

   return graph;
}

TH1D *graph2hist(TGraph *graph, const Experiments::DatasetInfo &dataset)
{
   TH1D *hist = HistTools::GraphToHist(graph);
   hist->SetStats(false);
   hist->SetDirectory(gROOT);
   hist->SetXTitle(Unit::GetEnergyLabel(dataset.Energy, dataset.EnergyPrefix));
   hist->SetYTitle(Unit::GetDifferentialFluxLabel(dataset.Energy, dataset.EnergyPrefix, dataset.AreaPrefix));
   HistTools::ResetStyle(hist);

   return hist;
}

/// === [START] AMS-02 DATA FUNCTIONS ===
const UInt_t FIRST_AMS02_BARTELS_ROTATION = 2426;

TFile *get_ams02_proton_file(Bool_t open_file = true)
{
   Char_t path[PATH_LENGTH];
   Char_t name[NAME_LENGTH] = "ams02_H_flux.root";
   snprintf(path, PATH_LENGTH, "%s/ams02/%s", Experiments::DataPath.c_str(), name);

   TFile *f_ams02 = (TFile *)gROOT->GetListOfFiles()->FindObject(path);
   if (f_ams02 == NULL && open_file)
   {
      f_ams02 = new TFile(path);
      if (f_ams02->IsZombie() || !f_ams02->IsOpen())
      {
         cerr << FG_RED_B << Form(" !!! get_ams02_proton_file-E-File not opened: %s", path) << RESET << endl;

         delete f_ams02;

         return NULL;
      }
   }

   return f_ams02;
}

TFile *get_ams02_helium_file(Bool_t open_file = true)
{
   Char_t path[PATH_LENGTH];
   Char_t name[NAME_LENGTH] = "ams02_He_flux.root";
   snprintf(path, PATH_LENGTH, "%s/ams02/%s", Experiments::DataPath.c_str(), name);

   TFile *f_ams02 = (TFile *)gROOT->GetListOfFiles()->FindObject(path);
   if (f_ams02 == NULL && open_file)
   {
      f_ams02 = new TFile(path);
      if (f_ams02->IsZombie() || !f_ams02->IsOpen())
      {
         cerr << FG_RED_B << Form(" !!! get_ams02_helium_file-E-File not opened: %s", path) << RESET << endl;

         delete f_ams02;

         return NULL;
      }
   }

   return f_ams02;
}

TFile *get_ams02_helium_2017_file(Bool_t open_file = true)
{
   Char_t path[PATH_LENGTH];
   Char_t name[NAME_LENGTH] = "ams02_He_flux_2017.root";
   snprintf(path, PATH_LENGTH, "%s/ams02/%s", Experiments::DataPath.c_str(), name);

   TFile *f_ams02 = (TFile *)gROOT->GetListOfFiles()->FindObject(path);
   if (f_ams02 == NULL && open_file)
   {
      f_ams02 = new TFile(path);
      if (f_ams02->IsZombie() || !f_ams02->IsOpen())
      {
         cerr << FG_RED_B << Form(" !!! get_ams02_helium_2017_file-E-File not opened: %s", path) << RESET << endl;

         delete f_ams02;

         return NULL;
      }
   }

   return f_ams02;
}

TTree *get_ams02_proton_tree(TFile *f_ams02 = NULL)
{
   if (f_ams02 == NULL) f_ams02 = get_ams02_proton_file();
   if (f_ams02 == NULL) return NULL;

   TTree *tree = NULL;
   Char_t name[NAME_LENGTH];
   snprintf(name, NAME_LENGTH, "ams02_pflux");
   f_ams02->GetObject(name, tree);
   if (tree == NULL)
   {
      cerr << FG_RED_B << Form(" !!! add_ams02_syst_error-E-Tree not found: %s", name) << RESET << endl;
      return NULL;
   }

   return tree;
}

void add_ams02_syst_error(TH1D *hist)
{
   TTree *tree =get_ams02_proton_tree();
   if (tree == NULL) return;

   Double_t syst;
   tree->SetBranchAddress("syst", &syst);
   for (UShort_t ibin = 1; ibin <= tree->GetEntries(); ++ibin)
   {
      tree->GetEntry(ibin - 1);

      Double_t stat = hist->GetBinError(ibin);
      Double_t err  = TMath::Sqrt(stat*stat + syst*syst);
      hist->SetBinError(ibin, err);
   }
   tree->ResetBranchAddresses();
}

void shift_alignment(TH1D *hist, TString &opt)
{
   Ssiz_t p = opt.Index("aligshift");
   Double_t shift = (opt[p + 9] == 'p' ? -1. : 1.)*26e3; // +- 1/(26 TV)

   UShort_t nbins = hist->GetNbinsX();
   TArrayD axis(*(hist->GetXaxis()->GetXbins()));
   for (UShort_t ibin = 0; ibin <= nbins; ++ibin)
   {
      Double_t R = axis[ibin];
      axis[ibin] *= shift/(R + shift);
   }
   hist->GetXaxis()->Set(nbins, axis.GetArray());

   hist->SetName(Form("%s_aligshift%c", hist->GetName(), shift > 0. ? 'p' : 'm'));
}

void remove_ams02_alig_error(TH1D *hist)
{
   TTree *tree = get_ams02_proton_tree();
   if (tree == NULL) return;

   Double_t alig_err;
   tree->SetBranchAddress("scale", &alig_err);
   for (UShort_t ibin = 1; ibin <= tree->GetEntries(); ++ibin)
   {
      tree->GetEntry(ibin - 1);

      Double_t full_err = hist->GetBinError(ibin);
      Double_t err = TMath::Sqrt(full_err*full_err - alig_err*alig_err);
      hist->SetBinError(ibin, err);
   }
   tree->ResetBranchAddresses();

   hist->SetName(Form("%s_noaligerr", hist->GetName()));
}

TH1D *get_ams02_proton_monthly_flux_hist(UShort_t idataset, UShort_t imeasurement, TString &opt, Bool_t keep_file_open)
{
   const Experiments::ExperimentInfo  &exp         = Experiments::Info[Experiments::AMS02];
   const Experiments::DatasetInfo     &dataset     = exp.Dataset[idataset];
   const Experiments::MeasurementInfo &measurement = dataset.Measurement[imeasurement];

   UShort_t year  = measurement.DateRange[0] / 10000;
   UShort_t month = (measurement.DateRange[0] % 10000) / 100;

   Char_t path[PATH_LENGTH];
   Char_t name[NAME_LENGTH];
   if (opt.Contains("v25")) snprintf(name, PATH_LENGTH, "Flux_V25_%u_%u.root", year, month);
   else if (idataset == 2) snprintf(name, PATH_LENGTH, "Mix_Flux_V39_MCw_p1_%u_%u.root", year, month);
   else if (idataset == 5) snprintf(name, PATH_LENGTH, "Mix_Flux_V42_p1_BRwg_%u.root", FIRST_AMS02_BARTELS_ROTATION + imeasurement);
   else if (idataset == 7) snprintf(name, PATH_LENGTH, "I1_FluxP6_V9_B620_p1_BR_%u.root", FIRST_AMS02_BARTELS_ROTATION + imeasurement);
   else if (idataset == 8 && imeasurement < 68) snprintf(name, PATH_LENGTH, "I2_FluxP6_V9_B620_p1_BR_%u.root", FIRST_AMS02_BARTELS_ROTATION + imeasurement);
   else if (idataset == 8) snprintf(name, PATH_LENGTH, "I2_FluxP6_V15_B620_p1_BR_%u.root", FIRST_AMS02_BARTELS_ROTATION + imeasurement);
   else if (idataset == 11) snprintf(name, PATH_LENGTH, "I2_ProtonFlux_pBin_B620_Hawaii_Nov2016.root");
   else if (idataset == 12) snprintf(name, PATH_LENGTH, "I2_FluxP6_V27_B620_p1_BR_%u.root", FIRST_AMS02_BARTELS_ROTATION + imeasurement);
   else if (idataset == 15) snprintf(name, PATH_LENGTH, "I2_ProtonFlux_pBin_B620_Hawaii_V27_Extended.root");
   else snprintf(name, PATH_LENGTH, "ams02_phe_monthly_BR2426_BR2506.root");
   snprintf(path, PATH_LENGTH, "%s/ams02-monthly/%s", Experiments::DataPath.c_str(), name);

   TFile ams_file(path);
   if (!ams_file.IsOpen() || ams_file.IsZombie())
   {
      cerr << FG_RED_B << Form(" !!! get_ams02_proton_monthly_flux_hist-E-File not opened: %s", path) << RESET << endl;
      return NULL;
   }

   TH1D *hist;
   TH1 *h_ams = NULL;
   UShort_t br_shift = 0;
   if (idataset == 1)
   {
      if (imeasurement > 45) br_shift = 2;
      snprintf(name, PATH_LENGTH, "h_pflux_BR%u", FIRST_AMS02_BARTELS_ROTATION + imeasurement + br_shift);
      ams_file.GetObject(name, h_ams);
      if (h_ams == NULL)
      {
         cerr << FG_RED_B << Form(" !!! get_ams02_proton_monthly_flux_hist-E-Histogram not found: %s", name) << RESET << endl;
         return NULL;
      }
   }
   else if (idataset == 15 || idataset == 11)
   {
      TH2D *h2 = NULL;
      snprintf(name, PATH_LENGTH, "hh_ProtonFlux_%sErr", opt.Contains("stat") ? "Stat" : "Tot");
      if (idataset == 1 && opt.Contains("time"))
      {
         snprintf(name, PATH_LENGTH, "hh_ProtonFlux_RatioErr");
      }
      ams_file.GetObject(name, h2);
      if (h2 == NULL)
      {
         cerr << FG_RED_B << Form(" !!! get_ams02_proton_monthly_flux_hist-E-Histogram not found: %s", name) << RESET << endl;
         return NULL;
      }

      h_ams = h2->ProjectionY("", imeasurement + 1, imeasurement + 1, "e");
   }
   else
   {
      snprintf(name, NAME_LENGTH, opt.Contains("time") || opt.Contains("stat") ? "h_Flux" : "h_Flux_withErr");
      ams_file.GetObject(name, h_ams);
      if (h_ams == NULL)
      {
         cerr << FG_RED_B << Form(" !!! get_ams02_proton_monthly_flux_hist-E-Histogram not found: %s", name) << RESET << endl;
         return NULL;
      }
   }

   TGraphErrors g(h_ams);
   UShort_t nbins = h_ams->GetNbinsX();
   if (idataset > 1)
   {
      // remove first and last two points => range: 1 - 1800 GV
      for (UShort_t ipoint = 0; ipoint < 2; ++ipoint) g.RemovePoint(nbins - 1 - ipoint);
      g.RemovePoint(0);
   }

   static Char_t date1[11];
   static Char_t date2[11];
   snprintf(name, NAME_LENGTH, "h_%s_%s_%s_%u_%u_%s", exp.Name, Particle::Name[dataset.Particle[0]], Experiments::Measurement::Name[dataset.Type],
      measurement.DateRange[0], measurement.DateRange[1], Energy::Name[dataset.Energy]);
   hist = HistTools::GraphToHist(&g);
   hist->SetName(name);
   hist->SetStats(false);
   hist->SetDirectory(gROOT);
   if (idataset == 2) hist->SetTitle(Form("AMS-02 proton flux (UHM) - %04u/%02u", year, month));
   else
   {
      hist->SetTitle(Form("AMS-02 proton flux (UHM) - %s-%s (BR %u)", DateTimeTools::SplitDate(measurement.DateRange[0], date1), DateTimeTools::SplitDate(measurement.DateRange[1], date2),
         FIRST_AMS02_BARTELS_ROTATION + imeasurement + br_shift));
   }
   hist->SetXTitle(Unit::GetEnergyLabel(dataset.Energy, dataset.EnergyPrefix));
   hist->SetYTitle(Unit::GetDifferentialFluxLabel(dataset.Energy, dataset.EnergyPrefix, dataset.AreaPrefix));
   HistTools::ResetStyle(hist);

   if (opt.Contains("syst"))      add_ams02_syst_error(hist);
   if (opt.Contains("noaligerr")) remove_ams02_alig_error(hist);
   if (opt.Contains("aligshift")) shift_alignment(hist, opt);
   if (opt.Contains("time"))
   {
      if (idataset == 1)
      {
         TTree *tree = NULL;
         UShort_t shift = imeasurement > 45 ? 2 : 0;
         snprintf(name, PATH_LENGTH, "BR%u", FIRST_AMS02_BARTELS_ROTATION + imeasurement + shift);
         ams_file.GetObject(name, tree);
         Double_t stat, time;
         tree->SetBranchAddress("stat_err_p", &stat);
         tree->SetBranchAddress("time_err_p", &time);
         for (UShort_t bin = 1; bin <= hist->GetNbinsX(); ++bin)
         {
            tree->GetEntry(bin-1);
            hist->SetBinError(bin, sqrt(stat*stat + time*time));
         }
         delete tree;
      }
      else if (idataset == 8 || idataset == 12)
      {
         TH1 *h_trg_syst = NULL;
         snprintf(name, NAME_LENGTH, "h_FitSystErrTrg");
         ams_file.GetObject(name, h_trg_syst);
         if (h_trg_syst == NULL)
         {
            snprintf(name, NAME_LENGTH, "h_SystErrTrg");
            ams_file.GetObject(name, h_trg_syst);
            if (h_trg_syst == NULL)
            {
               cerr << FG_RED_B << Form(" !!! get_ams02_proton_monthly_flux_hist-E-Histogram not found: %s", name) << RESET << endl;
               return NULL;
            }
         }

         for (UShort_t bin = 1; bin <= hist->GetNbinsX(); ++bin)
         {
            Double_t stat     = hist->GetBinError(bin);
            Double_t flux     = hist->GetBinContent(bin);
            Double_t trg_syst = flux*h_trg_syst->GetBinContent(bin + 1)/100.; // h_ams right shifted of 1 bin
            Double_t err      = TMath::Sqrt(stat*stat + trg_syst*trg_syst);

            hist->SetBinError(bin, err);
         }
      }
   }
   if (opt.Contains("stat"))
   {
      if (idataset == 1)
      {
         TTree *tree = NULL;
         UShort_t shift = imeasurement > 45 ? 2 : 0;
         snprintf(name, PATH_LENGTH, "BR%u", FIRST_AMS02_BARTELS_ROTATION + imeasurement + shift);
         ams_file.GetObject(name, tree);
         Double_t stat;
         tree->SetBranchAddress("stat_err_p", &stat);
         for (UShort_t bin = 1; bin <= hist->GetNbinsX(); ++bin)
         {
            tree->GetEntry(bin-1);
            hist->SetBinError(bin, stat);
         }
         delete tree;
      }
   }

   TFile *f_ams02 = get_ams02_proton_file(false);
   if (!keep_file_open && f_ams02 != NULL) delete f_ams02;

   return hist;
}
TGraphAsymmErrors *get_ams02_proton_monthly_flux_graph(UShort_t idataset, UShort_t imeasurement, TString &opt, Bool_t keep_file_open)
{
   TH1D *hist = get_ams02_proton_monthly_flux_hist(idataset, imeasurement, opt, keep_file_open);
   if (hist == NULL) return NULL;

   return hist2graph(hist);
}

TH1D *get_ams02_proton_flux_hist(UShort_t imeasurement, TString &opt, Bool_t keep_file_open)
{
   const Experiments::ExperimentInfo  &exp         = Experiments::Info[Experiments::AMS02];
   const Experiments::DatasetInfo     &dataset     = exp.Dataset[0];
   const Experiments::MeasurementInfo &measurement = dataset.Measurement[0];

   TFile *f_ams02 = get_ams02_proton_file();
   if (f_ams02 == NULL) return NULL;

   TH1D *hist, *h_ams = NULL;
   Char_t name[NAME_LENGTH];
   snprintf(name, NAME_LENGTH, "h_ams02_pflux_201105_201311");
   f_ams02->GetObject(name, h_ams);
   if (h_ams == NULL)
   {
      cerr << FG_RED_B << Form(" !!! get_ams02_proton_flux_hist-E-Histogram not found: %s", name) << RESET << endl;
      return NULL;
   }

   TTree *tree = get_ams02_proton_tree(f_ams02);
   if (tree == NULL) return NULL;

   static Char_t date1[11];
   static Char_t date2[11];
   snprintf(name, NAME_LENGTH, "h_%s_%s_%s_%u_%u_%s", exp.Name, Particle::Name[dataset.Particle[0]], Experiments::Measurement::Name[dataset.Type],
      measurement.DateRange[0], measurement.DateRange[1], Energy::Name[dataset.Energy]);
   hist = (TH1D *)h_ams->Clone(name);
   hist->SetStats(false);
   hist->SetDirectory(gROOT);
   hist->SetTitle(Form("AMS-02 proton flux - %s-%s", DateTimeTools::SplitDate(measurement.DateRange[0], date1), DateTimeTools::SplitDate(measurement.DateRange[1], date2)));
   hist->SetXTitle(Unit::GetEnergyLabel(dataset.Energy, dataset.EnergyPrefix));
   hist->SetYTitle(Unit::GetDifferentialFluxLabel(dataset.Energy, dataset.EnergyPrefix, dataset.AreaPrefix));
   HistTools::ResetStyle(hist);

   if (opt.Contains("noaligerr")) remove_ams02_alig_error(hist);
   if (opt.Contains("aligshift")) shift_alignment(hist, opt);

   if (!keep_file_open && f_ams02 != NULL) delete f_ams02;

   return hist;
}
TGraphAsymmErrors *get_ams02_proton_flux_graph(UShort_t imeasurement, TString &opt, Bool_t keep_file_open)
{
   TH1D *hist = get_ams02_proton_flux_hist(imeasurement, opt, keep_file_open);
   if (hist == NULL) return NULL;

   return hist2graph(hist);
}

TH1D *get_ams02_helium_flux_hist(UShort_t imeasurement, TString &opt, Bool_t keep_file_open)
{
   const Experiments::ExperimentInfo  &exp         = Experiments::Info[Experiments::AMS02];
   const Experiments::DatasetInfo     &dataset     = exp.Dataset[3];
   const Experiments::MeasurementInfo &measurement = dataset.Measurement[0];

   TFile *f_ams02 = get_ams02_helium_file();
   if (f_ams02 == NULL) return NULL;

   TH1D *hist, *h_ams = NULL;
   Char_t name[NAME_LENGTH];
   snprintf(name, NAME_LENGTH, "he");
   f_ams02->GetObject(name, h_ams);
   if (h_ams == NULL)
   {
      cerr << FG_RED_B << Form(" !!! get_ams02_helium_flux_hist-E-Histogram not found: %s", name) << RESET << endl;
      return NULL;
   }

   static Char_t date1[11];
   static Char_t date2[11];
   snprintf(name, NAME_LENGTH, "h_%s_%s_%s_%u_%u_%s", exp.Name, Particle::Name[dataset.Particle[0]], Experiments::Measurement::Name[dataset.Type],
      measurement.DateRange[0], measurement.DateRange[1], Energy::Name[dataset.Energy]);
   hist = (TH1D *)h_ams->Clone(name);
   hist->SetStats(false);
   hist->SetDirectory(gROOT);
   hist->SetTitle(Form("AMS-02 helium flux - %s-%s", DateTimeTools::SplitDate(measurement.DateRange[0], date1), DateTimeTools::SplitDate(measurement.DateRange[1], date2)));
   hist->SetXTitle(Unit::GetEnergyLabel(dataset.Energy, dataset.EnergyPrefix));
   hist->SetYTitle(Unit::GetDifferentialFluxLabel(dataset.Energy, dataset.EnergyPrefix, dataset.AreaPrefix));
   HistTools::ResetStyle(hist);

   if (!keep_file_open && f_ams02 != NULL) delete f_ams02;

   return hist;
}
TGraphAsymmErrors *get_ams02_helium_flux_graph(UShort_t imeasurement, TString &opt, Bool_t keep_file_open)
{
   TH1D *hist = get_ams02_helium_flux_hist(imeasurement, opt, keep_file_open);
   if (hist == NULL) return NULL;

   return hist2graph(hist);
}

TH1D *get_ams02_helium_flux_2017_hist(UShort_t imeasurement, TString &opt, Bool_t keep_file_open)
{
   const Experiments::ExperimentInfo  &exp         = Experiments::Info[Experiments::AMS02];
   const Experiments::DatasetInfo     &dataset     = exp.Dataset[18];
   const Experiments::MeasurementInfo &measurement = dataset.Measurement[0];

   TFile *f_ams02 = get_ams02_helium_2017_file();
   if (f_ams02 == NULL) return NULL;

   TTree *tree = NULL;
   Char_t name[NAME_LENGTH];
   snprintf(name, NAME_LENGTH, "data");
   f_ams02->GetObject(name, tree);
   if (tree == NULL)
   {
      cerr << FG_RED_B << Form(" !!! get_ams02_helium_flux_2017_hist-E-Tree not found: %s", name) << RESET << endl;
      return NULL;
   }

   opt.ToLower();
   UShort_t err_type = opt.Contains("stat") + 2*opt.Contains("syst");

   UShort_t nbins = tree->GetEntries();
   Double_t *bins = new Double_t[nbins+1];
   Double_t *flux = new Double_t[nbins];
   Double_t *stat = new Double_t[nbins];
   Double_t *syst = new Double_t[nbins];
   Double_t Rlow, F, dFstat, dFsyst;
   tree->SetBranchAddress("Rlow", &Rlow);
   tree->SetBranchAddress("F", &F);
   tree->SetBranchAddress("dFstat", &dFstat);
   tree->SetBranchAddress("dFsyst", &dFsyst);
   for (UShort_t ibin = 0; ibin < nbins; ++ibin)
   {
      tree->GetEntry(ibin);

      bins[ibin] = Rlow;
      flux[ibin] = F;
      stat[ibin] = dFstat;
      syst[ibin] = dFsyst;
   }
   bins[nbins] = tree->GetLeaf("Rup")->GetValue();

   static Char_t date1[11];
   static Char_t date2[11];
   snprintf(name, NAME_LENGTH, "h_%s_%s_%s_%u_%u_%s%s", exp.Name, Particle::Name[dataset.Particle[0]], Experiments::Measurement::Name[dataset.Type],
      measurement.DateRange[0], measurement.DateRange[1], Energy::Name[dataset.Energy],
      err_type == 1 ? "_stat" : (err_type == 2 ? "_syst" : ""));
   TH1D *hist = new TH1D(name, "", nbins, bins);
   for (UShort_t ibin = 0; ibin < nbins; ++ibin)
   {
      hist->SetBinContent(ibin + 1, flux[ibin]);
      Double_t err;
      if (err_type == 1) err = stat[ibin];
      else if (err_type == 2) err = syst[ibin];
      else err = sqrt(stat[ibin]*stat[ibin] + syst[ibin]*syst[ibin]);
      hist->SetBinError(ibin + 1, err);
   }
   hist->SetStats(false);
   hist->SetDirectory(gROOT);
   hist->SetTitle(Form("AMS-02 He flux - %s-%s", DateTimeTools::SplitDate(measurement.DateRange[0], date1), DateTimeTools::SplitDate(measurement.DateRange[1], date2)));
   hist->SetXTitle(Unit::GetEnergyLabel(dataset.Energy, dataset.EnergyPrefix));
   hist->SetYTitle(Unit::GetDifferentialFluxLabel(dataset.Energy, dataset.EnergyPrefix, dataset.AreaPrefix));
   HistTools::ResetStyle(hist);

   delete[] bins;
   delete[] flux;
   delete[] stat;
   delete[] syst;

   if (!keep_file_open && f_ams02 != NULL) delete f_ams02;

   return hist;
}
TGraphAsymmErrors *get_ams02_helium_flux_2017_graph(UShort_t imeasurement, TString &opt, Bool_t keep_file_open)
{
   TH1D *hist = get_ams02_helium_flux_2017_hist(imeasurement, opt, keep_file_open);
   if (hist == NULL) return NULL;

   return hist2graph(hist);
}

TH1D *get_ams02_data_qiyan_hist(UShort_t idataset, TString &opt, Bool_t keep_file_open)
{
   const Experiments::ExperimentInfo  &exp         = Experiments::Info[Experiments::AMS02];
   const Experiments::DatasetInfo     &dataset     = exp.Dataset[idataset];
   const Experiments::MeasurementInfo &measurement = dataset.Measurement[0];

   Particle::Type part = dataset.Particle[0];

   Char_t path[PATH_LENGTH];
   Char_t name[NAME_LENGTH];
   UShort_t year = idataset <= 22 ? 2017 : 2018;
   UShort_t shift = 0, nbins = 66; // default for Particle::NITROGEN
   if (dataset.Type == Experiments::Measurement::Flux)
   {
      snprintf(path, PATH_LENGTH, "%s/ams02/%u_%s.root", Experiments::DataPath.c_str(), year, Particle::Name[part]);
      snprintf(name, NAME_LENGTH, "Z%.0ffluxh_totalA", Particle::Z[part]);
      if (part == Particle::CARBON)
      {
         shift = 6;
         nbins = 68;
      }
      else if (part == Particle::OXYGEN)
      {
         shift = 7;
         nbins = 67;
      }
      else if (part == Particle::LITHIUM || part == Particle::BERYLLIUM || part == Particle::BORON)
      {
         shift = 6;
         nbins = 67;
      }
   }
   else if (dataset.Type == Experiments::Measurement::Ratio)
   {
      snprintf(path, PATH_LENGTH, "%s/ams02/%u_%s%sratio.root", Experiments::DataPath.c_str(), year, Particle::Name[part], Particle::Name[dataset.Particle[1]]);
      snprintf(name, NAME_LENGTH, "%s%sRatioAh", Particle::Name[part], Particle::Name[dataset.Particle[1]]);
      if ((part == Particle::HELIUM || part == Particle::CARBON) && dataset.Particle[1] == Particle::OXYGEN)
      {
         shift = 7;
         nbins = 67;
      }
      else if (dataset.Particle[1] == Particle::OXYGEN || dataset.Particle[1] == Particle::BORON)
      {
         shift = 7;
         nbins = 66;
      }
      else if (dataset.Particle[1] == Particle::CARBON)
      {
         shift = 6;
         nbins = 67;
      }
   }
   else
   {
      cerr << FG_RED_B << Form(" !!! get_ams02_data_qiyan_hist-E-Type not found: %s", Experiments::Measurement::Name[dataset.Type]) << RESET << endl;
      return NULL;
   }

   TFile f(path);
   if (!f.IsOpen() || f.IsZombie())
   {
      cerr << FG_RED_B << Form(" !!! get_ams02_data_qiyan_hist-E-File not opened: %s", path) << RESET << endl;
      return NULL;
   }

   TH1D *h = NULL;
   f.GetObject(name, h);
   if (h == NULL)
   {
      cerr << FG_RED_B << Form(" !!! get_ams02_data_qiyan_hist-E-TH1 not found: %s", name) << RESET << endl;
      return NULL;
   }

   static Char_t date1[11];
   static Char_t date2[11];
   if (dataset.Type == Experiments::Measurement::Flux)
   {
      snprintf(name, NAME_LENGTH, "h_%s_%s_%s_%u_%u_%s", exp.Name, Particle::Name[part], Experiments::Measurement::Name[dataset.Type],
         measurement.DateRange[0], measurement.DateRange[1], Energy::Name[dataset.Energy]);
   }
   else
   {
      snprintf(name, NAME_LENGTH, "h_%s_%s%s_%s_%u_%u_%s", exp.Name, Particle::Name[part], Particle::Name[dataset.Particle[1]], Experiments::Measurement::Name[dataset.Type],
         measurement.DateRange[0], measurement.DateRange[1], Energy::Name[dataset.Energy]);
   }


   TArrayD axis(*(h->GetXaxis()->GetXbins()));
   TH1D *hist = new TH1D(name, "", nbins, axis.GetArray() + shift);
   for (UShort_t bin = 1; bin <= nbins; ++bin)
   {
      hist->SetBinContent(bin, h->GetBinContent(bin + shift));
      hist->SetBinError(bin, h->GetBinError(bin + shift));
   }
   hist->SetStats(false);
   hist->SetDirectory(gROOT);
   if (dataset.Type == Experiments::Measurement::Flux)
   {
      hist->SetTitle(Form("AMS-02 %s - %s-%s", Particle::Name[part], DateTimeTools::SplitDate(measurement.DateRange[0], date1), DateTimeTools::SplitDate(measurement.DateRange[1], date2)));
      hist->SetYTitle(Unit::GetDifferentialFluxLabel(dataset.Energy, dataset.EnergyPrefix, dataset.AreaPrefix));
   }
   else
   {
      hist->SetTitle(Form("AMS-02 %s/%s - %s-%s", Particle::Name[part], Particle::Name[dataset.Particle[1]], DateTimeTools::SplitDate(measurement.DateRange[0], date1), DateTimeTools::SplitDate(measurement.DateRange[1], date2)));
      hist->SetYTitle(Form("%s/%s", Particle::Name[part], Particle::Name[dataset.Particle[1]]));
   }
   hist->SetXTitle(Unit::GetEnergyLabel(dataset.Energy, dataset.EnergyPrefix));
   HistTools::ResetStyle(hist);

   return hist;
}
TGraphAsymmErrors *get_ams02_data_qiyan_graph(UShort_t idataset, TString &opt, Bool_t keep_file_open)
{
   TH1D *hist = get_ams02_data_qiyan_hist(idataset, opt, keep_file_open);
   if (hist == NULL) return NULL;

   return hist2graph(hist);
}

TH1D *get_ams02_helium_monthly_flux_hist(UShort_t idataset, UShort_t imeasurement, TString &opt, Bool_t keep_file_open);
TGraphAsymmErrors *get_ams02_helium_monthly_flux_graph(UShort_t idataset, UShort_t imeasurement, TString &opt, Bool_t keep_file_open)
{
   if (idataset != 6)
   {
      TH1D *hist = get_ams02_helium_monthly_flux_hist(idataset, imeasurement, opt, keep_file_open);
      if (hist == NULL) return NULL;

      return hist2graph(hist);
   }

   const Experiments::ExperimentInfo  &exp         = Experiments::Info[Experiments::AMS02];
   const Experiments::DatasetInfo     &dataset     = exp.Dataset[idataset];
   const Experiments::MeasurementInfo &measurement = dataset.Measurement[imeasurement];

   if (imeasurement >= 46) ++imeasurement;

   Char_t path[PATH_LENGTH];
   snprintf(path, PATH_LENGTH, "%s/ams02-monthly/ams02_He_monthly.root", Experiments::DataPath.c_str());

   TFile ams_file(path);
   if (!ams_file.IsOpen() || ams_file.IsZombie())
   {
      cerr << FG_RED_B << Form(" !!! get_ams02_helium_monthly_flux_graph-E-File not opened: %s", path) << RESET << endl;
      return NULL;
   }

   TGraphAsymmErrors *graph;
   TGraphErrors *g_ams = NULL;
   Char_t name[PATH_LENGTH];
   snprintf(name, NAME_LENGTH, "flux_%u", FIRST_AMS02_BARTELS_ROTATION + imeasurement);
   ams_file.GetObject(name, g_ams);
   if (g_ams == NULL)
   {
      cerr << FG_RED_B << Form(" !!! get_ams02_helium_monthly_flux_graph-E-Graph not found: %s", name) << RESET << endl;
      return NULL;
   }

   static Char_t date1[11];
   static Char_t date2[11];
   snprintf(name, NAME_LENGTH, "h_%s_%s_%s_%u_%u_%s", exp.Name, Particle::Name[dataset.Particle[0]], Experiments::Measurement::Name[dataset.Type],
      measurement.DateRange[0], measurement.DateRange[1], Energy::Name[dataset.Energy]);
   graph = new TGraphAsymmErrors(g_ams->GetN(), g_ams->GetX(), g_ams->GetY(), g_ams->GetEX(), g_ams->GetEX(), g_ams->GetEY(), g_ams->GetEY());
   graph->SetName(name);
   graph->SetTitle(g_ams->GetTitle());
   gROOT->Append(graph);
   graph->SetTitle(Form("AMS-02 helium flux (CIEMAT) - %s-%s (BR %u);%s;%s", DateTimeTools::SplitDate(measurement.DateRange[0], date1), DateTimeTools::SplitDate(measurement.DateRange[1], date2),
      FIRST_AMS02_BARTELS_ROTATION + imeasurement, Unit::GetEnergyLabel(dataset.Energy, dataset.EnergyPrefix), Unit::GetDifferentialFluxLabel(dataset.Energy, dataset.EnergyPrefix, dataset.AreaPrefix)));
   HistTools::ResetStyle(graph);

   return graph;
}
TH1D *get_ams02_helium_monthly_flux_hist(UShort_t idataset, UShort_t imeasurement, TString &opt, Bool_t keep_file_open)
{
   if (idataset == 6)
   {
      TGraphAsymmErrors *graph = get_ams02_helium_monthly_flux_graph(idataset, imeasurement, opt, keep_file_open);
      if (graph == NULL) return NULL;

      return graph2hist(graph, Experiments::Info[Experiments::AMS02].Dataset[idataset]);
   }

   const Experiments::ExperimentInfo  &exp         = Experiments::Info[Experiments::AMS02];
   const Experiments::DatasetInfo     &dataset     = exp.Dataset[idataset];
   const Experiments::MeasurementInfo &measurement = dataset.Measurement[imeasurement];

   Char_t path[PATH_LENGTH];
   Char_t name[NAME_LENGTH];
   if (idataset == 9 && imeasurement < 68) snprintf(name, PATH_LENGTH, "I2_FluxP6_heV14_B1036_range_1_BR_%u.root", FIRST_AMS02_BARTELS_ROTATION + imeasurement);
   else if (idataset == 9) snprintf(name, PATH_LENGTH, "I2_FluxP6_heV15_B1036_range_1_BR_%u.root", FIRST_AMS02_BARTELS_ROTATION + imeasurement);
   else if (idataset == 10) snprintf(name, PATH_LENGTH, "I2_HeliumFlux_pBin_B1036_Hawaii_Nov2016.root");
   else if (idataset == 14) snprintf(name, PATH_LENGTH, "I2_HeliumFlux_pBin_B1036_Hawaii_heV23.root");
   else if (idataset == 13) snprintf(name, PATH_LENGTH, "I2_FluxP6_heV27_B1036_range_1_BR_%u.root", FIRST_AMS02_BARTELS_ROTATION + imeasurement);
   else if (idataset == 16) snprintf(name, PATH_LENGTH, "I2_HeliumFlux_pBin_B1036_Hawaii_heV27_Extended.root");
   else snprintf(name, PATH_LENGTH, "ams02_phe_monthly_BR2426_BR2506.root");
   snprintf(path, PATH_LENGTH, "%s/ams02-monthly/%s", Experiments::DataPath.c_str(), name);

   TFile ams_file(path);
   if (!ams_file.IsOpen() || ams_file.IsZombie())
   {
      cerr << FG_RED_B << Form(" !!! get_ams02_helium_monthly_flux_hist-E-File not opened: %s", path) << RESET << endl;
      return NULL;
   }

   TH1D *hist;
   TH1 *h_ams = NULL;
   UShort_t br_shift = 0;
   if (idataset == 4)
   {
      if (imeasurement > 45) br_shift = 2;
      snprintf(name, PATH_LENGTH, "h_heflux_BR%u", FIRST_AMS02_BARTELS_ROTATION + imeasurement + br_shift);
      ams_file.GetObject(name, h_ams);
      if (h_ams == NULL)
      {
         cerr << FG_RED_B << Form(" !!! get_ams02_helium_monthly_flux_hist-E-Histogram not found: %s", name) << RESET << endl;
         return NULL;
      }
   }
   else if (idataset == 16 || idataset == 10)
   {
      TH2D *h2 = NULL;
      snprintf(name, PATH_LENGTH, "hh_HeliumFlux_%sErr", opt.Contains("stat") ? "Stat" : "Tot");
      if (idataset == 4 && opt.Contains("time"))
      {
         snprintf(name, PATH_LENGTH, "hh_HeliumFlux_RatioErr");
      }
      ams_file.GetObject(name, h2);
      if (h2 == NULL)
      {
         cerr << FG_RED_B << Form(" !!! get_ams02_helium_monthly_flux_hist-E-Histogram not found: %s", name) << RESET << endl;
         return NULL;
      }

      h_ams = h2->ProjectionY("", imeasurement + 1, imeasurement + 1, "e");
   }
   else
   {
      snprintf(name, NAME_LENGTH, opt.Contains("time") || opt.Contains("stat") ? "h_Flux" : "h_Flux_withErr");
      ams_file.GetObject(name, h_ams);
      if (h_ams == NULL)
      {
         cerr << FG_RED_B << Form(" !!! get_ams02_helium_monthly_flux_hist-E-Histogram not found: %s", name) << RESET << endl;
         return NULL;
      }
   }

   TGraphErrors g(h_ams);
   UShort_t nbins = h_ams->GetNbinsX();
   UShort_t shift;
   if (idataset > 4)
   {
      // remove first six and last point
      g.RemovePoint(nbins - 1);
      if (idataset == 16 || idataset == 10 || idataset == 13)
      {
         //  => range: 1.51 - 3000 GV
         shift = 4;
      }
      else
      {
         //  => range: 1.92 - 3000 GV
         shift = 6;
      }
      for (Short_t ipoint = 0; ipoint < shift; ++ipoint) g.RemovePoint(0);
   }

   static Char_t date1[11];
   static Char_t date2[11];
   snprintf(name, NAME_LENGTH, "h_%s_%s_%s_%u_%u_%s", exp.Name, Particle::Name[dataset.Particle[0]], Experiments::Measurement::Name[dataset.Type],
      measurement.DateRange[0], measurement.DateRange[1], Energy::Name[dataset.Energy]);
   hist = HistTools::GraphToHist(&g);
   hist->SetName(name);
   hist->SetStats(false);
   hist->SetDirectory(gROOT);
   hist->SetTitle(Form("AMS-02 helium flux (UHM) - %s-%s (BR %u)", DateTimeTools::SplitDate(measurement.DateRange[0], date1), DateTimeTools::SplitDate(measurement.DateRange[1], date2),
      FIRST_AMS02_BARTELS_ROTATION + imeasurement + br_shift));
   hist->SetXTitle(Unit::GetEnergyLabel(dataset.Energy, dataset.EnergyPrefix));
   hist->SetYTitle(Unit::GetDifferentialFluxLabel(dataset.Energy, dataset.EnergyPrefix, dataset.AreaPrefix));
   HistTools::ResetStyle(hist);

   //~ if (opt.Contains("syst"))      add_ams02_syst_error(hist);
   //~ if (opt.Contains("noaligerr")) remove_ams02_alig_error(hist);
   //~ if (opt.Contains("aligshift")) shift_alignment(hist, opt);

   if (opt.Contains("time"))
   {
      if (idataset == 4)
      {
         TTree *tree = NULL;
         UShort_t shift = imeasurement > 45 ? 2 : 0;
         snprintf(name, PATH_LENGTH, "BR%u", FIRST_AMS02_BARTELS_ROTATION + imeasurement + shift);
         ams_file.GetObject(name, tree);
         Double_t stat, time;
         tree->SetBranchAddress("stat_err_he", &stat);
         tree->SetBranchAddress("time_err_he", &time);
         for (UShort_t bin = 1; bin <= hist->GetNbinsX(); ++bin)
         {
            tree->GetEntry(bin+4);
            hist->SetBinError(bin, sqrt(stat*stat + time*time));
         }
         delete tree;
      }
      else if (idataset == 9 || idataset == 13)
      {
         TH1 *h_trg_syst = NULL;
         snprintf(name, NAME_LENGTH, "h_FitSystErrTrg");
         ams_file.GetObject(name, h_trg_syst);
         if (h_trg_syst == NULL)
         {
            snprintf(name, NAME_LENGTH, "h_SystErrTrg");
            ams_file.GetObject(name, h_trg_syst);
            if (h_trg_syst == NULL)
            {
               cerr << FG_RED_B << Form(" !!! get_ams02_helium_monthly_flux_hist-E-Histogram not found: %s", name) << RESET << endl;
               return NULL;
            }
         }

         for (UShort_t bin = 1; bin <= hist->GetNbinsX(); ++bin)
         {
            Double_t stat     = hist->GetBinError(bin);
            Double_t flux     = hist->GetBinContent(bin);
            Double_t trg_syst = flux*h_trg_syst->GetBinContent(bin + shift)/100.;
            Double_t err      = TMath::Sqrt(stat*stat + trg_syst*trg_syst);

            hist->SetBinError(bin, err);
         }
      }
   }
   if (opt.Contains("stat"))
   {
      if (idataset == 4)
      {
         TTree *tree = NULL;
         UShort_t shift = imeasurement > 45 ? 2 : 0;
         snprintf(name, PATH_LENGTH, "BR%u", FIRST_AMS02_BARTELS_ROTATION + imeasurement + shift);
         ams_file.GetObject(name, tree);
         Double_t stat;
         tree->SetBranchAddress("stat_err_he", &stat);
         for (UShort_t bin = 1; bin <= hist->GetNbinsX(); ++bin)
         {
            tree->GetEntry(bin+4);
            hist->SetBinError(bin, stat);
         }
         delete tree;
      }
   }

   return hist;
}

TH1D *get_ams02_phe_monthly_ratio_hist(UShort_t idataset, UShort_t imeasurement, TString &opt, Bool_t keep_file_open)
{
   const Experiments::ExperimentInfo  &exp         = Experiments::Info[Experiments::AMS02];
   const Experiments::DatasetInfo     &dataset     = exp.Dataset[idataset];
   const Experiments::MeasurementInfo &measurement = dataset.Measurement[imeasurement];

   Char_t path[PATH_LENGTH];
   Char_t name[NAME_LENGTH];
   snprintf(name, PATH_LENGTH, "ams02_phe_monthly_BR2426_BR2506.root");
   snprintf(path, PATH_LENGTH, "%s/ams02-monthly/%s", Experiments::DataPath.c_str(), name);

   TFile ams_file(path);
   if (!ams_file.IsOpen() || ams_file.IsZombie())
   {
      cerr << FG_RED_B << Form(" !!! get_ams02_helium_monthly_flux_hist-E-File not opened: %s", path) << RESET << endl;
      return NULL;
   }

   TH1D *hist;
   TH1 *h_ams = NULL;
   UShort_t br_shift = imeasurement > 45 ? 2 : 0;
   snprintf(name, PATH_LENGTH, "h_pohe_BR%u", FIRST_AMS02_BARTELS_ROTATION + imeasurement + br_shift);
   ams_file.GetObject(name, h_ams);
   if (h_ams == NULL)
   {
      cerr << FG_RED_B << Form(" !!! get_ams02_phe_monthly_ratio_hist-E-Histogram not found: %s", name) << RESET << endl;
      return NULL;
   }

   TGraphErrors g(h_ams);
   //~ UShort_t nbins = h_ams->GetNbinsX();

   static Char_t date1[11];
   static Char_t date2[11];
   snprintf(name, NAME_LENGTH, "h_%s_%s_%s_%s_%u_%u_%s", exp.Name, Particle::Name[dataset.Particle[0]], Particle::Name[dataset.Particle[1]], Experiments::Measurement::Name[dataset.Type],
      measurement.DateRange[0], measurement.DateRange[1], Energy::Name[dataset.Energy]);
   hist = HistTools::GraphToHist(&g);
   hist->SetName(name);
   hist->SetStats(false);
   hist->SetDirectory(gROOT);
   hist->SetTitle(Form("AMS-02 proton-to-helium ratio - %s-%s (BR %u)", DateTimeTools::SplitDate(measurement.DateRange[0], date1), DateTimeTools::SplitDate(measurement.DateRange[1], date2),
      FIRST_AMS02_BARTELS_ROTATION + imeasurement + br_shift));
   hist->SetXTitle(Unit::GetEnergyLabel(dataset.Energy, dataset.EnergyPrefix));
   hist->SetYTitle("p/He");
   HistTools::ResetStyle(hist);

   if (opt.Contains("time") || opt.Contains("stat"))
   {
      Bool_t time_err = opt.Contains("time");
      TTree *tree = NULL;
      UShort_t shift = imeasurement > 45 ? 2 : 0;
      snprintf(name, PATH_LENGTH, "BR%u", FIRST_AMS02_BARTELS_ROTATION + imeasurement + shift);
      ams_file.GetObject(name, tree);
      Double_t stat, time;
      tree->SetBranchAddress("stat_err_pohe", &stat);
      tree->SetBranchAddress("time_err_pohe", &time);
      for (UShort_t bin = 1; bin <= hist->GetNbinsX(); ++bin)
      {
         tree->GetEntry(bin+4);
         if (time_err) hist->SetBinError(bin, sqrt(stat*stat + time*time));
         else hist->SetBinError(bin, stat);
      }
      delete tree;
   }

   return hist;
}
TGraphAsymmErrors *get_ams02_phe_monthly_ratio_graph(UShort_t idataset, UShort_t imeasurement, TString &opt, Bool_t keep_file_open)
{
   TH1D *hist = get_ams02_phe_monthly_ratio_hist(idataset, imeasurement, opt, keep_file_open);
   if (hist == NULL) return NULL;

   return hist2graph(hist);
}

TH1D *get_ams02_helium_isotopes_hist(UShort_t idataset, UShort_t imeasurement, TString &opt, Bool_t keep_file_open)
{
   const Experiments::ExperimentInfo  &exp         = Experiments::Info[Experiments::AMS02];
   const Experiments::DatasetInfo     &dataset     = exp.Dataset[idataset];
   const Experiments::MeasurementInfo &measurement = dataset.Measurement[imeasurement];

   opt.ToLower();

   Char_t path[PATH_LENGTH];
   Char_t name[NAME_LENGTH];
   if (dataset.Type == Experiments::Measurement::Flux)
   {
      if (opt.Contains("jan")) snprintf(path, PATH_LENGTH, "%s/ams02/table_%s_flux_%s.dat", Experiments::DataPath.c_str(), Particle::Name[dataset.Particle[0]], Energy::Name[dataset.Energy]);
      else snprintf(path, PATH_LENGTH, "%s/ams02/%s_%s.dat", Experiments::DataPath.c_str(), Particle::Name[dataset.Particle[0]], Energy::Name[dataset.Energy]);
   }
   else if (dataset.Type == Experiments::Measurement::Ratio)
   {
      if (opt.Contains("jan")) snprintf(path, PATH_LENGTH, "%s/ams02/table_ratio_He3He4_%s.dat", Experiments::DataPath.c_str(), Energy::Name[dataset.Energy]);
      else snprintf(path, PATH_LENGTH, "%s/ams02/ratio_He3He4_%s.dat", Experiments::DataPath.c_str(), Energy::Name[dataset.Energy]);
   }

   TNtuple nt("nt", "nt", "min:max:meas:stat:syst:tot");
   if (nt.ReadFile(path) == 0)
   {
      cerr << FG_RED_B << Form(" !!! get_ams02_helium_isotopes_hist-E-Error reading file: %s", path) << RESET << endl;
      return NULL;
   }

   UShort_t err_type = opt.Contains("stat") + 2*opt.Contains("syst");

   UShort_t nbins = nt.GetEntries();
   Double_t *bins = new Double_t[nbins+1];
   Double_t *y = new Double_t[nbins];
   Double_t *dy = new Double_t[nbins];
   Float_t min, max, meas, stat, syst, tot;
   nt.SetBranchAddress("min", &min);
   nt.SetBranchAddress("max", &max);
   nt.SetBranchAddress("meas", &meas);
   nt.SetBranchAddress("stat", &stat);
   nt.SetBranchAddress("syst", &syst);
   nt.SetBranchAddress("tot", &tot);
   for (UShort_t ibin = 0; ibin < nbins; ++ibin)
   {
      nt.GetEntry(ibin);

      bins[ibin] = min;
      y[ibin] = meas;
      dy[ibin] = err_type == 1 ? stat : (err_type == 2 ? syst : tot);
   }
   bins[nbins] = nt.GetLeaf("max")->GetValue();

   static Char_t date1[11];
   static Char_t date2[11];
   snprintf(name, NAME_LENGTH, "h_%s_%s_%s_%u_%u_%s%s", exp.Name, Particle::Name[dataset.Particle[0]], Experiments::Measurement::Name[dataset.Type],
      measurement.DateRange[0], measurement.DateRange[1], Energy::Name[dataset.Energy],
      err_type == 1 ? "_stat" : (err_type == 2 ? "_syst" : ""));
   TH1D *hist = new TH1D(name, "", nbins, bins);
   for (UShort_t ibin = 0; ibin < nbins; ++ibin)
   {
      hist->SetBinContent(ibin + 1, y[ibin]);
      hist->SetBinError(ibin + 1, dy[ibin]);
   }
   hist->SetStats(false);
   hist->SetDirectory(gROOT);
   if (dataset.Type == Experiments::Measurement::Flux)
   {
      hist->SetTitle(Form("AMS-02 %s flux - %s-%s", Particle::Symbol[dataset.Particle[0]], DateTimeTools::SplitDate(measurement.DateRange[0], date1), DateTimeTools::SplitDate(measurement.DateRange[1], date2)));
      hist->SetYTitle(Unit::GetDifferentialFluxLabel(dataset.Energy, dataset.EnergyPrefix, dataset.AreaPrefix));
   }
   else if (dataset.Type == Experiments::Measurement::Ratio)
   {
      hist->SetTitle(Form("AMS-02 %s/%s flux ratio - %s-%s",
         Particle::Symbol[dataset.Particle[0]], Particle::Symbol[dataset.Particle[1]], DateTimeTools::SplitDate(measurement.DateRange[0], date1), DateTimeTools::SplitDate(measurement.DateRange[1], date2)));
      hist->SetYTitle(Form("%s/%s", Particle::Symbol[dataset.Particle[0]], Particle::Symbol[dataset.Particle[1]]));
   }
   hist->SetXTitle(Unit::GetEnergyLabel(dataset.Energy, dataset.EnergyPrefix));
   HistTools::ResetStyle(hist);

   delete[] bins;
   delete[] y;
   delete[] dy;

   return hist;
}
TGraphAsymmErrors *get_ams02_helium_isotopes_graph(UShort_t idataset, UShort_t imeasurement, TString &opt, Bool_t keep_file_open)
{
   TH1D *hist = get_ams02_helium_isotopes_hist(idataset, imeasurement, opt, keep_file_open);
   if (hist == NULL) return NULL;

   return hist2graph(hist);
}

TH1D *get_ams02_helium_isotopes_time_hist(UShort_t idataset, UShort_t imeasurement, TString &opt, Bool_t keep_file_open)
{
   const Experiments::ExperimentInfo  &exp         = Experiments::Info[Experiments::AMS02];
   const Experiments::DatasetInfo     &dataset     = exp.Dataset[idataset];
   const Experiments::MeasurementInfo &measurement = dataset.Measurement[imeasurement];

   opt.ToLower();

   UShort_t BR1 = FIRST_AMS02_BARTELS_ROTATION + 4*imeasurement + (imeasurement >= 11)*4;
   UShort_t BR2 = BR1 + 3;

   Char_t path[PATH_LENGTH];
   Char_t name[NAME_LENGTH];
   if (dataset.Type == Experiments::Measurement::Flux)
   {
      snprintf(path, PATH_LENGTH, "%s/ams02-monthly/%s_%s_%u_%u.dat", Experiments::DataPath.c_str(), Particle::Name[dataset.Particle[0]], Energy::Name[dataset.Energy], BR1, BR2);
   }
   else if (dataset.Type == Experiments::Measurement::Ratio)
   {
      snprintf(path, PATH_LENGTH, "%s/ams02-monthly/ratio_He3He4_%s_%u_%u.dat", Experiments::DataPath.c_str(), Energy::Name[dataset.Energy], BR1, BR2);
   }

   TNtuple nt("nt", "nt", "min:max:meas:stat:syst:tot");
   if (nt.ReadFile(path) == 0)
   {
      cerr << FG_RED_B << Form(" !!! get_ams02_helium_isotopes_time_hist-E-Error reading file: %s", path) << RESET << endl;
      return NULL;
   }

   UShort_t err_type = opt.Contains("stat") + 2*opt.Contains("syst");

   UShort_t nbins = nt.GetEntries();
   Double_t *bins = new Double_t[nbins+1];
   Double_t *y = new Double_t[nbins];
   Double_t *dy = new Double_t[nbins];
   Float_t min, max, meas, stat, syst, tot;
   nt.SetBranchAddress("min", &min);
   nt.SetBranchAddress("max", &max);
   nt.SetBranchAddress("meas", &meas);
   nt.SetBranchAddress("stat", &stat);
   nt.SetBranchAddress("syst", &syst);
   nt.SetBranchAddress("tot", &tot);
   for (UShort_t ibin = 0; ibin < nbins; ++ibin)
   {
      nt.GetEntry(ibin);

      bins[ibin] = min;
      y[ibin] = meas;
      dy[ibin] = err_type == 1 ? stat : (err_type == 2 ? syst : tot);
   }
   bins[nbins] = nt.GetLeaf("max")->GetValue();

   static Char_t date1[11];
   static Char_t date2[11];
   snprintf(name, NAME_LENGTH, "h_%s_%s_%s_%u_%u_%s%s", exp.Name, Particle::Name[dataset.Particle[0]], Experiments::Measurement::Name[dataset.Type],
      measurement.DateRange[0], measurement.DateRange[1], Energy::Name[dataset.Energy],
      err_type == 1 ? "_stat" : (err_type == 2 ? "_syst" : ""));
   TH1D *hist = new TH1D(name, "", nbins, bins);
   for (UShort_t ibin = 0; ibin < nbins; ++ibin)
   {
      hist->SetBinContent(ibin + 1, y[ibin]);
      hist->SetBinError(ibin + 1, dy[ibin]);
   }
   hist->SetStats(false);
   hist->SetDirectory(gROOT);
   if (dataset.Type == Experiments::Measurement::Flux)
   {
      hist->SetTitle(Form("AMS-02 %s flux - %s-%s", Particle::Symbol[dataset.Particle[0]], DateTimeTools::SplitDate(measurement.DateRange[0], date1), DateTimeTools::SplitDate(measurement.DateRange[1], date2)));
      hist->SetYTitle(Unit::GetDifferentialFluxLabel(dataset.Energy, dataset.EnergyPrefix, dataset.AreaPrefix));
   }
   else if (dataset.Type == Experiments::Measurement::Ratio)
   {
      hist->SetTitle(Form("AMS-02 %s/%s flux ratio - %s-%s",
         Particle::Symbol[dataset.Particle[0]], Particle::Symbol[dataset.Particle[1]], DateTimeTools::SplitDate(measurement.DateRange[0], date1), DateTimeTools::SplitDate(measurement.DateRange[1], date2)));
      hist->SetYTitle(Form("%s/%s", Particle::Symbol[dataset.Particle[0]], Particle::Symbol[dataset.Particle[1]]));
   }
   hist->SetXTitle(Unit::GetEnergyLabel(dataset.Energy, dataset.EnergyPrefix));
   HistTools::ResetStyle(hist);

   delete[] bins;
   delete[] y;
   delete[] dy;

   return hist;
}
TGraphAsymmErrors *get_ams02_helium_isotopes_time_graph(UShort_t idataset, UShort_t imeasurement, TString &opt, Bool_t keep_file_open)
{
   TH1D *hist = get_ams02_helium_isotopes_time_hist(idataset, imeasurement, opt, keep_file_open);
   if (hist == NULL) return NULL;

   return hist2graph(hist);
}
/// === [END] AMS-02 DATA FUNCTIONS ===

/// === [START] AMS-01 DATA FUNCTIONS ===
TGraphAsymmErrors *get_ams01_proton_flux_graph(UShort_t imeasurement, TString &opt, Bool_t keep_file_open)
{
   const Experiments::ExperimentInfo  &exp         = Experiments::Info[Experiments::AMS01];
   const Experiments::DatasetInfo     &dataset     = exp.Dataset[0];
   const Experiments::MeasurementInfo &measurement = dataset.Measurement[0];

   Char_t path[PATH_LENGTH];
   Char_t name[NAME_LENGTH] = "ams01_H_flux.root";
   snprintf(path, PATH_LENGTH, "%s/%s", Experiments::DataPath.c_str(), name);

   TFile ams_file(path);
   if (!ams_file.IsOpen() || ams_file.IsZombie())
   {
      cerr << FG_RED_B << Form(" !!! get_ams01_proton_flux_graph-E-File not opened: %s", path) << RESET << endl;
      return NULL;
   }

   TGraphAsymmErrors *g_ams, *graph;
   snprintf(name, NAME_LENGTH, "gr_exp1");
   ams_file.GetObject(name, g_ams);
   if (g_ams == NULL)
   {
      cerr << FG_RED_B << Form(" !!! get_ams01_proton_flux_graph-E-Graph not found: %s", name) << RESET << endl;
      return NULL;
   }

   static Char_t date1[11];
   static Char_t date2[11];
   snprintf(name, NAME_LENGTH, "g_%s_%s_%s_%u_%u_%s", exp.Name, Particle::Name[dataset.Particle[0]], Experiments::Measurement::Name[dataset.Type],
      measurement.DateRange[0], measurement.DateRange[1], Energy::Name[dataset.Energy]);
   graph = (TGraphAsymmErrors *)g_ams->Clone(name);
   gROOT->Append(graph);
   graph->SetTitle(Form("AMS-01 proton flux - %s-%s", DateTimeTools::SplitDate(measurement.DateRange[0], date1), DateTimeTools::SplitDate(measurement.DateRange[1], date2)));
   HistTools::ResetStyle(graph);

   return graph;
}
TH1D *get_ams01_proton_flux_hist(UShort_t imeasurement, TString &opt, Bool_t keep_file_open)
{
   TGraphAsymmErrors *graph = get_ams01_proton_flux_graph(imeasurement, opt, keep_file_open);
   if (graph == NULL) return NULL;

   return graph2hist(graph, Experiments::Info[Experiments::AMS01].Dataset[0]);
}

TGraphAsymmErrors *get_ams01_helium_flux_graph(UShort_t imeasurement, TString &opt, Bool_t keep_file_open)
{
   const Experiments::ExperimentInfo  &exp         = Experiments::Info[Experiments::AMS01];
   const Experiments::DatasetInfo     &dataset     = exp.Dataset[1];
   const Experiments::MeasurementInfo &measurement = dataset.Measurement[0];

   Char_t path[PATH_LENGTH];
   Char_t name[NAME_LENGTH] = "ams01_He_flux.root";
   snprintf(path, PATH_LENGTH, "%s/%s", Experiments::DataPath.c_str(), name);

   TFile ams_file(path);
   if (!ams_file.IsOpen() || ams_file.IsZombie())
   {
      cerr << FG_RED_B << Form(" !!! get_ams01_helium_flux_graph-E-File not opened: %s", path) << RESET << endl;
      return NULL;
   }

   TGraphAsymmErrors *g_ams, *graph;
   snprintf(name, NAME_LENGTH, "g_ams01_heflux_%u_%u", measurement.DateRange[0], measurement.DateRange[1]);
   ams_file.GetObject(name, g_ams);
   if (g_ams == NULL)
   {
      cerr << FG_RED_B << Form(" !!! get_ams01_helium_flux_graph-E-Graph not found: %s", name) << RESET << endl;
      return NULL;
   }

   static Char_t date1[11];
   static Char_t date2[11];
   snprintf(name, NAME_LENGTH, "g_%s_%s_%s_%u_%u_%s", exp.Name, Particle::Name[dataset.Particle[0]], Experiments::Measurement::Name[dataset.Type],
      measurement.DateRange[0], measurement.DateRange[1], Energy::Name[dataset.Energy]);
   graph = (TGraphAsymmErrors *)g_ams->Clone(name);
   gROOT->Append(graph);
   graph->SetTitle(Form("AMS-01 helium flux - %s-%s", DateTimeTools::SplitDate(measurement.DateRange[0], date1), DateTimeTools::SplitDate(measurement.DateRange[1], date2)));
   HistTools::ResetStyle(graph);

   return graph;
}
TH1D *get_ams01_helium_flux_hist(UShort_t imeasurement, TString &opt, Bool_t keep_file_open)
{
   TGraphAsymmErrors *graph = get_ams01_helium_flux_graph(imeasurement, opt, keep_file_open);
   if (graph == NULL) return NULL;

   return graph2hist(graph, Experiments::Info[Experiments::AMS01].Dataset[1]);
}
/// === [END] AMS-01 DATA FUNCTIONS ===

/// === [START] PAMELA DATA FUNCTIONS ===
TGraphAsymmErrors *get_pamela_proton_monthly_flux_graph_apj2013(UShort_t imeasurement, TString &opt, Bool_t keep_file_open)
{
   const Experiments::ExperimentInfo  &exp         = Experiments::Info[Experiments::PAMELA];
   const Experiments::DatasetInfo     &dataset     = exp.Dataset[1];
   const Experiments::MeasurementInfo &measurement = dataset.Measurement[imeasurement];

   Char_t path[PATH_LENGTH];
   Char_t name[NAME_LENGTH];
   snprintf(name, NAME_LENGTH, "pamela_H_monthlyflux_%s.root", opt.Contains("stat") ? "stat" : "syst");
   snprintf(path, PATH_LENGTH, "%s/pamela_monthly_p_ApJ2013/%s", Experiments::DataPath.c_str(), name);

   TFile *pamela_file = (TFile *)gROOT->GetListOfFiles()->FindObject(path);
   if (pamela_file == NULL)
   {
      pamela_file = new TFile(path);
   }
   if (!pamela_file->IsOpen() || pamela_file->IsZombie())
   {
      cerr << FG_RED_B << Form(" !!! get_pamela_proton_monthly_flux_graph_apj2013-E-File not opened: %s", path) << RESET << endl;
      delete pamela_file;
      return NULL;
   }

   TGraphAsymmErrors *g_pamela, *graph;
   snprintf(name, NAME_LENGTH, "graph%u", imeasurement + 1);
   pamela_file->GetObject(name, g_pamela);
   if (g_pamela == NULL)
   {
      cerr << FG_RED_B << Form(" !!! get_pamela_proton_monthly_flux_graph_apj2013-E-Graph not found: %s", name) << RESET << endl;
      return NULL;
   }

   static Char_t date1[11];
   static Char_t date2[11];
   snprintf(name, NAME_LENGTH, "g_%s_%s_%s_%u_%u_%s", exp.Name, Particle::Name[dataset.Particle[0]], Experiments::Measurement::Name[dataset.Type],
      measurement.DateRange[0], measurement.DateRange[1], Energy::Name[dataset.Energy]);
   graph = (TGraphAsymmErrors *)g_pamela->Clone(name);
   gROOT->Append(graph);
   graph->SetTitle(Form("PAMELA proton flux %s- %s-%s", opt.Contains("stat") ? "(stat. only) " : "",
      DateTimeTools::SplitDate(measurement.DateRange[0], date1), DateTimeTools::SplitDate(measurement.DateRange[1], date2)));
   HistTools::ResetStyle(graph);

   if (!keep_file_open) delete pamela_file;

   return graph;
}
TH1D *get_pamela_proton_monthly_flux_hist_apj2013(UShort_t imeasurement, TString &opt, Bool_t keep_file_open)
{
   TGraphAsymmErrors *graph = get_pamela_proton_monthly_flux_graph_apj2013(imeasurement, opt, keep_file_open);
   if (graph == NULL) return NULL;

   return graph2hist(graph, Experiments::Info[Experiments::PAMELA].Dataset[1]);
}

TGraphAsymmErrors *get_pamela_proton_monthly_flux_graph_apj2018(UShort_t imeasurement, TString &opt, Bool_t keep_file_open)
{
   const Experiments::ExperimentInfo  &exp         = Experiments::Info[Experiments::PAMELA];
   const Experiments::DatasetInfo     &dataset     = exp.Dataset[3];
   const Experiments::MeasurementInfo &measurement = dataset.Measurement[imeasurement];

   Char_t path[PATH_LENGTH];
   Char_t name[NAME_LENGTH];
   //~ snprintf(name, NAME_LENGTH, "pflux_%d_%d.dat", measurement.DateRange[0]-20000000, measurement.DateRange[1]-20000000);
   snprintf(name, NAME_LENGTH, "p_PAM_ApJL2018_kin_%03u.dat", imeasurement);
   snprintf(path, PATH_LENGTH, "%s/pamela_monthly_p_ApJ2018/%s", Experiments::DataPath.c_str(), name);

   TNtuple nt("nt", "", "E1:E2:F:dFstat:dFsyst");
   if (nt.ReadFile(path) == 0)
   {
      cerr << FG_RED_B << Form(" !!! get_pamela_proton_monthly_flux_graph_apj2018-E-File not opened: %s", path) << RESET << endl;
      return NULL;
   }

   Float_t E1, E2, F, dFstat, dFsyst;
   nt.SetBranchAddress("E1", &E1);
   nt.SetBranchAddress("E2", &E2);
   nt.SetBranchAddress("F", &F);
   nt.SetBranchAddress("dFstat", &dFstat);
   nt.SetBranchAddress("dFsyst", &dFsyst);

   static Char_t date1[11];
   static Char_t date2[11];
   snprintf(name, NAME_LENGTH, "g_%s_%s_%s_%u_%u_%s", exp.Name, Particle::Name[dataset.Particle[0]], Experiments::Measurement::Name[dataset.Type],
      measurement.DateRange[0], measurement.DateRange[1], Energy::Name[dataset.Energy]);
   TGraphAsymmErrors *graph = new TGraphAsymmErrors(nt.GetEntries());
   graph->SetName(name);
   gROOT->Append(graph);
   graph->SetTitle(Form("PAMELA proton flux %s- %s-%s", opt.Contains("stat") ? "(stat. only) " : (opt.Contains("syst") ? "(syst. only) " : ""),
      DateTimeTools::SplitDate(measurement.DateRange[0], date1), DateTimeTools::SplitDate(measurement.DateRange[1], date2)));
   HistTools::ResetStyle(graph);
   for (UShort_t ientry = 0; ientry < nt.GetEntries(); ++ientry)
   {
      nt.GetEntry(ientry);

      Double_t E = 0.5*(E1 + E2);
      Double_t dE = 0.5*(E2 - E1);

      Double_t dF;
      if (opt.Contains("stat")) dF = dFstat;
      else if (opt.Contains("syst")) dF = dFsyst;
      else dF = sqrt(dFstat*dFstat + dFsyst*dFsyst);

      graph->SetPoint(ientry, E, F);
      graph->SetPointError(ientry, dE, dE, dF, dF);
   }

   return graph;
}
TH1D *get_pamela_proton_monthly_flux_hist_apj2018(UShort_t imeasurement, TString &opt, Bool_t keep_file_open)
{
   TGraphAsymmErrors *graph = get_pamela_proton_monthly_flux_graph_apj2018(imeasurement, opt, keep_file_open);
   if (graph == NULL) return NULL;

   return graph2hist(graph, Experiments::Info[Experiments::PAMELA].Dataset[3]);
}


TGraphAsymmErrors *get_pamela_proton_flux_graph(UShort_t imeasurement, TString &opt, Bool_t keep_file_open)
{
   const Experiments::ExperimentInfo  &exp         = Experiments::Info[Experiments::PAMELA];
   const Experiments::DatasetInfo     &dataset     = exp.Dataset[0];
   const Experiments::MeasurementInfo &measurement = dataset.Measurement[0];

   Char_t path[PATH_LENGTH];
   Char_t name[NAME_LENGTH];
   snprintf(name, NAME_LENGTH, "pamela_H_flux_%s.root", opt.Contains("stat") ? "stat" : "syst");
   snprintf(path, PATH_LENGTH, "%s/pamela/%s", Experiments::DataPath.c_str(), name);

   TFile pamela_file(path);
   if (!pamela_file.IsOpen() || pamela_file.IsZombie())
   {
      cerr << FG_RED_B << Form(" !!! get_pamela_proton_flux_graph-E-File not opened: %s", path) << RESET << endl;
      return NULL;
   }

   TGraphAsymmErrors *g_pamela, *graph;
   snprintf(name, NAME_LENGTH, "graph1");
   pamela_file.GetObject(name, g_pamela);
   if (g_pamela == NULL)
   {
      cerr << FG_RED_B << Form(" !!! get_pamela_proton_flux_graph-E-Graph not found: %s", name) << RESET << endl;
      return NULL;
   }

   static Char_t date1[11];
   static Char_t date2[11];
   snprintf(name, NAME_LENGTH, "g_%s_%s_%s_%u_%u_%s", exp.Name, Particle::Name[dataset.Particle[0]], Experiments::Measurement::Name[dataset.Type],
      measurement.DateRange[0], measurement.DateRange[1], Energy::Name[dataset.Energy]);
   graph = (TGraphAsymmErrors *)g_pamela->Clone(name);
   gROOT->Append(graph);
   graph->SetTitle(Form("PAMELA proton flux %s- %s-%s", opt.Contains("stat") ? "(stat. only) " : "",
      DateTimeTools::SplitDate(measurement.DateRange[0], date1), DateTimeTools::SplitDate(measurement.DateRange[1], date2)));
   HistTools::ResetStyle(graph);

   if (!opt.Contains("nocorr"))
   {
      // lower the flux by 3.2%, as per doi:10.1088/0004-637X/765/2/91
      const Double_t cf = 1 - 0.032;
      for (UShort_t ipoint = 0; ipoint < graph->GetN(); ++ipoint)
      {
         Double_t y    = graph->GetY()[ipoint];
         Double_t eylp = graph->GetEYlow()[ipoint] / y;
         Double_t eyup = graph->GetEYhigh()[ipoint] / y;

         y *= cf;

         graph->GetY()[ipoint]      = y;
         graph->GetEYlow()[ipoint]  = y*eylp;
         graph->GetEYhigh()[ipoint] = y*eyup;
      }
   }

   return graph;
}
TH1D *get_pamela_proton_flux_hist(UShort_t imeasurement, TString &opt, Bool_t keep_file_open)
{
   TGraphAsymmErrors *graph = get_pamela_proton_flux_graph(imeasurement, opt, keep_file_open);
   if (graph == NULL) return NULL;

   return graph2hist(graph, Experiments::Info[Experiments::PAMELA].Dataset[0]);
}

TGraphAsymmErrors *get_pamela_helium_flux_graph(UShort_t imeasurement, TString &opt, Bool_t keep_file_open)
{
   const Experiments::ExperimentInfo  &exp         = Experiments::Info[Experiments::PAMELA];
   const Experiments::DatasetInfo     &dataset     = exp.Dataset[2];
   const Experiments::MeasurementInfo &measurement = dataset.Measurement[0];

   Char_t path[PATH_LENGTH];
   Char_t name[NAME_LENGTH];
   snprintf(name, NAME_LENGTH, "pamela_He_flux_%s.root", opt.Contains("stat") ? "stat" : "syst");
   snprintf(path, PATH_LENGTH, "%s/pamela/%s", Experiments::DataPath.c_str(), name);

   TFile pamela_file(path);
   if (!pamela_file.IsOpen() || pamela_file.IsZombie())
   {
      cerr << FG_RED_B << Form(" !!! get_pamela_helium_flux_graph-E-File not opened: %s", path) << RESET << endl;
      return NULL;
   }

   TGraphAsymmErrors *g_pamela, *graph;
   snprintf(name, NAME_LENGTH, "graph1");
   pamela_file.GetObject(name, g_pamela);
   if (g_pamela == NULL)
   {
      cerr << FG_RED_B << Form(" !!! get_pamela_helium_flux_graph-E-Graph not found: %s", name) << RESET << endl;
      return NULL;
   }

   static Char_t date1[11];
   static Char_t date2[11];
   snprintf(name, NAME_LENGTH, "g_%s_%s_%s_%u_%u_%s", exp.Name, Particle::Name[dataset.Particle[0]], Experiments::Measurement::Name[dataset.Type],
      measurement.DateRange[0], measurement.DateRange[1], Energy::Name[dataset.Energy]);
   graph = (TGraphAsymmErrors *)g_pamela->Clone(name);
   gROOT->Append(graph);
   graph->SetTitle(Form("PAMELA helium flux %s- %s-%s", opt.Contains("stat") ? "(stat. only) " : "",
      DateTimeTools::SplitDate(measurement.DateRange[0], date1), DateTimeTools::SplitDate(measurement.DateRange[1], date2)));
   HistTools::ResetStyle(graph);

   return graph;
}
TH1D *get_pamela_helium_flux_hist(UShort_t imeasurement, TString &opt, Bool_t keep_file_open)
{
   TGraphAsymmErrors *graph = get_pamela_helium_flux_graph(imeasurement, opt, keep_file_open);
   if (graph == NULL) return NULL;

   return graph2hist(graph, Experiments::Info[Experiments::PAMELA].Dataset[2]);
}
/// === [END] PAMELA DATA FUNCTIONS ===

/// === [START] VOYAGER DATA FUNCTIONS ===
TGraphAsymmErrors *get_voyager1_sci_proton_flux_graph(TString &opt, Bool_t keep_file_open)
{
   const Experiments::ExperimentInfo  &exp         = Experiments::Info[Experiments::Voyager1];
   const Experiments::DatasetInfo     &dataset     = exp.Dataset[0];
   const Experiments::MeasurementInfo &measurement = dataset.Measurement[0];

   Char_t path[PATH_LENGTH];
   Char_t name[NAME_LENGTH] = "voyager1_H_flux.root";
   snprintf(path, PATH_LENGTH, "%s/voyager/%s", Experiments::DataPath.c_str(), name);

   TFile voyager1_file(path);
   if (!voyager1_file.IsOpen() || voyager1_file.IsZombie())
   {
      cerr << FG_RED_B << Form(" !!! get_voyager1_sci_proton_flux_graph-E-File not opened: %s", path) << RESET << endl;
      return NULL;
   }

   TGraphAsymmErrors *g_voyager1, *graph;
   snprintf(name, NAME_LENGTH, "g_v1_pflux_%u_%u", measurement.DateRange[0], measurement.DateRange[1]);
   voyager1_file.GetObject(name, g_voyager1);
   if (g_voyager1 == NULL)
   {
      cerr << FG_RED_B << Form(" !!! get_voyager1_sci_proton_flux_graph-E-Graph not found: %s", name) << RESET << endl;
      return NULL;
   }

   static Char_t date1[11];
   static Char_t date2[11];
   snprintf(name, NAME_LENGTH, "g_%s_%s_%s_%u_%u_%s", exp.Name, Particle::Name[dataset.Particle[0]], Experiments::Measurement::Name[dataset.Type],
      measurement.DateRange[0], measurement.DateRange[1], Energy::Name[dataset.Energy]);
   graph = (TGraphAsymmErrors *)g_voyager1->Clone(name);
   gROOT->Append(graph);
   graph->SetTitle(Form("Voyager 1 proton flux - %s-%s", DateTimeTools::SplitDate(measurement.DateRange[0], date1), DateTimeTools::SplitDate(measurement.DateRange[1], date2)));
   HistTools::ResetStyle(graph);

   if (opt.Contains("syst"))
   {
      for (UShort_t ipoint = 0; ipoint < graph->GetN(); ++ipoint)
      {
         Double_t y   = graph->GetY()[ipoint];

         graph->GetEYlow()[ipoint]  += 0.1*y;
         graph->GetEYhigh()[ipoint] += 0.1*y;
      }
   }

   return graph;
}
TH1D *get_voyager1_sci_proton_flux_hist(TString &opt, Bool_t keep_file_open)
{
   TGraphAsymmErrors *graph = get_voyager1_sci_proton_flux_graph(opt, keep_file_open);
   if (graph == NULL) return NULL;

   return graph2hist(graph, Experiments::Info[Experiments::Voyager1].Dataset[0]);
}

TGraphAsymmErrors *get_voyager1_sci_helium_flux_graph(TString &opt, Bool_t keep_file_open)
{
   const Experiments::ExperimentInfo  &exp         = Experiments::Info[Experiments::Voyager1];
   const Experiments::DatasetInfo     &dataset     = exp.Dataset[1];
   const Experiments::MeasurementInfo &measurement = dataset.Measurement[0];

   Char_t path[PATH_LENGTH];
   Char_t name[NAME_LENGTH] = "voyager1_He_flux.root";
   snprintf(path, PATH_LENGTH, "%s/voyager/%s", Experiments::DataPath.c_str(), name);

   TFile voyager1_file(path);
   if (!voyager1_file.IsOpen() || voyager1_file.IsZombie())
   {
      cerr << FG_RED_B << Form(" !!! get_voyager1_sci_helium_flux_graph-E-File not opened: %s", path) << RESET << endl;
      return NULL;
   }

   TGraphAsymmErrors *g_voyager1, *graph;
   snprintf(name, NAME_LENGTH, "g_v1_heflux_%u_%u", measurement.DateRange[0], measurement.DateRange[1]);
   voyager1_file.GetObject(name, g_voyager1);
   if (g_voyager1 == NULL)
   {
      cerr << FG_RED_B << Form(" !!! get_voyager1_sci_helium_flux_graph-E-Graph not found: %s", name) << RESET << endl;
      return NULL;
   }

   static Char_t date1[11];
   static Char_t date2[11];
   snprintf(name, NAME_LENGTH, "g_%s_%s_%s_%u_%u_%s", exp.Name, Particle::Name[dataset.Particle[0]], Experiments::Measurement::Name[dataset.Type],
      measurement.DateRange[0], measurement.DateRange[1], Energy::Name[dataset.Energy]);
   graph = (TGraphAsymmErrors *)g_voyager1->Clone(name);
   gROOT->Append(graph);
   graph->SetTitle(Form("Voyager 1 He flux - %s-%s", DateTimeTools::SplitDate(measurement.DateRange[0], date1), DateTimeTools::SplitDate(measurement.DateRange[1], date2)));
   HistTools::ResetStyle(graph);

   if (opt.Contains("syst"))
   {
      for (UShort_t ipoint = 0; ipoint < graph->GetN(); ++ipoint)
      {
         Double_t y   = graph->GetY()[ipoint];

         graph->GetEYlow()[ipoint]  += 0.1*y;
         graph->GetEYhigh()[ipoint] += 0.1*y;
      }
   }

   return graph;
}
TH1D *get_voyager1_sci_helium_flux_hist(TString &opt, Bool_t keep_file_open)
{
   TGraphAsymmErrors *graph = get_voyager1_sci_helium_flux_graph(opt, keep_file_open);
   if (graph == NULL) return NULL;

   return graph2hist(graph, Experiments::Info[Experiments::Voyager1].Dataset[1]);
}

TGraphAsymmErrors *get_voyager1_apj_ions_flux_graph(UShort_t idataset, UShort_t imeasurement, TString &opt, Bool_t keep_file_open)
{
   const Experiments::ExperimentInfo  &exp         = Experiments::Info[Experiments::Voyager1];
   const Experiments::DatasetInfo     &dataset     = exp.Dataset[idataset];
   const Experiments::MeasurementInfo &measurement = dataset.Measurement[imeasurement];

   Particle::Type particle = dataset.Particle[0];

   // number of entries for HET-A analysis, from B up to Ni
   UShort_t nHETAbins[] = { 5, 8, 6, 10, 1, 6, 3, 6, 5, 6, 1, 4, 1, 1, 1, 3, 1, 2, 1, 3, 1, 5, 0, 2 };

   Char_t path[PATH_LENGTH];
   Char_t name[NAME_LENGTH] = "voyager1_ions_flux_2016.root";
   snprintf(path, PATH_LENGTH, "%s/voyager/%s", Experiments::DataPath.c_str(), name);

   TFile voyager1_file(path);
   if (!voyager1_file.IsOpen() || voyager1_file.IsZombie())
   {
      cerr << FG_RED_B << Form(" !!! get_voyager1_apj_ions_flux_graph-E-File not opened: %s", path) << RESET << endl;
      return NULL;
   }

   TTree *data;
   snprintf(name, NAME_LENGTH, "v1ions");
   voyager1_file.GetObject(name, data);
   if (data == NULL)
   {
      cerr << FG_RED_B << Form(" !!! get_voyager1_apj_ions_flux_graph-E-Tree not found: %s", name) << RESET << endl;
      return NULL;
   }
   UInt_t Z;
   Double_t emin;
   Double_t emax;
   Double_t flux;
   Double_t sig;
   Double_t sys;
   data->SetBranchAddress("Z", &Z);
   data->SetBranchAddress("emin", &emin);
   data->SetBranchAddress("emax", &emax);
   data->SetBranchAddress("flux", &flux);
   data->SetBranchAddress("sig", &sig);
   data->SetBranchAddress("sys", &sys);

   static Char_t date1[11];
   static Char_t date2[11];
   snprintf(name, NAME_LENGTH, "g_%s_%s_%s_%u_%u_%s", exp.Name, Particle::Name[dataset.Particle[0]], Experiments::Measurement::Name[dataset.Type],
      measurement.DateRange[0], measurement.DateRange[1], Energy::Name[dataset.Energy]);
   TGraphAsymmErrors *graph = new TGraphAsymmErrors();
   graph->SetName(name);
   gROOT->Append(graph);
   graph->SetTitle(Form("Voyager 1 %s flux - %s-%s", Particle::Title[particle], DateTimeTools::SplitDate(measurement.DateRange[0], date1), DateTimeTools::SplitDate(measurement.DateRange[1], date2)));
   HistTools::ResetStyle(graph);

   UShort_t ipoint = 0;
   for (Long64_t ientry = 0, jentry = 0; ientry < data->GetEntries(); ++ientry)
   {
      data->GetEntry(ientry);

      if (Z != Particle::Z[particle]) continue;

      ++jentry;
      if (Z >= 5 && imeasurement == 1 && jentry <= nHETAbins[Z-5]) continue;

      Double_t ene = TMath::Sqrt(emin*emax);
      Double_t err = TMath::Sqrt(sig*sig + sys*sys);

      graph->SetPoint(ipoint, ene, flux);
      graph->SetPointError(ipoint, ene - emin, emax - ene, err, err);
      ++ipoint;

      if (Z >= 5 && imeasurement == 0 && jentry >= nHETAbins[Z-5]) break;
   }

   return graph;
}
TH1D *get_voyager1_apj_ions_flux_hist(UShort_t idataset, UShort_t imeasurement, TString &opt, Bool_t keep_file_open)
{
   TGraphAsymmErrors *graph = get_voyager1_apj_ions_flux_graph(idataset, imeasurement, opt, keep_file_open);
   if (graph == NULL) return NULL;

   return graph2hist(graph, Experiments::Info[Experiments::Voyager1].Dataset[idataset]);
}

TGraphAsymmErrors *get_voyager1_arxiv_ions_flux_graph(UShort_t idataset, UShort_t imeasurement, TString &opt, Bool_t keep_file_open)
{
   const Experiments::ExperimentInfo  &exp         = Experiments::Info[Experiments::Voyager1];
   const Experiments::DatasetInfo     &dataset     = exp.Dataset[idataset];
   const Experiments::MeasurementInfo &measurement = dataset.Measurement[imeasurement];

   Particle::Type particle = dataset.Particle[0];

   Char_t path[PATH_LENGTH];
   Char_t name[NAME_LENGTH] = "arxiv_1712.02818.root";
   snprintf(path, PATH_LENGTH, "%s/voyager/%s", Experiments::DataPath.c_str(), name);

   TFile voyager1_file(path);
   if (!voyager1_file.IsOpen() || voyager1_file.IsZombie())
   {
      cerr << FG_RED_B << Form(" !!! get_voyager1_arxiv_ions_flux_graph-E-File not opened: %s", path) << RESET << endl;
      return NULL;
   }

   TTree *data;
   snprintf(name, NAME_LENGTH, "v1ions");
   voyager1_file.GetObject(name, data);
   if (data == NULL)
   {
      cerr << FG_RED_B << Form(" !!! get_voyager1_arxiv_ions_flux_graph-E-Tree not found: %s", name) << RESET << endl;
      return NULL;
   }
   UInt_t Z;
   Double_t emin;
   Double_t emax;
   Double_t flux;
   Double_t diff_cnts;
   Double_t perc_unc;
   data->SetBranchAddress("Z", &Z);
   data->SetBranchAddress("EMin", &emin);
   data->SetBranchAddress("EMax", &emax);
   data->SetBranchAddress("Flux", &flux);
   data->SetBranchAddress("DiffCnts", &diff_cnts);
   data->SetBranchAddress("PercUnc", &perc_unc);

   static Char_t date1[11];
   static Char_t date2[11];
   snprintf(name, NAME_LENGTH, "g_%s_%s_%s_%u_%u_%s", exp.Name, Particle::Name[dataset.Particle[0]], Experiments::Measurement::Name[dataset.Type],
      measurement.DateRange[0], measurement.DateRange[1], Energy::Name[dataset.Energy]);
   if (Particle::Z[particle] > 2 && imeasurement > 0) strncat(name, "_int", 4);
   TGraphAsymmErrors *graph = new TGraphAsymmErrors();
   graph->SetName(name);
   gROOT->Append(graph);
   graph->SetTitle(Form("Voyager 1 %s flux - %s-%s%s", Particle::Title[particle], DateTimeTools::SplitDate(measurement.DateRange[0], date1), DateTimeTools::SplitDate(measurement.DateRange[1], date2),
      Particle::Z[particle] > 2 && imeasurement > 0 ? " (>1.5 GeV/n)" : ""));
   HistTools::ResetStyle(graph);

   UShort_t ipoint = 0;
   for (Long64_t ientry = 0; ientry < data->GetEntries(); ++ientry)
   {
      data->GetEntry(ientry);

      if (Z != Particle::Z[particle]) continue;
      if (Z > 2 && ((imeasurement == 0 && emax == 0) || (imeasurement == 1 && emax > 0))) continue;

      Double_t ene  = sqrt(emin*emax);
      Double_t sys  = flux*perc_unc/1e2;
      Double_t stat = flux/sqrt(diff_cnts*(emax-emin));
      Double_t err  = sqrt(stat*stat + sys*sys);

      graph->SetPoint(ipoint, ene, flux);
      graph->SetPointError(ipoint, ene - emin, emax - ene, err, err);
      ++ipoint;
   }
   graph->Sort();

   return graph;
}
TH1D *get_voyager1_arxiv_ions_flux_hist(UShort_t idataset, UShort_t imeasurement, TString &opt, Bool_t keep_file_open)
{
   TGraphAsymmErrors *graph = get_voyager1_arxiv_ions_flux_graph(idataset, imeasurement, opt, keep_file_open);
   if (graph == NULL) return NULL;

   return graph2hist(graph, Experiments::Info[Experiments::Voyager1].Dataset[idataset]);
}

TGraphAsymmErrors *get_voyager1_arxiv_h_he_iso_flux_graph(UShort_t idataset, UShort_t imeasurement, TString &opt, Bool_t keep_file_open)
{
   const Experiments::ExperimentInfo  &exp         = Experiments::Info[Experiments::Voyager1];
   const Experiments::DatasetInfo     &dataset     = exp.Dataset[idataset];
   const Experiments::MeasurementInfo &measurement = dataset.Measurement[imeasurement];

   Particle::Type particle = dataset.Particle[0];

   Char_t path[PATH_LENGTH];
   Char_t name[NAME_LENGTH] = "arxiv_1802.08273.root";
   snprintf(path, PATH_LENGTH, "%s/voyager/%s", Experiments::DataPath.c_str(), name);

   TFile voyager1_file(path);
   if (!voyager1_file.IsOpen() || voyager1_file.IsZombie())
   {
      cerr << FG_RED_B << Form(" !!! get_voyager1_arxiv_h_he_iso_flux_graph-E-File not opened: %s", path) << RESET << endl;
      return NULL;
   }

   TTree *data;
   snprintf(name, NAME_LENGTH, "v1iso");
   voyager1_file.GetObject(name, data);
   if (data == NULL)
   {
      cerr << FG_RED_B << Form(" !!! get_voyager1_arxiv_h_he_iso_flux_graph-E-Tree not found: %s", name) << RESET << endl;
      return NULL;
   }
   UInt_t Z;
   UInt_t A;
   Double_t emin;
   Double_t emax;
   Double_t flux;
   Double_t diff_cnts;
   data->SetBranchAddress("Z", &Z);
   data->SetBranchAddress("A", &A);
   data->SetBranchAddress("EMin", &emin);
   data->SetBranchAddress("EMax", &emax);
   data->SetBranchAddress("Flux", &flux);
   data->SetBranchAddress("DiffCnts", &diff_cnts);

   static Char_t date1[11];
   static Char_t date2[11];
   snprintf(name, NAME_LENGTH, "g_%s_%s_%s_%u_%u_%s", exp.Name, Particle::Name[dataset.Particle[0]], Experiments::Measurement::Name[dataset.Type],
      measurement.DateRange[0], measurement.DateRange[1], Energy::Name[dataset.Energy]);
   TGraphAsymmErrors *graph = new TGraphAsymmErrors();
   graph->SetName(name);
   gROOT->Append(graph);
   graph->SetTitle(Form("Voyager 1 %s flux - %s-%s", Particle::Title[particle], DateTimeTools::SplitDate(measurement.DateRange[0], date1), DateTimeTools::SplitDate(measurement.DateRange[1], date2)));
   HistTools::ResetStyle(graph);

   UShort_t ipoint = 0;
   for (Long64_t ientry = 0; ientry < data->GetEntries(); ++ientry)
   {
      data->GetEntry(ientry);

      if (Z != Particle::Z[particle] || A != Particle::A[particle]) continue;

      Double_t ene  = sqrt(emin*emax);
      Double_t sys  = flux*0.05;
      Double_t stat = flux/sqrt(diff_cnts*(emax-emin));
      Double_t err  = sqrt(stat*stat + sys*sys);

      graph->SetPoint(ipoint, ene, flux);
      graph->SetPointError(ipoint, ene - emin, emax - ene, err, err);
      ++ipoint;
   }

   return graph;
}
TH1D *get_voyager1_arxiv_h_he_iso_flux_hist(UShort_t idataset, UShort_t imeasurement, TString &opt, Bool_t keep_file_open)
{
   TGraphAsymmErrors *graph = get_voyager1_arxiv_h_he_iso_flux_graph(idataset, imeasurement, opt, keep_file_open);
   if (graph == NULL) return NULL;

   return graph2hist(graph, Experiments::Info[Experiments::Voyager1].Dataset[idataset]);
}

TGraphAsymmErrors *get_voyager1_arxiv_iso_flux_graph(UShort_t idataset, UShort_t imeasurement, TString &opt, Bool_t keep_file_open)
{
   const Experiments::ExperimentInfo  &exp         = Experiments::Info[Experiments::Voyager1];
   const Experiments::DatasetInfo     &dataset     = exp.Dataset[idataset];
   const Experiments::MeasurementInfo &measurement = dataset.Measurement[imeasurement];

   Particle::Type particle = dataset.Particle[0];

   Char_t path[PATH_LENGTH];
   Char_t name[NAME_LENGTH] = "arxiv_1810.08589.root";
   snprintf(path, PATH_LENGTH, "%s/voyager/%s", Experiments::DataPath.c_str(), name);

   TFile voyager1_file(path);
   if (!voyager1_file.IsOpen() || voyager1_file.IsZombie())
   {
      cerr << FG_RED_B << Form(" !!! get_voyager1_arxiv_iso_flux_graph-E-File not opened: %s", path) << RESET << endl;
      return NULL;
   }

   TTree *data;
   snprintf(name, NAME_LENGTH, "v1iso");
   voyager1_file.GetObject(name, data);
   if (data == NULL)
   {
      cerr << FG_RED_B << Form(" !!! get_voyager1_arxiv_iso_flux_graph-E-Tree not found: %s", name) << RESET << endl;
      return NULL;
   }
   UInt_t Z;
   UInt_t A;
   Double_t emin;
   Double_t emax;
   Double_t flux;
   Double_t diff_cnts;
   data->SetBranchAddress("Z", &Z);
   data->SetBranchAddress("A", &A);
   data->SetBranchAddress("EMin", &emin);
   data->SetBranchAddress("EMax", &emax);
   data->SetBranchAddress("Flux", &flux);
   data->SetBranchAddress("DiffCnts", &diff_cnts);

   static Char_t date1[11];
   static Char_t date2[11];
   snprintf(name, NAME_LENGTH, "g_%s_%s_%s_%u_%u_%s", exp.Name, Particle::Name[dataset.Particle[0]], Experiments::Measurement::Name[dataset.Type],
      measurement.DateRange[0], measurement.DateRange[1], Energy::Name[dataset.Energy]);
   TGraphAsymmErrors *graph = new TGraphAsymmErrors();
   graph->SetName(name);
   gROOT->Append(graph);
   graph->SetTitle(Form("Voyager 1 %s flux - %s-%s", Particle::Title[particle], DateTimeTools::SplitDate(measurement.DateRange[0], date1), DateTimeTools::SplitDate(measurement.DateRange[1], date2)));
   HistTools::ResetStyle(graph);

   UShort_t ipoint = 0;
   for (Long64_t ientry = 0; ientry < data->GetEntries(); ++ientry)
   {
      data->GetEntry(ientry);

      if (Z != Particle::Z[particle] || A != Particle::A[particle]) continue;

      Double_t ene  = sqrt(emin*emax);
      Double_t sys  = flux*0.05;
      Double_t stat = flux/sqrt(diff_cnts*(emax-emin));
      Double_t err  = sqrt(stat*stat + sys*sys);

      graph->SetPoint(ipoint, ene, flux);
      graph->SetPointError(ipoint, ene - emin, emax - ene, err, err);
      ++ipoint;
   }

   return graph;
}
TH1D *get_voyager1_arxiv_iso_flux_hist(UShort_t idataset, UShort_t imeasurement, TString &opt, Bool_t keep_file_open)
{
   TGraphAsymmErrors *graph = get_voyager1_arxiv_iso_flux_graph(idataset, imeasurement, opt, keep_file_open);
   if (graph == NULL) return NULL;

   return graph2hist(graph, Experiments::Info[Experiments::Voyager1].Dataset[idataset]);
}
/// === [END] VOYAGER DATA FUNCTIONS ===

/// === [START] BESS DATA FUNCTIONS ===
TGraphAsymmErrors *get_bess_proton_flux_graph(UShort_t idataset, UShort_t imeasurement, TString &opt, Bool_t keep_file_open)
{
   const Experiments::ExperimentInfo  &exp         = Experiments::Info[Experiments::BESS];
   const Experiments::DatasetInfo     &dataset     = exp.Dataset[idataset];
   const Experiments::MeasurementInfo &measurement = dataset.Measurement[0];

   Char_t path[PATH_LENGTH];
   Char_t name[NAME_LENGTH] = "bess_H_flux.root";
   snprintf(path, PATH_LENGTH, "%s/%s", Experiments::DataPath.c_str(), name);

   TFile bess_file(path);
   if (!bess_file.IsOpen() || bess_file.IsZombie())
   {
      cerr << FG_RED_B << Form(" !!! get_bess_proton_flux_graph-E-File not opened: %s", path) << RESET << endl;
      return NULL;
   }

   TString str_opt = opt;
   if (str_opt == "") str_opt = "err";

   UShort_t begin_year  = measurement.DateRange[0] / 10000;
   UShort_t begin_month = (measurement.DateRange[0] % 10000) / 100;
   UShort_t end_year    = measurement.DateRange[1] / 10000;
   UShort_t end_month   = (measurement.DateRange[1] % 10000) / 100;

   TString begin_date;
   begin_date.Form("%04u_%02u", begin_year, begin_month);
   TString end_date = "";
   if (begin_year != end_year || begin_month != end_month) end_date.Form("_%04u_%02u", end_year, end_month);

   TGraphAsymmErrors *g_bess, *graph;
   snprintf(name, NAME_LENGTH, "%s_%s%s_%s_%s", TString(dataset.Description).ReplaceAll("-", "_").Data(),
      begin_date.Data(), end_date.Data(), "H", str_opt.Data());
   bess_file.GetObject(name, g_bess);
   if (g_bess == NULL)
   {
      snprintf(name, NAME_LENGTH, "%s_%s%s_%s_%s", TString(dataset.Description).ReplaceAll("-", "_").Data(),
         begin_date.Data(), end_date.Data(), "1H", str_opt.Data());
      bess_file.GetObject(name, g_bess);
      if (g_bess == NULL)
      {
         cerr << FG_RED_B << Form(" !!! get_bess_proton_flux_graph-E-Graph not found: %s", name) << RESET << endl;
         return NULL;
      }
   }

   static Char_t date1[11];
   static Char_t date2[11];
   snprintf(name, NAME_LENGTH, "g_%s_%s_%s_%u_%u_%s", exp.Name, Particle::Name[dataset.Particle[0]], Experiments::Measurement::Name[dataset.Type],
      measurement.DateRange[0], measurement.DateRange[1], Energy::Name[dataset.Energy]);
   graph = (TGraphAsymmErrors *)g_bess->Clone(name);
   gROOT->Append(graph);
   if (measurement.DateRange[1] != measurement.DateRange[0]) end_date.Form("-%s", DateTimeTools::SplitDate(measurement.DateRange[1], date2));
   graph->SetTitle(Form("%s proton flux %s- %s%s", dataset.Description, str_opt != "err" ? Form("(%s. only) ", str_opt.Data()) : "",
      DateTimeTools::SplitDate(measurement.DateRange[0], date1), end_date.Data()));
   HistTools::ResetStyle(graph);

   return graph;
}
TH1D *get_bess_proton_flux_hist(UShort_t idataset, UShort_t imeasurement, TString &opt, Bool_t keep_file_open)
{
   TGraphAsymmErrors *graph = get_bess_proton_flux_graph(idataset, imeasurement, opt, keep_file_open);
   if (graph == NULL) return NULL;

   return graph2hist(graph, Experiments::Info[Experiments::BESS].Dataset[idataset]);
}

TGraphAsymmErrors *get_bess_helium_flux_graph(UShort_t idataset, UShort_t imeasurement, TString &opt, Bool_t keep_file_open)
{
   const Experiments::ExperimentInfo  &exp         = Experiments::Info[Experiments::BESS];
   const Experiments::DatasetInfo     &dataset     = exp.Dataset[idataset];
   const Experiments::MeasurementInfo &measurement = dataset.Measurement[0];

   Char_t path[PATH_LENGTH];
   Char_t name[NAME_LENGTH] = "bess_He_flux.root";
   snprintf(path, PATH_LENGTH, "%s/%s", Experiments::DataPath.c_str(), name);

   TFile bess_file(path);
   if (!bess_file.IsOpen() || bess_file.IsZombie())
   {
      cerr << FG_RED_B << Form(" !!! get_bess_helium_flux_graph-E-File not opened: %s", path) << RESET << endl;
      return NULL;
   }

   TString str_opt = opt;
   if (str_opt == "") str_opt = "err";

   UShort_t begin_year  = measurement.DateRange[0] / 10000;
   UShort_t begin_month = (measurement.DateRange[0] % 10000) / 100;
   UShort_t end_year    = measurement.DateRange[1] / 10000;
   UShort_t end_month   = (measurement.DateRange[1] % 10000) / 100;

   TString begin_date;
   begin_date.Form("%04u_%02u", begin_year, begin_month);
   TString end_date = "";
   if (begin_year != end_year || begin_month != end_month) end_date.Form("_%04u_%02u", end_year, end_month);

   TGraphAsymmErrors *g_bess, *graph;
   snprintf(name, NAME_LENGTH, "%s_%s%s_He_%s", TString(dataset.Description).ReplaceAll("-", "_").Data(),
      begin_date.Data(), end_date.Data(), str_opt.Data());
   bess_file.GetObject(name, g_bess);
   if (g_bess == NULL)
   {
      cerr << FG_RED_B << Form(" !!! get_bess_helium_flux_graph-E-Graph not found: %s", name) << RESET << endl;
      return NULL;
   }

   static Char_t date1[11];
   static Char_t date2[11];
   snprintf(name, NAME_LENGTH, "g_%s_%s_%s_%u_%u_%s", exp.Name, Particle::Name[dataset.Particle[0]], Experiments::Measurement::Name[dataset.Type],
      measurement.DateRange[0], measurement.DateRange[1], Energy::Name[dataset.Energy]);
   graph = (TGraphAsymmErrors *)g_bess->Clone(name);
   gROOT->Append(graph);
   if (measurement.DateRange[1] != measurement.DateRange[0]) end_date.Form("-%s", DateTimeTools::SplitDate(measurement.DateRange[1], date2));
   graph->SetTitle(Form("%s helium flux %s- %s%s", dataset.Description, str_opt != "err" ? Form("(%s. only) ", str_opt.Data()) : "",
      DateTimeTools::SplitDate(measurement.DateRange[0], date1), end_date.Data()));
   HistTools::ResetStyle(graph);

   return graph;
}
TH1D *get_bess_helium_flux_hist(UShort_t idataset, UShort_t imeasurement, TString &opt, Bool_t keep_file_open)
{
   TGraphAsymmErrors *graph = get_bess_helium_flux_graph(idataset, imeasurement, opt, keep_file_open);
   if (graph == NULL) return NULL;

   return graph2hist(graph, Experiments::Info[Experiments::BESS].Dataset[idataset]);
}
/// === [END] BESS DATA FUNCTIONS ===

/// === [START] ACE DATA FUNCTIONS ===
TGraphAsymmErrors *get_ace_iso_flux_apj09_graph(UShort_t idataset, UShort_t imeasurement, TString &opt, Bool_t keep_file_open)
{
   const Experiments::ExperimentInfo  &exp         = Experiments::Info[Experiments::ACE];
   const Experiments::DatasetInfo     &dataset     = exp.Dataset[idataset];
   const Experiments::MeasurementInfo &measurement = dataset.Measurement[imeasurement];

   Particle::Type particle = dataset.Particle[0];

   Char_t path[PATH_LENGTH];
   Char_t name[NAME_LENGTH] = "ogliore09.root";
   snprintf(path, PATH_LENGTH, "%s/ace/%s", Experiments::DataPath.c_str(), name);

   TFile ace_file(path);
   if (!ace_file.IsOpen() || ace_file.IsZombie())
   {
      cerr << FG_RED_B << Form(" !!! get_ace_iso_flux_apj09_graph-E-File not opened: %s", path) << RESET << endl;
      return NULL;
   }

   TTree *data;
   snprintf(name, NAME_LENGTH, "ace");
   ace_file.GetObject(name, data);
   if (data == NULL)
   {
      cerr << FG_RED_B << Form(" !!! get_ace_iso_flux_apj09_graph-E-Tree not found: %s", name) << RESET << endl;
      return NULL;
   }
   UInt_t Z;
   UInt_t A;
   Double_t E;
   Double_t F;
   Double_t dFL, dFU;
   data->SetBranchAddress("Z", &Z);
   data->SetBranchAddress("A", &A);
   data->SetBranchAddress("E", &E);
   data->SetBranchAddress("F", &F);
   data->SetBranchAddress("dFL", &dFL);
   data->SetBranchAddress("dFU", &dFU);

   static Char_t date1[11];
   static Char_t date2[11];
   snprintf(name, NAME_LENGTH, "g_%s_%s_%s_%u_%u_%s", exp.Name, Particle::Name[dataset.Particle[0]], Experiments::Measurement::Name[dataset.Type],
      measurement.DateRange[0], measurement.DateRange[1], Energy::Name[dataset.Energy]);
   TGraphAsymmErrors *graph = new TGraphAsymmErrors();
   graph->SetName(name);
   gROOT->Append(graph);
   graph->SetTitle(Form("ACE/CRIS %s flux - %s-%s", Particle::Title[particle], DateTimeTools::SplitDate(measurement.DateRange[0], date1), DateTimeTools::SplitDate(measurement.DateRange[1], date2)));
   HistTools::ResetStyle(graph);

   UShort_t ipoint = 0;
   for (Long64_t ientry = 0; ientry < data->GetEntries(); ++ientry)
   {
      data->GetEntry(ientry);

      if (Z != Particle::Z[particle] || A != Particle::A[particle]) continue;

      graph->SetPoint(ipoint, E, F);
      graph->SetPointError(ipoint, 0., 0., dFL, dFU);
      ++ipoint;
   }
   graph->Sort();

   return graph;
}
TH1D *get_ace_iso_flux_apj09_hist(UShort_t idataset, UShort_t imeasurement, TString &opt, Bool_t keep_file_open)
{
   TGraphAsymmErrors *graph = get_ace_iso_flux_apj09_graph(idataset, imeasurement, opt, keep_file_open);
   if (graph == NULL) return NULL;

   return graph2hist(graph, Experiments::Info[Experiments::ACE].Dataset[idataset]);
}

TGraphAsymmErrors *get_ace_iso_ratio_jgra03_graph(UShort_t idataset, UShort_t imeasurement, TString &opt, Bool_t keep_file_open)
{
   const Experiments::ExperimentInfo  &exp         = Experiments::Info[Experiments::ACE];
   const Experiments::DatasetInfo     &dataset     = exp.Dataset[idataset];
   const Experiments::MeasurementInfo &measurement = dataset.Measurement[imeasurement];

   Particle::Type part1 = dataset.Particle[0];
   Particle::Type part2 = dataset.Particle[1];

   Char_t path[PATH_LENGTH];
   Char_t name[NAME_LENGTH] = "niebur03.root";
   snprintf(path, PATH_LENGTH, "%s/ace/%s", Experiments::DataPath.c_str(), name);

   TFile ace_file(path);
   if (!ace_file.IsOpen() || ace_file.IsZombie())
   {
      cerr << FG_RED_B << Form(" !!! get_ace_iso_ratio_jgra03_graph-E-File not opened: %s", path) << RESET << endl;
      return NULL;
   }

   TTree *data;
   snprintf(name, NAME_LENGTH, "ace");
   ace_file.GetObject(name, data);
   if (data == NULL)
   {
      cerr << FG_RED_B << Form(" !!! get_ace_iso_ratio_jgra03_graph-E-Tree not found: %s", name) << RESET << endl;
      return NULL;
   }
   UInt_t d;
   UInt_t m;
   Double_t E;
   Double_t R;
   Double_t dRL, dRU;
   data->SetBranchAddress("d", &d);
   data->SetBranchAddress("m", &m);
   data->SetBranchAddress("E", &E);
   data->SetBranchAddress("R", &R);
   data->SetBranchAddress("dRL", &dRL);
   data->SetBranchAddress("dRU", &dRU);

   static Char_t date1[11];
   static Char_t date2[11];
   snprintf(name, NAME_LENGTH, "g_%s_%s_%s_%s_%u_%u_%s", exp.Name, Particle::Name[part1], Particle::Name[part2], Experiments::Measurement::Name[dataset.Type],
      measurement.DateRange[0], measurement.DateRange[1], Energy::Name[dataset.Energy]);
   TGraphAsymmErrors *graph = new TGraphAsymmErrors();
   graph->SetName(name);
   gROOT->Append(graph);
   graph->SetTitle(Form("ACE/CRIS %s/%s ratio - %s-%s",
      Particle::Title[part1], Particle::Title[part2], DateTimeTools::SplitDate(measurement.DateRange[0], date1), DateTimeTools::SplitDate(measurement.DateRange[1], date2)));
   HistTools::ResetStyle(graph);

   UShort_t ipoint = 0;
   for (Long64_t ientry = 0; ientry < data->GetEntries(); ++ientry)
   {
      data->GetEntry(ientry);
      d += 14;

      if (d != idataset || m != imeasurement) continue;

      graph->SetPoint(ipoint, E, R);
      graph->SetPointError(ipoint, 0., 0., dRL, dRU);
      ++ipoint;
   }
   graph->Sort();

   return graph;
}
TH1D *get_ace_iso_ratio_jgra03_hist(UShort_t idataset, UShort_t imeasurement, TString &opt, Bool_t keep_file_open)
{
   TGraphAsymmErrors *graph = get_ace_iso_ratio_jgra03_graph(idataset, imeasurement, opt, keep_file_open);
   if (graph == NULL) return NULL;

   return graph2hist(graph, Experiments::Info[Experiments::ACE].Dataset[idataset]);
}
/// === [END] ACE DATA FUNCTIONS ===

string Experiments::DataPath = "~/cernbox/AMS/data/solar-modulation/data";

TH1D *Experiments::GetMeasurementHistogram(Type experiment, UShort_t idataset, UShort_t imeasurement, TString opt, Energy::Type energy, Bool_t keep_file_open)
{
   TH1D *hist = NULL;

   opt.ToLower();

   if (experiment == nTypes)
   {
      cerr << FG_RED_B << Form(" !!! Experiments::GetMeasurementHistogram-E-Experiment %u out-of-range", experiment) << RESET << endl;
   }
   else if (idataset >= Info[experiment].nDatasets)
   {
      cerr << FG_RED_B << Form(" !!! Experiments::GetMeasurementHistogram-E-Dataset %u out-of-range for experiment %s", idataset, Info[experiment].Title) << RESET << endl;
   }
   else if (experiment == AMS02)
   {
      if (idataset == 0) hist = get_ams02_proton_flux_hist(imeasurement, opt, keep_file_open);
      else if (idataset == 3) hist = get_ams02_helium_flux_hist(imeasurement, opt, keep_file_open);
      else if (idataset == 17) hist = get_ams02_phe_monthly_ratio_hist(idataset, imeasurement, opt, keep_file_open);
      else if (idataset == 18) hist = get_ams02_helium_flux_2017_hist(imeasurement, opt, keep_file_open);
      else if (19 <= idataset && idataset <= 33) hist = get_ams02_data_qiyan_hist(idataset, opt, keep_file_open);
      else if (34 <= idataset && idataset <= 39) hist = get_ams02_helium_isotopes_hist(idataset, imeasurement, opt, keep_file_open);
      else if (40 <= idataset && idataset <= 42) hist = get_ams02_helium_isotopes_time_hist(idataset, imeasurement, opt, keep_file_open);
      else if (idataset == 43) hist = get_ams02_data_qiyan_hist(idataset, opt, keep_file_open);
      else
      {
         switch (idataset)
         {
            case 1:
            case 2:
            case 5:
            case 7:
            case 8:
            case 11:
            case 12:
            case 15:
               hist = get_ams02_proton_monthly_flux_hist(idataset, imeasurement, opt, keep_file_open);
               break;
            case 4:
            case 6:
            case 9:
            case 10:
            case 13:
            case 14:
            case 16:
               hist = get_ams02_helium_monthly_flux_hist(idataset, imeasurement, opt, keep_file_open);
               break;
         }
      }
   }
   else if (experiment == AMS01)
   {
      if (idataset == 0) hist = get_ams01_proton_flux_hist(imeasurement, opt, keep_file_open);
      else if (idataset == 1) hist = get_ams01_helium_flux_hist(imeasurement, opt, keep_file_open);
   }
   else if (experiment == PAMELA)
   {
      if (idataset == 0) hist = get_pamela_proton_flux_hist(imeasurement, opt, keep_file_open);
      else if (idataset == 1) hist = get_pamela_proton_monthly_flux_hist_apj2013(imeasurement, opt, keep_file_open);
      else if (idataset == 2) hist = get_pamela_helium_flux_hist(imeasurement, opt, keep_file_open);
      else if (idataset == 3) hist = get_pamela_proton_monthly_flux_hist_apj2018(imeasurement, opt, keep_file_open);
   }
   else if (experiment == Voyager1)
   {
      if (idataset == 0) hist = get_voyager1_sci_proton_flux_hist(opt, keep_file_open);
      else if (idataset == 1) hist = get_voyager1_sci_helium_flux_hist(opt, keep_file_open);
      else if (idataset <= 28) hist = get_voyager1_apj_ions_flux_hist(idataset, imeasurement, opt, keep_file_open);
      else if (idataset <= 35) hist = get_voyager1_arxiv_ions_flux_hist(idataset, imeasurement, opt, keep_file_open);
      else if (idataset <= 39) hist = get_voyager1_arxiv_h_he_iso_flux_hist(idataset, imeasurement, opt, keep_file_open);
      else if (idataset <= 50) hist = get_voyager1_arxiv_iso_flux_hist(idataset, imeasurement, opt, keep_file_open);
   }
   else if (experiment == BESS)
   {
      if (idataset <= 7) hist = get_bess_proton_flux_hist(idataset, imeasurement, opt, keep_file_open);
      else if (idataset <= 15) hist = get_bess_helium_flux_hist(idataset, imeasurement, opt, keep_file_open);
   }
   else if (experiment == ACE)
   {
      if (idataset <= 13) hist = get_ace_iso_flux_apj09_hist(idataset, imeasurement, opt, keep_file_open);
      else if (idataset <= 15) hist = get_ace_iso_ratio_jgra03_hist(idataset, imeasurement, opt, keep_file_open);
   }

   const DatasetInfo &dataset = Info[experiment].Dataset[idataset];
   if (energy != Energy::nENERGYs && dataset.Type == Measurement::Flux)
   {
      convert_flux_energy(hist, dataset, energy);
      hist->SetXTitle(Unit::GetEnergyLabel(energy, SIPrefix::GIGA));
      hist->SetYTitle(Unit::GetDifferentialFluxLabel(energy, SIPrefix::GIGA, SIPrefix::NONE));
   }

   return hist;
}
TH1D *Experiments::GetMeasurementHistogram(Type experiment, UShort_t idataset, string date, TString opt, Energy::Type energy, Bool_t keep_file_open)
{
   TH1D *hist = NULL;

   if (experiment == nTypes)
   {
      cerr << FG_RED_B << Form(" !!! Experiments::GetMeasurementHistogram-E-Experiment %u out-of-range", experiment) << RESET << endl;
   }
   else if (idataset >= Info[experiment].nDatasets)
   {
      cerr << FG_RED_B << Form(" !!! Experiments::GetMeasurementHistogram-E-Dataset %u out-of-range for experiment %s", idataset, Info[experiment].Title) << RESET << endl;
   }
   else
   {
      UShort_t imeasurement = iMeasurement(experiment, idataset, date.c_str());

      if (imeasurement < Info[experiment].Dataset[idataset].nMeasurements)
      {
         hist = GetMeasurementHistogram(experiment, idataset, imeasurement, opt, energy, keep_file_open);
      }
      else
      {
         cerr << FG_RED_B << Form(" !!! Experiments::GetMeasurementHistogram-E-Date '%s' not found in dataset %u for experiment %s", date.c_str(), idataset, Info[experiment].Title) << RESET << endl;
      }
   }

   return hist;
}
TGraphAsymmErrors *Experiments::GetMeasurementGraph(Type experiment, UShort_t idataset, UShort_t imeasurement, TString opt, Energy::Type energy, Bool_t keep_file_open)
{
   TGraphAsymmErrors *graph = NULL;

   opt.ToLower();

   if (experiment == nTypes)
   {
      cerr << FG_RED_B << Form(" !!! Experiments::GetMeasurementGraph-E-Experiment %u out-of-range", experiment) << RESET << endl;
   }
   else if (idataset >= Info[experiment].nDatasets)
   {
      cerr << FG_RED_B << Form(" !!! Experiments::GetMeasurementGraph-E-Dataset %u out-of-range for experiment %s", idataset, Info[experiment].Title) << RESET << endl;
   }
   else if (experiment == AMS02)
   {
      if (idataset == 0) graph = get_ams02_proton_flux_graph(imeasurement, opt, keep_file_open);
      else if (idataset == 3) graph = get_ams02_helium_flux_graph(imeasurement, opt, keep_file_open);
      else if (idataset == 17) graph = get_ams02_phe_monthly_ratio_graph(idataset, imeasurement, opt, keep_file_open);
      else if (idataset == 18) graph = get_ams02_helium_flux_2017_graph(imeasurement, opt, keep_file_open);
      else if (19 <= idataset && idataset <= 33) graph = get_ams02_data_qiyan_graph(idataset, opt, keep_file_open);
      else if (34 <= idataset && idataset <= 39) graph = get_ams02_helium_isotopes_graph(idataset, imeasurement, opt, keep_file_open);
      else if (40 <= idataset && idataset <= 42) graph = get_ams02_helium_isotopes_time_graph(idataset, imeasurement, opt, keep_file_open);
      else if (idataset == 43) graph = get_ams02_data_qiyan_graph(idataset, opt, keep_file_open);
      else
      {
         switch (idataset)
         {
            case 1:
            case 2:
            case 5:
            case 7:
            case 8:
            case 11:
            case 12:
            case 15:
               graph = get_ams02_proton_monthly_flux_graph(idataset, imeasurement, opt, keep_file_open);
               break;
            case 4:
            case 6:
            case 9:
            case 10:
            case 13:
            case 14:
            case 16:
               graph = get_ams02_helium_monthly_flux_graph(idataset, imeasurement, opt, keep_file_open);
               break;
         }
      }
   }
   else if (experiment == AMS01)
   {
      if (idataset == 0) graph = get_ams01_proton_flux_graph(imeasurement, opt, keep_file_open);
      else if (idataset == 1) graph = get_ams01_helium_flux_graph(imeasurement, opt, keep_file_open);\
   }
   else if (experiment == PAMELA)
   {
      if (idataset == 0) graph = get_pamela_proton_flux_graph(imeasurement, opt, keep_file_open);
      else if (idataset == 1) graph = get_pamela_proton_monthly_flux_graph_apj2013(imeasurement, opt, keep_file_open);
      else if (idataset == 2) graph = get_pamela_helium_flux_graph(imeasurement, opt, keep_file_open);
      else if (idataset == 3) graph = get_pamela_proton_monthly_flux_graph_apj2018(imeasurement, opt, keep_file_open);
   }
   else if (experiment == Voyager1)
   {
      if (idataset == 0) graph = get_voyager1_sci_proton_flux_graph(opt, keep_file_open);
      else if (idataset == 1) graph = get_voyager1_sci_helium_flux_graph(opt, keep_file_open);
      else if (idataset <= 28) graph = get_voyager1_apj_ions_flux_graph(idataset, imeasurement, opt, keep_file_open);
      else if (idataset <= 35) graph = get_voyager1_arxiv_ions_flux_graph(idataset, imeasurement, opt, keep_file_open);
      else if (idataset <= 39) graph = get_voyager1_arxiv_h_he_iso_flux_graph(idataset, imeasurement, opt, keep_file_open);
      else if (idataset <= 50) graph = get_voyager1_arxiv_iso_flux_graph(idataset, imeasurement, opt, keep_file_open);
   }
   else if (experiment == BESS)
   {
      if (idataset <= 7) graph = get_bess_proton_flux_graph(idataset, imeasurement, opt, keep_file_open);
      else if (idataset <= 15) graph = get_bess_helium_flux_graph(idataset, imeasurement, opt, keep_file_open);
   }
   else if (experiment == ACE)
   {
      if (idataset <= 13) graph = get_ace_iso_flux_apj09_graph(idataset, imeasurement, opt, keep_file_open);
      else if (idataset <= 15) graph = get_ace_iso_ratio_jgra03_graph(idataset, imeasurement, opt, keep_file_open);
   }

   const DatasetInfo &dataset = Info[experiment].Dataset[idataset];
   if (energy != Energy::nENERGYs && dataset.Type == Measurement::Flux)
   {
      convert_flux_energy(graph, dataset, energy);
      const Char_t *title = graph->GetTitle();
      graph->SetTitle(Form("%s;%s;%s", title,
         Unit::GetEnergyLabel(energy, SIPrefix::GIGA),
         Unit::GetDifferentialFluxLabel(energy, SIPrefix::GIGA, SIPrefix::NONE)));
   }

   return graph;
}
TGraphAsymmErrors *Experiments::GetMeasurementGraph(Type experiment, UShort_t idataset, string date, TString opt, Energy::Type energy, Bool_t keep_file_open)
{
   TGraphAsymmErrors *graph = NULL;

   if (experiment == nTypes)
   {
      cerr << FG_RED_B << Form(" !!! Experiments::GetMeasurementGraph-E-Experiment %u out-of-range", experiment) << RESET << endl;
   }
   else if (idataset >= Info[experiment].nDatasets)
   {
      cerr << FG_RED_B << Form(" !!! Experiments::GetMeasurementGraph-E-Dataset %u out-of-range for experiment %s", idataset, Info[experiment].Title) << RESET << endl;
   }
   else
   {
      UShort_t imeasurement = iMeasurement(experiment, idataset, date.c_str());

      if (imeasurement < Info[experiment].Dataset[idataset].nMeasurements)
      {
         graph = GetMeasurementGraph(experiment, idataset, imeasurement, opt, energy, keep_file_open);
      }
      else
      {
         cerr << FG_RED_B << Form(" !!! Experiments::GetMeasurementGraph-E-Date '%s' not found in dataset %u for experiment %s", date.c_str(), idataset, Info[experiment].Title) << RESET << endl;
      }
   }

   return graph;
}

TGraphAsymmErrors *Experiments::GetMeasurementGraph(const Char_t *experiment, const Char_t *part, Energy::Type to_energy, const Char_t *filter, TString opt, UInt_t bd, UInt_t ed)
{
//~ PRINT_STRING(Form("LOADING MEASUREMENT '%s' FROM EXPERIMENT '%s'", part, experiment))
   Char_t meas_type[10];
   Char_t ene_type[5];
   Char_t exp_name[100];
   Char_t ref[100];
   Double_t eneavg, enemin, enemax, val, statlow, stathigh, systlow, systhigh;
   Long64_t start_utime, end_utime;

   opt.ToLower();

   UShort_t err_type = opt.Contains("stat") + 2*opt.Contains("syst");

   time_t begin_date = DateTimeTools::UIntToUTCTime(bd);
   time_t end_date   = DateTimeTools::UIntToUTCTime(ed) + Unit::day;

   TFile f(Form("%s/crdb/database.root", DataPath.c_str()));
   TTree *t_data = (TTree *)f.Get("data");
   t_data->SetBranchAddress("meas_type",    meas_type);
   t_data->SetBranchAddress("exp_name",     exp_name);
   t_data->SetBranchAddress("ene_type",     ene_type);
   t_data->SetBranchAddress("ref",          ref);
   t_data->SetBranchAddress("eneavg",      &eneavg);
   t_data->SetBranchAddress("enemin",      &enemin);
   t_data->SetBranchAddress("enemax",      &enemax);
   t_data->SetBranchAddress("val",         &val);
   t_data->SetBranchAddress("statlow",     &statlow);
   t_data->SetBranchAddress("stathigh",    &stathigh);
   t_data->SetBranchAddress("systlow",     &systlow);
   t_data->SetBranchAddress("systhigh",    &systhigh);
   t_data->SetBranchAddress("start_utime", &start_utime);
   t_data->SetBranchAddress("end_utime",   &end_utime);

   Energy::Type from_energy;
   TString exp;
   TGraphAsymmErrors *g = new TGraphAsymmErrors(10);
   UShort_t ipoint = 0;
   time_t fd, ld;
   for (Long64_t ientry = 0; ientry < t_data->GetEntries(); ++ientry)
   {
      t_data->GetEntry(ientry);

      if (strncmp(part, meas_type, 10)) continue;
      if (strstr(exp_name, experiment) == NULL) continue;
      if (strstr(ref, filter) == NULL) continue;
      if (bd > 0 && start_utime < begin_date) continue;
      if (ed > 0 && end_utime > end_date) continue;

      if (ipoint == 0)
      {
         if      (!strcmp(ene_type, "EKN"))  from_energy = Energy::KINETICPERNUCLEON;
         else if (!strcmp(ene_type, "EK"))   from_energy = Energy::KINETIC;
         else if (!strcmp(ene_type, "ETOT")) from_energy = Energy::TOTAL;
         else if (!strcmp(ene_type, "R"))    from_energy = Energy::RIGIDITY;

         exp = exp_name;
         fd = start_utime;
         ld = end_utime;
      }

      g->SetPoint(ipoint, eneavg, val);
      if (err_type == 2)
      {
         g->SetPointError(ipoint++, eneavg - enemin, enemax - eneavg, systlow, systhigh);
      }
      else if (err_type == 1)
      {
         g->SetPointError(ipoint++, eneavg - enemin, enemax - eneavg, statlow, stathigh);
      }
      else
      {
         g->SetPointError(ipoint++, eneavg - enemin, enemax - eneavg, TMath::Sqrt(statlow*statlow + systlow*systlow), TMath::Sqrt(stathigh*stathigh + systhigh*systhigh));
      }
   }

   if (ipoint == 0)
   {
      delete g;
      return NULL;
   }
   g->Set(ipoint);

   exp.Remove(exp.Index("("));
   TString exp_title = exp;
   exp.ToLower();
   exp.ReplaceAll("-", "");
   exp.ReplaceAll("+", "");
   exp.ReplaceAll(".", "");
   bd = DateTimeTools::UTCTimeToUInt(fd);
   ed = DateTimeTools::UTCTimeToUInt(ld);

   const Char_t *p = strstr(part, "/");
   if (p == NULL) // not a ratio, so we can convert the energy
   {
      Particle::Type particle;
      if      (!strcmp(part, "1H"))     particle = Particle::PROTON;
      else if (!strcmp(part, "1H-bar")) particle = Particle::ANTIPROTON;
      else if (!strcmp(part, "2H"))     particle = Particle::DEUTERON;
      else if (!strcmp(part,  "H"))     particle = Particle::HYDROGEN;
      else if (!strcmp(part, "3He"))    particle = Particle::HELIUM3;
      else if (!strcmp(part, "4He"))    particle = Particle::HELIUM4;
      else if (!strcmp(part,  "He"))    particle = Particle::HELIUM;
      else if (!strcmp(part,  "e+"))    particle = Particle::ELECTRON;
      else if (!strcmp(part,  "e-"))    particle = Particle::POSITRON;
      else if (!strcmp(part,  "e-+e+")) particle = Particle::ELECTRON;

      if (to_energy < Energy::nENERGYs && to_energy != from_energy)
      {
         HistTools::TransformEnergyAndDifferentialFlux(g, particle,
            from_energy, SIPrefix::GIGA, from_energy, SIPrefix::GIGA, SIPrefix::NONE,
            to_energy,   SIPrefix::GIGA, to_energy,   SIPrefix::GIGA, SIPrefix::NONE);
      }
      else to_energy = from_energy;

      g->SetName(Form("g_%s_%s_flux_%u_%u_%s", exp.Data(), part, bd, ed, Energy::Name[to_energy]));
      g->SetTitle(Form("%s - %s flux - %u-%u;%s;%s", exp_title.Data(), part, bd, ed, Unit::GetEnergyLabel(to_energy, SIPrefix::GIGA), Unit::GetDifferentialFluxLabel(to_energy, SIPrefix::GIGA, SIPrefix::NONE)));
   }
   else
   {
      g->SetName(Form("g_%s_%s_ratio_%u_%u_%s", exp.Data(), string(part).erase(p-part, 1).c_str(), bd, ed, Energy::Name[from_energy]));
      g->SetTitle(Form("%s - %s ratio - %u-%u;%s;%s", exp_title.Data(), part, bd, ed, Unit::GetEnergyLabel(from_energy, SIPrefix::GIGA), part));
   }
   gROOT->Append(g);

   return g;
}
TH1D *Experiments::GetMeasurementHistogram(const Char_t *experiment, const Char_t *part, Energy::Type to_energy, const Char_t *filter, TString opt, UInt_t bd, UInt_t ed)
{
   TGraphAsymmErrors *g = GetMeasurementGraph(experiment, part, to_energy, filter, opt, bd, ed);
   if (g == NULL) return NULL;
   TH1D *hist = HistTools::GraphToHist(g);

   hist->SetStats(false);
   HistTools::ResetStyle(hist);

   return hist;
}

TH1D **Experiments::GetDatasetHistograms(Type experiment, UShort_t idataset, TString opt, Energy::Type energy)
{
   TH1D **hists = NULL;

   if (experiment == nTypes)
   {
      cerr << FG_RED_B << Form(" !!! Experiments::GetDatasetHistogram-E-Experiment %u out-of-range", experiment) << RESET << endl;
   }
   else if (idataset >= Info[experiment].nDatasets)
   {
      cerr << FG_RED_B << Form(" !!! Experiments::GetDatasetHistogram-E-Dataset %u out-of-range for experiment %s", idataset, Info[experiment].Title) << RESET << endl;
   }
   else
   {
      const UShort_t nmeasurements = Info[experiment].Dataset[idataset].nMeasurements;
      hists = new TH1D *[nmeasurements]();

      for (UShort_t imeasurement = 0; imeasurement < nmeasurements; ++imeasurement)
      {
         hists[imeasurement] = GetMeasurementHistogram(experiment, idataset, imeasurement, opt, energy, imeasurement == nmeasurements - 1 ? false : true);
      }
   }

   return hists;
}
TGraphAsymmErrors **Experiments::GetDatasetGraphs(Type experiment, UShort_t idataset, TString opt, Energy::Type energy)
{
   TGraphAsymmErrors **graphs = NULL;

   if (experiment == nTypes)
   {
      cerr << FG_RED_B << Form(" !!! Experiments::GetDatasetGraph-E-Experiment %u out-of-range", experiment) << RESET << endl;
   }
   else if (idataset >= Info[experiment].nDatasets)
   {
      cerr << FG_RED_B << Form(" !!! Experiments::GetDatasetGraph-E-Dataset %u out-of-range for experiment %s", idataset, Info[experiment].Title) << RESET << endl;
   }
   else
   {
      const UShort_t nmeasurements = Info[experiment].Dataset[idataset].nMeasurements;
      graphs = new TGraphAsymmErrors *[nmeasurements]();

      for (UShort_t imeasurement = 0; imeasurement < nmeasurements; ++imeasurement)
      {
         graphs[imeasurement] = GetMeasurementGraph(experiment, idataset, imeasurement, opt, energy, imeasurement == nmeasurements - 1 ? false : true);
      }
   }

   return graphs;
}

time_t *Experiments::GetMeasurementTimeRange(const DatasetInfo *dataset, TNamed *obj)
{
   static time_t time_range[2];

   const ExperimentInfo *exp = dataset->Experiment;

   UShort_t idataset;
   for (idataset = 0; idataset < exp->nDatasets; ++idataset)
   {
      if (&exp->Dataset[idataset] == dataset) break;
   }

   if (idataset != exp->nDatasets)
   {
      const Char_t *date = GetMeasurementDate(obj);
      if (date != NULL)
      {
         string str(date);
         size_t p1 = str.find("-");
         if (p1 != string::npos)
         {
            time_range[0] = DateTimeTools::StringToUTCTime(str.substr(0, p1).c_str(), "%Y/%m/%d");
            time_range[1] = DateTimeTools::StringToUTCTime(str.substr(p1+1).c_str(), "%Y/%m/%d");
            if (time_range[1] < 0) time_range[1] = time_range[0] + 1*Unit::day;

            return time_range;
         }
         else cerr << FG_RED_B << Form(" !!! Experiments::GetMeasurementTimeRange-E-Date has wrong format: '%s'", date) << RESET << endl;

      }
   }
   else cerr << FG_RED_B << Form(" !!! Experiments::GetMeasurementTimeRange-E-Dataset '%s' not found in experiment '%s'", dataset->Description, exp->Name) << RESET << endl;

   return NULL;
}
time_t *Experiments::GetMeasurementTimeRange(const DatasetInfo *dataset, UShort_t imeasurement)
{
   static time_t time_range[2];

   const MeasurementInfo &measurement = dataset->Measurement[imeasurement];

   time_range[0] = DateTimeTools::UIntToUTCTime(measurement.DateRange[0]);
   time_range[1] = DateTimeTools::UIntToUTCTime(measurement.DateRange[1]);

   return time_range;
}
time_t *Experiments::GetMeasurementTimeRange(Type experiment, UShort_t idataset, UShort_t imeasurement)
{
   static time_t time_range[2];

   if (experiment == nTypes)
   {
      cerr << FG_RED_B << Form(" !!! Experiments::GetMeasurementTimeRange-E-Experiment %u out-of-range", experiment) << RESET << endl;

      return NULL;
   }
   else if (idataset >= Info[experiment].nDatasets)
   {
      cerr << FG_RED_B << Form(" !!! Experiments::GetMeasurementTimeRange-E-Dataset %u out-of-range for experiment %s", idataset, Info[experiment].Title) << RESET << endl;

      return NULL;
   }
   else if (imeasurement >= Info[experiment].Dataset[idataset].nMeasurements)
   {
      cerr << FG_RED_B << Form(" !!! Experiments::GetMeasurementTimeRange-E-Measurement %u out-of-range in dataset %u for experiment %s", imeasurement, idataset, Info[experiment].Title) << RESET << endl;

      return NULL;
   }
   else
   {
      const MeasurementInfo &measurement = Info[experiment].Dataset[idataset].Measurement[imeasurement];

      time_range[0] = DateTimeTools::UIntToUTCTime(measurement.DateRange[0]);
      time_range[1] = DateTimeTools::UIntToUTCTime(measurement.DateRange[1]);
   }

   return time_range;
}

vector< pair<time_t, time_t> > Experiments::GetDatasetTimeRanges(Type experiment, UShort_t idataset)
{
   UShort_t nfluxes = Info[experiment].Dataset[idataset].nMeasurements;

   vector< pair<time_t, time_t> > ranges(nfluxes);
   for (UShort_t iflux = 0; iflux < nfluxes; ++iflux)
   {
      const MeasurementInfo &measurement = Info[experiment].Dataset[idataset].Measurement[iflux];

      ranges[iflux] = make_pair(DateTimeTools::UIntToUTCTime(measurement.DateRange[0]),
         DateTimeTools::UIntToUTCTime(measurement.DateRange[1]) + Unit::day);
   }

   return ranges;
}

UShort_t Experiments::iMeasurement(Type experiment, UShort_t idataset, const Char_t *date)
{
   UInt_t idate = atoi(date);

   UShort_t imeasurement;
   for (imeasurement = 0; imeasurement < Info[experiment].Dataset[idataset].nMeasurements; ++imeasurement)
   {
      const MeasurementInfo &measurement = Info[experiment].Dataset[idataset].Measurement[imeasurement];

      if (measurement.DateRange[0] <= idate && idate <= measurement.DateRange[1]) break;
   }

   return imeasurement;
}
UShort_t Experiments::iMeasurement(Type experiment, UShort_t idataset, TNamed *obj)
{
   string name = obj->GetName();
   size_t p = 0;
   for (UShort_t i = 0; i < 4 && p != string::npos; ++i)
   {
      p = name.find("_", p + 1);
   }

   if (p == string::npos)
   {
      cerr << FG_RED_B << Form(" !!! Experiments::GetMeasurementDate-E-Name has wrong format: %s", name.c_str()) << RESET << endl;
      return Info[experiment].Dataset[idataset].nMeasurements;
   }

   return iMeasurement(experiment, idataset, name.substr(p + 1, 8).c_str());
}

UShort_t Experiments::iDataset(const DatasetInfo *dataset)
{
   const ExperimentInfo *exp = dataset->Experiment;

   UShort_t idataset;
   for (idataset = 0; idataset < exp->nDatasets; ++idataset)
   {
      if (&exp->Dataset[idataset] == dataset) break;
   }

   return idataset;
}

Experiments::Type Experiments::FromName(const Char_t *name)
{
   size_t len = strlen(name);

   UShort_t itype;
   for (itype = 0; itype < nTypes; ++itype)
   {
      if (!strncmp(name, Info[itype].Name, len)) break;
   }

   return cast(itype);
}
Experiments::Type Experiments::GetExperiment(TNamed *obj)
{
   string str = obj->GetName();

   size_t p1 = str.find('_');
   if (p1 == string::npos)
   {
      cerr << FG_RED_B << Form(" !!! Experiments::GetExperiment-E-Name has wrong format: %s", str.c_str()) << RESET << endl;
      return Experiments::nTypes;
   }

   Char_t exp_name[11] = "";
   size_t p2 = str.find('_', p1 + 1);
   snprintf(exp_name, 11, "%s", str.substr(p1 + 1, p2 - p1 - 1).c_str());

   return FromName(exp_name);
}

const Char_t *Experiments::GetMeasurementDate(TNamed *obj)
{
   static Char_t str_date[22] = "";

   string name = obj->GetName();
   size_t p = 0;
   for (UShort_t i = 0; i < 4 && p != string::npos; ++i)
   {
      p = name.find("_", p + 1);
   }

   if (p == string::npos)
   {
      cerr << FG_RED_B << Form(" !!! Experiments::GetMeasurementDate-E-Name has wrong format: %s", name.c_str()) << RESET << endl;
      return NULL;
   }

   string subs = name.substr(p + 1, 8);
   subs.insert(4, "/");
   subs.insert(7, "/");
   strncpy(str_date, subs.c_str(), 10);
   str_date[10] = '\0';

   strncat(str_date, "-", 1);

   subs = name.substr(p + 10, 8);
   subs.insert(4, "/");
   subs.insert(7, "/");
   strncat(str_date, subs.c_str(), 10);

   return str_date;
}
const Char_t *Experiments::GetMeasurementDate(const DatasetInfo *dataset, UShort_t imeasurement)
{
   static Char_t str_date[22] = "";

   const MeasurementInfo &measurement = dataset->Measurement[imeasurement];

   strncpy(str_date, DateTimeTools::SplitDate(measurement.DateRange[0]), 10);
   str_date[10] = '\0';
   strncat(str_date, "-", 1);
   strncat(str_date, DateTimeTools::SplitDate(measurement.DateRange[1]), 10);

   return str_date;
}
const Char_t *Experiments::GetMeasurementDate(Type experiment, UShort_t idataset, UShort_t imeasurement)
{
   static Char_t str_date[22] = "";

   if (experiment == nTypes)
   {
      cerr << FG_RED_B << Form(" !!! Experiments::GetMeasurementDate-E-Experiment %u out-of-range", experiment) << RESET << endl;

      return NULL;
   }
   else if (idataset >= Info[experiment].nDatasets)
   {
      cerr << FG_RED_B << Form(" !!! Experiments::GetMeasurementDate-E-Dataset %u out-of-range for experiment %s", idataset, Info[experiment].Title) << RESET << endl;

      return NULL;
   }
   else if (imeasurement >= Info[experiment].Dataset[idataset].nMeasurements)
   {
      cerr << FG_RED_B << Form(" !!! Experiments::GetMeasurementDate-E-Measurement %u out-of-range in dataset %u for experiment %s", imeasurement, idataset, Info[experiment].Title) << RESET << endl;

      return NULL;
   }
   else
   {
      const MeasurementInfo &measurement = Info[experiment].Dataset[idataset].Measurement[imeasurement];

      strncpy(str_date, DateTimeTools::SplitDate(measurement.DateRange[0]), 10);
      str_date[10] = '\0';
      strncat(str_date, "-", 1);
      strncat(str_date, DateTimeTools::SplitDate(measurement.DateRange[1]), 10);
   }

   return str_date;
}

Experiments::ACEBRFluxes::ACEBRFluxes(Particle::Type particle) : fin(NULL), data(NULL), factors(NULL), part(particle)
{
   fin = new TFile(Form("%s/ace/%s_BR.root", DataPath.c_str(), Particle::Name[particle]));
   gROOT->cd();

   if (fin->IsZombie() || !fin->IsOpen())
   {
      cerr << FG_RED_B << Form(" !!! ACEBRFluxes::ACEBRFluxes-E-File not opened") << RESET << endl;
      delete fin;
      fin = NULL;
   }
   else
   {
      data = (TTree *)fin->Get("ace");
      data->SetBranchAddress("start_utime", &start_utime);
      data->SetBranchAddress("F", F);
      data->SetBranchAddress("C", C);
      data->SetBranchAddress("livetime", &livetime);

      nbrs = data->GetEntries();

      factors = (TTree *)fin->Get("const");
      factors->SetBranchAddress("EMin", EMin);
      factors->SetBranchAddress("EMax", EMax);
      factors->SetBranchAddress("EMed", EMed);
      factors->SetBranchAddress("GF", GF);
      factors->SetBranchAddress("SOFTEff", SOFTEff);
      factors->SetBranchAddress("SpallCorr", SpallCorr);
      factors->SetBranchAddress("SpallCorrUnc", SpallCorrUnc);
      factors->GetEntry(0);
   }
}

Experiments::ACEBRFluxes::~ACEBRFluxes()
{
   if (fin != NULL) delete fin;
}

time_t *Experiments::ACEBRFluxes::TimeRange(UShort_t iBR)
{
   static time_t time_range[2];

   if (iBR >= nbrs) return NULL;

   time_range[0] = DateTimeTools::BRToUTCTime(first_br + iBR);
   time_range[1] = DateTimeTools::BRToUTCTime(first_br + iBR + 1) - Unit::day;

   return time_range;
}

TGraphAsymmErrors *Experiments::ACEBRFluxes::GetMeasurementGraph(UInt_t iBR)
{
   if (iBR >= nbrs) return NULL;

   data->GetEntry(iBR);

   time_t *time_range = TimeRange(iBR);
   UInt_t date_range[2] = { DateTimeTools::UTCTimeToUInt(time_range[0]), DateTimeTools::UTCTimeToUInt(time_range[1]) };

   static Char_t date1[11];
   static Char_t date2[11];
   Char_t name[NAME_LENGTH];
   snprintf(name, NAME_LENGTH, "g_ace_flux_%s_%u_%u_%s", Particle::Name[part],
      date_range[0], date_range[1], Energy::Name[Energy::KINETICPERNUCLEON]);
   TGraphAsymmErrors *graph = new TGraphAsymmErrors(nbins);
   graph->SetName(name);
   gROOT->Append(graph);
   graph->SetTitle(Form("ACE/CRIS %s flux - %s-%s;%s;%s",
      Particle::Title[part], DateTimeTools::SplitDate(date_range[0], date1), DateTimeTools::SplitDate(date_range[1], date2),
      Unit::GetEnergyLabel(Energy::KINETICPERNUCLEON, SIPrefix::MEGA),
      Unit::GetDifferentialFluxLabel(Energy::KINETICPERNUCLEON, SIPrefix::MEGA, SIPrefix::CENTI)));
   HistTools::ResetStyle(graph);

   for (UShort_t ibin = 0; ibin < nbins; ++ibin)
   {
      Double_t syst = F[ibin] * sqrt(8e-4 + SpallCorrUnc[ibin]*SpallCorrUnc[ibin]/SpallCorr[ibin]/SpallCorr[ibin]);
      Double_t stat = F[ibin]/sqrt(C[ibin]);
      Double_t err  = sqrt(stat*stat + syst*syst);

      graph->SetPoint(ibin, EMed[ibin], F[ibin]);
      graph->SetPointError(ibin, EMed[ibin] - EMin[ibin], EMax[ibin] - EMed[ibin], err, err);
   }

   return graph;
}
TH1D *Experiments::ACEBRFluxes::GetMeasurementHistogram(UInt_t iBR)
{
   TGraphAsymmErrors *graph = GetMeasurementGraph(iBR);
   if (graph == NULL) return NULL;

   TH1D *hist = HistTools::GraphToHist(graph);
   hist->SetStats(false);
   hist->SetDirectory(gROOT);
   hist->SetXTitle(Unit::GetEnergyLabel(Energy::KINETICPERNUCLEON, SIPrefix::MEGA));
   hist->SetYTitle(Unit::GetDifferentialFluxLabel(Energy::KINETICPERNUCLEON, SIPrefix::MEGA, SIPrefix::CENTI));
   HistTools::ResetStyle(hist);

   return hist;
}

TGraphAsymmErrors *Experiments::ACEBRFluxes::GetAverageGraph(UInt_t *BRs, UInt_t nBRs)
{
   Char_t name[NAME_LENGTH];
   snprintf(name, NAME_LENGTH, "g_ace_avgflux_%s_%s", Particle::Name[part],
      Energy::Name[Energy::KINETICPERNUCLEON]);
   TGraphAsymmErrors *graph = new TGraphAsymmErrors(nbins);
   graph->SetName(name);
   gROOT->Append(graph);
   graph->SetTitle(Form("ACE/CRIS %s averaged flux;%s;%s", Particle::Title[part],
      Unit::GetEnergyLabel(Energy::KINETICPERNUCLEON, SIPrefix::MEGA),
      Unit::GetDifferentialFluxLabel(Energy::KINETICPERNUCLEON, SIPrefix::MEGA, SIPrefix::CENTI)));
   HistTools::ResetStyle(graph);

   for (UShort_t ibin = 0; ibin < nbins; ++ibin)
   {
      graph->SetPoint(ibin, EMed[ibin], 0.);
      graph->SetPointError(ibin, EMed[ibin] - EMin[ibin], EMax[ibin] - EMed[ibin], 0., 0.);
   }

   Double_t dT = 0.;
   for (UInt_t ibr = 0; ibr < nBRs; ++ibr)
   {
      if (BRs[ibr] >= nbrs) continue;

      data->GetEntry(BRs[ibr]);
      dT += livetime;

      for (UShort_t ibin = 0; ibin < nbins; ++ibin)
      {
         graph->GetY()[ibin] += livetime*F[ibin];
         graph->GetEYlow()[ibin] += C[ibin];
      }
   }
   for (UShort_t ibin = 0; ibin < nbins; ++ibin)
   {
      Double_t flux   = graph->GetY()[ibin]/dT;
      Double_t counts = graph->GetEYlow()[ibin];
      Double_t syst   = flux * sqrt(8e-4 + SpallCorrUnc[ibin]*SpallCorrUnc[ibin]/SpallCorr[ibin]/SpallCorr[ibin]);
      Double_t stat   = flux/sqrt(counts);
      Double_t err    = sqrt(stat*stat + syst*syst);

      graph->GetY()[ibin]      = flux;
      graph->GetEYlow()[ibin]  = err;
      graph->GetEYhigh()[ibin] = err;
   }

   return graph;
}
TGraphAsymmErrors *Experiments::ACEBRFluxes::GetAverageGraph(UInt_t FirstBR, UInt_t LastBR)
{
   if (LastBR == 0) LastBR = nbrs - 1;
   UInt_t nfluxes = LastBR - FirstBR;
   UInt_t BRs[nfluxes];
   for (UInt_t ibr = 0; ibr <= nfluxes; ++ibr)
   {
      BRs[ibr] = FirstBR + ibr;
   }

   return GetAverageGraph(BRs, nfluxes);
}
TH1D *Experiments::ACEBRFluxes::GetAverageHistogram(UInt_t *BRs, UInt_t nBRs)
{
   TGraphAsymmErrors *graph = GetAverageGraph(BRs, nBRs);
   if (graph == NULL) return NULL;

   TH1D *hist = HistTools::GraphToHist(graph);
   hist->SetStats(false);
   hist->SetDirectory(gROOT);
   hist->SetXTitle(Unit::GetEnergyLabel(Energy::KINETICPERNUCLEON, SIPrefix::MEGA));
   hist->SetYTitle(Unit::GetDifferentialFluxLabel(Energy::KINETICPERNUCLEON, SIPrefix::MEGA, SIPrefix::CENTI));
   HistTools::ResetStyle(hist);

   return hist;
}
TH1D *Experiments::ACEBRFluxes::GetAverageHistogram(UInt_t FirstBR, UInt_t LastBR)
{
   TGraphAsymmErrors *graph = GetAverageGraph(FirstBR, LastBR);
   if (graph == NULL) return NULL;

   TH1D *hist = HistTools::GraphToHist(graph);
   hist->SetStats(false);
   hist->SetDirectory(gROOT);
   hist->SetXTitle(Unit::GetEnergyLabel(Energy::KINETICPERNUCLEON, SIPrefix::MEGA));
   hist->SetYTitle(Unit::GetDifferentialFluxLabel(Energy::KINETICPERNUCLEON, SIPrefix::MEGA, SIPrefix::CENTI));
   HistTools::ResetStyle(hist);

   return hist;
}

TGraphAsymmErrors **Experiments::ACEBRFluxes::GetDatasetGraphs(UInt_t FirstBR, UInt_t LastBR)
{
   if (LastBR == 0) LastBR = nbrs - 1;
   UInt_t nfluxes = LastBR - FirstBR;

   TGraphAsymmErrors **graphs = new TGraphAsymmErrors *[nfluxes]();
   for (UInt_t ibr = 0; ibr <= nfluxes; ++ibr)
   {
      graphs[ibr] = GetMeasurementGraph(ibr + FirstBR);
   }

   return graphs;
}
TH1D **Experiments::ACEBRFluxes::GetDatasetHistograms(UInt_t FirstBR, UInt_t LastBR)
{
   if (LastBR == 0) LastBR = nbrs - 1;
   UInt_t nfluxes = LastBR - FirstBR;

   TH1D **hists = new TH1D *[nfluxes]();
   for (UInt_t ibr = 0; ibr <= nfluxes; ++ibr)
   {
      hists[ibr] = GetMeasurementHistogram(ibr + FirstBR);
   }

   return hists;
}

Experiments::ACEIsotopicComposition::ACEIsotopicComposition()
{
   time_range[0] = DateTimeTools::UIntToUTCTime(19971130);
   time_range[1] = DateTimeTools::UIntToUTCTime(19990909);

   TFile fin(Form("%s/ace/isotope_table.root", DataPath.c_str()));
   TTree *ace = (TTree *)fin.Get("ace");
   gROOT->cd();

   UInt_t Z, A;
   Double_t emin, emax;
   Double_t val, err;
   ace->SetBranchAddress("Z", &Z);
   ace->SetBranchAddress("A", &A);
   ace->SetBranchAddress("emin", &emin);
   ace->SetBranchAddress("emax", &emax);
   ace->SetBranchAddress("abnd", &val);
   ace->SetBranchAddress("err", &err);

   for (Long64_t ientry = 0; ientry < ace->GetEntries(); ++ientry)
   {
      ace->GetEntry(ientry);

      Particle::Type part = Particle::FromChargeMassNumber(Z, A);
      particles.push_back(part);

      Double_t bins[2] = { emin, emax };
      TH1F *h = new TH1F(Form("h_ace_isocomp_%s", Particle::Name[part]),
         Form("ACE/CRIS %s relative abundance;Kinetic energy [MeV/n];%s/%s [%%]", Particle::Symbol[part], Particle::Symbol[part], Particle::Symbol[Particle::NICKEL64+Z]),
         1, bins);
      h->SetBinContent(1, val);
      h->SetBinError(1, err);
      values.push_back(h);
   }
}

THStack *Experiments::ACEIsotopicComposition::GetElementComposition(UShort_t Z)
{
   THStack *hs = new THStack(Form("hs_ace_isocomp_%s", Particle::Name[Particle::NICKEL64+Z]), Form("ACE/CRIS %s isotopes relative abundance;Kinetic energy [MeV/n];Relative abundance [%%]", Particle::Symbol[Particle::NICKEL64+Z]));

   for (UInt_t ipart = 0; ipart < particles.size(); ++ipart)
   {
      if (Particle::Z[particles[ipart]] == Z)
      {
         hs->Add(values[ipart]);
      }
   }

   return hs;
}
