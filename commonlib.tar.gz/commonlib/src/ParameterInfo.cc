#include "ParameterInfo.hh"
#include "debug.hh"

using namespace std;

const Char_t *ParameterInfo::GetLabel() const
{
   static Char_t label[128];
   snprintf(label, 128, "%s%s", Symbol, strlen(Unit) > 0 ? Form(" [%s]", Unit) : "");

   return label;
}

void ParameterInfo::Print(ostream &out, Option_t *opt) const
{
   if (strstr(opt, "D") != NULL) out << Form("[%p] ", this);

   out << Form("%s (%s, %s [%s]) = { %+11.5e, %+11.5e, %+11.5e }\n", Title, Name, Symbol, Unit, Min, Med, Max);
}

void ParameterInfo::Print(Option_t *opt) const
{
   Print(cout, opt);
}

void ModelInfo::Print(ostream &out, Option_t *opt) const
{
   if (strstr(opt, "D") != NULL) out << Form("[%p] ", this);

   out << Form("%s (%s, %s); nParameters = %d\n", Title, Name, Formula, nParameters);
   for (UInt_t ipar = 0; ipar < nParameters; ++ipar)
   {
      out << Form("   Par. %02d: ", ipar);
      Parameter[ipar].Print(out, opt);
   }
}

void ModelInfo::Print(Option_t *opt) const
{
   Print(cout, opt);
}
