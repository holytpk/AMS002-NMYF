#include "Units.hh"
#include "HistTools.hh"
#include "GOES.hh"
#include "debug.hh"

using Unit::MeV;
using Unit::GeV;
using Unit::s;
using Unit::min;
using Unit::sr;
using Unit::cm2;
using Unit::m2;

const Char_t *GOES_DATA_PATH = "/home/ccorti/cernbox/AMS/data/GOES";
const Char_t *SCRIPT_PATH    = "/home/ccorti/cernbox/phd-uhm/code/common/script";

GOES::GOES() :
   _file_data(), _tree_data(), _date(), _intervals()
{
PRINT_FUNCTION()
   _init();
}

GOES::GOES(const Char_t *date, const Char_t *particles) :
   _file_data(),  _tree_data(), _date(), _intervals()
{
PRINT_FUNCTION()
PRINT_VARIABLE(date)
PRINT_VARIABLE(particles)
   _init(date, particles);
}

GOES::GOES(const GOES &obj) :
   _file_data(), _tree_data(), _date(), _intervals()
{
PRINT_FUNCTION()
PRINT_STRING(Form("[%p] GOES::GOES - Source internal status", &obj))
PRINT_VARIABLE(obj._datafile_path)
PRINT_VARIABLE(obj._script_path)
PRINT_VARIABLE(obj._date)
PRINT_VARIABLE(obj._particles)
PRINT_VARIABLE(obj._intervals)
PRINT_VARIABLE(obj._timebins)
PRINT_POINTER_NAME_ARRAY(obj._file_data[GOESInfo::FULL],GOESInfo::_nDATAFILEs[GOESInfo::FULL])
PRINT_POINTER_NAME_ARRAY(obj._file_data[GOESInfo::AVG1M],GOESInfo::_nDATAFILEs[GOESInfo::AVG1M])
PRINT_POINTER_NAME_ARRAY(obj._file_data[GOESInfo::AVG5M],GOESInfo::_nDATAFILEs[GOESInfo::AVG5M])
PRINT_POINTER_NAME_ARRAY(obj._file_data[GOESInfo::SCIENCE],GOESInfo::_nDATAFILEs[GOESInfo::SCIENCE])
PRINT_POINTER_NAME_ARRAY(obj._file_data[GOESInfo::STATUS],GOESInfo::_nDATAFILEs[GOESInfo::STATUS])
PRINT_POINTER_NAME_ARRAY(obj._tree_data[GOESInfo::FULL],GOESInfo::_nDATAFILEs[GOESInfo::FULL])
PRINT_POINTER_NAME_ARRAY(obj._tree_data[GOESInfo::AVG1M],GOESInfo::_nDATAFILEs[GOESInfo::AVG1M])
PRINT_POINTER_NAME_ARRAY(obj._tree_data[GOESInfo::AVG5M],GOESInfo::_nDATAFILEs[GOESInfo::AVG5M])
PRINT_POINTER_NAME_ARRAY(obj._tree_data[GOESInfo::SCIENCE],GOESInfo::_nDATAFILEs[GOESInfo::SCIENCE])
PRINT_POINTER_NAME_ARRAY(obj._tree_data[GOESInfo::STATUS],GOESInfo::_nDATAFILEs[GOESInfo::STATUS])
   SetDatafilePath(obj._datafile_path);
   SetScriptPath(obj._script_path);

   _set_date(obj._date);

   _intervals = _set_string(obj._intervals);
   _timebins  = obj._timebins;

   _particles = obj._particles;

   _load_data();
PRINT_STRING(Form("[%p] GOES::GOES - Internal status", this))
PRINT_VARIABLE(_datafile_path)
PRINT_VARIABLE(_script_path)
PRINT_VARIABLE(_date)
PRINT_VARIABLE(_particles)
PRINT_VARIABLE(_intervals)
PRINT_VARIABLE(_timebins)
PRINT_POINTER_NAME_ARRAY(_file_data[GOESInfo::FULL],GOESInfo::_nDATAFILEs[GOESInfo::FULL])
PRINT_POINTER_NAME_ARRAY(_file_data[GOESInfo::AVG1M],GOESInfo::_nDATAFILEs[GOESInfo::AVG1M])
PRINT_POINTER_NAME_ARRAY(_file_data[GOESInfo::AVG5M],GOESInfo::_nDATAFILEs[GOESInfo::AVG5M])
PRINT_POINTER_NAME_ARRAY(_file_data[GOESInfo::SCIENCE],GOESInfo::_nDATAFILEs[GOESInfo::SCIENCE])
PRINT_POINTER_NAME_ARRAY(_file_data[GOESInfo::STATUS],GOESInfo::_nDATAFILEs[GOESInfo::STATUS])
PRINT_POINTER_NAME_ARRAY(_tree_data[GOESInfo::FULL],GOESInfo::_nDATAFILEs[GOESInfo::FULL])
PRINT_POINTER_NAME_ARRAY(_tree_data[GOESInfo::AVG1M],GOESInfo::_nDATAFILEs[GOESInfo::AVG1M])
PRINT_POINTER_NAME_ARRAY(_tree_data[GOESInfo::AVG5M],GOESInfo::_nDATAFILEs[GOESInfo::AVG5M])
PRINT_POINTER_NAME_ARRAY(_tree_data[GOESInfo::SCIENCE],GOESInfo::_nDATAFILEs[GOESInfo::SCIENCE])
PRINT_POINTER_NAME_ARRAY(_tree_data[GOESInfo::STATUS],GOESInfo::_nDATAFILEs[GOESInfo::STATUS])
}

#ifndef __clang__
GOES& GOES::operator=(GOES obj)
{
PRINT_FUNCTION()
PRINT_STRING(Form("[%p] GOES::operator= - Source status", &obj))
PRINT_VARIABLE(obj._datafile_path)
PRINT_VARIABLE(obj._script_path)
PRINT_VARIABLE(obj._date)
PRINT_VARIABLE(obj._particles)
PRINT_VARIABLE(obj._intervals)
PRINT_VARIABLE(obj._timebins)
PRINT_POINTER_NAME_ARRAY(obj._file_data[GOESInfo::FULL],GOESInfo::_nDATAFILEs[GOESInfo::FULL])
PRINT_POINTER_NAME_ARRAY(obj._file_data[GOESInfo::AVG1M],GOESInfo::_nDATAFILEs[GOESInfo::AVG1M])
PRINT_POINTER_NAME_ARRAY(obj._file_data[GOESInfo::AVG5M],GOESInfo::_nDATAFILEs[GOESInfo::AVG5M])
PRINT_POINTER_NAME_ARRAY(obj._file_data[GOESInfo::SCIENCE],GOESInfo::_nDATAFILEs[GOESInfo::SCIENCE])
PRINT_POINTER_NAME_ARRAY(obj._file_data[GOESInfo::STATUS],GOESInfo::_nDATAFILEs[GOESInfo::STATUS])
PRINT_POINTER_NAME_ARRAY(obj._tree_data[GOESInfo::FULL],GOESInfo::_nDATAFILEs[GOESInfo::FULL])
PRINT_POINTER_NAME_ARRAY(obj._tree_data[GOESInfo::AVG1M],GOESInfo::_nDATAFILEs[GOESInfo::AVG1M])
PRINT_POINTER_NAME_ARRAY(obj._tree_data[GOESInfo::AVG5M],GOESInfo::_nDATAFILEs[GOESInfo::AVG5M])
PRINT_POINTER_NAME_ARRAY(obj._tree_data[GOESInfo::SCIENCE],GOESInfo::_nDATAFILEs[GOESInfo::SCIENCE])
PRINT_POINTER_NAME_ARRAY(obj._tree_data[GOESInfo::STATUS],GOESInfo::_nDATAFILEs[GOESInfo::STATUS])
   swap(_datafile_path, obj._datafile_path);
   swap(_script_path, obj._script_path);

   swap(_date, obj._date);

   swap(_intervals, obj._intervals);
   swap(_timebins,  obj._timebins);

   swap(_particles, obj._particles);

   swap(_file_data, obj._file_data);
   swap(_tree_data, obj._tree_data);
PRINT_STRING(Form("[%p] GOES::_init - Internal status", this))
PRINT_VARIABLE(_datafile_path)
PRINT_VARIABLE(_script_path)
PRINT_VARIABLE(_date)
PRINT_VARIABLE(_particles)
PRINT_VARIABLE(_intervals)
PRINT_VARIABLE(_timebins)
PRINT_POINTER_NAME_ARRAY(_file_data[GOESInfo::FULL],GOESInfo::_nDATAFILEs[GOESInfo::FULL])
PRINT_POINTER_NAME_ARRAY(_file_data[GOESInfo::AVG1M],GOESInfo::_nDATAFILEs[GOESInfo::AVG1M])
PRINT_POINTER_NAME_ARRAY(_file_data[GOESInfo::AVG5M],GOESInfo::_nDATAFILEs[GOESInfo::AVG5M])
PRINT_POINTER_NAME_ARRAY(_file_data[GOESInfo::SCIENCE],GOESInfo::_nDATAFILEs[GOESInfo::SCIENCE])
PRINT_POINTER_NAME_ARRAY(_file_data[GOESInfo::STATUS],GOESInfo::_nDATAFILEs[GOESInfo::STATUS])
PRINT_POINTER_NAME_ARRAY(_tree_data[GOESInfo::FULL],GOESInfo::_nDATAFILEs[GOESInfo::FULL])
PRINT_POINTER_NAME_ARRAY(_tree_data[GOESInfo::AVG1M],GOESInfo::_nDATAFILEs[GOESInfo::AVG1M])
PRINT_POINTER_NAME_ARRAY(_tree_data[GOESInfo::AVG5M],GOESInfo::_nDATAFILEs[GOESInfo::AVG5M])
PRINT_POINTER_NAME_ARRAY(_tree_data[GOESInfo::SCIENCE],GOESInfo::_nDATAFILEs[GOESInfo::SCIENCE])
PRINT_POINTER_NAME_ARRAY(_tree_data[GOESInfo::STATUS],GOESInfo::_nDATAFILEs[GOESInfo::STATUS])
   return *this;
}
#endif

GOES::~GOES()
{
   _reset();
}

Bool_t GOES::LoadData(const Char_t *date, const Char_t *particles)
{
PRINT_FUNCTION()
PRINT_VARIABLE(date)
PRINT_VARIABLE(particles)
   size_t date_len = date != NULL ? strlen(date) : 0;
   size_t part_len = particles != NULL ? strlen(particles) : 0;

   if (date_len == 0)
   {
      if (part_len > 0)
      {
         cerr << " !!! Error: date is empty but particles is not; cannot load any particles with no date specified\n";

         return false;
      }

      if (_date != NULL && strlen(_date) > 0)
      {
         cerr << Form(" !!! Warning: the previous data '%s' will be deleted\n", _date);
         _reset();
      }

      return true;
   }
   else
   {
      if (_date != NULL && strncmp(_date, date, date_len))
      {
         _reset();
      }

      if (_set_date(date))
      {
         _parse_particles(particles);

         return _load_data();
      }
      else return false;
   }
}

void GOES::SetDatafilePath(const Char_t *path)
{
   snprintf(_datafile_path, _PATH_LENGTH, "%s", path);
}

const Char_t *GOES::GetDatafilePath() const
{
   return const_cast<const Char_t *>(_datafile_path);
}

void GOES::SetScriptPath(const Char_t *path)
{
   snprintf(_script_path, _PATH_LENGTH, "%s", path);
}

const Char_t *GOES::GetScriptPath() const
{
   return const_cast<const Char_t *>(_script_path);
}

const Char_t *GOES::GetDate() const
{
   return const_cast<const Char_t *>(_date);
}

const vector<Particle::Type> &GOES::GetParticles() const
{
   return _particles;
}

const vector<Particle::Type> &GOES::ParseParticles(const Char_t *particles)
{
   static vector<Particle::Type> vparts;

   size_t len = particles != NULL ? strlen(particles) : 0;

   if (len > 0)
   {
      TString parts(particles);
      TString tok;
      Ssiz_t from = 0;
      while (parts.Tokenize(tok, from, ","))
      {
         Particle::Type particle = Particle::FromSymbol(tok.Data());
         if (GOESInfo::iParticle(particle) == GOESInfo::nParticles)
         {
            cerr << Form(" !!! Warning: particle '%s' not recognized; skipping particle\n", tok.Data());
         }
         else if (find(vparts.begin(), vparts.end(), particle) == vparts.end())
         {
            vparts.push_back(particle);
         }
      }
   }
   else
   {
      vparts.clear();
      for (UShort_t iparticle = 0; iparticle < GOESInfo::nParticles; ++iparticle)
      {
         vparts.push_back(GOESInfo::Particle(iparticle));
      }
   }

   return vparts;
}

const vector<TimeInterval> &GOES::GetTimeIntervals() const
{
   return _timebins;
}

Bool_t GOES::SetTimeIntervals(const Char_t *intervals)
{
   return _lazy_parse_intervals(intervals);
}
void GOES::SetTimeIntervals(const vector<TimeInterval> &timebins)
{
   _timebins = timebins;
   _intervals = _set_string(DateTimeTools::TimeIntervalsToString(timebins));
}

TGraphAsymmErrors **GOES::GetDifferentialProtonFluxFromHEPAD(GOESInfo::DataSet dataset, const Char_t *intervals, Bool_t sideband_correction, Bool_t error_is_statistical, Bool_t use_corrected_geometrical_factor)
{
PRINT_FUNCTION()
PRINT_VARIABLE(dataset)
PRINT_VARIABLE(intervals)
PRINT_VARIABLE(sideband_correction)
PRINT_VARIABLE(error_is_statistical)
PRINT_VARIABLE(use_corrected_geometrical_factor)
   vector<UShort_t> bins;
   for (UShort_t ibin = 7; ibin < 10; ++ibin) bins.push_back(ibin);

   return GetEnergyDependence(dataset, GOESInfo::CORRECTED_FLUX, Particle::PROTON, bins, intervals, GOESInfo::HEPAD, sideband_correction, error_is_statistical, use_corrected_geometrical_factor);
}
TGraphAsymmErrors **GOES::GetDifferentialProtonFluxFromHEPAD(GOESInfo::DataSet dataset, Bool_t sideband_correction, Bool_t error_is_statistical, Bool_t use_corrected_geometrical_factor)
{
   return GetDifferentialProtonFluxFromHEPAD(dataset, _intervals, sideband_correction, error_is_statistical, use_corrected_geometrical_factor);
}

TGraphAsymmErrors **GOES::GetDifferentialProtonFluxFromEPEAD(GOESInfo::Detector detector, const Char_t *intervals, Bool_t error_is_statistical, Bool_t use_corrected_geometrical_factor)
{
PRINT_FUNCTION()
PRINT_VARIABLE(detector)
PRINT_VARIABLE(intervals)
PRINT_VARIABLE(error_is_statistical)
PRINT_VARIABLE(use_corrected_geometrical_factor)
   vector<UShort_t> bins;
   for (UShort_t ibin = 0; ibin < 6; ++ibin) bins.push_back(ibin);

   return GetEnergyDependence(GOESInfo::AVG5M, GOESInfo::CORRECTED_FLUX, Particle::PROTON, bins, intervals, detector, false, error_is_statistical, use_corrected_geometrical_factor);
}
TGraphAsymmErrors **GOES::GetDifferentialProtonFluxFromEPEAD(GOESInfo::Detector detector, Bool_t error_is_statistical, Bool_t use_corrected_geometrical_factor)
{
   return GetDifferentialProtonFluxFromEPEAD(detector, _intervals, error_is_statistical, use_corrected_geometrical_factor);
}

TGraphAsymmErrors **GOES::GetDifferentialProtonFluxFullRange(GOESInfo::Detector detector, const Char_t *intervals, Bool_t sideband_correction, Bool_t error_is_statistical, Bool_t use_corrected_geometrical_factor)
{
PRINT_FUNCTION()
PRINT_VARIABLE(detector)
PRINT_VARIABLE(intervals)
PRINT_VARIABLE(sideband_correction)
PRINT_VARIABLE(error_is_statistical)
PRINT_VARIABLE(use_corrected_geometrical_factor)
   vector<UShort_t> bins;
   for (UShort_t ibin = 0; ibin < 6; ++ibin) bins.push_back(ibin);
   for (UShort_t ibin = 7; ibin < 10; ++ibin) bins.push_back(ibin);

   return GetEnergyDependence(GOESInfo::AVG5M, GOESInfo::CORRECTED_FLUX, Particle::PROTON, bins, intervals, detector, sideband_correction, error_is_statistical, use_corrected_geometrical_factor);
}
TGraphAsymmErrors **GOES::GetDifferentialProtonFluxFullRange(GOESInfo::Detector detector, Bool_t sideband_correction, Bool_t error_is_statistical, Bool_t use_corrected_geometrical_factor)
{
   return GetDifferentialProtonFluxFullRange(detector, _intervals, sideband_correction, error_is_statistical, use_corrected_geometrical_factor);
}

TGraphAsymmErrors **GOES::GetDifferentialProtonFluxFromIntegralChannels(GOESInfo::Detector detector, const Char_t *intervals, Bool_t error_is_statistical)
{
PRINT_FUNCTION()
PRINT_VARIABLE(detector)
PRINT_VARIABLE(intervals)
PRINT_VARIABLE(error_is_statistical)
   Particle::Type particle      = Particle::PROTON;
   GOESInfo::DataSet dataset   = GOESInfo::AVG5M;
   GOESInfo::DataType datatype = GOESInfo::CORRECTED_FLUX;
   Bool_t sideband_correction = false;

   vector<UShort_t> bins;
   for (UShort_t ibin = 11; ibin < 18; ++ibin) bins.push_back(ibin);
   TGraphAsymmErrors **gae_integral_flux = GetEnergyDependence(dataset, datatype, particle, bins, intervals, detector, sideband_correction, error_is_statistical, true);

   bins.pop_back();
   UShort_t ntimebins = _timebins.size();
   UShort_t nbins     = bins.size();

   TGraphAsymmErrors **gae_differential_flux = new TGraphAsymmErrors *[ntimebins]();

   Char_t name[_STR_LENGTH];
   Bool_t fill = false;
   TGraphAsymmErrors *gae;
   gROOT->cd();
   for (UShort_t itimebin = 0; itimebin < ntimebins; ++itimebin)
   {
      _get_energygraph_name(name, dataset, datatype, particle, bins, _timebins[itimebin], detector, sideband_correction, error_is_statistical, true);
      strncat(name, "_diff", _STR_LENGTH);
//~ PRINT_VARIABLE(name)
      gae = (TGraphAsymmErrors *)gROOT->FindObject(name);
//~ PRINT_POINTER_NAME(gae)
      if (gae == NULL)
      {
         gae = new TGraphAsymmErrors(nbins);
         gae->SetName(name);
         gae->SetTitle(Form("%s - %s", DateTimeTools::UTCTimeToString(_timebins[itimebin].first, "%H:%M"), DateTimeTools::UTCTimeToString(_timebins[itimebin].second, "%H:%M")));
         gDirectory->Append(gae);
         fill = true;
      }
      gae_differential_flux[itimebin] = gae;
PRINT_POINTER_NAME(gae_differential_flux[itimebin])
   }
PRINT_VARIABLE(fill)
   if (fill)
   {
      for (UShort_t itimebin = 0; itimebin < ntimebins; ++itimebin)
      {
         for (UShort_t ibin = 0; ibin < nbins; ++ibin)
         {
            Double_t f1  = gae_integral_flux[itimebin]->GetY()[ibin];
            Double_t f2  = gae_integral_flux[itimebin]->GetY()[ibin + 1];
            Double_t ef1 = gae_integral_flux[itimebin]->GetErrorY(ibin);
            Double_t ef2 = gae_integral_flux[itimebin]->GetErrorY(ibin + 1);

            Double_t range[2] = { GOESInfo::BinRange(particle, bins[ibin])[0], GOESInfo::BinRange(particle, bins[ibin + 1])[0] };

            Double_t diff_flux = (f1 - f2) / (range[1] - range[0]);
            Double_t ef        = diff_flux * TMath::Sqrt(ef1*ef1 + ef2*ef2) / (f1 - f2);

            Double_t x   = TMath::Sqrt(range[0]*range[1]);
            Double_t exl = x - range[0];
            Double_t exu = range[1] - x;

            gae_differential_flux[itimebin]->SetPoint(ibin, x, diff_flux);
            gae_differential_flux[itimebin]->SetPointError(ibin, exl, exu, ef, ef);
         }
      }
   }

   return gae_differential_flux;
}
TGraphAsymmErrors **GOES::GetDifferentialProtonFluxFromIntegralChannels(GOESInfo::Detector detector, Bool_t error_is_statistical)
{
   return GetDifferentialProtonFluxFromIntegralChannels(detector, _intervals, error_is_statistical);
}

TGraphAsymmErrors **GOES::GetDifferentialProtonFluxFromIntegralChannelsFullRange(GOESInfo::Detector detector, const Char_t *intervals, Bool_t sideband_correction, Bool_t error_is_statistical, Bool_t use_corrected_geometrical_factor)
{
PRINT_FUNCTION()
PRINT_VARIABLE(detector)
PRINT_VARIABLE(intervals)
PRINT_VARIABLE(sideband_correction)
PRINT_VARIABLE(error_is_statistical)
PRINT_VARIABLE(use_corrected_geometrical_factor)
   Particle::Type particle = Particle::PROTON;
   GOESInfo::DataSet dataset = GOESInfo::AVG5M;
   GOESInfo::DataType datatype = GOESInfo::CORRECTED_FLUX;

   TGraphAsymmErrors **gae_diff_flux_from_int = GetDifferentialProtonFluxFromIntegralChannels(detector, intervals, error_is_statistical);
   TGraphAsymmErrors **gae_hepad_flux = GetDifferentialProtonFluxFromHEPAD(GOESInfo::AVG5M, intervals, sideband_correction, error_is_statistical, use_corrected_geometrical_factor);

   vector<UShort_t> bins;
   for (UShort_t ibin = 11; ibin < 17; ++ibin) bins.push_back(ibin);
   for (UShort_t ibin = 7; ibin < 10; ++ibin) bins.push_back(ibin);

   UShort_t ntimebins = _timebins.size();

   TGraphAsymmErrors **gae_diff_flux_full_range = new TGraphAsymmErrors *[ntimebins]();

   Char_t name[_STR_LENGTH];
   Bool_t fill = false;
   TGraphAsymmErrors *gae;
   gROOT->cd();
   for (UShort_t itimebin = 0; itimebin < ntimebins; ++itimebin)
   {
      _get_energygraph_name(name, dataset, datatype, particle, bins, _timebins[itimebin], detector, sideband_correction, error_is_statistical, use_corrected_geometrical_factor);
      strncat(name, "_diff", _STR_LENGTH);
//~ PRINT_VARIABLE(name)
      gae = (TGraphAsymmErrors *)gROOT->FindObject(name);
//~ PRINT_POINTER_NAME(gae)
      if (gae == NULL)
      {
         gae = new TGraphAsymmErrors(0);
         gae->SetName(name);
         gae->SetTitle(Form("%s - %s", DateTimeTools::UTCTimeToString(_timebins[itimebin].first, "%H:%M"), DateTimeTools::UTCTimeToString(_timebins[itimebin].second, "%H:%M")));
         gDirectory->Append(gae);
         fill = true;
      }
      gae_diff_flux_full_range[itimebin] = gae;
PRINT_POINTER_NAME(gae_diff_flux_full_range[itimebin])
   }
PRINT_VARIABLE(fill)
   if (fill)
   {
      for (UShort_t itimebin = 0; itimebin < ntimebins; ++itimebin)
      {
         HistTools::Append(gae_diff_flux_full_range[itimebin], gae_diff_flux_from_int[itimebin]);
         HistTools::Append(gae_diff_flux_full_range[itimebin], gae_hepad_flux[itimebin]);
      }
   }

   return gae_diff_flux_full_range;
}
TGraphAsymmErrors **GOES::GetDifferentialProtonFluxFromIntegralChannelsFullRange(GOESInfo::Detector detector, Bool_t sideband_correction, Bool_t error_is_statistical, Bool_t use_corrected_geometrical_factor)
{
   return GetDifferentialProtonFluxFromIntegralChannelsFullRange(detector, _intervals, sideband_correction, error_is_statistical, use_corrected_geometrical_factor);
}

TGraphAsymmErrors **GOES::GetDifferentialHeliumFluxFromHEPAD(GOESInfo::DataSet dataset, const Char_t *intervals, Bool_t error_is_statistical, Bool_t use_corrected_geometrical_factor)
{
PRINT_FUNCTION()
PRINT_VARIABLE(dataset)
PRINT_VARIABLE(intervals)
PRINT_VARIABLE(error_is_statistical)
PRINT_VARIABLE(use_corrected_geometrical_factor)
   vector<UShort_t> bins;
   for (UShort_t ibin = 6; ibin < 7; ++ibin) bins.push_back(ibin);

   return GetEnergyDependence(dataset, GOESInfo::CORRECTED_FLUX, Particle::HELIUM4, bins, intervals, GOESInfo::HEPAD, false, error_is_statistical, use_corrected_geometrical_factor);
}
TGraphAsymmErrors **GOES::GetDifferentialHeliumFluxFromHEPAD(GOESInfo::DataSet dataset, Bool_t error_is_statistical, Bool_t use_corrected_geometrical_factor)
{
   return GetDifferentialHeliumFluxFromHEPAD(dataset, _intervals, error_is_statistical, use_corrected_geometrical_factor);
}

TGraphAsymmErrors **GOES::GetDifferentialHeliumFluxFromEPEAD(GOESInfo::DataSet dataset, GOESInfo::Detector detector, const Char_t *intervals, Bool_t error_is_statistical, Bool_t use_corrected_geometrical_factor)
{
PRINT_FUNCTION()
PRINT_VARIABLE(dataset)
PRINT_VARIABLE(detector)
PRINT_VARIABLE(intervals)
PRINT_VARIABLE(error_is_statistical)
PRINT_VARIABLE(use_corrected_geometrical_factor)
   vector<UShort_t> bins;
   for (UShort_t ibin = 0; ibin < 6; ++ibin) bins.push_back(ibin);

   return GetEnergyDependence(dataset, GOESInfo::CORRECTED_FLUX, Particle::HELIUM4, bins, intervals, detector, false, error_is_statistical, use_corrected_geometrical_factor);
}
TGraphAsymmErrors **GOES::GetDifferentialHeliumFluxFromEPEAD(GOESInfo::DataSet dataset, GOESInfo::Detector detector, Bool_t error_is_statistical, Bool_t use_corrected_geometrical_factor)
{
   return GetDifferentialHeliumFluxFromEPEAD(dataset, detector, _intervals, error_is_statistical, use_corrected_geometrical_factor);
}

TGraphAsymmErrors **GOES::GetDifferentialHeliumFluxFullRange(GOESInfo::DataSet dataset, GOESInfo::Detector detector, const Char_t *intervals, Bool_t error_is_statistical, Bool_t use_corrected_geometrical_factor)
{
PRINT_FUNCTION()
PRINT_VARIABLE(dataset)
PRINT_VARIABLE(detector)
PRINT_VARIABLE(intervals)
PRINT_VARIABLE(error_is_statistical)
PRINT_VARIABLE(use_corrected_geometrical_factor)
   vector<UShort_t> bins;
   for (UShort_t ibin = 0; ibin < 7; ++ibin) bins.push_back(ibin);

   return GetEnergyDependence(dataset, GOESInfo::CORRECTED_FLUX, Particle::HELIUM4, bins, intervals, detector, false, error_is_statistical, use_corrected_geometrical_factor);
}
TGraphAsymmErrors **GOES::GetDifferentialHeliumFluxFullRange(GOESInfo::DataSet dataset, GOESInfo::Detector detector, Bool_t error_is_statistical, Bool_t use_corrected_geometrical_factor)
{
   return GetDifferentialHeliumFluxFullRange(dataset, detector, _intervals, error_is_statistical, use_corrected_geometrical_factor);
}

TGraphErrors *GOES::GetTimeDependence(GOESInfo::DataSet dataset, GOESInfo::DataType datatype, Particle::Type particle, UShort_t ibin, GOESInfo::Detector detector, Bool_t exclude_bad_quality, Bool_t sideband_correction,
   Bool_t use_corrected_geometrical_factor)
{
PRINT_FUNCTION()
PRINT_VARIABLE(dataset)
PRINT_VARIABLE(datatype)
PRINT_VARIABLE(particle)
PRINT_VARIABLE(ibin)
PRINT_VARIABLE(detector)
PRINT_VARIABLE(exclude_bad_quality)
PRINT_VARIABLE(sideband_correction)
PRINT_VARIABLE(use_corrected_geometrical_factor)
   if (_date == NULL || strlen(_date) == 0)
   {
      std::cerr << " !!! Error: no data is loaded: use LoadData first\n" << std::flush;
      return NULL;
   }
   else if (find(_particles.begin(), _particles.end(), particle) == _particles.end())
   {
      std::cerr << Form(" !!! Error: %s not loaded: use LoadData first\n", Particle::Name[particle]) << std::flush;
      return NULL;
   }

   if (dataset >= GOESInfo::nDataSets || datatype >= GOESInfo::nDataTypes || !GOESInfo::_is_associated(particle) || detector >= GOESInfo::nDetectors || ibin >= GOESInfo::nBins(particle, dataset))
   {
      std::cerr << Form(" !!! Error: particle=%d, datatype=%d/%d, detector=%d/%d, dataset=%d/%d or ibin=%d/%d out of range\n",
         particle, datatype, GOESInfo::nDataTypes, detector, GOESInfo::nDetectors, dataset, GOESInfo::nDataSets, ibin, GOESInfo::nBins(particle, dataset)) << std::flush;
      return NULL;
   }

   if (!GOESInfo::_available_channel[GOESInfo::iParticle(particle)][dataset][datatype][ibin] && !(dataset == GOESInfo::STATUS && datatype == GOESInfo::YAW_FLIP))
   {
      std::cerr << Form(" !!! Error: the combination particle='%s', datatype='%s', detector='%s' and bin=%u is not valid for the dataset '%s'\n",
         Particle::Name[particle], GOESInfo::_datatype_name[datatype], GOESInfo::_detector_name[detector], ibin, GOESInfo::_dataset_name[dataset]) << std::flush;
      return NULL;
   }
   else
   {
      return _get_graph_vs_time(dataset, datatype, particle, ibin, detector, exclude_bad_quality, sideband_correction, use_corrected_geometrical_factor);
   }
}

TGraphAsymmErrors **GOES::GetEnergyDependence(GOESInfo::DataSet dataset, GOESInfo::DataType datatype, Particle::Type particle, vector<UShort_t> &bins, const Char_t *intervals, GOESInfo::Detector detector, Bool_t sideband_correction,
   Bool_t error_is_statistical, Bool_t use_corrected_geometrical_factor)
{
PRINT_FUNCTION()
PRINT_VARIABLE(dataset)
PRINT_VARIABLE(datatype)
PRINT_VARIABLE(particle)
PRINT_VARIABLE(bins)
PRINT_VARIABLE(intervals)
PRINT_VARIABLE(detector)
PRINT_VARIABLE(sideband_correction)
PRINT_VARIABLE(error_is_statistical)
PRINT_VARIABLE(use_corrected_geometrical_factor)
   if (_date == NULL || strlen(_date) == 0)
   {
      std::cerr << " !!! Error: no data is loaded: use LoadData first\n" << std::flush;
      return NULL;
   }
   else if (find(_particles.begin(), _particles.end(), particle) == _particles.end())
   {
      std::cerr << Form(" !!! Error: %s not loaded: use LoadData first\n", Particle::Name[particle]) << std::flush;
      return NULL;
   }
   else if (!_lazy_parse_intervals(intervals)) return NULL;
PRINT_VARIABLE(_timebins)
   if (dataset >= GOESInfo::nDataSets || datatype >= GOESInfo::nDataTypes || !GOESInfo::_is_associated(particle) || detector >= GOESInfo::nDetectors)
   {
      std::cerr << Form(" !!! Error: particle=%d, datatype=%d/%d, detector=%d/%d or dataset=%d/%d out of range\n",
         particle, datatype, GOESInfo::nDataTypes, detector, GOESInfo::nDetectors, dataset, GOESInfo::nDataSets) << endl;
      return NULL;
   }

   for (UShort_t ibin = 0; ibin < bins.size(); ++ibin)
   {
      if (!GOESInfo::_available_channel[GOESInfo::iParticle(particle)][dataset][datatype][bins[ibin]])
      {
         std::cerr << Form(" !!! Error: the combination particle='%s', datatype='%s', detector='%s' and ibin=%d is not valid for the dataset '%s'\n",
            Particle::Name[particle], GOESInfo::_datatype_name[datatype], GOESInfo::_detector_name[detector], bins[ibin], GOESInfo::_dataset_name[dataset]) << endl;
         return NULL;
      }
   }

   return _get_graph_vs_energy(dataset, datatype, particle, bins, detector, sideband_correction, error_is_statistical, use_corrected_geometrical_factor);
}
TGraphAsymmErrors **GOES::GetEnergyDependence(GOESInfo::DataSet dataset, GOESInfo::DataType datatype, Particle::Type particle, vector<UShort_t> &bins, GOESInfo::Detector detector, Bool_t sideband_correction,
   Bool_t error_is_statistical, Bool_t use_corrected_geometrical_factor)
{
   return GetEnergyDependence(dataset, datatype, particle, bins, _intervals, detector, sideband_correction, error_is_statistical, use_corrected_geometrical_factor);
}

void GOES::_init(const Char_t *date, const Char_t *particles)
{
PRINT_FUNCTION()
PRINT_VARIABLE(date)
PRINT_VARIABLE(particles)
   SetDatafilePath(GOES_DATA_PATH);
   SetScriptPath(SCRIPT_PATH);
   LoadData(date, particles);
PRINT_STRING(Form("[%p] GOES::_init - Internal status", this))
PRINT_VARIABLE(_datafile_path)
PRINT_VARIABLE(_script_path)
PRINT_VARIABLE(_date)
PRINT_VARIABLE(_particles)
PRINT_VARIABLE(_intervals)
PRINT_VARIABLE(_timebins)
PRINT_POINTER_NAME_ARRAY(_file_data[GOESInfo::FULL],GOESInfo::_nDATAFILEs[GOESInfo::FULL])
PRINT_POINTER_NAME_ARRAY(_file_data[GOESInfo::AVG1M],GOESInfo::_nDATAFILEs[GOESInfo::AVG1M])
PRINT_POINTER_NAME_ARRAY(_file_data[GOESInfo::AVG5M],GOESInfo::_nDATAFILEs[GOESInfo::AVG5M])
PRINT_POINTER_NAME_ARRAY(_file_data[GOESInfo::SCIENCE],GOESInfo::_nDATAFILEs[GOESInfo::SCIENCE])
PRINT_POINTER_NAME_ARRAY(_file_data[GOESInfo::STATUS],GOESInfo::_nDATAFILEs[GOESInfo::STATUS])
PRINT_POINTER_NAME_ARRAY(_tree_data[GOESInfo::FULL],GOESInfo::_nDATAFILEs[GOESInfo::FULL])
PRINT_POINTER_NAME_ARRAY(_tree_data[GOESInfo::AVG1M],GOESInfo::_nDATAFILEs[GOESInfo::AVG1M])
PRINT_POINTER_NAME_ARRAY(_tree_data[GOESInfo::AVG5M],GOESInfo::_nDATAFILEs[GOESInfo::AVG5M])
PRINT_POINTER_NAME_ARRAY(_tree_data[GOESInfo::SCIENCE],GOESInfo::_nDATAFILEs[GOESInfo::SCIENCE])
PRINT_POINTER_NAME_ARRAY(_tree_data[GOESInfo::STATUS],GOESInfo::_nDATAFILEs[GOESInfo::STATUS])
}

void GOES::_reset()
{
PRINT_FUNCTION()
   if (_date != NULL)
   {
      delete _date;
      _date = NULL;
   }

   if (_intervals != NULL)
   {
      delete _intervals;
      _intervals = NULL;
   }

   _particles.clear();
   _timebins.clear();

   for (UShort_t idataset = 0; idataset < GOESInfo::nDataSets; ++idataset)
   {
      for (UShort_t ifile = 0; ifile < GOESInfo::_nDATAFILEs[idataset]; ++ifile)
      {
         _tree_data[idataset][ifile] = NULL;

         if (_file_data[idataset][ifile] != NULL)
         {
            delete _file_data[idataset][ifile];
            _file_data[idataset][ifile] = NULL;
         }
      }
   }
}

Bool_t GOES::_set_date(const Char_t *date)
{
PRINT_FUNCTION()
PRINT_VARIABLE(date)
   size_t date_len = strlen(date);
   size_t good_len = strspn(date, "0123456789");
   if (date_len != 8 || date_len != good_len)
   {
      cerr << Form(" !!! Error: date '%s' has a wrong format\n", date);

      return false;
   }
   else
   {
      _date = new Char_t[date_len + 1];
      snprintf(_date, date_len + 1, "%s", date);

      return true;
   }
}

Char_t *GOES::_set_string(const Char_t *str)
{
PRINT_FUNCTION()
PRINT_POINTER(str)
   Char_t *_string = NULL;
   size_t len = str != NULL ? strlen(str) : 0;
   if (len > 0)
   {
PRINT_VARIABLE(str)
      _string = new Char_t[len + 1];
      snprintf(_string, len + 1, "%s", str);
   }

   return _string;
}

void GOES::_parse_particles(const Char_t *particles)
{
PRINT_FUNCTION()
PRINT_VARIABLE(particles)
   size_t len = particles != NULL ? strlen(particles) : 0;

   if (len > 0)
   {
      TString parts(particles);
      TString tok;
      Ssiz_t from = 0;
      while (parts.Tokenize(tok, from, ","))
      {
         Particle::Type particle = Particle::FromSymbol(tok.Data());
         if (GOESInfo::iParticle(particle) == GOESInfo::nParticles)
         {
            cerr << Form(" !!! Warning: particle '%s' not recognized; skipping particle\n", tok.Data());
         }
         else if (find(_particles.begin(), _particles.end(), particle) == _particles.end())
         {
            _particles.push_back(particle);
         }
      }
   }
   else
   {
      _particles.clear();
      for (UShort_t iparticle = 0; iparticle < GOESInfo::nParticles; ++iparticle)
      {
         _particles.push_back(GOESInfo::Particle(iparticle));
      }
   }
PRINT_VARIABLE(_particles)
}

Bool_t GOES::_load_data()
{
PRINT_FUNCTION()
   Bool_t res = true;

   Char_t path[_PATH_LENGTH];
   snprintf(path, _PATH_LENGTH, "%s/%s", _datafile_path, _date);

   for (UShort_t idataset = 0; idataset < GOESInfo::nDataSets; ++idataset)
   {
      for (UShort_t ifile = 0; ifile < GOESInfo::_nDATAFILEs[idataset]; ++ifile)
      {
         // check if the current data file need to be loaded, given the selected particles
         // if the data file is not associated to any particle, load it anyway
         Bool_t load = false;
         if (GOESInfo::_nassociated_particles(idataset, ifile) == 0)
         {
            load = true;
         }
         else
         {
            for (UShort_t iparticle = 0; iparticle < _particles.size(); ++iparticle)
            {
               if (GOESInfo::_is_associated(idataset, ifile, _particles[iparticle]))
               {
                  load = true;
                  break;
               }
            }
         }
PRINT_STRING(Form("dataset=%u, file=%u, load=%u", idataset, ifile, load))
         if (load)
         {
            TString filename = GOESInfo::_DATAFILE_NAME[idataset][ifile];
            Int_t exit_code = 0;
            if (gSystem->FindFile(path, filename) == NULL)
            {
               Char_t cmd[_PATH_LENGTH];
               TString particles;
               for (UShort_t iparticle = 0; iparticle < _particles.size(); ++iparticle)
               {
                  if (iparticle > 0) particles += ',';
                  particles += Particle::Symbol[_particles[iparticle]];
               }
               snprintf(cmd, _PATH_LENGTH, "%s/get_goes_data --date=%s --particle=%s -l=%s", _script_path, _date, particles.Data(), _datafile_path);
               exit_code = gSystem->Exec(cmd);
            }

            if (!exit_code) res &= _load_datafile(idataset, ifile);
         }
      }
   }

   return res;
}

Bool_t GOES::_load_datafile(UShort_t idataset, UShort_t ifile)
{
PRINT_FUNCTION()
PRINT_VARIABLE(idataset)
PRINT_VARIABLE(ifile)
   if (idataset >= GOESInfo::nDataSets || ifile >= GOESInfo::_nMAX_DATAFILEs || ifile >= GOESInfo::_nDATAFILEs[idataset])
   {
      cerr << Form(" !!! Error (this should never happen): the requested datafile '%u/%u' does not exists; skipping datafile\n", idataset, ifile);

      return false;
   }

   static Char_t datafile_path[_PATH_LENGTH];
   static Char_t tree_name[_STR_LENGTH];

   if (_file_data[idataset][ifile] == NULL)
   {
      if (strlen(_datafile_path) + strlen(GOESInfo::_DATAFILE_NAME[idataset][ifile]) + 11 > _PATH_LENGTH) // 11 = strlen(date) + 2*'/' + '\0'; strlen(date) = 8
      {
         cerr << Form(" !!! Error: the datafile path '%s/%s/%s' is longer than _PATH_LENGTH=%u; skip datafile\n", _datafile_path, _date, GOESInfo::_DATAFILE_NAME[idataset][ifile], _PATH_LENGTH);

         return false;
      }
      else
      {
         snprintf(datafile_path, _PATH_LENGTH, "%s/%s/%s", _datafile_path, _date, GOESInfo::_DATAFILE_NAME[idataset][ifile]);
         TFile *datafile = new TFile(datafile_path);
         if (datafile == NULL || datafile->IsZombie() || !datafile->IsOpen())
         {
            cerr << Form(" !!! Error: failed to open the datafile '%s'; skip datafile\n", datafile_path);

            return false;
         }
         else
         {
            _file_data[idataset][ifile] = datafile;
//~ PRINT_POINTER(_file_data[idataset][ifile])
         }
      }
   }

   if (_tree_data[idataset][ifile] == NULL)
   {
      if (_file_data[idataset][ifile] == NULL)
      {
         cerr << Form(" !!! Error (this should never happen): the datafile '%s/%s/%s' is not open yet; skipping datafile\n", _datafile_path, _date, GOESInfo::_DATAFILE_NAME[idataset][ifile]);

         return false;
      }
      else
      {
         snprintf(tree_name, _STR_LENGTH, "tree");
         TTree *datatree;
         _file_data[idataset][ifile]->GetObject(tree_name, datatree);
         if (datatree == NULL)
         {
            cerr << Form(" !!! Error: no tree with name '%s' found in the file '%s'; skipping datafile\n", tree_name, _file_data[idataset][ifile]->GetName());

            return false;
         }
         else
         {
            _tree_data[idataset][ifile] = datatree;
//~ PRINT_POINTER(_tree_data[idataset][ifile])
         }
      }
   }

   return true;
}

Bool_t GOES::_lazy_parse_intervals(const Char_t *intervals)
{
PRINT_FUNCTION()
PRINT_VARIABLE(intervals)
   if (_intervals == NULL || strncmp(_intervals, intervals, strlen(_intervals)))
   {
      _timebins.clear();

      if (!DateTimeTools::ParseTimeIntervals(_date, intervals, _timebins)) return false;

      _intervals = _set_string(intervals);
   }

   return true;
}

Bool_t GOES::_get_timegraph_name(Char_t *name, GOESInfo::DataSet dataset, GOESInfo::DataType datatype, Particle::Type particle, UShort_t ibin, GOESInfo::Detector detector, Bool_t exclude_bad_quality, Bool_t sideband_correction,
   Bool_t use_corrected_geometrical_factor)
{
   Char_t suffix[_STR_LENGTH];
   snprintf(suffix, _STR_LENGTH, "%s%s", exclude_bad_quality ? "_nbq" : "", use_corrected_geometrical_factor ? "_ngf" : "_ogf");
   UShort_t bin = ibin + 1;

   if (particle == Particle::PROTON && (datatype == GOESInfo::UNCORRECTED_FLUX || datatype == GOESInfo::CORRECTED_FLUX) && (ibin == 7 || ibin == 8))
   {
      snprintf(name, _STR_LENGTH, "g_time_%s_GOES13_%s_%s_%c%02u_%s%s%s", _date, Particle::Symbol[particle], GOESInfo::_dataset_name[dataset], GOESInfo::_detector_symb[detector], bin, GOESInfo::_datatype_abbreviation[datatype],
         (sideband_correction) ? "_sbc" : "", suffix);
   }
   else if (particle == Particle::PROTON || particle == Particle::HELIUM4)
   {
      snprintf(name, _STR_LENGTH, "g_time_%s_GOES13_%s_%s_%c%02u_%s%s", _date, Particle::Symbol[particle], GOESInfo::_dataset_name[dataset], GOESInfo::_detector_symb[detector], bin, GOESInfo::_datatype_abbreviation[datatype], suffix);
   }
   else
   {
      std::cerr << " !!! Error: _get_timegraph_name not yet implemented\n" << std::flush;
      return false;
   }

   return true;
}

Bool_t GOES::_get_timegraph_title(Char_t *title, GOESInfo::DataSet dataset, GOESInfo::DataType datatype, Particle::Type particle, UShort_t ibin, GOESInfo::Detector detector, Bool_t exclude_bad_quality, Bool_t sideband_correction,
   Bool_t use_corrected_geometrical_factor)
{
   Char_t avg_time[_STR_LENGTH];
   Double_t sec = GOESInfo::BinTime(particle, dataset, ibin);
   if (sec < 60) snprintf(avg_time, _STR_LENGTH, "%.1fs", sec);
   else snprintf(avg_time, _STR_LENGTH, "%.0fm", sec / 60.);

   Char_t suffix[_STR_LENGTH];
   snprintf(suffix, _STR_LENGTH, "(");
   if (datatype != GOESInfo::QUALITY)
   {
      if (exclude_bad_quality)
      {
         strcat(suffix, "No bad qual.");
      }
      else if (datatype != GOESInfo::QUALITY)
      {
         strcat(suffix, "All qual.");
      }
   }
   if (datatype == GOESInfo::UNCORRECTED_FLUX || datatype == GOESInfo::CORRECTED_FLUX)
   {
      if (use_corrected_geometrical_factor)
      {
         strcat(suffix, ", Corr. geom. factor");
      }
      else
      {
         strcat(suffix, ", Wrong geom. factor");
      }

      if (particle == Particle::PROTON && (ibin == 7 || ibin == 8))
      {
         if (sideband_correction)
         {
            strcat(suffix, ", Side-band corr.");
         }
         else
         {
            strcat(suffix, ", No side-band corr.");
         }
      }
   }
   snprintf(suffix, _STR_LENGTH, ") ");
   if (strlen(suffix) <= 3) snprintf(suffix, _STR_LENGTH, "%s", "");

   if (particle == Particle::PROTON || particle == Particle::HELIUM4)
   {
      snprintf(title, _STR_LENGTH, "%s, GOES13-%s, %s (%s) - %s %s/ %s, %s", DateTimeTools::NormalizeDate(_date, "%Y%m%d", "%d/%m/%Y"),
         GOESInfo::DetectorName(detector), Particle::Name[particle], GOESInfo::DatasetName(dataset), GOESInfo::DatatypeTitle(datatype), suffix, avg_time,
         GOESInfo::BinRangeName(particle, ibin));
   }
   else
   {
      std::cerr << " !!! Error: _get_timegraph_title not yet implemented\n" << std::flush;
      return false;
   }

   return true;
}

Bool_t GOES::_get_energygraph_name(Char_t *name, GOESInfo::DataSet dataset, GOESInfo::DataType datatype, Particle::Type particle, vector<UShort_t> &bins, TimeInterval &interval, GOESInfo::Detector detector, Bool_t sideband_correction,
   Bool_t error_is_statistical, Bool_t use_corrected_geometrical_factor)
{
   Char_t suffix[_STR_LENGTH];
   snprintf(suffix, _STR_LENGTH, "%s%s_%s%s", DateTimeTools::UTCTimeToString(interval.first, "%H%M%S"), DateTimeTools::UTCTimeToString(interval.second, "%H%M%S"), error_is_statistical ? "staterr" : "disp",
      use_corrected_geometrical_factor ? "_ngf" : "_ogf");

   if (particle == Particle::PROTON && (datatype == GOESInfo::UNCORRECTED_FLUX || datatype == GOESInfo::CORRECTED_FLUX) && (find(bins.begin(), bins.end(), 7) != bins.end() || find(bins.begin(), bins.end(), 8) != bins.end()))
   {
      snprintf(name, _STR_LENGTH, "g_ene_%s_GOES13_%s_%s_%c%02u%02u_%s%s_%s", _date, Particle::Symbol[particle], GOESInfo::_dataset_name[dataset], GOESInfo::_detector_symb[detector], bins[0], bins[bins.size()-1],
         GOESInfo::_datatype_abbreviation[datatype], (sideband_correction) ? "_sbc" : "", suffix);
   }
   else if (particle == Particle::PROTON || particle == Particle::HELIUM4)
   {
      snprintf(name, _STR_LENGTH, "g_ene_%s_GOES13_%s_%s_%c%02u%02u_%s_%s", _date, Particle::Symbol[particle], GOESInfo::_dataset_name[dataset], GOESInfo::_detector_symb[detector], bins[0], bins[bins.size()-1],
         GOESInfo::_datatype_abbreviation[datatype], suffix);
   }
   else
   {
      std::cerr << " !!! Error: _get_energygraph_name not yet implemented\n" << std::flush;
      return false;
   }

   return true;
}

Bool_t GOES::_get_energygraph_title(Char_t *title, GOESInfo::DataSet dataset, GOESInfo::DataType datatype, Particle::Type particle, vector<UShort_t> &bins, TimeInterval &interval, GOESInfo::Detector detector, Bool_t sideband_correction,
   Bool_t error_is_statistical, Bool_t use_corrected_geometrical_factor)
{
   Char_t suffix[_STR_LENGTH];
   snprintf(suffix, _STR_LENGTH, "(");
   if (datatype != GOESInfo::QUALITY)
   {
      strcat(suffix, "No bad qual.");
   }
   if (datatype == GOESInfo::UNCORRECTED_FLUX || datatype == GOESInfo::CORRECTED_FLUX)
   {
      if (use_corrected_geometrical_factor)
      {
         strcat(suffix, ", Corr. geom. factor");
      }
      else
      {
         strcat(suffix, ", Wrong geom. factor");
      }

      if (particle == Particle::PROTON && (find(bins.begin(), bins.end(), 7) != bins.end() || find(bins.begin(), bins.end(), 8) != bins.end()))
      {
         if (sideband_correction)
         {
            strcat(suffix, ", Side-band corr.");
         }
         else
         {
            strcat(suffix, ", No side-band corr.");
         }
      }
   }
   if (datatype == GOESInfo::UNCORRECTED_FLUX || datatype == GOESInfo::CORRECTED_FLUX || datatype == GOESInfo::UNCORRECTED_RATE || datatype == GOESInfo::CORRECTED_RATE)
   {
      if (error_is_statistical)
      {
         strcat(suffix, ", Stat. err.");
      }
      else
      {
         strcat(suffix, ", Std. dev.");
      }
   }
   snprintf(suffix, _STR_LENGTH, ") ");
   if (strlen(suffix) <= 3) snprintf(suffix, _STR_LENGTH, "%s", "");

   if (particle == Particle::PROTON || particle == Particle::HELIUM4)
   {
      snprintf(title, _STR_LENGTH, "%s, GOES13-%s, %s (%s) - %s%s, %s-%s", DateTimeTools::NormalizeDate(_date, "%Y%m%d", "%d/%m/%Y"),
         GOESInfo::_detector_name[detector], Particle::Name[particle], GOESInfo::DatasetName(dataset), GOESInfo::DatatypeTitle(datatype),
            suffix, DateTimeTools::UTCTimeToString(interval.first, "%H:%M"), DateTimeTools::UTCTimeToString(interval.second, "%H:%M"));
   }
   else
   {
      std::cerr << " !!! Error: _get_energygraph_title not yet implemented\n" << std::flush;
      return false;
   }

   return true;
}

TGraphErrors *GOES::_get_graph_vs_time(GOESInfo::DataSet dataset, GOESInfo::DataType datatype, Particle::Type particle, UShort_t ibin, GOESInfo::Detector detector, Bool_t exclude_bad_quality, Bool_t sideband_correction,
   Bool_t use_corrected_geometrical_factor)
{
PRINT_FUNCTION()
PRINT_VARIABLE(dataset)
PRINT_VARIABLE(datatype)
PRINT_VARIABLE(particle)
PRINT_VARIABLE(ibin)
PRINT_VARIABLE(detector)
PRINT_VARIABLE(exclude_bad_quality)
PRINT_VARIABLE(sideband_correction)
PRINT_VARIABLE(use_corrected_geometrical_factor)
   TGraphErrors *ge = NULL;

   if (dataset == GOESInfo::STATUS && datatype == GOESInfo::YAW_FLIP)
   {
      ge = _get_time_graph_yawflip();
   }
   else
   {
      switch (particle)
      {
         case Particle::HELIUM4:
            ge = _get_time_graph_helium(dataset, datatype, ibin, detector, exclude_bad_quality, use_corrected_geometrical_factor);
            break;
         case Particle::ELECTRON:
            ge = NULL;
            std::cerr << " !!! Error: _get_time_graph_electron: method not yet implemented!\n" << std::flush;
            break;
         case Particle::PROTON:
            ge = _get_time_graph_proton(dataset, datatype, ibin, detector, exclude_bad_quality, sideband_correction, use_corrected_geometrical_factor);
            break;
         default:
            ge = NULL;
            std::cerr << " !!! Error: particle not supported!\n" << std::flush;
      }
   }

   return ge;
}

TGraphAsymmErrors **GOES::_get_graph_vs_energy(GOESInfo::DataSet dataset, GOESInfo::DataType datatype, Particle::Type particle, vector<UShort_t> &bins, GOESInfo::Detector detector, Bool_t sideband_correction, Bool_t error_is_statistical,
   Bool_t use_corrected_geometrical_factor)
{
PRINT_FUNCTION()
PRINT_VARIABLE(dataset)
PRINT_VARIABLE(datatype)
PRINT_VARIABLE(particle)
PRINT_VARIABLE(bins)
PRINT_VARIABLE(detector)
PRINT_VARIABLE(sideband_correction)
PRINT_VARIABLE(error_is_statistical)
PRINT_VARIABLE(use_corrected_geometrical_factor)
   UShort_t nbins = bins.size();
   UShort_t ntimebins = _timebins.size();

   TGraphErrors *ge = NULL;
   TGraphErrors **ge_time = new TGraphErrors *[nbins]();

   Char_t name[_STR_LENGTH];
   Char_t title[_STR_LENGTH];
   for (UShort_t ibin = 0; ibin < bins.size(); ++ibin)
   {
      UShort_t jbin = bins[ibin];

      _get_timegraph_name(name, dataset, datatype, particle, jbin, detector, true, sideband_correction, use_corrected_geometrical_factor);
      ge = (TGraphErrors *)gROOT->FindObject(name);
      if (ge == NULL)
      {
         if (particle == Particle::HELIUM4) ge = _get_time_graph_helium(dataset, datatype, jbin, detector, true, use_corrected_geometrical_factor);
         else if (particle == Particle::PROTON) ge = _get_time_graph_proton(dataset, datatype, jbin, detector, true, sideband_correction, use_corrected_geometrical_factor);
         else if (particle == Particle::ELECTRON) std::cerr << " !!! Error: _get_graph_vs_energy not yet implemented for electrons\n" << std::flush;
      }
      ge_time[ibin] = ge;
   }

   TGraphAsymmErrors *gae       = NULL;
   TGraphAsymmErrors **gae_time = new TGraphAsymmErrors *[ntimebins]();

   Bool_t fill = false;
   gROOT->cd();
   for (UShort_t itimebin = 0; itimebin < ntimebins; ++itimebin)
   {
      _get_energygraph_name(name, dataset, datatype, particle, bins, _timebins[itimebin], detector, sideband_correction, error_is_statistical, use_corrected_geometrical_factor);
      gae = (TGraphAsymmErrors *)gROOT->FindObject(name);
      if (gae == NULL)
      {
         _get_energygraph_title(title, dataset, datatype, particle, bins, _timebins[itimebin], detector, sideband_correction, error_is_statistical, use_corrected_geometrical_factor);
         gae = new TGraphAsymmErrors(nbins);
         gae->SetName(name);
         gae->SetTitle(title);
         gDirectory->Append(gae);
         fill = true;
      }
      gae_time[itimebin] = gae;
PRINT_POINTER_NAME(gae_time[itimebin])
   }
PRINT_VARIABLE(fill)
   if (fill)
   {
      Double_t **data  = new Double_t *[nbins];
      Double_t **data2 = new Double_t *[nbins];
      Double_t **data3 = new Double_t *[nbins];
      Double_t **data4 = new Double_t *[nbins];
      UShort_t **count = new UShort_t *[nbins];

      for (UShort_t ibin = 0; ibin < nbins; ++ibin)
      {
         data[ibin]  = new Double_t[ntimebins]();
         data2[ibin] = new Double_t[ntimebins]();
         data3[ibin] = new Double_t[ntimebins]();
         data4[ibin] = new Double_t[ntimebins]();
         count[ibin] = new UShort_t[ntimebins]();

         ge = ge_time[ibin];
         if (ge == NULL) continue;

         UShort_t npoints = ge->GetN();

         for (UShort_t ipoint = 0; ipoint < npoints; ++ipoint)
         {
            UInt_t   x = ge->GetX()[ipoint];
            Double_t y = ge->GetY()[ipoint];

            if (y <= 0.) continue;

            UShort_t itimebin = DateTimeTools::GetTimeBin(x, _timebins);
            if (itimebin > 0 && itimebin <= ntimebins)
            {
               --itimebin;
               data[ibin][itimebin]  += y;
               data2[ibin][itimebin] += y*y;
               data3[ibin][itimebin] += y*y*y;
               data4[ibin][itimebin] += y*y*y*y;
               ++count[ibin][itimebin];
            }
         }
      }

      for (UShort_t itimebin = 0; itimebin < ntimebins; ++itimebin)
      {
         gae = gae_time[itimebin];
         if (gae == NULL) continue;

         UShort_t ipoint = 0;
         for (UShort_t ibin = 0; ibin < nbins; ++ibin)
         {
            UShort_t jbin = bins[ibin];

            Double_t x   = GOESInfo::BinCenter(particle, jbin);
            Double_t xl  = GOESInfo::BinRange(particle, jbin)[0];
            Double_t xu  = GOESInfo::BinRange(particle, jbin)[1];
            Double_t exl = x - xl;
            Double_t exu = xu > 0. ? xu - x : x;

            Double_t y = 0., dy = 0., disp = 0.;

            Double_t N = count[ibin][itimebin];

            if (N == 0.) cerr << Form(" !!! GOES::_get_graph_vs_energy: zero entries in bin = %02u, timebin = %02u\n", jbin, itimebin) << std::flush;
            else
            {
                         y = data[ibin][itimebin] / N;  // sample mean
               Double_t y2 = data2[ibin][itimebin] / N; // second central moment
               Double_t y3 = data3[ibin][itimebin] / N; // third central moment
               Double_t y4 = data4[ibin][itimebin] / N; // fourth central moment
               Double_t g2 = (N > 1. ? (y4 - 4*y3*y + 6*y2*y*y - 3*y*y*y*y) / (y2*y2 + y*y*y*y - 2*y2*y*y) : 0) - 3; // sample excess kurtosis
               Double_t uc = N - 1.5 - g2/4; // correction for unbiased sample standard deviation
               if (TMath::IsNaN(uc) || uc <= 0.) cerr << Form(" !!! GOES::_get_graph_vs_energy: correction for unbiased sample standard deviation is zero, negative or NaN in bin = %02u, timebin = %02u\n", jbin, itimebin) << std::flush;
               else
               {
                  disp = TMath::Sqrt(N/uc*(y2 - y*y)); // unbiased sample standard deviation
               }

               if (jbin <= 10) dy = TMath::Sqrt(y / (N * GOESInfo::BinTime(particle, dataset, jbin) * GOESInfo::BinFluxFactor(particle, jbin)));
PRINT_STRING(Form("[%02u:%02u] N=%3.0f, y=%+8.1e, g2=%+8.1e, uc=%+8.1e, disp=%+8.1e, dy=%+8.1e, dy/y=%+8.1e, disp/y=%+8.1e, disp/dy=%+8.1e", itimebin, jbin, N, y, g2, uc, disp, dy, dy/y*100., disp/y*100., disp/dy*100.))
            }

            gae->SetPoint(ipoint, x, y);
            if (error_is_statistical) gae->SetPointError(ipoint, exl, exu, dy, dy);
            else gae->SetPointError(ipoint, exl, exu, disp, disp);

            ++ipoint;
         }
      }
   }

   return gae_time;
}

TGraphErrors *GOES::_get_time_graph_helium(GOESInfo::DataSet dataset, GOESInfo::DataType datatype, UShort_t ibin, GOESInfo::Detector detector, Bool_t exclude_bad_quality, Bool_t use_corrected_geometrical_factor)
{
PRINT_FUNCTION()
PRINT_VARIABLE(dataset)
PRINT_VARIABLE(datatype)
PRINT_VARIABLE(ibin)
PRINT_VARIABLE(detector)
PRINT_VARIABLE(exclude_bad_quality)
PRINT_VARIABLE(use_corrected_geometrical_factor)
   Particle::Type particle = Particle::HELIUM4;

   UShort_t ifile;
   UShort_t nbins;
   UShort_t first_bin;
   Char_t   det_char[2] = "";
   if (0 <= ibin && ibin <= 5)
   {
      if (detector == GOESInfo::EPEAD_A)
      {
         ifile       = 1;
         det_char[0] = 'W';
      }
      else
      {
         ifile       = 0;
         det_char[0] = 'E';
      }
      nbins     = 6;
      first_bin = 1;
   }
   else
   {
      ifile     = dataset == GOESInfo::FULL ? 2 : 1;
      nbins     = 2;
      first_bin = 7;
   }

   TTree *tree = _tree_data[dataset][GOESInfo::_PARTICLE_DATAFILE[GOESInfo::iParticle(particle)][dataset][ifile]];
PRINT_POINTER_NAME(tree)
   if (tree == NULL) return NULL;

   ULong64_t nentries = tree->GetEntries();

   TGraphErrors **ge_quality    = new TGraphErrors *[nbins]();
   TGraphErrors **ge_num_points = new TGraphErrors *[nbins]();
   TGraphErrors **ge_corr_rate  = new TGraphErrors *[nbins]();
   TGraphErrors **ge_corr_flux  = new TGraphErrors *[nbins]();

   TGraphErrors *ge;

   Char_t name[_STR_LENGTH];
   Char_t title[_STR_LENGTH];
   Char_t avg_time[_STR_LENGTH];

   Bool_t fill = false;

   gROOT->cd();
   for (UShort_t jbin = 0; jbin < nbins; ++jbin)
   {
      UShort_t kbin = first_bin + jbin - 1;

      Double_t sec = GOESInfo::BinTime(particle, dataset, kbin);
      if (sec < 60) snprintf(avg_time, _STR_LENGTH, "%.1fs", sec);
      else snprintf(avg_time, _STR_LENGTH, "%.0fm", sec / 60.);

      _get_timegraph_name(name, dataset, GOESInfo::QUALITY, particle, kbin, detector, exclude_bad_quality, false, use_corrected_geometrical_factor);
      ge = (TGraphErrors *)gROOT->FindObject(name);
      if (ge == NULL)
      {
         _get_timegraph_title(title, dataset, GOESInfo::QUALITY, particle, kbin, detector, exclude_bad_quality, false, use_corrected_geometrical_factor);
         ge = new TGraphErrors(nentries);
         ge->SetName(name);
         ge->SetTitle(title);
         gDirectory->Append(ge);
         fill = true;
      }
      ge_quality[jbin] = ge;

      if (dataset == GOESInfo::FULL)
      {
         _get_timegraph_name(name, dataset, GOESInfo::CORRECTED_RATE, particle, kbin, detector, exclude_bad_quality, false, use_corrected_geometrical_factor);
         ge = (TGraphErrors *)gROOT->FindObject(name);
         if (ge == NULL)
         {
            _get_timegraph_title(title, dataset, GOESInfo::CORRECTED_RATE, particle, kbin, detector, exclude_bad_quality, false, use_corrected_geometrical_factor);
            ge = new TGraphErrors(nentries);
            ge->SetName(name);
            ge->SetTitle(title);
            gDirectory->Append(ge);
            fill = true;
         }
         ge_corr_rate[jbin] = ge;
      }
      else
      {
         _get_timegraph_name(name, dataset, GOESInfo::DATA_POINTS, particle, kbin, detector, exclude_bad_quality, false, use_corrected_geometrical_factor);
         ge = (TGraphErrors *)gROOT->FindObject(name);
         if (ge == NULL)
         {
            _get_timegraph_title(title, dataset, GOESInfo::DATA_POINTS, particle, kbin, detector, exclude_bad_quality, false, use_corrected_geometrical_factor);
            ge = new TGraphErrors(nentries);
            ge->SetName(name);
            ge->SetTitle(title);
            gDirectory->Append(ge);
            fill = true;
         }
         ge_num_points[jbin] = ge;
      }

      _get_timegraph_name(name, dataset, GOESInfo::CORRECTED_FLUX, particle, kbin, detector, exclude_bad_quality, false, use_corrected_geometrical_factor);
      ge = (TGraphErrors *)gROOT->FindObject(name);
      if (ge == NULL)
      {
         _get_timegraph_title(title, dataset, GOESInfo::CORRECTED_FLUX, particle, kbin, detector, exclude_bad_quality, false, use_corrected_geometrical_factor);
         ge = new TGraphErrors(nentries);
         ge->SetName(name);
         ge->SetTitle(title);
         gDirectory->Append(ge);
         fill = true;
      }
      ge_corr_flux[jbin] = ge;
   }

   ge = (datatype == GOESInfo::QUALITY ? ge_quality : (datatype == GOESInfo::CORRECTED_RATE ? ge_corr_rate : (datatype == GOESInfo::DATA_POINTS ? ge_num_points : ge_corr_flux)))[ibin + 1 - first_bin];
PRINT_POINTER_NAME(ge)
PRINT_VARIABLE(fill)
   if (fill)
   {
      UInt_t utime;
      Float_t *quality    = new Float_t[nbins];
      Float_t *num_points = new Float_t[nbins];
      Float_t *corr_rate  = new Float_t[nbins];
      Float_t *corr_flux  = new Float_t[nbins];

      tree->SetBranchAddress("time_tag", &utime);
      for (UShort_t jbin = 0; jbin < nbins; ++jbin)
      {
         UShort_t kbin = first_bin + jbin;

         tree->SetBranchAddress(Form("A%u%s_QUAL_FLAG", kbin, det_char),
            &quality[jbin]);   // QUALITY

         if (dataset == GOESInfo::FULL)
         {
            tree->SetBranchAddress(Form("A%u%s_%s", kbin, det_char, detector == GOESInfo::HEPAD ? "COUNT_RATE" : "CR"),
               &corr_rate[jbin]); // CORRECTED_RATE
         }
         else
         {
            tree->SetBranchAddress(Form("A%u%s_NUM_PTS", kbin, det_char),
               &num_points[jbin]); // DATA_POINTS
         }
         tree->SetBranchAddress(Form("A%u%s_FLUX", kbin, det_char),
            &corr_flux[jbin]); // CORRECTED_FLUX
      }

      for (ULong64_t ientry = 0; ientry < nentries; ++ientry)
      {
         tree->GetEntry(ientry);

         for (UShort_t jbin = 0; jbin < nbins; ++jbin)
         {
            UShort_t kbin = first_bin + jbin - 1;

            Float_t q  = quality[jbin];
            Float_t npts = 0.;
            Float_t cf = corr_flux[jbin];
            Float_t cr = 0.;

            Double_t dr = 0.;
            Double_t df = 0.;

            /* R = N/T => N = R*T
             * dN = sqrt(N) => dN/N = sqrt(N)/N = 1/sqrt(N)
             * dR = dN/T = sqrt(N)/T = sqrt(R*T)/T = sqrt(R/T)
             * dR/R = sqrt(R/T)/R = 1/sqrt(R*T) = 1/sqrt(N)
             * F = R/G = N/(T*G) => G = R/F, R = F*G
             * dF = dR/G = sqrt(R/T)/G = sqrt(R/T)/R*F = F/sqrt(R*T) = F*dR/R
             * dF/F = F*dR/R/F = dR/R = 1/sqrt(N)
             * F = N/(T*G) => N = F*T*G
             * dF = dN/(T*G) = sqrt(N)/(T*G) = sqrt(F/(T*G))
             * dF/F = sqrt(F/(T*G))/F = 1/sqrt(F*T*G) = 1/sqrt(N)
             */

            if (q)
            {
               cr = cf = npts = 0;
            }
            else
            {
               Double_t corr = GOESInfo::BinCorrectionFactor(particle, kbin);
               if (use_corrected_geometrical_factor)
               {
                  cf *= corr;
                  corr = 1.;
               }

               if (dataset == GOESInfo::FULL)
               {
                  cr = corr_rate[jbin];
                  if (cr <= 0.)
                  {
                     cr = cf = 0;
                  }
                  else
                  {
                     dr = TMath::Sqrt(cr / GOESInfo::BinTime(particle, dataset, kbin));
                     df = cf*dr/cr;
                  }
               }
               else
               {
                  npts = num_points[jbin];

                  if (cf <= 0) cf = 0.;
                  else df = TMath::Sqrt(cf / (GOESInfo::BinTime(particle, dataset, kbin) * GOESInfo::BinFluxFactor(particle, kbin) * corr));
               }
            }

            if (!q || !exclude_bad_quality)
            {
               ge_quality[jbin]->SetPoint(ientry, utime, q);
               ge_quality[jbin]->SetPointError(ientry, 0., 0.);

               ge_corr_flux[jbin]->SetPoint(ientry, utime, cf);
               ge_corr_flux[jbin]->SetPointError(ientry, 0., df);

               if (dataset == GOESInfo::FULL)
               {
                  ge_corr_rate[jbin]->SetPoint(ientry, utime, cr);
                  ge_corr_rate[jbin]->SetPointError(ientry, 0., dr);
               }
               else
               {
                  ge_num_points[jbin]->SetPoint(ientry, utime, npts);
                  ge_num_points[jbin]->SetPointError(ientry, 0., 0.);
               }
            }
         }
      }

      tree->ResetBranchAddresses();

      gROOT->cd();

      delete [] quality;
      delete [] num_points;
      delete [] corr_rate;
      delete [] corr_flux;
   }

   delete [] ge_quality;
   delete [] ge_num_points;
   delete [] ge_corr_rate;
   delete [] ge_corr_flux;

   return ge;
}

TGraphErrors *GOES::_get_time_graph_proton(GOESInfo::DataSet dataset, GOESInfo::DataType datatype, UShort_t ibin, GOESInfo::Detector detector, Bool_t exclude_bad_quality, Bool_t sideband_correction, Bool_t use_corrected_geometrical_factor)
{
PRINT_FUNCTION()
PRINT_VARIABLE(dataset)
PRINT_VARIABLE(datatype)
PRINT_VARIABLE(ibin)
PRINT_VARIABLE(detector)
PRINT_VARIABLE(exclude_bad_quality)
PRINT_VARIABLE(sideband_correction)
PRINT_VARIABLE(use_corrected_geometrical_factor)
   Particle::Type particle = Particle::PROTON;

   UShort_t ifile;
   UShort_t nbins;
   UShort_t first_bin;
   Char_t   det_char[2] = "";
   if (ibin == 0)
   {
      ifile       = 0;
      nbins       = dataset == GOESInfo::FULL ? 1 : 7;
      first_bin   = 1;
      det_char[0] = detector == GOESInfo::EPEAD_A ? 'W' : 'E';
   }
   else if (1 <= ibin && ibin <= 6)
   {
      if (detector == GOESInfo::EPEAD_A)
      {
         ifile       = dataset == GOESInfo::FULL ? 2 : 0;
         det_char[0] = 'W';
      }
      else
      {
         ifile       = dataset == GOESInfo::FULL ? 1 : 0;
         det_char[0] = 'E';
      }
      nbins     = dataset == GOESInfo::FULL ? 6 : 7;
      first_bin = dataset == GOESInfo::FULL ? 2 : 1;
   }
   else if (7 <= ibin && ibin <= 10)
   {
      ifile       = dataset == GOESInfo::FULL ? 3 : 1;
      nbins       = 4;
      first_bin   = 8;
   }
   else if (11 <= ibin && ibin <= 23)
   {
      ifile       = 2;
      nbins       = ibin <= 17 ? 7 : 6;
      first_bin   = ibin <= 17 ? 12 : 19;
      det_char[0] = detector == GOESInfo::EPEAD_A ? 'W' : 'E';
   }

   TTree *tree = _tree_data[dataset][GOESInfo::_PARTICLE_DATAFILE[GOESInfo::iParticle(particle)][dataset][ifile]];
PRINT_POINTER_NAME(tree)
   if (tree == NULL) return NULL;

   ULong64_t nentries = tree->GetEntries();

   TGraphErrors **ge_quality     = new TGraphErrors *[nbins]();
   TGraphErrors **ge_num_points  = new TGraphErrors *[nbins]();
   TGraphErrors **ge_uncorr_rate = new TGraphErrors *[nbins]();
   TGraphErrors **ge_uncorr_flux = new TGraphErrors *[nbins]();
   TGraphErrors **ge_corr_rate   = new TGraphErrors *[nbins]();
   TGraphErrors **ge_corr_flux   = new TGraphErrors *[nbins]();

   TGraphErrors *ge = NULL;

   Char_t name[_STR_LENGTH];
   Char_t title[_STR_LENGTH];
   Char_t avg_time[_STR_LENGTH];
   Char_t prefix[_STR_LENGTH];

   if (ibin <= 10) snprintf(prefix, _STR_LENGTH, "P");
   else if (ibin <= 17) snprintf(prefix, _STR_LENGTH, "ZPGT");
   else snprintf(prefix, _STR_LENGTH, "ZPEQ");

   Bool_t fill = false;

   gROOT->cd();
   for (UShort_t jbin = 0; jbin < nbins; ++jbin)
   {
      UShort_t kbin = first_bin + jbin - 1;

      Double_t sec = GOESInfo::BinTime(particle, dataset, kbin);
      if (sec < 60) snprintf(avg_time, _STR_LENGTH, "%.1fs", sec);
      else snprintf(avg_time, _STR_LENGTH, "%.0fm", sec / 60.);

      _get_timegraph_name(name, dataset, GOESInfo::QUALITY, particle, kbin, detector, exclude_bad_quality, sideband_correction, use_corrected_geometrical_factor);
      ge = (TGraphErrors *)gROOT->FindObject(name);
      if (ge == NULL)
      {
         _get_timegraph_title(title, dataset, GOESInfo::QUALITY, particle, kbin, detector, exclude_bad_quality, false, use_corrected_geometrical_factor);
         ge = new TGraphErrors(nentries);
         ge->SetName(name);
         ge->SetTitle(title);
         gDirectory->Append(ge);
         fill = true;
      }
      ge_quality[jbin] = ge;

      if ((dataset == GOESInfo::AVG1M || dataset == GOESInfo::AVG5M) && kbin <= 10)
      {
         _get_timegraph_name(name, dataset, GOESInfo::DATA_POINTS, particle, kbin, detector, exclude_bad_quality, sideband_correction, use_corrected_geometrical_factor);
         ge = (TGraphErrors *)gROOT->FindObject(name);
         if (ge == NULL)
         {
            _get_timegraph_title(title, dataset, GOESInfo::DATA_POINTS, particle, kbin, detector, exclude_bad_quality, false, use_corrected_geometrical_factor);
            ge = new TGraphErrors(nentries);
            ge->SetName(name);
            ge->SetTitle(title);
            gDirectory->Append(ge);
            fill = true;
         }
         ge_num_points[jbin] = ge;
      }

      if (dataset == GOESInfo::FULL && kbin <= 6)
      {
         _get_timegraph_name(name, dataset, GOESInfo::UNCORRECTED_RATE, particle, kbin, detector, exclude_bad_quality, sideband_correction, use_corrected_geometrical_factor);
         ge = (TGraphErrors *)gROOT->FindObject(name);
         if (ge == NULL)
         {
            _get_timegraph_title(title, dataset, GOESInfo::UNCORRECTED_RATE, particle, kbin, detector, exclude_bad_quality, false, use_corrected_geometrical_factor);
            ge = new TGraphErrors(nentries);
            ge->SetName(name);
            ge->SetTitle(title);
            gDirectory->Append(ge);
            fill = true;
         }
         ge_uncorr_rate[jbin] = ge;
      }
      else if (dataset == GOESInfo::FULL && kbin >= 7)
      {
         _get_timegraph_name(name, dataset, GOESInfo::CORRECTED_RATE, particle, kbin, detector, exclude_bad_quality, sideband_correction, use_corrected_geometrical_factor);
         ge = (TGraphErrors *)gROOT->FindObject(name);
         if (ge == NULL)
         {
            _get_timegraph_title(title, dataset, GOESInfo::CORRECTED_RATE, particle, kbin, detector, exclude_bad_quality, false, use_corrected_geometrical_factor);
            ge = new TGraphErrors(nentries);
            ge->SetName(name);
            ge->SetTitle(title);
            gDirectory->Append(ge);
            fill = true;
         }
         ge_corr_rate[jbin] = ge;
      }

      if ((dataset == GOESInfo::FULL || dataset == GOESInfo::AVG1M || dataset == GOESInfo::AVG5M) && kbin <= 6)
      {
         _get_timegraph_name(name, dataset, GOESInfo::UNCORRECTED_FLUX, particle, kbin, detector, exclude_bad_quality, sideband_correction, use_corrected_geometrical_factor);
         ge = (TGraphErrors *)gROOT->FindObject(name);
         if (ge == NULL)
         {
            _get_timegraph_title(title, dataset, GOESInfo::UNCORRECTED_FLUX, particle, kbin, detector, exclude_bad_quality, false, use_corrected_geometrical_factor);
            ge = new TGraphErrors(nentries);
            ge->SetName(name);
            ge->SetTitle(title);
            gDirectory->Append(ge);
            fill = true;
         }
         ge_uncorr_flux[jbin] = ge;
      }

      if (kbin >= 7 || dataset == GOESInfo::AVG5M)
      {
         _get_timegraph_name(name, dataset, GOESInfo::CORRECTED_FLUX, particle, kbin, detector, exclude_bad_quality, sideband_correction, use_corrected_geometrical_factor);
         ge = (TGraphErrors *)gROOT->FindObject(name);
         if (ge == NULL)
         {
            _get_timegraph_title(title, dataset, GOESInfo::CORRECTED_FLUX, particle, kbin, detector, exclude_bad_quality, false, use_corrected_geometrical_factor);
            ge = new TGraphErrors(nentries);
            ge->SetName(name);
            ge->SetTitle(title);
            gDirectory->Append(ge);
            fill = true;
         }
         ge_corr_flux[jbin] = ge;
      }
   }

   ge = (datatype == GOESInfo::QUALITY ? ge_quality : (datatype == GOESInfo::CORRECTED_RATE ? ge_corr_rate : (datatype == GOESInfo::DATA_POINTS ? ge_num_points :
         (datatype == GOESInfo::UNCORRECTED_RATE ? ge_uncorr_rate : (datatype == GOESInfo::UNCORRECTED_FLUX ? ge_uncorr_flux : ge_corr_flux)))))[ibin + 1 - first_bin];
PRINT_POINTER_NAME(ge)
PRINT_VARIABLE(fill)
   if (fill)
   {
      UInt_t utime;
      Float_t *quality     = new Float_t[nbins];
      Float_t *num_points  = new Float_t[nbins];
      Float_t *uncorr_rate = new Float_t[nbins];
      Float_t *uncorr_flux = new Float_t[nbins];
      Float_t *corr_rate   = new Float_t[nbins];
      Float_t *corr_flux   = new Float_t[nbins];

      tree->SetBranchAddress("time_tag", &utime);
      for (UShort_t jbin = 0; jbin < nbins; ++jbin)
      {
         UShort_t kbin = first_bin + jbin - 1;
         UShort_t bin = ibin <= 10 ? kbin + 1 : GOESInfo::BinCenter(particle, kbin);

         tree->SetBranchAddress(Form("%s%u%s_QUAL_FLAG", prefix, bin, det_char),
            &quality[jbin]);   // QUALITY

         if ((dataset == GOESInfo::AVG1M || dataset == GOESInfo::AVG5M) && kbin <= 10)
         {
            tree->SetBranchAddress(Form("%s%u%s_NUM_PTS", prefix, bin, det_char),
               &num_points[jbin]);   // DATA_POINTS
         }

         if (dataset == GOESInfo::FULL && kbin <= 6)
         {
            tree->SetBranchAddress(Form("%s%u%s_UNCOR_CR", prefix, bin, det_char),
               &uncorr_rate[jbin]);   // UNCORRECTED_RATE
         }
         else if (dataset == GOESInfo::FULL && kbin >= 7)
         {
            tree->SetBranchAddress(Form("%s%u_COUNT_RATE", prefix, bin),
               &corr_rate[jbin]);   // CORRECTED_RATE
         }

         if ((dataset == GOESInfo::FULL || dataset == GOESInfo::AVG1M || dataset == GOESInfo::AVG5M) && kbin <= 6)
         {
            tree->SetBranchAddress(Form("%s%u%s_UNCOR_FLUX", prefix, bin, det_char),
               &uncorr_flux[jbin]);   // UNCORRECTED_FLUX
         }

         if (kbin <= 6 && dataset == GOESInfo::AVG5M)
         {
            tree->SetBranchAddress(Form("%s%u%s_COR_FLUX", prefix, bin, det_char),
               &corr_flux[jbin]);   // CORRECTED_FLUX
         }
         else if (7 <= kbin && kbin <= 10)
         {
            tree->SetBranchAddress(Form("%s%u_FLUX", prefix, bin),
               &corr_flux[jbin]);   // CORRECTED_FLUX
         }
         else if (kbin >= 11)
         {
            tree->SetBranchAddress(Form("%s%u%s", prefix, bin, det_char),
               &corr_flux[jbin]);   // CORRECTED_FLUX
         }
      }

      for (ULong64_t ientry = 0; ientry < nentries; ++ientry)
      {
         tree->GetEntry(ientry);

         for (UShort_t jbin = 0; jbin < nbins; ++jbin)
         {
            UShort_t kbin = first_bin + jbin - 1;

            // bin variables
            Float_t q = quality[jbin];
            Float_t npts = 0.;
            Float_t r = 0.;
            Float_t f = 0.;

            Double_t dr = 0.;
            Double_t df = 0.;

            /* R = N/T => N = R*T
             * dN = sqrt(N) => dN/N = sqrt(N)/N = 1/sqrt(N)
             * dR = dN/T = sqrt(N)/T = sqrt(R*T)/T = sqrt(R/T)
             * dR/R = sqrt(R/T)/R = 1/sqrt(R*T) = 1/sqrt(N)
             * F = R/G = N/(T*G) => G = R/F, R = F*G
             * dF = dR/G = sqrt(R/T)/G = sqrt(R/T)/R*F = F/sqrt(R*T) = F*dR/R
             * dF/F = F*dR/R/F = dR/R = 1/sqrt(N)
             * F = N/(T*G) => N = F*T*G
             * dF = dN/(T*G) = sqrt(N)/(T*G) = sqrt(F/(T*G))
             * dF/F = sqrt(F/(T*G))/F = 1/sqrt(F*T*G) = 1/sqrt(N)
             */

            if (!q)
            {
               if ((dataset == GOESInfo::AVG1M || dataset == GOESInfo::AVG5M) && kbin <= 10)
               {
                  npts = num_points[jbin];
               }

               if (dataset == GOESInfo::FULL && kbin <= 6)
               {
                  r = uncorr_rate[jbin];
               }
               else if (dataset == GOESInfo::FULL && kbin >= 7)
               {
                  r = corr_rate[jbin];
               }

               if ((dataset == GOESInfo::FULL || dataset == GOESInfo::AVG1M || dataset == GOESInfo::AVG5M) && kbin <= 6)
               {
                  f = uncorr_flux[jbin];
               }

               if (kbin >= 7 || dataset == GOESInfo::AVG5M)
               {
                  f = corr_flux[jbin];
                  if (sideband_correction)
                  {
                     if (kbin == 7)
                     {
                        f -= 0.74*corr_flux[3]; //  P8 - 0.74*P11
                     }
                     else if (kbin == 8)
                     {
                        f -= 0.11*corr_flux[3]; //  P9 - 0.11*P11
                     }
                  }
               }

               if (r <= 0.) r = 0.;
               else dr = TMath::Sqrt(r / GOESInfo::BinTime(particle, dataset, kbin));

               if (f <= 0) f = 0.;
               else if (kbin <= 10)
               {
                  Double_t corr = GOESInfo::BinCorrectionFactor(particle, kbin);
                  if (use_corrected_geometrical_factor)
                  {
                     f *= corr;
                     corr = 1.;
                  }

                  if (r > 0.) df = f*dr/r;
                  else df = TMath::Sqrt(f / (GOESInfo::BinTime(particle, dataset, kbin) * GOESInfo::BinFluxFactor(particle, kbin) * corr));
               }
            }

            if (!q || !exclude_bad_quality)
            {
               ge_quality[jbin]->SetPoint(ientry, utime, q);
               ge_quality[jbin]->SetPointError(ientry, 0., 0.);

               if ((dataset == GOESInfo::AVG1M || dataset == GOESInfo::AVG5M) && kbin <= 10)
               {
                  ge_num_points[jbin]->SetPoint(ientry, utime, npts);
                  ge_num_points[jbin]->SetPointError(ientry, 0., 0.);
               }

               if (dataset == GOESInfo::FULL && kbin <= 6)
               {
                  ge_uncorr_rate[jbin]->SetPoint(ientry, utime, r);
                  ge_uncorr_rate[jbin]->SetPointError(ientry, 0., dr);
               }
               else if (dataset == GOESInfo::FULL && kbin >= 7)
               {
                  ge_corr_rate[jbin]->SetPoint(ientry, utime, r);
                  ge_corr_rate[jbin]->SetPointError(ientry, 0., dr);
               }

               if ((dataset == GOESInfo::FULL || dataset == GOESInfo::AVG1M || dataset == GOESInfo::AVG5M) && kbin <= 6)
               {
                  ge_uncorr_flux[jbin]->SetPoint(ientry, utime, f);
                  ge_uncorr_flux[jbin]->SetPointError(ientry, 0., df);
               }

               if (kbin >= 7 || dataset == GOESInfo::AVG5M)
               {
                  ge_corr_flux[jbin]->SetPoint(ientry, utime, f);
                  ge_corr_flux[jbin]->SetPointError(ientry, 0., df);
               }
            }
         }
      }

      tree->ResetBranchAddresses();

      gROOT->cd();

      delete [] quality;
      delete [] num_points;
      delete [] uncorr_rate;
      delete [] uncorr_flux;
      delete [] corr_rate;
      delete [] corr_flux;
   }

   delete [] ge_quality;
   delete [] ge_num_points;
   delete [] ge_uncorr_rate;
   delete [] ge_uncorr_flux;
   delete [] ge_corr_rate;
   delete [] ge_corr_flux;

   return ge;
}

TGraphErrors *GOES::_get_time_graph_yawflip()
{
   std::cerr << " !!! Error: _get_time_graph_yawflip: method not yet implemented!\n" << std::flush;
   return NULL;
}
