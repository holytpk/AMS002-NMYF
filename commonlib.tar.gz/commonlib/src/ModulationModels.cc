#include "ModulationModels.hh"
#include "debug.hh"

Double_t ModulationModels::Models::ForceFieldApproximation(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy)
{
   // Force-field approximation
   // dJ(1 AU, T, t)/dT = T(T + 2M) / ((T + Phi(t))(T + Phi(t) + 2M)) dJ(inf, T + Phi(t))/dT
   // Phi = Ze phi
   // [T] = GeV
   // [phi] = GV

   LISModels::Type lismodel = LISModels::cast(par[0]);
   Double_t        phi      = par[1];
   Double_t        N        = par[2];

   Double_t Phi = Particle::Z[particle] * phi;
   Double_t M   = Particle::Mass[particle]/Unit::GeV;

   Double_t T  = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::KINETIC);
   Double_t Tp = T + Phi;
   //~ Double_t xp = Unit::ConvertEnergyType(Tp, particle, Energy::KINETIC, SIPrefix::GIGA, energy);

   // The force-field approximation is defined as function of T, while data and model can be defined as function of a different type of energy, x
   // There are two jacobians:
   // 1) From dJ(1 AU)/dx to dJ(1 AU)/dT, so we can use the force-field approximation => T -> x, computed in T(x) => variable J defined below
   // 2) From dJ(inf)/dT to dJ(inf)/dx, so we can use the model itself => x -> T, computed in x(T+Phi) = xp
   //    This is computed inside the model function itself, provided we ask the model to be computed as a function of T in T+Phi
   Double_t J = Unit::EnergyJacobian(T, particle, Energy::KINETIC, SIPrefix::GIGA, energy);

   return N * J * T*(T + 2*M) / (Tp*(Tp + 2*M)) * LISModels::Info[lismodel].Model(Tp, &par[3], particle, Energy::KINETIC);
}

Double_t ModulationModels::Models::ForceFieldApproximation(Double_t x, TGraph *graph, Double_t *par, Particle::Type particle, Energy::Type energy)
{
   // Force-field approximation
   // J(r, E, t) = (E^{2} - M^{2}) / ((E + Phi(t))^{2} - M^{2}) J(inf, E + Phi(t))
   // Phi = Ze phi
   // [E] = GeV
   // [phi] = GV

   Double_t phi = par[1];

   Double_t Phi = Particle::Z[particle] * phi;

   Double_t T  = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::KINETIC);
   Double_t Tp = T + Phi;
   Double_t xp = Unit::ConvertEnergyType(Tp, particle, Energy::KINETIC, SIPrefix::GIGA, energy);

   return graph->Eval(xp);
}

Double_t ModulationModels::Models::DoubleForceField(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy)
{
   // Double force-field approximation
   // dJ(1 AU, T, t)/dT = T(T + 2M) / ((T + Phi(T,t))(T + Phi(T,t) + 2M)) dJ(inf, T + Phi(T,t))/dT
   // Phi = Ze phi
   // phi = f(T, T1, T2, phi1, phi2)
   // [T] = [T1] = [T2] = GeV
   // [phi] = [phi1] = [phi2] = GV

   LISModels::Type lismodel = LISModels::cast(par[0]);
   Double_t        phi1     = par[1];
   Double_t        phi2     = par[2];
   Double_t        R1       = par[3];
   Double_t        R2       = par[4];
   Double_t        N        = par[5];

   Double_t M = Particle::Mass[particle]/Unit::GeV;

   const Double_t T1 = Unit::ConvertEnergyType(R1, particle, Energy::RIGIDITY, SIPrefix::GIGA, Energy::KINETIC);
   const Double_t T2 = Unit::ConvertEnergyType(R2, particle, Energy::RIGIDITY, SIPrefix::GIGA, Energy::KINETIC);

   Double_t T = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::KINETIC);

   Double_t t = (T - T1)/(T2 - T1);
   Double_t phi = T < T1 ? phi1 : (T1 <= T && T < T2 ? phi1 + (phi2 - phi1)*t*t*(3 - 2*t) : phi2);
   Double_t Phi = Particle::Z[particle] * phi;

   Double_t Tp = T + Phi;

   // The force-field approximation is defined as function of T, while data and model can be defined as function of a different type of energy, x
   // There are two jacobians:
   // 1) From dJ(1 AU)/dx to dJ(1 AU)/dT, so we can use the force-field approximation => T -> x, computed in T(x) => variable J defined below
   // 2) From dJ(inf)/dT to dJ(inf)/dx, so we can use the model itself => x -> T, computed in x(T+Phi) = xp
   //    This is computed inside the model function itself, provided we ask the model to be computed as a function of T in T+Phi
   Double_t J = Unit::EnergyJacobian(T, particle, Energy::KINETIC, SIPrefix::GIGA, energy);

   return N * J * T*(T + 2*M) / (Tp*(Tp + 2*M)) * LISModels::Info[lismodel].Model(Tp, &par[6], particle, Energy::KINETIC);
}

Double_t ModulationModels::Models::DoubleForceField(Double_t x, TGraph *graph, Double_t *par, Particle::Type particle, Energy::Type energy)
{
   // Double force-field approximation
   // dJ(1 AU, T, t)/dT = T(T + 2M) / ((T + Phi(T,t))(T + Phi(T,t) + 2M)) dJ(inf, T + Phi(T,t))/dT
   // Phi = Ze phi
   // phi = f(T, T1, T2, phi1, phi2)
   // [T] = [T1] = [T2] = GeV
   // [phi] = [phi1] = [phi2] = GV

   Double_t phi1 = par[1];
   Double_t phi2 = par[2];
   Double_t R1   = par[3];
   Double_t R2   = par[4];

   const Double_t T1 = Unit::ConvertEnergyType(R1, particle, Energy::RIGIDITY, SIPrefix::GIGA, Energy::KINETIC);
   const Double_t T2 = Unit::ConvertEnergyType(R2, particle, Energy::RIGIDITY, SIPrefix::GIGA, Energy::KINETIC);

   Double_t T = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::KINETIC);

   Double_t t   = (T - T1)/(T2 - T1);
   Double_t phi = T < T1 ? phi1 : (T1 <= T && T < T2 ? phi1 + (phi2 - phi1)*t*t*(3 - 2*t) : phi2);
   Double_t Phi = Particle::Z[particle] * phi;

   Double_t Tp = T + Phi;

   Double_t xp = Unit::ConvertEnergyType(Tp, particle, Energy::KINETIC, SIPrefix::GIGA, energy);

   return graph->Eval(xp);
}

Double_t ModulationModels::Models::DoubleForceFieldRig(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy)
{
   // Double force-field approximation
   // dJ(1 AU, T, t)/dT = T(T + 2M) / ((T + Phi(T,t))(T + Phi(T,t) + 2M)) dJ(inf, T + Phi(T,t))/dT
   // Phi = Ze phi
   // phi = f(R, R1, R2, phi1, phi2)
   // [R] = [R1] = [R2] = GV
   // [phi] = [phi1] = [phi2] = GV

   LISModels::Type lismodel = LISModels::cast(par[0]);
   Double_t        phi1     = par[1];
   Double_t        phi2     = par[2];
   Double_t        R1       = par[3];
   Double_t        R2       = par[4];
   Double_t        N        = par[5];

   Double_t M = Particle::Mass[particle]/Unit::GeV;

   Double_t R = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::RIGIDITY);
   Double_t T = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::KINETIC);

   Double_t r = (R - R1)/(R2 - R1);
   Double_t phi = R < R1 ? phi1 : (R1 <= R && R < R2 ? phi1 + (phi2 - phi1)*r*r*(3 - 2*r) : phi2);
   Double_t Phi = Particle::Z[particle] * phi;

   Double_t Tp = T + Phi;

   // The force-field approximation is defined as function of T, while data and model can be defined as function of a different type of energy, x
   // There are two jacobians:
   // 1) From dJ(1 AU)/dx to dJ(1 AU)/dT, so we can use the force-field approximation => T -> x, computed in T(x) => variable J defined below
   // 2) From dJ(inf)/dT to dJ(inf)/dx, so we can use the model itself => x -> T, computed in x(T+Phi) = xp
   //    This is computed inside the model function itself, provided we ask the model to be computed as a function of T in T+Phi
   Double_t J = Unit::EnergyJacobian(T, particle, Energy::KINETIC, SIPrefix::GIGA, energy);

   return N * J * T*(T + 2*M) / (Tp*(Tp + 2*M)) * LISModels::Info[lismodel].Model(Tp, &par[6], particle, Energy::KINETIC);
}

Double_t ModulationModels::Models::DoubleForceFieldRig(Double_t x, TGraph *graph, Double_t *par, Particle::Type particle, Energy::Type energy)
{
   // Double force-field approximation
   // dJ(1 AU, T, t)/dT = T(T + 2M) / ((T + Phi(T,t))(T + Phi(T,t) + 2M)) dJ(inf, T + Phi(T,t))/dT
   // Phi = Ze phi
   // phi = f(T, T1, T2, phi1, phi2)
   // [T] = [T1] = [T2] = GeV
   // [phi] = [phi1] = [phi2] = GV

   Double_t phi1 = par[1];
   Double_t phi2 = par[2];
   Double_t R1   = par[3];
   Double_t R2   = par[4];

   Double_t R = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::RIGIDITY);
   Double_t T = Unit::ConvertEnergyType(x, particle, energy, SIPrefix::GIGA, Energy::KINETIC);

   Double_t r = (R - R1)/(R2 - R1);
   Double_t phi = R < R1 ? phi1 : (R1 <= R && R < R2 ? phi1 + (phi2 - phi1)*r*r*(3 - 2*r) : phi2);
   Double_t Phi = Particle::Z[particle] * phi;

   Double_t Tp = T + Phi;

   Double_t xp = Unit::ConvertEnergyType(Tp, particle, Energy::KINETIC, SIPrefix::GIGA, energy);

   return graph->Eval(xp);
}

Double_t ModulationModels::FittingFunction(Double_t *x, Double_t *par)
{
   /// parameters:
   ///    0  = ModulationModels::Type; fixed during fit
   ///    1  = Energy::Type; fixed during fit
   ///    2  = Particle::Type; fixed during fit
   ///    3  = LISModels::Type; fixed during fit
   ///    4  = phi: solar potential [GV]; free during fit
   ///    5  = N: flux normalization [(GeV/GV s m^2 sr)^{-1}]; free during fit
   ///    6- = parameters used by the LIS formula; free during fit

   Double_t xx = x[0];

   ModulationModels::Type modmodel = ModulationModels::cast(par[0]);
   Energy::Type           energy   = Energy::cast(par[1]);
   Particle::Type         particle = Particle::cast(par[2]);

   return Info[modmodel].Model(xx, &par[3], particle, energy);
}

TF1 *ModulationModels::CreateFunction(const Char_t *name, Double_t min_ene, Double_t max_ene, ModulationModels::Type modmodel, LISModels::Type lismodel, Particle::Type particle, Energy::Type energy, Bool_t fixlis)
{
   TF1 *f_mod = new TF1(name, FittingFunction, min_ene, max_ene, 5 + Info[modmodel].nParameters + LISModels::Info[lismodel].nParameters);

   f_mod->SetParName(0, "modmodel");
   f_mod->FixParameter(0, modmodel);

   f_mod->SetParName(1, "energytype");
   f_mod->FixParameter(1, energy);

   f_mod->SetParName(2, "particle");
   f_mod->FixParameter(2, particle);

   f_mod->SetParName(3, "lismodel");
   f_mod->FixParameter(3, lismodel);

   for (UShort_t ipar = 0; ipar < Info[modmodel].nParameters; ++ipar)
   {
      f_mod->SetParName(4 + ipar, Info[modmodel].Parameter[ipar].Name);
      f_mod->SetParameter(4 + ipar, Info[modmodel].Parameter[ipar].Med);
      f_mod->SetParLimits(4 + ipar, Info[modmodel].Parameter[ipar].Min, Info[modmodel].Parameter[ipar].Max);
   }

   f_mod->SetParName(4 + Info[modmodel].nParameters, "norm");
   if (fixlis)
   {
      f_mod->FixParameter(4 + Info[modmodel].nParameters, LISModels::Info[lismodel].Normalization);
   }
   else
   {
      f_mod->SetParameter(4 + Info[modmodel].nParameters, LISModels::Info[lismodel].Normalization);
      f_mod->SetParLimits(4 + Info[modmodel].nParameters, LISModels::Info[lismodel].Normalization < 1. ? 0.01 : 5,
         LISModels::Info[lismodel].Normalization < 1. ? 1. : (LISModels::Info[lismodel].Normalization < 1e4 ? 1e5 : (LISModels::Info[lismodel].Normalization < 1e5 ? 1e5 : 1e6)));
   }

   for (UShort_t ipar = 0; ipar < LISModels::Info[lismodel].nParameters; ++ipar)
   {
      f_mod->SetParName(5 + Info[modmodel].nParameters + ipar, LISModels::Info[lismodel].Parameter[ipar].Name);
      if (fixlis)
      {
         f_mod->FixParameter(5 + Info[modmodel].nParameters + ipar, LISModels::Info[lismodel].Parameter[ipar].Med);
      }
      else
      {
         f_mod->SetParameter(5 + Info[modmodel].nParameters + ipar, LISModels::Info[lismodel].Parameter[ipar].Med);
         f_mod->SetParLimits(5 + Info[modmodel].nParameters + ipar, LISModels::Info[lismodel].Parameter[ipar].Min, LISModels::Info[lismodel].Parameter[ipar].Max);
      }
   }

   return f_mod;
}

ModulationModels::Model::Model(const Char_t *name, Double_t min_ene, Double_t max_ene, ModulationModels::Type modmodel, LISModels::Type lismodel, Particle::Type particle, Energy::Type energy, Bool_t fixlis) :
   _pars(NULL), _modmodel(modmodel), _lismodel(lismodel), _energy(energy), _particle(particle)
{
   _func = new TF1(name, this, min_ene, max_ene, 1 + Info[_modmodel].nParameters + LISModels::Info[_lismodel].nParameters);
   _pars = new Double_t[_func->GetNpar() + 1];
   _pars[0] = _lismodel;

   for (UShort_t ipar = 0; ipar < Info[_modmodel].nParameters; ++ipar)
   {
      _func->SetParName(ipar, Info[_modmodel].Parameter[ipar].Name);
      _func->SetParameter(ipar, Info[_modmodel].Parameter[ipar].Med);
      _func->SetParLimits(ipar, Info[_modmodel].Parameter[ipar].Min, Info[_modmodel].Parameter[ipar].Max);
   }

   _func->SetParName(Info[_modmodel].nParameters, "norm");
   if (fixlis)
   {
      _func->FixParameter(Info[_modmodel].nParameters, LISModels::Info[_lismodel].Normalization);
   }
   else
   {
      _func->SetParameter(Info[_modmodel].nParameters, LISModels::Info[_lismodel].Normalization);
      _func->SetParLimits(Info[_modmodel].nParameters, LISModels::Info[_lismodel].Normalization < 1. ? 0.01 : 5.,
         LISModels::Info[_lismodel].Normalization < 1. ? 1. : (LISModels::Info[_lismodel].Normalization < 1e4 ? 1e5 : (LISModels::Info[_lismodel].Normalization < 1e5 ? 1e5 : 1e6)));
   }

   for (UShort_t ipar = 0; ipar < LISModels::Info[_lismodel].nParameters; ++ipar)
   {
      _func->SetParName(1 + Info[_modmodel].nParameters + ipar, LISModels::Info[_lismodel].Parameter[ipar].Name);
      if (fixlis)
      {
         _func->FixParameter(1 + Info[_modmodel].nParameters + ipar, LISModels::Info[_lismodel].Parameter[ipar].Med);
      }
      else
      {
         _func->SetParameter(1 + Info[_modmodel].nParameters + ipar, LISModels::Info[_lismodel].Parameter[ipar].Med);
         _func->SetParLimits(1 + Info[_modmodel].nParameters + ipar, LISModels::Info[_lismodel].Parameter[ipar].Min, LISModels::Info[_lismodel].Parameter[ipar].Max);
      }
   }

   _func->SetNpx(200);
}

ModulationModels::Model::~Model()
{
   if (_pars != NULL)
   {
      delete[] _pars;
      _pars = NULL;
   }
}

Double_t ModulationModels::Model::operator()(Double_t *x, Double_t *par)
{
   /// parameters:
   ///    0-nmodpars-1   = modulation parameters
   ///    nmodpars       = N: flux normalization [(GeV/GV s m^2 sr)^{-1}]
   ///    nmodpars+1-end = parameters used by the LIS model

   Double_t xx = x[0];

   std::copy(par, par + _func->GetNpar(), _pars + 1);

   return Info[_modmodel].Model(xx, _pars, _particle, _energy);
}

TF1 *ModulationModels::Model::CreateFunction(const Char_t *name, Double_t min_ene, Double_t max_ene, ModulationModels::Type modmodel, LISModels::Type lismodel, Particle::Type particle, Energy::Type energy, Bool_t fixlis)
{
   Model *m = new Model(name, min_ene, max_ene, modmodel, lismodel, particle, energy, fixlis);
   return m->GetTF1Pointer();
}

ModulationModels::ForceField::ForceField(const Char_t *Name, TF1 *LIS, Energy::Type energy, Particle::Type particle) :
   _lis(LIS), _func(NULL),
   _energy(energy), _particle(particle),
   _nmodpars(1)
{
   Double_t xmin = 0.5, xmax = 2e3;
   _lis->GetRange(xmin, xmax);

   _nlispars = _lis->GetNpar();

   _func = new TF1(Name, this, xmin, xmax, _nmodpars + _nlispars);
   _func->SetNpx(1000);
   _func->SetParName(0, "phi");
   _func->SetParameter(0, 0.56);
   _func->SetParLimits(0, 1e-3, 1.3);
   for (UShort_t ipar = 1; ipar <= _nlispars; ++ipar)
   {
      _func->SetParName(ipar, _lis->GetParName(ipar - 1));
      Double_t pl, ph;
      Double_t p = _lis->GetParameter(ipar - 1);
      _lis->GetParLimits(ipar - 1, pl, ph);
      Bool_t fixed = (pl*ph != 0 && pl >= ph);
      if (!fixed)
      {
         _func->SetParameter(ipar, p);
         if (pl*ph != 0) _func->SetParLimits(ipar, pl, ph);
      }
      else
      {
         _func->FixParameter(ipar, p);
      }
   }
}

ModulationModels::ForceField::~ForceField()
{
   if (_func != NULL) delete _func;
}

Double_t ModulationModels::ForceField::operator()(Double_t *x, Double_t *par)
{
   // Force-field approximation
   // dJ(1 AU, T, t)/dT = T(T + 2M) / ((T + Phi(t))(T + Phi(t) + 2M)) dJ(inf, T + Phi(t))/dT
   // Phi = Ze phi
   // [T] = GeV
   // [phi] = GV

   Double_t phi = par[0];

   Double_t Phi = Particle::Z[_particle] * phi;
   Double_t M   = Particle::Mass[_particle]/Unit::GeV;

   Double_t T  = Unit::ConvertEnergyType(x[0], _particle, _energy, SIPrefix::GIGA, Energy::KINETIC);
   Double_t Tp = T + Phi;
   //~ Double_t xp = Unit::ConvertEnergyType(Tp, _particle, Energy::KINETIC, SIPrefix::GIGA, _energy);

   // The force-field approximation is defined as function of T, while data and model can be defined as function of a different type of energy, x
   // There are two jacobians:
   // 1) From dJ(1 AU)/dx to dJ(1 AU)/dT, so we can use the force-field approximation => T -> x, computed in T(x) => variable J defined below
   // 2) From dJ(inf)/dT to dJ(inf)/dx, so we can use the model itself => x -> T, computed in x(T+Phi) = xp
   //    This is computed inside the model function itself, provided we ask the model to be computed as a function of T in T+Phi
   Double_t J = Unit::EnergyJacobian(T, _particle, Energy::KINETIC, SIPrefix::GIGA, _energy);

   _lis->SetParameters(&par[1]);
   return J * T*(T + 2*M) / (Tp*(Tp + 2*M)) * _lis->Eval(Tp);
}

ModulationModels::ModifiedForceField::ModifiedForceField(const Char_t *Name, TF1 *LIS, Energy::Type energy, Particle::Type particle) :
   _lis(LIS), _func(NULL),
   _energy(energy), _particle(particle),
   _nmodpars(4)
{
   Double_t xmin = 0.5, xmax = 2e3;
   _lis->GetRange(xmin, xmax);

   _nlispars = _lis->GetNpar();

   _func = new TF1(Name, this, xmin, xmax, _nmodpars + _nlispars);
   _func->SetNpx(1000);

   _func->SetParName(0, "phi1");
   _func->SetParameter(0, 0.5);
   _func->SetParLimits(0, 0., 2.);

   _func->SetParName(1, "phi2");
   _func->SetParameter(1, 0.57);
   _func->SetParLimits(1, 0., 2);

   _func->SetParName(2, "R1");
   _func->SetParameter(2, 0.5);
   _func->SetParLimits(2, 0., 20.);

   _func->SetParName(3, "R2");
   _func->SetParameter(3, 5.5);
   _func->SetParLimits(3, 20., 1e3);

   for (UShort_t ipar = 0; ipar < _nlispars; ++ipar)
   {
      _func->SetParName(ipar + _nmodpars, _lis->GetParName(ipar));
      Double_t pl, ph;
      Double_t p = _lis->GetParameter(ipar);
      _lis->GetParLimits(ipar, pl, ph);
      Bool_t fixed = (pl*ph != 0 && pl >= ph);
      if (!fixed)
      {
         _func->SetParameter(ipar + _nmodpars, p);
         if (pl*ph != 0) _func->SetParLimits(ipar + _nmodpars, pl, ph);
      }
      else
      {
         _func->FixParameter(ipar + _nmodpars, p);
      }
   }
}

ModulationModels::ModifiedForceField::~ModifiedForceField()
{
   if (_func != NULL) delete _func;
}

Double_t ModulationModels::ModifiedForceField::operator()(Double_t *x, Double_t *par)
{
   // Modified force-field approximation
   // dJ(1 AU, T, t)/dT = T(T + 2M) / ((T + Phi(R,t))(T + Phi(R,t) + 2M)) dJ(inf, T + Phi(R,t))/dT
   // Phi(R) = Ze phi(R)
   // phi = f(R, R1, R2, phi1, phi2)
   // [R] = [R1] = [R2] = GV
   // [phi] = [phi1] = [phi2] = GV

   Double_t phi1 = par[0];
   Double_t phi2 = par[1];
   Double_t R1   = par[2];
   Double_t R2   = par[3];

   Double_t M = Particle::Mass[_particle]/Unit::GeV;

   Double_t R = Unit::ConvertEnergyType(x[0], _particle, _energy, SIPrefix::GIGA, Energy::RIGIDITY);
   Double_t T = Unit::ConvertEnergyType(x[0], _particle, _energy, SIPrefix::GIGA, Energy::KINETIC);

   Double_t r = (R - R1)/(R2 - R1);
   Double_t phi = R < R1 ? phi1 : (R1 <= R && R < R2 ? phi1 + (phi2 - phi1)*r*r*(3 - 2*r) : phi2);
   Double_t Phi = Particle::Z[_particle] * phi;

   Double_t Tp = T + Phi;

   // The force-field approximation is defined as function of T, while data and model can be defined as function of a different type of energy, x
   // There are two jacobians:
   // 1) From dJ(1 AU)/dx to dJ(1 AU)/dT, so we can use the force-field approximation => T -> x, computed in T(x) => variable J defined below
   // 2) From dJ(inf)/dT to dJ(inf)/dx, so we can use the model itself => x -> T, computed in x(T+Phi) = xp
   //    This is computed inside the model function itself, provided we ask the model to be computed as a function of T in T+Phi
   Double_t J = Unit::EnergyJacobian(T, _particle, Energy::KINETIC, SIPrefix::GIGA, _energy);

   _lis->SetParameters(&par[_nmodpars]);
   return J * T*(T + 2*M) / (Tp*(Tp + 2*M)) * _lis->Eval(Tp);
}
