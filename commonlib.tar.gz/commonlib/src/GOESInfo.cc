#include "GOESInfo.hh"
#include "debug.hh"

using Unit::MeV;
using Unit::cm2;
using Unit::sr;
using Unit::s;

const Energy::Type   GOESInfo::EnergyType       = Energy::KINETIC;
const SIPrefix::Type GOESInfo::EnergyPrefix     = SIPrefix::MEGA;
const Energy::Type   GOESInfo::FluxEnergyType   = Energy::KINETIC;
const SIPrefix::Type GOESInfo::FluxEnergyPrefix = SIPrefix::MEGA;
const SIPrefix::Type GOESInfo::FluxLengthPrefix = SIPrefix::CENTI;

const Char_t *GOESInfo::EnergyUnit = "MeV";
const Char_t *GOESInfo::FluxUnit   = "MeV cm";

const Particle::Type GOESInfo::_particle[GOESInfo::nParticles] = { Particle::HELIUM4, Particle::ELECTRON, Particle::PROTON };

const Char_t   *GOESInfo::_detector_name[GOESInfo::nDetectors] = { "EPEAD A", "EPEAD B", "HEPAD" };
const Char_t    GOESInfo::_detector_symb[GOESInfo::nDetectors] = { 'A', 'B', 'H' };

const Char_t *GOESInfo::_dataset_name[GOESInfo::nDataSets] = { "FULL", "AVG1M", "AVG5M", "SCIENCE", "STATUS" };

const Char_t *GOESInfo::_datatype_name[GOESInfo::nDataTypes] = { "UNCORRECTED_RATE", "CORRECTED_RATE", "UNCORRECTED_FLUX", "CORRECTED_FLUX", "DEADTIME_CORRECTED_FLUX", "QUALITY", "DATA_POINTS", "YAW_FLIP" };
const Char_t *GOESInfo::_datatype_title[GOESInfo::nDataTypes] = { "Uncorrected rate", "Corrected rate", "Uncorrected flux", "Corrected flux", "Dead-time corrected flux", "Quality flag", "Data points used for average", "Yaw flip flag" };
const Char_t *GOESInfo::_datatype_abbreviation[GOESInfo::nDataTypes] = { "ucrate", "crate", "ucflux", "cflux", "dtcflux", "qual", "npts", "yaw" };

const UShort_t  GOESInfo::_nbins[GOESInfo::nParticles][GOESInfo::nDataSets] = {
   { 8,  8,  8,  0, 0 }, // HELIUM4
   { 3,  3,  3,  2, 0 }, // ELECTRON
   { 11, 11, 24, 0, 0 }  // PROTON
};
const Double_t  GOESInfo::_bin_time[GOESInfo::nParticles][GOESInfo::nDataSets][GOESInfo::_nMAX_BINs] = { // sec
   { // HELIUM4
      {  32.8*s,  32.8*s,  32.8*s,  32.8*s,  32.8*s,  32.8*s,  32.8*s,  32.8*s }, // FULL
      {  60.0*s,  60.0*s,  60.0*s,  60.0*s,  60.0*s,  60.0*s,  60.0*s,  60.0*s }, // AVG1M
      { 300.0*s, 300.0*s, 300.0*s, 300.0*s, 300.0*s, 300.0*s, 300.0*s, 300.0*s }, // AVG5M
      {},                                                                         // SCIENCE
      {}                                                                          // STATUS
   },
   { // ELECTRON
      {   4.1*s,  16.4*s,  16.4*s }, // FULL
      {  60.0*s,  60.0*s,  60.0*s }, // AVG1M
      { 300.0*s, 300.0*s, 300.0*s }, // AVG5M
      {  60.0*s,  60.0*s },          // SCIENCE
      {}                             // STATUS
   },
   { // PROTON
      {   8.2*s,  32.8*s,  32.8*s,  32.8*s,  32.8*s,  32.8*s,  32.8*s,  32.8*s,  32.8*s,  32.8*s,  32.8*s }, // FULL
      {  60.0*s,  60.0*s,  60.0*s,  60.0*s,  60.0*s,  60.0*s,  60.0*s,  60.0*s,  60.0*s,  60.0*s,  60.0*s }, // AVG1M
      { 300.0*s, 300.0*s, 300.0*s, 300.0*s, 300.0*s, 300.0*s, 300.0*s, 300.0*s, 300.0*s, 300.0*s, 300.0*s,
        300.0*s, 300.0*s, 300.0*s, 300.0*s, 300.0*s, 300.0*s, 300.0*s,
        300.0*s, 300.0*s, 300.0*s, 300.0*s, 300.0*s },                                                       // AVG5M
      {},                                                                                                    // SCIENCE
      {}                                                                                                     // STATUS
   }
};
const Double_t  GOESInfo::_bin_range[GOESInfo::nParticles][GOESInfo::_nMAX_BINs][2] = { // MeV
   { { 3.8, 9.9 }, { 9.9, 21.3 }, { 21.3, 61 }, { 60, 160 }, { 160, 260 }, { 300, 500 }, { 2560, 3400 }, { 3400, 0 } }, // alpha
   { { 0.8, 0 }, { 2, 0 }, { 4, 0 } }, // electrons
   { { 0.74, 4.2 }, { 4.2, 8.7 }, { 8.7, 14.5 }, { 15, 40 }, { 38, 82 }, { 84, 200 }, { 110, 900 }, { 330, 420 }, { 420, 510 }, { 510, 700 }, { 700, 0 },
     { 1.0, 0 }, { 5.0, 0 }, { 10.0, 0 }, { 30.0, 0 }, { 50.0, 0 }, { 60.0, 0 }, { 100.0, 0 },
     { 5.0, 0 }, { 15.0, 0 }, { 30.0, 0 }, { 50.0, 0 }, { 60.0, 0 }, { 100.0, 0 } }  // protons
};
const Double_t  GOESInfo::_bin_center[GOESInfo::nParticles][GOESInfo::_nMAX_BINs] = { // MeV
   { 6.9, 16.1, 41.2, 120.0, 210.0, 435.0, 2980.0, 3400.0 }, // alpha
   { 0.8, 2.0, 4.0, }, // electrons
   { 2.5, 6.5, 11.6, 30.6, 63.1, 165.0, 433.0, 375.0, 465.0, 605.0, 700.0,
     1.0, 5.0, 10.0, 30.0, 50.0, 60.0, 100.0,
     5.0, 15.0, 30.0, 50.0, 60.0, 100.0 }  // protons
};
const Double_t  GOESInfo::_bin_geometrical_factor[GOESInfo::nParticles][GOESInfo::_nMAX_BINs] = { // (cm^2 sr)
   { 0.0561, 0.056, 0.056, 0.21, 0.36, 1.0353, 0.73, 0.73 }, // alpha
   { 0.75, 0.05, 0.056 }, // electrons
   { 0.056, 0.056, 0.056, 0.2084, 0.3295, 1.6293, 1.0620, 0.73, 0.73, 0.7316, 0.73, // protons (cm^2 sr)
     0.056, 0.056, 0.056, 0.2084, 0.3295, 0.3295, 1.6293, // dummy values! not reliable
     0.056, 0.056, 0.056, 0.2084, 0.3295, 0.3295  }                // dummy values! not reliable
};
const Double_t  GOESInfo::_bin_correction_factor[GOESInfo::nParticles][GOESInfo::_nMAX_BINs] = { // corr_fact = wrong_geom_fact / corr_geom_fact; corr_flux = wrong_flux * corr_fact
   { 1., 1., 1., 19.7/21., 1., 1., 189./613., 0.9/0.73 }, // alpha
   { 1., 1., 1. }, // electrons
   { 0.202/0.194, 1., 1., 4.64/5.21, 15.5/14.5, 90./129., 300./839., 67.5/65.7, 67.5/65.7, 162./139., 1565./0.73,
     1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1. }  // protons
};

const UShort_t GOESInfo::_nDATAFILEs[GOESInfo::nDataSets] = {
   9, // FULL
   4, // AVG1M
   5, // AVG5M
   1, // SCIENCE
   1  // STATUS
};
const Char_t *GOESInfo::_DATAFILE_NAME[GOESInfo::nDataSets][GOESInfo::_nMAX_DATAFILEs] = {
   { // FULL
     "g13_epead_a16e_32s.root", "g13_epead_a16w_32s.root",                           // HELIUM4
     "g13_epead_e1ew_4s.root", "g13_epead_e2ew_16s.root", "g13_epead_e3ew_16s.root", // ELECTRON
     "g13_epead_p1ew_8s.root", "g13_epead_p27e_32s.root", "g13_epead_p27w_32s.root", // PROTON
     "g13_hepad_ap_32s.root"                                                         // HELIUM4, PROTON
   },
   { // AVG1M
     "g13_epead_a16ew_1m.root", // HELIUM4
     "g13_epead_e13ew_1m.root", // ELECTRON
     "g13_epead_p17ew_1m.root", // PROTON
     "g13_hepad_ap_1m.root",    // HELIUM4, PROTON
   },
   { // AVG5M
     "g13_epead_a16ew_5m.root", // HELIUM4
     "g13_epead_e13ew_5m.root", // ELECTRON
     "g13_epead_p17ew_5m.root", // PROTON
     "g13_hepad_ap_5m.root",    // HELIUM4, PROTON
     "g13_epead_cpflux_5m.root" // PROTON
   },
   { // SCIENCE
      "g13_epead_e13ew_1m_science_v1.0.0.root" // ELECTRON
   },
   { // STATUS
      "g13_epead_orientation_flag_1m_v1.0.0.root"
   }
};
const UShort_t GOESInfo::_nPARTICLE_DATAFILEs[GOESInfo::nParticles][GOESInfo::nDataSets] = {
   { 3, 2, 2, 0, 0 }, // alpha
   { 3, 1, 1, 1, 0 }, // electron
   { 4, 2, 3, 0, 0 }  // proton
};
const UShort_t GOESInfo::_PARTICLE_DATAFILE[GOESInfo::nParticles][GOESInfo::nDataSets][GOESInfo::_nMAX_DATAFILEs] = {
   { // HELIUM4
      { 0, 1, 8 }, // FULL
      { 0, 3 },    // AVG1M
      { 0, 3 },    // AVG5M
      {},          // SCIENCE
      {}           // STATUS
   },
   { // ELECTRON
      { 2, 3, 4 }, // FULL
      { 1 },       // AVG1M
      { 1 },       // AVG5M
      { 0 },       // SCIENCE
      {}           // STATUS
   },
   { // PROTON
      { 5, 6, 7, 8 }, // FULL
      { 2, 3 },       // AVG1M
      { 2, 3, 4 },    // AVG5M
      {},             // SCIENCE
      {}              // STATUS
   }
};

const Bool_t GOESInfo::_available_channel[GOESInfo::nParticles][GOESInfo::nDataSets][GOESInfo::nDataTypes][GOESInfo::_nMAX_BINs] = {
   { // ALPHA
      { // FULL
         { 0 },                      // UNCORRECTED_RATE
         { 1, 1, 1, 1, 1, 1, 1, 1 }, // CORRECTED_RATE
         { 0 },                      // UNCORRECTED_FLUX
         { 1, 1, 1, 1, 1, 1, 1, 1 }, // CORRECTED_FLUX
         { 0 },                      // DEADTIME_CORRECTED_FLUX
         { 1, 1, 1, 1, 1, 1, 1, 1 }, // QUALITY
         { 0 },                      // DATA_POINTS
         { 0 }                       // YAW_FLIP
      },
      { // AVG1M
         { 0 },                      // UNCORRECTED_RATE
         { 0 },                      // CORRECTED_RATE
         { 0 },                      // UNCORRECTED_FLUX
         { 1, 1, 1, 1, 1, 1, 1, 1 }, // CORRECTED_FLUX
         { 0 },                      // DEADTIME_CORRECTED_FLUX
         { 1, 1, 1, 1, 1, 1, 1, 1 }, // QUALITY
         { 1, 1, 1, 1, 1, 1, 1, 1 }, // DATA_POINTS
         { 0 }                       // YAW_FLIP
      },
      { // AVG5M
         { 0 },                      // UNCORRECTED_RATE
         { 0 },                      // CORRECTED_RATE
         { 0 },                      // UNCORRECTED_FLUX
         { 1, 1, 1, 1, 1, 1, 1, 1 }, // CORRECTED_FLUX
         { 0 },                      // DEADTIME_CORRECTED_FLUX
         { 1, 1, 1, 1, 1, 1, 1, 1 }, // QUALITY
         { 1, 1, 1, 1, 1, 1, 1, 1 }, // DATA_POINTS
         { 0 }                       // YAW_FLIP
      },
      { // SCIENCE
         { 0 }, // UNCORRECTED_RATE
         { 0 }, // CORRECTED_RATE
         { 0 }, // UNCORRECTED_FLUX
         { 0 }, // CORRECTED_FLUX
         { 0 }, // DEADTIME_CORRECTED_FLUX
         { 0 }, // QUALITY
         { 0 }, // DATA_POINTS
         { 0 }  // YAW_FLIP
      },
      { // STATUS
         { 0 }, // UNCORRECTED_RATE
         { 0 }, // CORRECTED_RATE
         { 0 }, // UNCORRECTED_FLUX
         { 0 }, // CORRECTED_FLUX
         { 0 }, // DEADTIME_CORRECTED_FLUX
         { 0 }, // QUALITY
         { 0 }, // DATA_POINTS
         { 0 }  // YAW_FLIP
      }
   },
   { // ELECTRON
      { // FULL
         { 1, 1, 1 }, // UNCORRECTED_RATE
         { 0 },       // CORRECTED_RATE
         { 1, 1, 1 }, // UNCORRECTED_FLUX
         { 0 },       // CORRECTED_FLUX
         { 0 },       // DEADTIME_CORRECTED_FLUX
         { 1, 1, 1 }, // QUALITY
         { 0 },       // DATA_POINTS
         { 0 }        // YAW_FLIP
      },
      { // AVG1M
         { 0 },       // UNCORRECTED_RATE
         { 0 },       // CORRECTED_RATE
         { 1, 1, 1 }, // UNCORRECTED_FLUX
         { 0 },       // CORRECTED_FLUX
         { 0 },       // DEADTIME_CORRECTED_FLUX
         { 1, 1, 1 }, // QUALITY
         { 1, 1, 1 }, // DATA_POINTS
         { 0 }        // YAW_FLIP
      },
      { // AVG5M
         { 0 },       // UNCORRECTED_RATE
         { 0 },       // CORRECTED_RATE
         { 1, 1, 1 }, // UNCORRECTED_FLUX
         { 1, 1, 1 }, // CORRECTED_FLUX
         { 0 },       // DEADTIME_CORRECTED_FLUX
         { 1, 1, 1 }, // QUALITY
         { 1, 1, 1 }, // DATA_POINTS
         { 0 }        // YAW_FLIP
      },
      { // SCIENCE
         { 0 },    // UNCORRECTED_RATE
         { 0 },    // CORRECTED_RATE
         { 0 },    // UNCORRECTED_FLUX
         { 1, 1 }, // CORRECTED_FLUX
         { 1, 1 }, // DEADTIME_CORRECTED_FLUX
         { 1, 1 }, // QUALITY
         { 0 },    // DATA_POINTS
         { 0 }     // YAW_FLIP
      },
      { // STATUS
         { 0 }, // UNCORRECTED_RATE
         { 0 }, // CORRECTED_RATE
         { 0 }, // UNCORRECTED_FLUX
         { 0 }, // CORRECTED_FLUX
         { 0 }, // DEADTIME_CORRECTED_FLUX
         { 0 }, // QUALITY
         { 0 }, // DATA_POINTS
         { 0 }  // YAW_FLIP
      }
   },
   { // PROTON
      { // FULL
         { 1, 1, 1, 1, 1, 1, 1 },             // UNCORRECTED_RATE
         { 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1 }, // CORRECTED_RATE
         { 1, 1, 1, 1, 1, 1, 1 },             // UNCORRECTED_FLUX
         { 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1 }, // CORRECTED_FLUX
         { 0 },                               // DEADTIME_CORRECTED_FLUX
         { 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 }, // QUALITY
         { 0 },                               // DATA_POINTS
         { 0 }                                // YAW_FLIP
      },
      { // AVG1M
         { 0 },                               // UNCORRECTED_RATE
         { 0 },                               // CORRECTED_RATE
         { 1, 1, 1, 1, 1, 1, 1 },             // UNCORRECTED_FLUX
         { 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1 }, // CORRECTED_FLUX
         { 0 },                               // DEADTIME_CORRECTED_FLUX
         { 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 }, // QUALITY
         { 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 }, // DATA_POINTS
         { 0 }                                // YAW_FLIP
      },
      { // AVG5M
         { 0 },                               // UNCORRECTED_RATE
         { 0 },                               // CORRECTED_RATE
         { 1, 1, 1, 1, 1, 1, 1 },             // UNCORRECTED_FLUX
         { 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
           1, 1, 1, 1, 1, 1, 1,
           1, 1, 1, 1, 1, 1 },                // CORRECTED_FLUX
         { 0 },                               // DEADTIME_CORRECTED_FLUX
         { 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
           1, 1, 1, 1, 1, 1, 1,
           1, 1, 1, 1, 1, 1 },                // QUALITY
         { 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 }, // DATA_POINTS
         { 0 }                                // YAW_FLIP
      },
      { // SCIENCE
         { 0 }, // UNCORRECTED_RATE
         { 0 }, // CORRECTED_RATE
         { 0 }, // UNCORRECTED_FLUX
         { 0 }, // CORRECTED_FLUX
         { 0 }, // DEADTIME_CORRECTED_FLUX
         { 0 }, // QUALITY
         { 0 }, // DATA_POINTS
         { 0 }  // YAW_FLIP
      },
      { // STATUS
         { 0 }, // UNCORRECTED_RATE
         { 0 }, // CORRECTED_RATE
         { 0 }, // UNCORRECTED_FLUX
         { 0 }, // CORRECTED_FLUX
         { 0 }, // DEADTIME_CORRECTED_FLUX
         { 0 }, // QUALITY
         { 0 }, // DATA_POINTS
         { 0 }  // YAW_FLIP
      }
   },
};

UShort_t GOESInfo::_nassociated_particles(UShort_t idataset, UShort_t ifile)
{
   UShort_t nparts = 0;
   for (UShort_t iparticle = 0; iparticle < nParticles; ++iparticle)
   {
      for (UShort_t jfile = 0; jfile < _nPARTICLE_DATAFILEs[iparticle][idataset]; ++jfile)
      {
         if (_PARTICLE_DATAFILE[iparticle][idataset][jfile] == ifile)
         {
            ++nparts;
         }
      }
   }

   return nparts;
}

Bool_t GOESInfo::_is_associated(UShort_t idataset, UShort_t ifile, Particle::Type particle)
{
   UShort_t iparticle = iParticle(particle);
   for (UShort_t jfile = 0; jfile < _nPARTICLE_DATAFILEs[iparticle][idataset]; ++jfile)
   {
      if (_PARTICLE_DATAFILE[iparticle][idataset][jfile] == ifile)
      {
         return true;
      }
   }

   return false;
}

Bool_t GOESInfo::_is_associated(Particle::Type particle)
{
   for (UShort_t ipart = 0; ipart < nParticles; ++ipart)
   {
      if (_particle[ipart] == particle) return true;
   }

   return false;
}

UShort_t GOESInfo::detector_index(Detector detector)
{
   return static_cast<UShort_t>(detector);
}
UShort_t GOESInfo::detector_index(Char_t detector)
{
   UShort_t idet = 0;

   for ( ; idet < nDetectors; ++idet)
   {
      if (_detector_symb[idet] == detector) break;
   }

   return idet;
}
UShort_t GOESInfo::detector_index(const Char_t *detector)
{
   UShort_t idet = 0;

   for ( ; idet < nDetectors; ++idet)
   {
      if (strncmp(_detector_name[idet], detector, 10) == 0) break;
   }

   return idet;
}

Particle::Type GOESInfo::Particle(UShort_t iparticle) { return iparticle < nParticles ? _particle[iparticle] : Particle::nPARTICLEs; }
Particle::Type GOESInfo::Particle(const Char_t *particle_name)
{
   Particle::Type particle = Particle::FromName(particle_name);
   for (UShort_t ipart = 0; ipart < nParticles; ++ipart)
   {
      if (_particle[ipart] == particle) return particle;
   }

   return Particle::nPARTICLEs;
}
UShort_t GOESInfo::iParticle(Particle::Type particle)
{
   UShort_t ipart;
   for (ipart = 0; ipart < nParticles; ++ipart)
   {
      if (_particle[ipart] == particle) break;
   }

   return ipart;
}
UShort_t GOESInfo::iParticle(const Char_t *particle_name) { return iParticle(Particle::FromName(particle_name)); }

GOESInfo::DataSet GOESInfo::Dataset(UShort_t idataset) { return idataset < nDataSets ? static_cast<GOESInfo::DataSet>(idataset) : DataSet::nDATASETs; }
GOESInfo::DataSet GOESInfo::Dataset(const Char_t *dataset_name) { return Dataset(iDataset(dataset_name)); }
UShort_t GOESInfo::iDataset(DataSet dataset) { return dataset; }
UShort_t GOESInfo::iDataset(const Char_t *dataset_name)
{
   UShort_t iset = 0;

   for ( ; iset < nDataSets; ++iset)
   {
      if (strncmp(_dataset_name[iset], dataset_name, 7) == 0) break;
   }

   return iset;
}

UShort_t GOESInfo::nBins(UShort_t iparticle, UShort_t idataset) { return _nbins[iparticle][idataset]; }
UShort_t GOESInfo::nBins(Particle::Type particle, UShort_t idataset) { return _nbins[iParticle(particle)][idataset]; }
UShort_t GOESInfo::nBins(const Char_t *particle_name, UShort_t idataset) { return _nbins[iParticle(particle_name)][idataset]; }
UShort_t GOESInfo::nBins(Particle::Type particle, DataSet dataset) { return _nbins[iParticle(particle)][dataset]; }
UShort_t GOESInfo::nBins(const Char_t *particle_name, DataSet dataset) { return _nbins[iParticle(particle_name)][dataset]; }
UShort_t GOESInfo::nBins(Particle::Type particle, const Char_t *dataset_name) { return _nbins[iParticle(particle)][iDataset(dataset_name)]; }
UShort_t GOESInfo::nBins(const Char_t *particle_name, const Char_t *dataset_name) { return _nbins[iParticle(particle_name)][iDataset(dataset_name)]; }

Double_t GOESInfo::BinTime(UShort_t iparticle, UShort_t idataset, UShort_t ibin) { return _bin_time[iparticle][idataset][ibin]; }
Double_t GOESInfo::BinTime(Particle::Type particle, UShort_t idataset, UShort_t ibin) { return _bin_time[iParticle(particle)][idataset][ibin]; }
Double_t GOESInfo::BinTime(const Char_t *particle_name, UShort_t idataset, UShort_t ibin) { return _bin_time[iParticle(particle_name)][idataset][ibin]; }
Double_t GOESInfo::BinTime(Particle::Type particle, DataSet dataset, UShort_t ibin) { return _bin_time[iParticle(particle)][dataset][ibin]; }
Double_t GOESInfo::BinTime(const Char_t *particle_name, DataSet dataset, UShort_t ibin) { return _bin_time[iParticle(particle_name)][dataset][ibin]; }
Double_t GOESInfo::BinTime(Particle::Type particle, const Char_t *dataset_name, UShort_t ibin) { return _bin_time[iParticle(particle)][iDataset(dataset_name)][ibin]; }
Double_t GOESInfo::BinTime(const Char_t *particle_name, const Char_t *dataset_name, UShort_t ibin) { return _bin_time[iParticle(particle_name)][iDataset(dataset_name)][ibin]; }

const Energy::Range GOESInfo::BinRange(UShort_t iparticle, UShort_t ibin) { return (const Energy::Range)_bin_range[iparticle][ibin]; }
const Energy::Range GOESInfo::BinRange(Particle::Type particle, UShort_t ibin) { return (const Energy::Range)_bin_range[iParticle(particle)][ibin]; }
const Energy::Range GOESInfo::BinRange(const Char_t *particle_name, UShort_t ibin) { return (const Energy::Range)_bin_range[iParticle(particle_name)][ibin]; }

const Char_t *GOESInfo::BinRangeName(UShort_t iparticle, UShort_t ibin, Energy::Type energy_type, SIPrefix::Type energy_prefix)
{
   const UShort_t STR_LENGTH = 128;
   static Char_t str_range[nParticles][_nMAX_BINs][STR_LENGTH];

   Double_t xmin = Unit::ConvertEnergyType(_bin_range[iparticle][ibin][0], _particle[iparticle], EnergyType, EnergyPrefix, energy_type);
   Double_t xmax = Unit::ConvertEnergyType(_bin_range[iparticle][ibin][1], _particle[iparticle], EnergyType, EnergyPrefix, energy_type);

   if (xmin == -DBL_MAX)
   {
      strncpy(str_range[iparticle][ibin], "", STR_LENGTH);
   }
   else
   {
      if (_bin_range[iparticle][ibin][1] > 0.)
      {
         snprintf(str_range[iparticle][ibin], STR_LENGTH, "%s - %s %s%s",
            Format::ToPrecision(Unit::ConvertEnergy(xmin, EnergyPrefix, energy_prefix), 3u).c_str(), Format::ToPrecision(Unit::ConvertEnergy(xmax, EnergyPrefix, energy_prefix), 3u).c_str(),
            SIPrefix::Symbol[energy_prefix], Energy::UnitName[energy_type]);
      }
      else
      {
         snprintf(str_range[iparticle][ibin], STR_LENGTH, "> %s %s%s",
            Format::ToPrecision(Unit::ConvertEnergy(xmin, EnergyPrefix, energy_prefix), 3u).c_str(), SIPrefix::Symbol[energy_prefix], Energy::UnitName[energy_type]);
      }
   }

   return str_range[iparticle][ibin];
}
const Char_t *GOESInfo::BinRangeName(Particle::Type particle, UShort_t ibin, Energy::Type energy_type, SIPrefix::Type energy_prefix) { return BinRangeName(iParticle(particle), ibin, energy_type, energy_prefix); }
const Char_t *GOESInfo::BinRangeName(const Char_t *particle_name, UShort_t ibin, Energy::Type energy_type, SIPrefix::Type energy_prefix) { return BinRangeName(iParticle(particle_name), ibin, energy_type, energy_prefix); }
const Char_t *GOESInfo::BinRangeName(UShort_t iparticle, UShort_t ibin, const Char_t *energy_unit)
{
   Energy::Type enetype;
   SIPrefix::Type enepfx;
   if (!Unit::ParseEnergyUnit(energy_unit, enetype, enepfx)) return NULL;

   return BinRangeName(iparticle, ibin, enetype, enepfx);
}
const Char_t *GOESInfo::BinRangeName(Particle::Type particle, UShort_t ibin, const Char_t *energy_unit) { return BinRangeName(iParticle(particle), ibin, energy_unit); }
const Char_t *GOESInfo::BinRangeName(const Char_t *particle_name, UShort_t ibin, const Char_t *energy_unit) { return BinRangeName(iParticle(particle_name), ibin, energy_unit); }

Double_t GOESInfo::BinCenter(UShort_t iparticle, UShort_t ibin) { return _bin_center[iparticle][ibin]; }
Double_t GOESInfo::BinCenter(Particle::Type particle, UShort_t ibin) { return _bin_center[iParticle(particle)][ibin]; }
Double_t GOESInfo::BinCenter(const Char_t *particle_name, UShort_t ibin) { return _bin_center[iParticle(particle_name)][ibin]; }

const Char_t *GOESInfo::BinCenterName(UShort_t iparticle, UShort_t ibin, Energy::Type energy_type, SIPrefix::Type energy_prefix)
{
   const UShort_t STR_LENGTH = 128;
   static Char_t str_center[nParticles][_nMAX_BINs][STR_LENGTH];

   Double_t x = Unit::ConvertEnergyType(_bin_center[iparticle][ibin], _particle[iparticle], EnergyType, EnergyPrefix, energy_type);

   if (x == -DBL_MAX)
   {
      strncpy(str_center[iparticle][ibin], "", STR_LENGTH);
   }
   else
   {
      snprintf(str_center[iparticle][ibin], STR_LENGTH, "%s %s%s",
         Format::ToPrecision(Unit::ConvertEnergy(x, EnergyPrefix, energy_prefix), 3u).c_str(), SIPrefix::Symbol[energy_prefix], Energy::UnitName[energy_type]);
   }

   return str_center[iparticle][ibin];
}
const Char_t *GOESInfo::BinCenterName(Particle::Type particle, UShort_t ibin, Energy::Type energy_type, SIPrefix::Type energy_prefix) { return BinCenterName(iParticle(particle), ibin, energy_type, energy_prefix); }
const Char_t *GOESInfo::BinCenterName(const Char_t *particle_name, UShort_t ibin, Energy::Type energy_type, SIPrefix::Type energy_prefix) { return BinCenterName(iParticle(particle_name), ibin, energy_type, energy_prefix); }
const Char_t *GOESInfo::BinCenterName(UShort_t iparticle, UShort_t ibin, const Char_t *energy_unit)
{
   Energy::Type enetype;
   SIPrefix::Type enepfx;
   if (!Unit::ParseEnergyUnit(energy_unit, enetype, enepfx)) return NULL;

   return BinCenterName(iparticle, ibin, enetype, enepfx);
}
const Char_t *GOESInfo::BinCenterName(Particle::Type particle, UShort_t ibin, const Char_t *energy_unit) { return BinCenterName(iParticle(particle), ibin, energy_unit); }
const Char_t *GOESInfo::BinCenterName(const Char_t *particle_name, UShort_t ibin, const Char_t *energy_unit) { return BinCenterName(iParticle(particle_name), ibin, energy_unit); }

Double_t GOESInfo::BinGeometricalFactor(UShort_t iparticle, UShort_t ibin) { return _bin_geometrical_factor[iparticle][ibin]; }
Double_t GOESInfo::BinGeometricalFactor(Particle::Type particle, UShort_t ibin) { return _bin_geometrical_factor[iParticle(particle)][ibin]; }
Double_t GOESInfo::BinGeometricalFactor(const Char_t *particle_name, UShort_t ibin) { return _bin_geometrical_factor[iParticle(particle_name)][ibin]; }

Double_t GOESInfo::BinFluxFactor(UShort_t iparticle, UShort_t ibin)
{
   Double_t dE = 1.;
   if (_bin_range[iparticle][ibin][1] > 0.)
   {
      dE = _bin_range[iparticle][ibin][1] - _bin_range[iparticle][ibin][0];
   }

   return _bin_geometrical_factor[iparticle][ibin]*dE;
}
Double_t GOESInfo::BinFluxFactor(Particle::Type particle, UShort_t ibin) { return BinFluxFactor(iParticle(particle), ibin); }
Double_t GOESInfo::BinFluxFactor(const Char_t *particle_name, UShort_t ibin) { return BinFluxFactor(iParticle(particle_name), ibin); }

Double_t GOESInfo::BinCorrectionFactor(UShort_t iparticle, UShort_t ibin) { return _bin_correction_factor[iparticle][ibin]; }
Double_t GOESInfo::BinCorrectionFactor(Particle::Type particle, UShort_t ibin) { return _bin_correction_factor[iParticle(particle)][ibin]; }
Double_t GOESInfo::BinCorrectionFactor(const Char_t *particle_name, UShort_t ibin) { return _bin_correction_factor[iParticle(particle_name)][ibin]; }

const Char_t *GOESInfo::DetectorName(UShort_t idetector) { return _detector_name[idetector]; }
const Char_t *GOESInfo::DetectorName(Detector detector) { return _detector_name[detector]; }
const Char_t *GOESInfo::DetectorName(Char_t detector) { return _detector_name[detector_index(detector)]; }

const Char_t *GOESInfo::DatasetName(UShort_t idataset) { return _dataset_name[idataset]; }
const Char_t *GOESInfo::DatasetName(DataSet dataset) { return _dataset_name[dataset]; }

const Char_t *GOESInfo::DatatypeName(UShort_t idatatype) { return _datatype_name[idatatype]; }
const Char_t *GOESInfo::DatatypeName(DataType datatype) { return _datatype_name[datatype]; }

const Char_t *GOESInfo::DatatypeTitle(UShort_t idatatype) { return _datatype_title[idatatype]; }
const Char_t *GOESInfo::DatatypeTitle(DataType datatype) { return _datatype_title[datatype]; }

Char_t GOESInfo::DetectorSymbol(UShort_t idetector) { return _detector_symb[idetector]; }
Char_t GOESInfo::DetectorSymbol(Detector detector) { return _detector_symb[detector]; }
Char_t GOESInfo::DetectorSymbol(const Char_t *detector) { return _detector_symb[detector_index(detector)]; }

GOESInfo::DetectorList &GOESInfo::Detectors(UShort_t iparticle, UShort_t ibin)
{
   static DetectorList detectors;
   detectors.clear();

   if (iparticle == Particle::ELECTRON)
   {
      detectors.push_back(EPEAD_A);
      detectors.push_back(EPEAD_B);
   }
   else if (iparticle == Particle::HELIUM4)
   {
      if (ibin < 6)
      {
         detectors.push_back(EPEAD_A);
         detectors.push_back(EPEAD_B);
      }
      else detectors.push_back(HEPAD);
   }
   else if (iparticle == Particle::PROTON)
   {
      if (7 <= ibin && ibin <= 10) detectors.push_back(HEPAD);
      else
      {
         detectors.push_back(EPEAD_A);
         detectors.push_back(EPEAD_B);
      }
   }

   return detectors;
}
GOESInfo::DetectorList &GOESInfo::Detectors(Particle::Type particle, UShort_t ibin) { return Detectors(iParticle(particle), ibin); }
GOESInfo::DetectorList &GOESInfo::Detectors(const Char_t *particle_name, UShort_t ibin) { return Detectors(iParticle(particle_name), ibin); }
