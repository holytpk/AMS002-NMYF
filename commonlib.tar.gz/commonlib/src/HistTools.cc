#include "HistTools.hh"
#include "debug.hh"
#include "Spline.hh"

#include <TGraphQQ.h>
#include <TFrame.h>
#include <TMethodCall.h>
#include <RVersion.h>

#include <map>

using namespace std;

const UShort_t STR_LENGTH = 128;

class MyFitResult : public ROOT::Fit::FitResult
{
   public:
      MyFitResult(const ROOT::Fit::FitResult &fitresult, TF1 *fit, Int_t *idx = NULL) : ROOT::Fit::FitResult(fitresult)
      {
         #if ROOT_VERSION_CODE >= ROOT_VERSION(6,0,0)
         SetFitFunction(shared_ptr<IModelFunction>(new ROOT::Math::WrappedMultiTF1(*fit, 1)));
         #else
         SetFitFunction(new ROOT::Math::WrappedMultiTF1(*fit, 1));
         #endif
         UseParameters(idx);
      }

      #if ROOT_VERSION_CODE >= ROOT_VERSION(6,0,0)
      void SetFitFunction(shared_ptr<IModelFunction> func) { fFitFunc = func; }
      #else
      void SetFitFunction(IModelFunction * func) { fFitFunc = func; }
      #endif

      void UseParameters(Int_t *idx)
      {
         if (idx == NULL) return;

         UInt_t npars = fFitFunc->NPar();

         // replace the member vectors and maps with new ones that contain only the given parameters
         // parameter indices as indices of the overall Fitter!
         vector<double> params;
         vector<double> errors;
         vector<string> par_names;
         vector< pair<double, double> > param_bounds;
         vector<double> cov_matrix;
         vector<double> global_cc;
         #if ROOT_VERSION_CODE >= ROOT_VERSION(5,34,36)
         // fixed_params is a map from ROOT 5.34/36, instead of a vector
         map<unsigned int, bool> fixed_params;
         #else
         vector<unsigned int> fixed_params;
         #endif
         map<unsigned int, unsigned int> bound_params;
         map<unsigned int, pair<double, double> > minos_errors;

         cov_matrix.reserve(npars*(npars + 1)/2);
         for (UInt_t jpar = 0; jpar < npars; ++jpar)
         {
            UInt_t ipar = idx[jpar];

            params.push_back(fParams[ipar]);
            errors.push_back(fErrors[ipar]);
            par_names.push_back(fParNames[ipar]);
            global_cc.push_back(fGlobalCC[ipar]);
            //~ if (fFixedParams.find(ipar) != fFixedParams.end()) fixed_params.insert(pair<unsigned int, bool>(jpar, fFixedParams[ipar]));
            #if ROOT_VERSION_CODE >= ROOT_VERSION(5,34,36)
            // fixed_params is a map from ROOT 5.34/36, instead of a vector
            if (IsParameterFixed(ipar)) fixed_params.insert(pair<unsigned int, bool>(jpar, fFixedParams[ipar]));
            #else
            if (IsParameterFixed(ipar)) fixed_params[ipar]=1; else fixed_params[ipar]=0;
            #endif
            //~ if (fBoundParams.find(ipar) != fBoundParams.end())
            #if ROOT_VERSION_CODE >= ROOT_VERSION(5,34,36)
            // fParamBounds and fBoundParams are not present in ROOT versions below 5.34/36
            if (IsParameterBound(ipar))
            {
               bound_params.insert(pair<unsigned int, unsigned int>(jpar, param_bounds.size()));
               UInt_t kpar = fBoundParams[ipar];
               param_bounds.push_back(fParamBounds[kpar]);
            }
            #endif
            //~ if (fMinosErrors.find(ipar) != fMinosErrors.end()) minos_errors.insert(pair<unsigned int, pair<double, double>>(jpar, fMinosErrors[ipar]));
            if (HasMinosError(ipar)) minos_errors.insert(pair<unsigned int, pair<double, double>>(jpar, fMinosErrors[ipar]));
         }

         for (UInt_t ipar = 0; ipar < npars; ++ipar)
         {
            UInt_t kpar = idx[ipar];
            for (UInt_t jpar = 0; jpar <= ipar; ++jpar)
            {
               UInt_t lpar = idx[jpar];
               cov_matrix.push_back(CovMatrix(kpar, lpar));
            }
         }

         fParams      = params;
         fErrors      = errors;
         fParNames    = par_names;
         fCovMatrix   = cov_matrix;
         fGlobalCC    = global_cc;
         fFixedParams = fixed_params;
         #if ROOT_VERSION_CODE >= ROOT_VERSION(5,34,36)
         // fParamBounds and fBoundParams are not present in ROOT versions below 5.34/36
         fParamBounds = param_bounds;
         fBoundParams = bound_params;
         #endif
         fMinosErrors = minos_errors;
      }
};


/// === [START] FunctionSum IMPLEMENTATION ===
FunctionSum::FunctionSum(const Char_t *name, Double_t xmin, Double_t xmax) : _name(name), _xmin(xmin), _xmax(xmax), _ntotpars(0), _modified(true), _free_norm(false), _fpointer(NULL)
{
}

void FunctionSum::Add(TF1 *f, Double_t c)
{
   if (_funcs.empty())
   {
      Double_t x1, x2;
      f->GetRange(x1, x2);
      if (_xmin == DBL_MIN) _xmin = x1;
      if (_xmax == DBL_MAX) _xmax = x2;
   }

   _funcs.push_back(f);
   _factors.push_back(c);
   _npars.push_back(f->GetNpar());

   _ntotpars += f->GetNpar() + 1;

   _modified = true;
}

void FunctionSum::CopyParametersToFunctions()
{
   UShort_t offset = _free_norm;
   for (UShort_t ifunc = 0, ipar = 0; ifunc < _funcs.size(); ++ifunc)
   {
      TF1 *f = _funcs[ifunc];
      for (UShort_t jpar = 0; jpar < _npars[ifunc]; ++jpar, ++ipar)
      {
         Double_t p, dp, pl, ph;
         p  = _fpointer->GetParameter(ipar + offset);
         dp = _fpointer->GetParError(ipar + offset);
         _fpointer->GetParLimits(ipar + offset, pl, ph);
         Bool_t fixed = pl*ph != 0. && pl >= ph;
         Bool_t bound = pl < ph;
         if (fixed)
         {
            f->FixParameter(jpar, p);
         }
         else
         {
            f->SetParameter(jpar, p);
            f->SetParError(jpar, dp);
            if (bound)
            {
               f->SetParLimits(jpar, pl, ph);
            }
         }
      }
   }
}

void FunctionSum::Reset()
{
   _ntotpars = 0;
   _modified = true;
   _fpointer = NULL;
   _funcs.clear();
   _npars.clear();
   _factors.clear();
}

void FunctionSum::SetFreeNormalization()
{
   _free_norm = true;
}

void FunctionSum::SetWeight(UShort_t ifunc, Double_t w)
{
   if (ifunc < _funcs.size())
   {
      _factors[ifunc] = w;
      if (_fpointer != NULL)
      {
         UShort_t offset = _free_norm;
         UShort_t ipar = 0;
         for (UShort_t jfunc = 0; jfunc < ifunc; ++jfunc)
         {
            ipar += _npars[jfunc] + 1;
         }
         _fpointer->SetParameter(offset + ipar, _factors[ifunc]);
      }
   }
}

UShort_t FunctionSum::nFunctions()
{
   return _funcs.size();
}

TF1 *FunctionSum::GetTF1Pointer()
{
   if (_modified)
   {
      if (_funcs.size() == 0)
      {
         cerr << Form(" !!! FunctionSum::GetTF1Pointer: no function added, pointer will be NULL") << endl;
      }
      else
      {
         UShort_t offset = _free_norm;
         _fpointer = new TF1(_name.Data(), this, _xmin, _xmax, _ntotpars + offset);
         _fpointer->SetNpx(1000);

         for (UShort_t ifunc = 0, ipar = 0; ifunc < _funcs.size(); ++ifunc)
         {
            TF1 *f = _funcs[ifunc];
            _fpointer->SetParameter(offset + ipar, _factors[ifunc]);
            _fpointer->SetParName(offset + ipar, Form("w%02u", ifunc));
            ++ipar;
            for (UShort_t jpar = 0; jpar < _npars[ifunc]; ++jpar, ++ipar)
            {
               Double_t p, pl, ph;
               p = f->GetParameter(jpar);
               f->GetParLimits(jpar, pl, ph);
               Bool_t fixed = pl*ph != 0. && pl >= ph;
               Bool_t bound = pl < ph;
               if (fixed)
               {
                  _fpointer->FixParameter(ipar + offset, p);
               }
               else
               {
                  _fpointer->SetParameter(ipar + offset, p);
                  if (bound)
                  {
                     _fpointer->SetParLimits(ipar + offset, pl, ph);
                  }
               }
               _fpointer->SetParName(ipar + offset, Form("%s%02u", f->GetParName(jpar), ifunc));
            }
         }
         if (_free_norm)
         {
            _fpointer->SetParName(0, "norm");
         }

         _modified = false;
      }
   }

   return _fpointer;
}

TF1 *FunctionSum::GetFunction(UShort_t ifunc)
{
   if (ifunc < _funcs.size()) return _funcs[ifunc];
   else return NULL;
}

Double_t FunctionSum::operator()(Double_t *x, Double_t *par)
{
   Double_t val = 0.;
   UShort_t offset = _free_norm;

   for (UShort_t ifunc = 0, ipar = 0; ifunc < _funcs.size(); ++ifunc)
   {
      _factors[ifunc] = par[offset + ipar];
      if (_npars[ifunc] > 0)
      {
         val += _factors[ifunc]*_funcs[ifunc]->EvalPar(x, &par[ipar+offset+1]);
      }
      else
      {
         val += _factors[ifunc]*_funcs[ifunc]->Eval(x[0]);
      }
      ipar += _npars[ifunc] + 1;
   }

   return (_free_norm ? par[0] : 1.)*val;
}
/// === [END] FunctionSum IMPLEMENTATION ===



/// === [START] PowerLawInterpolation IMPLEMENTATION ===
PowerLawInterpolation::PowerLawInterpolation(TGraph *g) : logx(NULL), logy(NULL)
{
   N = g->GetN();

   logx = new Double_t[N];
   logy = new Double_t[N];
   for (UInt_t ibin = 0; ibin < N; ++ibin)
   {
      logx[ibin] = log(g->GetX()[ibin]);
      logy[ibin] = log(g->GetY()[ibin]);
   }
}

PowerLawInterpolation::PowerLawInterpolation(TH1 *h) : logx(NULL), logy(NULL)
{
   N = h->GetNbinsX();

   logx = new Double_t[N];
   logy = new Double_t[N];
   for (UInt_t ibin = 0; ibin < N; ++ibin)
   {
      logx[ibin] = log(h->GetXaxis()->GetBinCenterLog(ibin+1));
      logy[ibin] = log(h->GetBinContent(ibin+1));
   }
}

PowerLawInterpolation::PowerLawInterpolation(const PowerLawInterpolation &obj)
{
   N = obj.N;
   logx = new Double_t[N];
   logy = new Double_t[N];
   for (UInt_t i = 0; i < N; ++i)
   {
      logx[i] = obj.logx[i];
      logy[i] = obj.logy[i];
   }
}

PowerLawInterpolation& PowerLawInterpolation::operator=(PowerLawInterpolation obj)
{
   N = obj.N;
   logx = new Double_t[N];
   logy = new Double_t[N];
   for (UInt_t i = 0; i < N; ++i)
   {
      logx[i] = obj.logx[i];
      logy[i] = obj.logy[i];
   }

   return *this;
}

PowerLawInterpolation::~PowerLawInterpolation()
{
   if (logx != NULL) delete [] logx;
   if (logy != NULL) delete [] logy;
}

Double_t PowerLawInterpolation::operator()(Double_t *x, Double_t *par) const
{
   if (x[0] <= 0.) return 0.;

   Double_t lnx = log(x[0]);

   Int_t i = find_nearest(lnx);
   Int_t i1, i2;
   if (i <= 0)
   {
      i1 = 0;
      i2 = 1;
   }
   else if ((UInt_t)i >= N-1)
   {
      i1 = N - 2;
      i2 = N - 1;
   }
   else if (lnx < logx[i])
   {
      i1 = i - 1;
      i2 = i;
   }
   else
   {
      i1 = i;
      i2 = i + 1;
   }

   Double_t lnx1 = logx[i1];
   Double_t lnx2 = logx[i2];
   Double_t lny1 = logy[i1];
   Double_t lny2 = logy[i2];

   return exp(lny1 + (lny2 - lny1) * (lnx - lnx1) / (lnx2 - lnx1));
}

Int_t PowerLawInterpolation::find_nearest(Double_t x) const
{
   Int_t ibin  = 0;
   Int_t count = N;
   Int_t first = 0, step;
   while (count > 0)
   {
      ibin = first;
      step = count/2;
      ibin += step;
      if (logx[ibin] < x)
      {
         first = ++ibin;
         count -= step + 1;
      }
      else
      {
         count = step;
      }
   }

   return ibin;
};
/// === [END] PowerLawInterpolation IMPLEMENTATION ===



/// === [START] TF1 MANIPULATIONS ===
// TGraph -> TF1
static Double_t graph_func(Double_t *x, Double_t *par)
{
   Double_t xx = x[0];

   TGraph *g = (TGraph *)((void *)((ULong64_t)par[0]));

   return g->Eval(xx);
}

TF1 *HistTools::CreateTF1FromGraph(TGraph *g, const Char_t *name, Double_t xmin, Double_t xmax)
{
   Double_t x1, x2;
   GetRange(g, x1, x2);
   if (xmin == DBL_MIN) xmin = x1;
   if (xmax == DBL_MAX) xmax = x2;

   TF1 *f_graph = new TF1(name, graph_func, xmin, xmax, 1);
   f_graph->FixParameter(0, (ULong64_t)((void *)g));

   CopyLineStyle(g, f_graph);
   f_graph->SetNpx(1000);

   return f_graph;
}



// TF1 with TF1, TF1, TF1 with number
TF1 *HistTools::CombineTF1(TF1 *f1, TF1 *f2, CFunctionPtr operation, const Char_t *name, Double_t xmin, Double_t xmax)
{
   Double_t x1min, x1max, x2min, x2max;
   f1->GetRange(x1min, x1max);
   f2->GetRange(x2min, x2max);
   if (xmin == DBL_MIN) xmin = TMath::Min(x1min, x2min);
   if (xmax == DBL_MAX) xmax = TMath::Max(x1max, x2max);

   TF1 *f_comb = new TF1(name, operation, xmin, xmax, 2);
   f_comb->FixParameter(0, (ULong64_t)((void *)f1));
   f_comb->FixParameter(1, (ULong64_t)((void *)f2));

   CopyLineStyle(f1, f_comb);
   f_comb->SetNpx(f1->GetNpx());

   return f_comb;
}

TF1 *HistTools::CombineTF1(TF1 *f, CFunctionPtr operation, const Char_t *name, Double_t xmin, Double_t xmax)
{
   Double_t x1min, x1max;
   f->GetRange(x1min, x1max);
   if (xmin == DBL_MIN) xmin = x1min;
   if (xmax == DBL_MAX) xmax = x1max;

   TF1 *f_comb = new TF1(name, operation, xmin, xmax, 1);
   f_comb->FixParameter(0, (ULong64_t)((void *)f));

   CopyLineStyle(f, f_comb);
   f_comb->SetNpx(f->GetNpx());

   return f_comb;
}

TF1 *HistTools::CombineTF1Const(TF1 *f, Double_t number, CFunctionPtr operation, const Char_t *name, Double_t xmin, Double_t xmax)
{
   Double_t x1min, x1max;
   f->GetRange(x1min, x1max);
   if (xmin == DBL_MIN) xmin = x1min;
   if (xmax == DBL_MAX) xmax = x1max;

   TF1 *f_comb = new TF1(name, operation, xmin, xmax, 2);
   f_comb->SetParameter(0, (ULong64_t)((void *)f));
   f_comb->SetParameter(1, number);

   CopyLineStyle(f, f_comb);
   f_comb->SetNpx(f->GetNpx());

   return f_comb;
}



// Two TF1s operations
Double_t HistTools::Compose(Double_t *x, Double_t *par)
{
   Double_t xx = x[0];

   TF1 *f1 = (TF1 *)((void *)((ULong64_t)par[0]));
   TF1 *f2 = (TF1 *)((void *)((ULong64_t)par[1]));

   return f1->Eval(f2->Eval(xx));
}

Double_t HistTools::Multiply(Double_t *x, Double_t *par)
{
   Double_t xx = x[0];

   TF1 *f1 = (TF1 *)((void *)((ULong64_t)par[0]));
   TF1 *f2 = (TF1 *)((void *)((ULong64_t)par[1]));

   return f1->Eval(xx)*f2->Eval(xx);
}

Double_t HistTools::Divide(Double_t *x, Double_t *par)
{
   Double_t xx = x[0];

   TF1 *f1 = (TF1 *)((void *)((ULong64_t)par[0]));
   TF1 *f2 = (TF1 *)((void *)((ULong64_t)par[1]));

   return f1->Eval(xx)/f2->Eval(xx);
}

Double_t HistTools::Add(Double_t *x, Double_t *par)
{
   Double_t xx = x[0];

   TF1 *f1 = (TF1 *)((void *)((ULong64_t)par[0]));
   TF1 *f2 = (TF1 *)((void *)((ULong64_t)par[1]));

   return f1->Eval(xx) + f2->Eval(xx);
}

Double_t HistTools::Subtract(Double_t *x, Double_t *par)
{
   Double_t xx = x[0];

   TF1 *f1 = (TF1 *)((void *)((ULong64_t)par[0]));
   TF1 *f2 = (TF1 *)((void *)((ULong64_t)par[1]));

   return f1->Eval(xx) - f2->Eval(xx);
}



// Single TF1 operations
Double_t HistTools::Reciprocal(Double_t *x, Double_t *par)
{
   Double_t xx = x[0];

   TF1 *f = (TF1 *)((void *)((ULong64_t)par[0]));

   return 1./f->Eval(xx);
}

Double_t HistTools::Integral(Double_t *x, Double_t *par)
{
   Double_t xx = x[0];

   TF1 *f = (TF1 *)((void *)((ULong64_t)par[0]));

   Double_t x1, x2;
   f->GetRange(x1, x2);

   return f->Integral(x1, xx);
}

Double_t HistTools::Derivative(Double_t *x, Double_t *par)
{
   Double_t xx = x[0];

   TF1 *f = (TF1 *)((void *)((ULong64_t)par[0]));

   return f->Derivative(xx, NULL, 1e-6);
}

Double_t HistTools::Derivative2(Double_t *x, Double_t *par)
{
   Double_t xx = x[0];

   TF1 *f = (TF1 *)((void *)((ULong64_t)par[0]));

   return f->Derivative2(xx, NULL, 1e-6);
}

Double_t HistTools::Derivative3(Double_t *x, Double_t *par)
{
   Double_t xx = x[0];

   TF1 *f = (TF1 *)((void *)((ULong64_t)par[0]));

   return f->Derivative3(xx, NULL, 1e-6);
}

Double_t HistTools::Inverse(Double_t *x, Double_t *par)
{
   Double_t y = x[0];

   TF1 *f = (TF1 *)((void *)((ULong64_t)par[0]));

   return f->GetX(y);
}


// TF1 and number operations
Double_t HistTools::MultiplyConst(Double_t *x, Double_t *par)
{
   Double_t xx = x[0];

   TF1 *f = (TF1 *)((void *)((ULong64_t)par[0]));

   return f->Eval(xx)*par[1];
}

Double_t HistTools::DivideConst(Double_t *x, Double_t *par)
{
   Double_t xx = x[0];

   TF1 *f = (TF1 *)((void *)((ULong64_t)par[0]));

   return f->Eval(xx)/par[1];
}

Double_t HistTools::AddConst(Double_t *x, Double_t *par)
{
   Double_t xx = x[0];

   TF1 *f = (TF1 *)((void *)((ULong64_t)par[0]));

   return f->Eval(xx) + par[1];
}



// Miscellaneous
Bool_t HistTools::IsParameterFixed(const TF1 *f, UShort_t ipar)
{
   Double_t pl, ph;
   f->GetParLimits(ipar, pl, ph);

   return pl*ph != 0. && pl >= ph;
}

Bool_t HistTools::IsParameterBound(const TF1 *f, UShort_t ipar)
{
   Double_t pl, ph;
   f->GetParLimits(ipar, pl, ph);

   return pl < ph;
}

void HistTools::FixParameters(TF1 *f)
{
   for (UShort_t ipar = 0; ipar < f->GetNpar(); ++ipar)
   {
      f->FixParameter(ipar, f->GetParameter(ipar));
   }
}

void HistTools::CopyParameters(TF1 *f_src, TF1 *f_dst, UShort_t first_dst, UShort_t npars, UShort_t first_src, const Char_t *suf, Bool_t force_fixed, Bool_t copy_names)
{
   UShort_t N = npars > 0 ? npars : f_src->GetNpar();
   for (UShort_t ipar = 0; ipar < N; ++ipar)
   {
      Double_t p, dp, pl, ph;
      p  = f_src->GetParameter(first_src + ipar);
      dp = f_src->GetParError(first_src + ipar);
      f_src->GetParLimits(first_src + ipar, pl, ph);
      Bool_t fixed = pl*ph != 0. && pl >= ph;
      Bool_t bound = pl < ph;
      if (fixed || force_fixed)
      {
         f_dst->FixParameter(first_dst + ipar, p);
      }
      else
      {
         f_dst->SetParameter(first_dst + ipar, p);
         f_dst->SetParError(first_dst + ipar, dp);
         if (bound)
         {
            f_dst->SetParLimits(first_dst + ipar, pl, ph);
         }
      }
      if (copy_names)
      {
         if (suf && strlen(suf) > 0)
         {
            f_dst->SetParName(first_dst + ipar, Form("%s%s", f_src->GetParName(first_src + ipar), suf));
         }
         else
         {
            f_dst->SetParName(first_dst + ipar, f_src->GetParName(first_src + ipar));
         }
      }
   }
}

void HistTools::CopyParametersValue(TF1 *f_src, TF1 *f_dst, UShort_t first_dst, UShort_t npars, UShort_t first_src, Bool_t force_fixed)
{
   CopyParameters(f_src, f_dst, first_dst, npars, first_src, "", force_fixed, false);
}

void HistTools::PrintFunction(const TF1 *f)
{
   Double_t x1, x2;
   f->GetRange(x1, x2);
#if ROOT_VERSION_CODE >= ROOT_VERSION(6,0,0)
   printf("[%p] %s : %s -> %s; Npar=%2u; Ndim=%u; Range=(%+12.6g,%+12.6g)\n", f, f->GetName(), f->GetTitle(), f->GetExpFormula().Data(), f->GetNpar(), f->GetNdim(), x1, x2);
#else
   printf("[%p] %s : %s -> %s; Npar=%2u; Ndim=%u; Range=(%+12.6g,%+12.6g)\n", f, f->GetName(), f->GetTitle(), f->GetExpFormula("n").Data(), f->GetNpar(), f->GetNdim(), x1, x2);
#endif
   printf("    Nfitpoints=%3u, Nfreepar=%2u; NDF=%3u, Chi2=%12.6e, Prob=%12.6e\n", f->GetNumberFitPoints(), f->GetNumberFreeParameters(), f->GetNDF(), f->GetChisquare(), f->GetProb());
   TMethodCall *mc = f->GetMethodCall();
   if (mc != NULL)
   {
      printf("    Valid=%d; MethodName=%s; Params=%s; Proto=%s\n", mc->IsValid(), mc->GetMethodName(), mc->GetParams(), mc->GetProto());
   }
   for (UShort_t ipar = 0; ipar < f->GetNpar(); ++ipar)
   {
      Double_t pl, ph;
      f->GetParLimits(ipar, pl, ph);
      Bool_t fixed = IsParameterFixed(f, ipar);
      Bool_t bound = IsParameterBound(f, ipar);
      Char_t bounds[STR_LENGTH];
      if (bound) snprintf(bounds, STR_LENGTH, "[%s, %s]", Format::ToPrecision(pl, 5u).c_str(), Format::ToPrecision(ph, 5u).c_str());
      else snprintf(bounds, STR_LENGTH, "[-inf, +inf]");
      printf("    Par %2u\t%15s = %25s %s\n", ipar, f->GetParName(ipar),
         (fixed || f->GetParError(ipar) == 0.) ? Format::ToPrecision(f->GetParameter(ipar), 5u).c_str() : Format::Measurement(f->GetParameter(ipar), f->GetParError(ipar), (UShort_t)0).c_str(),
         fixed ? "" : bounds);
   }
}
/// === [END] TF1 MANIPULATIONS ===



/// === [START] TH1 AND TGRAPH MANIPULATIONS ===
// Test TObject *
Bool_t HistTools::IsHist(TObject *obj)
{
   return obj->IsA()->InheritsFrom(TH1::Class());
}

Bool_t HistTools::IsGraph(TObject *obj)
{
   return obj->IsA()->InheritsFrom(TGraph::Class());
}



// TObject * conversion
TH1 *HistTools::ToHist(TObject *obj)
{
   return dynamic_cast<TH1 *>(obj);
}

TGraph *HistTools::ToGraph(TObject *obj)
{
   return dynamic_cast<TGraph *>(obj);
}



//
TGraph *HistTools::ScaleNew(TGraph *graph, Double_t norm, const Char_t *suffix)
{
   TGraph *graph_scaled = (TGraph *)graph->Clone();

   if (strlen(graph->GetName()) > 0 && suffix != NULL && strlen(suffix) > 0)
   {
      graph_scaled->SetName(Form("%s%s", graph->GetName(), suffix));
   }

   Scale(graph_scaled, norm);

   return graph_scaled;
}

void HistTools::Scale(TGraph *graph, Double_t norm)
{
   UInt_t npoints = graph->GetN();
   for (UInt_t ipoint = 0; ipoint < npoints; ++ipoint)
   {
      graph->GetY()[ipoint] *= norm;
      if (graph->GetEY() != NULL)
      {
         graph->GetEY()[ipoint] *= norm;
      }
      else if (graph->GetEYlow() != NULL)
      {
         graph->GetEYlow()[ipoint] *= norm;
         graph->GetEYhigh()[ipoint] *= norm;
      }
   }
}



//
TH1 *HistTools::PowerLawRescaleNew(TH1 *hist, Double_t gamma, const Char_t *suffix)
{
   TH1 *hist_rescaled = (TH1 *)hist->Clone(Form("%s%s", hist->GetName(), suffix));

   PowerLawRescale(hist_rescaled, gamma);

   return hist_rescaled;
}

void HistTools::PowerLawRescale(TH1 *hist, Double_t gamma)
{
   for (UInt_t ibin = 1; ibin <= (UInt_t)hist->GetNbinsX(); ++ibin)
   {
      Double_t x1 = hist->GetBinLowEdge(ibin);
      Double_t x2 = hist->GetBinLowEdge(ibin + 1);
      Double_t y  = hist->GetBinContent(ibin);
      Double_t dy = hist->GetBinError(ibin);

      Double_t gamma_integral = 1. - gamma;
      //~ Double_t xc = TMath::Power(TMath::Abs(1./gamma_integral * (TMath::Power(x2, gamma_integral) - TMath::Power(x1, gamma_integral)) / (x2 - x1)), -1./gamma);
      Double_t f = TMath::Abs(gamma_integral * (x2 - x1) / (TMath::Power(x2, gamma_integral) - TMath::Power(x1, gamma_integral)));

      //~ hist->SetBinContent(ibin, y * TMath::Power(xc, gamma));
      //~ hist->SetBinError(ibin, dy * TMath::Power(xc, gamma));
      hist->SetBinContent(ibin, y * f);
      hist->SetBinError(ibin, dy * f);
   }
}



//
void HistTools::Rescale(TGraph *g, TGraph *gnorm)
{
   double m1 = GetMinimum(gnorm);
   double M1 = GetMaximum(gnorm);
   double m2 = GetMinimum(g);
   double M2 = GetMaximum(g);

   Rescale(g, m1, M1, m2, M2);
}

void HistTools::Rescale(TGraph *g, Double_t rmin, Double_t rmax)
{
   Rescale(g, gPad->GetUymin(), gPad->GetUymax(), rmin, rmax);
}

void HistTools::Rescale(TGraph *g, Double_t lmin, Double_t lmax, Double_t rmin, Double_t rmax)
{
   Double_t scale = (lmax - lmin)/(rmax - rmin);

   for (UShort_t ipoint = 0; ipoint < g->GetN(); ++ipoint)
   {
      Double_t y = g->GetY()[ipoint];

      g->GetY()[ipoint] = lmin + (y - rmin)*scale;

      if (g->GetEY() != NULL)
      {
         g->GetEY()[ipoint] *= scale;
      }
      else if (g->GetEYlow() != NULL)
      {
         g->GetEYlow()[ipoint]  *= scale;
         g->GetEYhigh()[ipoint] *= scale;
      }
   }
}



//
TGraph *HistTools::LogXNew(TGraph *graph, const Char_t *suffix)
{
   TGraph *graph_log = (TGraph *)graph->Clone();

   if (strlen(graph->GetName()) > 0 && suffix != NULL && strlen(suffix) > 0)
   {
      graph_log->SetName(Form("%s%s", graph->GetName(), suffix));
   }

   LogX(graph_log);

   return graph_log;
}

TH1 *HistTools::LogXNew(TH1 *hist, const Char_t *suffix)
{
   TH1 *hist_log = (TH1 *)hist->Clone();

   if (strlen(hist->GetName()) > 0 && suffix != NULL && strlen(suffix) > 0)
   {
      hist_log->SetName(Form("%s%s", hist->GetName(), suffix));
   }

   LogX(hist_log);

   return hist_log;
}

void HistTools::LogX(TGraph *graph)
{
   UInt_t npoints = graph->GetN();
   for (UInt_t ipoint = 0; ipoint < npoints; ++ipoint)
   {
      Double_t x = graph->GetX()[ipoint];
      graph->GetX()[ipoint] = TMath::Log(x);
      if (graph->GetEX() != NULL)
      {
         Double_t ex = graph->GetEX()[ipoint];
         graph->GetEX()[ipoint] = TMath::Sqrt(0.5*(TMath::Power(TMath::Log((x+ex)/x), 2) + TMath::Power(TMath::Log(x/(x-ex)), 2)));
      }
      else if (graph->GetEXlow() != NULL)
      {
         Double_t exl = graph->GetEXlow()[ipoint];
         Double_t exu = graph->GetEXhigh()[ipoint];
         graph->GetEXlow()[ipoint]  = TMath::Log(x/(x-exl));
         graph->GetEXhigh()[ipoint] = TMath::Log((x+exu)/x);
      }
   }
}

void HistTools::LogX(TH1 *hist)
{
   Int_t nbins = hist->GetNbinsX();
   TArrayD axis(*(hist->GetXaxis()->GetXbins()));
   for (Int_t ibin = 1; ibin <= nbins + 1; ++ibin)
   {
      axis[ibin - 1] = TMath::Log(hist->GetBinLowEdge(ibin));
   }
   hist->GetXaxis()->Set(nbins, axis.GetArray());

   hist->ResetStats();
}



//
TGraph *HistTools::LogYNew(TGraph *graph, const Char_t *suffix)
{
   TGraph *graph_log = (TGraph *)graph->Clone();

   if (strlen(graph->GetName()) > 0 && suffix != NULL && strlen(suffix) > 0)
   {
      graph_log->SetName(Form("%s%s", graph->GetName(), suffix));
   }

   LogY(graph_log);

   return graph_log;
}

TH1 *HistTools::LogYNew(TH1 *hist, const Char_t *suffix)
{
   TH1 *hist_log = (TH1 *)hist->Clone();

   if (strlen(hist->GetName()) > 0 && suffix != NULL && strlen(suffix) > 0)
   {
      hist_log->SetName(Form("%s%s", hist->GetName(), suffix));
   }

   LogY(hist_log);

   return hist_log;
}

void HistTools::LogY(TGraph *graph)
{
   UInt_t npoints = graph->GetN();
   UInt_t cur_point = 0;
   for (UInt_t ipoint = 0; ipoint < npoints; ++ipoint)
   {
      Double_t y = graph->GetY()[cur_point];
      if (y <= 0)
      {
         graph->RemovePoint(cur_point);
      }
      else
      {
         graph->GetY()[cur_point] = TMath::Log(y);
         if (graph->GetEY() != NULL)
         {
            Double_t ey = graph->GetEY()[cur_point];
            graph->GetEY()[cur_point] = TMath::Sqrt(0.5*(TMath::Power(TMath::Log((y+ey)/y), 2) + TMath::Power(TMath::Log(y/(y-ey)), 2)));
         }
         else if (graph->GetEYlow() != NULL)
         {
            Double_t eyl = graph->GetEYlow()[cur_point];
            Double_t eyu = graph->GetEYhigh()[cur_point];
            graph->GetEYlow()[cur_point]  = TMath::Log(y/(y-eyl));
            graph->GetEYhigh()[cur_point] = TMath::Log((y+eyu)/y);
         }

         ++cur_point;
      }
   }
}

void HistTools::LogY(TH1 *hist)
{
   Int_t nbinsx = hist->GetNbinsX();
   Int_t nbinsy = hist->GetNbinsY();
   Int_t nbinsz = hist->GetNbinsZ();

   if (hist->GetDimension() < 2) nbinsy = -1;
   if (hist->GetDimension() < 3) nbinsz = -1;

   Int_t ibin;
   for (Int_t ibinz = 0; ibinz <= nbinsz + 1; ++ibinz)
   {
      for (Int_t ibiny = 0; ibiny <= nbinsy + 1; ++ibiny)
      {
         for (Int_t ibinx = 0; ibinx <= nbinsx + 1; ++ibinx)
         {
            ibin = hist->GetBin(ibinx, ibiny, ibinz);

            Double_t y  = hist->GetBinContent(ibin);
            Double_t ey = hist->GetBinError(ibin);

            if (y > 0.)
            {
               hist->SetBinContent(ibin, TMath::Log(y));
               hist->SetBinError(ibin, TMath::Sqrt(0.5*(TMath::Power(TMath::Log((y+ey)/y), 2) + TMath::Power(TMath::Log(y/(y-ey)), 2))));
            }
            else
            {
               hist->SetBinContent(ibin, -DBL_MAX);
               hist->SetBinError(ibin, 0.);
            }
         }
      }
   }

   hist->ResetStats();
}



//
TGraph *HistTools::ExpXNew(TGraph *graph, const Char_t *suffix)
{
   TGraph *graph_exp = (TGraph *)graph->Clone();

   if (strlen(graph->GetName()) > 0 && suffix != NULL && strlen(suffix) > 0)
   {
      graph_exp->SetName(Form("%s%s", graph->GetName(), suffix));
   }

   ExpX(graph_exp);

   return graph_exp;
}

TH1 *HistTools::ExpXNew(TH1 *hist, const Char_t *suffix)
{
   TH1 *hist_exp = (TH1 *)hist->Clone();

   if (strlen(hist->GetName()) > 0 && suffix != NULL && strlen(suffix) > 0)
   {
      hist_exp->SetName(Form("%s%s", hist->GetName(), suffix));
   }

   ExpX(hist_exp);

   return hist_exp;
}

void HistTools::ExpX(TGraph *graph)
{
   UInt_t npoints = graph->GetN();
   for (UInt_t ipoint = 0; ipoint < npoints; ++ipoint)
   {
      Double_t x = graph->GetX()[ipoint];
      graph->GetX()[ipoint] = TMath::Exp(x);
      if (graph->GetEX() != NULL)
      {
         Double_t ex = graph->GetEX()[ipoint];
         graph->GetEX()[ipoint] = TMath::Sqrt(TMath::Exp(2*x)*TMath::CosH(ex)*(TMath::CosH(ex) - 1));
      }
      else if (graph->GetEXlow() != NULL)
      {
         Double_t exl = graph->GetEXlow()[ipoint];
         Double_t exu = graph->GetEXhigh()[ipoint];
         graph->GetEXlow()[ipoint]  = TMath::Exp(x)*(1 - TMath::Exp(-exl));
         graph->GetEXhigh()[ipoint] = TMath::Exp(x)*(TMath::Exp(exu) - 1);
      }
   }
}

void HistTools::ExpX(TH1 *hist)
{
   Int_t nbins = hist->GetNbinsX();
   TArrayD axis(*(hist->GetXaxis()->GetXbins()));
   for (Int_t ibin = 1; ibin <= nbins + 1; ++ibin)
   {
      axis[ibin - 1] = TMath::Exp(hist->GetBinLowEdge(ibin));
   }
   hist->GetXaxis()->Set(nbins, axis.GetArray());

   hist->ResetStats();
}



//
TGraph *HistTools::ExpYNew(TGraph *graph, const Char_t *suffix)
{
   TGraph *graph_log = (TGraph *)graph->Clone();

   if (strlen(graph->GetName()) > 0 && suffix != NULL && strlen(suffix) > 0)
   {
      graph_log->SetName(Form("%s%s", graph->GetName(), suffix));
   }

   ExpY(graph_log);

   return graph_log;
}

TH1 *HistTools::ExpYNew(TH1 *hist, const Char_t *suffix)
{
   TH1 *hist_log = (TH1 *)hist->Clone();

   if (strlen(hist->GetName()) > 0 && suffix != NULL && strlen(suffix) > 0)
   {
      hist_log->SetName(Form("%s%s", hist->GetName(), suffix));
   }

   ExpY(hist_log);

   return hist_log;
}

void HistTools::ExpY(TGraph *graph)
{
   UInt_t npoints = graph->GetN();
   for (UInt_t ipoint = 0; ipoint < npoints; ++ipoint)
   {
      Double_t y = graph->GetY()[ipoint];
      graph->GetY()[ipoint] = TMath::Exp(y);
      if (graph->GetEY() != NULL)
      {
         Double_t ey = graph->GetEY()[ipoint];
         graph->GetEY()[ipoint] = TMath::Sqrt(TMath::Exp(2*y)*TMath::CosH(ey)*(TMath::CosH(ey) - 1));
      }
      else if (graph->GetEYlow() != NULL)
      {
         Double_t eyl = graph->GetEYlow()[ipoint];
         Double_t eyu = graph->GetEYhigh()[ipoint];
         graph->GetEYlow()[ipoint]  = TMath::Exp(y)*(1 - TMath::Exp(-eyl));
         graph->GetEYhigh()[ipoint] = TMath::Exp(y)*(TMath::Exp(eyu) - 1);
      }
   }
}

void HistTools::ExpY(TH1 *hist)
{
   Int_t nbinsx = hist->GetNbinsX();
   Int_t nbinsy = hist->GetNbinsY();
   Int_t nbinsz = hist->GetNbinsZ();

   if (hist->GetDimension() < 2) nbinsy = -1;
   if (hist->GetDimension() < 3) nbinsz = -1;

   Int_t ibin;
   for (Int_t ibinz = 0; ibinz <= nbinsz + 1; ++ibinz)
   {
      for (Int_t ibiny = 0; ibiny <= nbinsy + 1; ++ibiny)
      {
         for (Int_t ibinx = 0; ibinx <= nbinsx + 1; ++ibinx)
         {
            ibin = hist->GetBin(ibinx, ibiny, ibinz);

            Double_t y  = hist->GetBinContent(ibin);
            Double_t ey = hist->GetBinError(ibin);

            hist->SetBinContent(ibin, TMath::Exp(y));
            hist->SetBinError(ibin, TMath::Sqrt(TMath::Exp(2*y)*TMath::CosH(ey)*(TMath::CosH(ey) - 1)));
         }
      }
   }

   hist->ResetStats();
}



//
TGraph *HistTools::ComposeNew(TGraph *graph, TF1 *func, const Char_t *suffix)
{
   TGraph *graph_comp = (TGraph *)graph->Clone();

   if (strlen(graph->GetName()) > 0 && suffix != NULL && strlen(suffix) > 0)
   {
      graph_comp->SetName(Form("%s%s", graph->GetName(), suffix));
   }

   Compose(graph_comp, func);

   return graph_comp;
}

TH1 *HistTools::ComposeNew(TH1 *hist, TF1 *func, const Char_t *suffix)
{
   TH1 *hist_comp = (TH1 *)hist->Clone();

   if (strlen(hist->GetName()) > 0 && suffix != NULL && strlen(suffix) > 0)
   {
      hist_comp->SetName(Form("%s%s", hist->GetName(), suffix));
   }

   Compose(hist_comp, func);

   return hist_comp;
}

void HistTools::Compose(TGraph *graph, TF1 *func)
{
   UInt_t npoints = graph->GetN();
   for (UInt_t ipoint = 0; ipoint < npoints; ++ipoint)
   {
      Double_t x = graph->GetX()[ipoint];
      graph->GetX()[ipoint] = func->Eval(x);
      if (graph->GetEX() != NULL)
      {
         Double_t ex = graph->GetEX()[ipoint];
         graph->GetEX()[ipoint] = TMath::Sqrt(0.5*(TMath::Power(func->Eval(x + ex) - func->Eval(x), 2) + TMath::Power(func->Eval(x) - func->Eval(x - ex), 2)));
      }
      else if (graph->GetEXlow() != NULL)
      {
         Double_t exl = graph->GetEXlow()[ipoint];
         Double_t exu = graph->GetEXhigh()[ipoint];
         graph->GetEXlow()[ipoint]  = func->Eval(x) - func->Eval(x - exl);
         graph->GetEXhigh()[ipoint] = func->Eval(x + exu) - func->Eval(x);
      }
   }
}

void HistTools::Compose(TH1 *hist, TF1 *func)
{
   Int_t nbins = hist->GetNbinsX();
   TArrayD axis(*(hist->GetXaxis()->GetXbins()));
   for (Int_t ibin = 1; ibin <= nbins + 1; ++ibin)
   {
      axis[ibin - 1] = func->Eval(hist->GetBinLowEdge(ibin));
   }
   hist->GetXaxis()->Set(nbins, axis.GetArray());

   hist->ResetStats();
}



//
TGraph *HistTools::AddNew(TGraph *graph1, Double_t f1, TGraph *graph2, Double_t f2, UShort_t propagate_errors)
{
   TGraph *graph_sum = (TGraph *)graph1->Clone();
   ResetStyle(graph_sum);

   if (Add(graph_sum, f1, graph2, f2, propagate_errors)) return graph_sum;
   else
   {
      delete graph_sum;
      return NULL;
   }
}

TGraph *HistTools::AddNew(TGraph *graph1, Double_t f1, Double_t y, Double_t ey, UShort_t propagate_errors)
{
   TGraph *graph_sum = (TGraph *)graph1->Clone();

   if (Add(graph_sum, f1, y, ey, propagate_errors)) return graph_sum;
   else
   {
      delete graph_sum;
      return NULL;
   }
}

Bool_t HistTools::Add(TGraph *graph1, Double_t f1, const TGraph *graph2, Double_t f2, UShort_t propagate_errors)
{
   if (graph1->GetN() != graph2->GetN())
   {
      std::cerr << FG_RED_B << Form(" !!! HistTools::Add: size mismatch between graph1:%s (%s) and graph2:%s (%s)", graph1->GetName(), graph1->GetTitle(), graph2->GetName(), graph2->GetTitle()) << RESET << std::endl;
      return false;
   }
   if (graph1->IsA() != graph2->IsA())
   {
      std::cerr << FG_RED_B << Form(" !!! HistTools::Add: type mismatch between graph1:%s (%s) and graph2:%s (%s)", graph1->GetName(), graph1->GetTitle(), graph2->GetName(), graph2->GetTitle()) << RESET << std::endl;
      return false;
   }

   UInt_t npoints = graph1->GetN();
   for (UInt_t ipoint = 0; ipoint < npoints; ++ipoint)
   {
      Double_t y1 = graph1->GetY()[ipoint];
      Double_t y2 = graph2->GetY()[ipoint];

      graph1->GetY()[ipoint] = f1*y1 + f2*y2;

      if (graph1->GetEYlow() != NULL)
      {
         Double_t ey1l = graph1->GetEYlow()[ipoint];
         Double_t ey1u = graph1->GetEYhigh()[ipoint];
         Double_t ey2l = graph2->GetEYlow()[ipoint];
         Double_t ey2u = graph2->GetEYhigh()[ipoint];

         if (propagate_errors == 0)
         {
            graph1->GetEYlow()[ipoint]  = 0.;
            graph1->GetEYhigh()[ipoint] = 0.;
         }
         else if (propagate_errors == 1)
         {
            graph1->GetEYlow()[ipoint]  = f1*ey1l;
            graph1->GetEYhigh()[ipoint] = f1*ey1u;
         }
         else if (propagate_errors == 2)
         {
            graph1->GetEYlow()[ipoint]  = TMath::Sqrt(f1*f1*ey1l*ey1l + f2*f2*ey2l*ey2l);
            graph1->GetEYhigh()[ipoint] = TMath::Sqrt(f1*f1*ey1u*ey1u + f2*f2*ey2u*ey2u);
         }
         else if (propagate_errors / 10 == 1)
         {
            if (propagate_errors % 10 == 1)
            {
               graph1->GetEYlow()[ipoint]  = f1*ey1l*f1*ey1l;
               graph1->GetEYhigh()[ipoint] = f1*ey1u*f1*ey1u;
            }
            else if (propagate_errors % 10 == 2)
            {
               graph1->GetEYlow()[ipoint]  = f1*f1*ey1l*ey1l + f2*f2*ey2l*ey2l;
               graph1->GetEYhigh()[ipoint] = f1*f1*ey1u*ey1u + f2*f2*ey2u*ey2u;
            }
         }
      }
      else if (graph1->GetEY() != NULL)
      {
         Double_t ey1 = graph1->GetEY()[ipoint];
         Double_t ey2 = graph2->GetEY()[ipoint];

         if (propagate_errors == 0)
         {
            graph1->GetEY()[ipoint] = 0.;
         }
         else if (propagate_errors == 1)
         {
            graph1->GetEY()[ipoint]  = f1*ey1;
         }
         else if (propagate_errors == 2)
         {
            graph1->GetEY()[ipoint]  = TMath::Sqrt(f1*f1*ey1*ey1 + f2*f2*ey2*ey2);
         }
         else if (propagate_errors / 10 == 1)
         {
            if (propagate_errors % 10 == 1)
            {
               graph1->GetEY()[ipoint]  = f1*ey1*f1*ey1;
            }
            else if (propagate_errors % 10 == 2)
            {
               graph1->GetEY()[ipoint]  = f1*f1*ey1*ey1 + f2*f2*ey2*ey2;
            }
         }
      }
   }

   return true;
}

Bool_t HistTools::Add(TGraph *graph1, Double_t f1, Double_t y, Double_t ey, UShort_t propagate_errors)
{
   UInt_t npoints = graph1->GetN();
   for (UInt_t ipoint = 0; ipoint < npoints; ++ipoint)
   {
      Double_t y1 = graph1->GetY()[ipoint];

      graph1->GetY()[ipoint] = f1*y1 + y;

      if (graph1->GetEYlow() != NULL)
      {
         Double_t ey1l = graph1->GetEYlow()[ipoint];
         Double_t ey1u = graph1->GetEYhigh()[ipoint];
         Double_t ey2l = ey;
         Double_t ey2u = ey;

         if (propagate_errors == 0)
         {
            graph1->GetEYlow()[ipoint]  = 0.;
            graph1->GetEYhigh()[ipoint] = 0.;
         }
         else if (propagate_errors == 1)
         {
            graph1->GetEYlow()[ipoint]  = f1*ey1l;
            graph1->GetEYhigh()[ipoint] = f1*ey1u;
         }
         else if (propagate_errors == 2)
         {
            graph1->GetEYlow()[ipoint]  = TMath::Sqrt(f1*f1*ey1l*ey1l + ey2l*ey2l);
            graph1->GetEYhigh()[ipoint] = TMath::Sqrt(f1*f1*ey1u*ey1u + ey2u*ey2u);
         }
         else if (propagate_errors / 10 == 1)
         {
            if (propagate_errors % 10 == 1)
            {
               graph1->GetEYlow()[ipoint]  = f1*ey1l*f1*ey1l;
               graph1->GetEYhigh()[ipoint] = f1*ey1u*f1*ey1u;
            }
            else if (propagate_errors % 10 == 2)
            {
               graph1->GetEYlow()[ipoint]  = f1*f1*ey1l*ey1l + ey2l*ey2l;
               graph1->GetEYhigh()[ipoint] = f1*f1*ey1u*ey1u + ey2u*ey2u;
            }
         }
      }
      else if (graph1->GetEY() != NULL)
      {
         Double_t ey1 = graph1->GetEY()[ipoint];
         Double_t ey2 = ey;

         if (propagate_errors == 0)
         {
            graph1->GetEY()[ipoint] = 0.;
         }
         else if (propagate_errors == 1)
         {
            graph1->GetEY()[ipoint]  = f1*ey1;
         }
         else if (propagate_errors == 2)
         {
            graph1->GetEY()[ipoint]  = TMath::Sqrt(f1*f1*ey1*ey1 + ey2*ey2);
         }
         else if (propagate_errors / 10 == 1)
         {
            if (propagate_errors % 10 == 1)
            {
               graph1->GetEY()[ipoint] = f1*ey1*f1*ey1;
            }
            else if (propagate_errors % 10 == 2)
            {
               graph1->GetEY()[ipoint] = f1*f1*ey1*ey1 + ey2*ey2;
            }
         }
      }
   }

   return true;
}




//
TGraph *HistTools::SqrtErrorNew(TGraph *graph, const Char_t *suffix)
{
   TGraph *graph_sqrt = (TGraph *)graph->Clone();

   if (strlen(graph->GetName()) > 0 && suffix != NULL && strlen(suffix) > 0)
   {
      graph_sqrt->SetName(Form("%s%s", graph->GetName(), suffix));
   }

   SqrtError(graph_sqrt);

   return graph_sqrt;
}

void HistTools::SqrtError(TGraph *graph)
{
   UInt_t npoints = graph->GetN();
   for (UInt_t ipoint = 0; ipoint < npoints; ++ipoint)
   {
      if (graph->GetEYlow() != NULL)
      {
         Double_t err = graph->GetEYlow()[ipoint];
         graph->GetEYlow()[ipoint] = TMath::Sqrt(err);

         err = graph->GetEYhigh()[ipoint];
         graph->GetEYhigh()[ipoint] = TMath::Sqrt(err);
      }
      else if (graph->GetEY() != NULL)
      {
         Double_t err = graph->GetEY()[ipoint];
         graph->GetEY()[ipoint] = TMath::Sqrt(err);
      }
   }
}




//
TGraph *HistTools::MultiplyNew(TGraph *graph, TF1 *func, UShort_t propagate_errors)
{
   TGraph *graph_mul = (TGraph *)graph->Clone();
   ResetStyle(graph_mul);

   Multiply(graph_mul, func, propagate_errors);

   return graph_mul;
}

TGraph *HistTools::MultiplyNew(TGraph *graph1, TGraph *graph2, UShort_t propagate_errors)
{
   TGraph *graph_mul = (TGraph *)graph1->Clone();
   ResetStyle(graph_mul);

   if (Multiply(graph_mul, graph2, propagate_errors)) return graph_mul;
   else
   {
      delete graph_mul;
      return NULL;
   }
}

void HistTools::Multiply(TGraph *graph, TF1 *func, UShort_t propagate_errors)
{
   UInt_t npoints = graph->GetN();
   for (UInt_t ipoint = 0; ipoint < npoints; ++ipoint)
   {
      Double_t y1 = graph->GetY()[ipoint];
      Double_t y2 = func->Eval(graph->GetX()[ipoint]);

      graph->GetY()[ipoint] = y1*y2;

      if (graph->GetEYlow() != NULL)
      {
         Double_t eyl = graph->GetEYlow()[ipoint];
         Double_t eyu = graph->GetEYhigh()[ipoint];

         if (propagate_errors == 0)
         {
            graph->GetEYlow()[ipoint]  = 0.;
            graph->GetEYhigh()[ipoint] = 0.;
         }
         else if (propagate_errors == 1)
         {
            graph->GetEYlow()[ipoint]  = y2*eyl;
            graph->GetEYhigh()[ipoint] = y2*eyu;
         }
      }
      else if (graph->GetEY() != NULL)
      {
         Double_t ey = graph->GetEY()[ipoint];

         if (propagate_errors == 0)
         {
            graph->GetEY()[ipoint] = 0.;
         }
         else if (propagate_errors == 1)
         {
            graph->GetEY()[ipoint]  = y2*ey;
         }
      }
   }
}

Bool_t HistTools::Multiply(TGraph *graph1, const TGraph *graph2, UShort_t propagate_errors)
{
   if (graph1->GetN() != graph2->GetN())
   {
      std::cerr << FG_RED_B << Form(" !!! HistTools::Multiply: size mismatch between graph1:%s (%s) and graph2:%s (%s)", graph1->GetName(), graph1->GetTitle(), graph2->GetName(), graph2->GetTitle()) << RESET << std::endl;
      return false;
   }
   if (graph1->IsA() != graph2->IsA())
   {
      std::cerr << FG_RED_B << Form(" !!! HistTools::Multiply: type mismatch between graph1:%s (%s) and graph2:%s (%s)", graph1->GetName(), graph1->GetTitle(), graph2->GetName(), graph2->GetTitle()) << RESET << std::endl;
      return false;
   }

   UInt_t npoints = graph1->GetN();
   for (UInt_t ipoint = 0; ipoint < npoints; ++ipoint)
   {
      Double_t y1 = graph1->GetY()[ipoint];
      Double_t y2 = graph2->GetY()[ipoint];

      graph1->GetY()[ipoint] = y1*y2;

      if (graph1->GetEYlow() != NULL)
      {
         Double_t ey1l = graph1->GetEYlow()[ipoint];
         Double_t ey1u = graph1->GetEYhigh()[ipoint];
         Double_t ey2l = graph2->GetEYlow()[ipoint];
         Double_t ey2u = graph2->GetEYhigh()[ipoint];

         if (propagate_errors == 0)
         {
            graph1->GetEYlow()[ipoint]  = 0.;
            graph1->GetEYhigh()[ipoint] = 0.;
         }
         else if (propagate_errors == 1)
         {
            graph1->GetEYlow()[ipoint]  = y2*ey1l;
            graph1->GetEYhigh()[ipoint] = y2*ey1u;
         }
         else if (propagate_errors == 2)
         {
            graph1->GetEYlow()[ipoint]  = TMath::Sqrt(y2*ey1l*y2*ey1l + y1*ey2l*y1*ey2l);
            graph1->GetEYhigh()[ipoint] = TMath::Sqrt(y2*ey1u*y2*ey1u + y1*ey2u*y1*ey2u);
         }
      }
      else if (graph1->GetEY() != NULL)
      {
         Double_t ey1 = graph1->GetEY()[ipoint];
         Double_t ey2 = graph1->GetEY()[ipoint];

         if (propagate_errors == 0)
         {
            graph1->GetEY()[ipoint] = 0.;
         }
         else if (propagate_errors == 1)
         {
            graph1->GetEY()[ipoint]  = y2*ey1;
         }
         else if (propagate_errors == 2)
         {
            graph1->GetEY()[ipoint]  = TMath::Sqrt(y2*ey1*y2*ey1 + y1*ey2*y1*ey2);
         }
      }
   }

   return true;
}




//
TGraph *HistTools::DivideNew(TGraph *graph, TF1 *func, UShort_t propagate_errors)
{
   TGraph *graph_div = (TGraph *)graph->Clone();
   ResetStyle(graph_div);

   Divide(graph_div, func, propagate_errors);

   return graph_div;
}

TGraph *HistTools::DivideNew(TGraph *graph1, TGraph *graph2, UShort_t propagate_errors)
{
   TGraph *graph_div = (TGraph *)graph1->Clone();
   ResetStyle(graph_div);

   if (Divide(graph_div, graph2, propagate_errors)) return graph_div;
   else
   {
      delete graph_div;
      return NULL;
   }
}

void HistTools::Divide(TGraph *graph, TF1 *func, UShort_t propagate_errors)
{
   UInt_t npoints = graph->GetN();
   for (UInt_t ipoint = 0; ipoint < npoints; ++ipoint)
   {
      Double_t y1 = graph->GetY()[ipoint];
      Double_t y2 = func->Eval(graph->GetX()[ipoint]);

      graph->GetY()[ipoint] = y1/y2;

      if (graph->GetEYlow() != NULL)
      {
         Double_t eyl = graph->GetEYlow()[ipoint];
         Double_t eyu = graph->GetEYhigh()[ipoint];

         if (propagate_errors == 0)
         {
            graph->GetEYlow()[ipoint]  = 0.;
            graph->GetEYhigh()[ipoint] = 0.;
         }
         else if (propagate_errors == 1)
         {
            graph->GetEYlow()[ipoint]  = eyl/y2;
            graph->GetEYhigh()[ipoint] = eyu/y2;
         }
      }
      else if (graph->GetEY() != NULL)
      {
         Double_t ey = graph->GetEY()[ipoint];

         if (propagate_errors == 0)
         {
            graph->GetEY()[ipoint] = 0.;
         }
         else if (propagate_errors == 1)
         {
            graph->GetEY()[ipoint]  = ey/y2;
         }
      }
   }
}

Bool_t HistTools::Divide(TGraph *graph1, const TGraph *graph2, UShort_t propagate_errors)
{
   if (graph1->GetN() != graph2->GetN())
   {
      std::cerr << FG_RED_B << Form(" !!! HistTools::Divide: size mismatch between graph1:%s (%s) and graph2:%s (%s)", graph1->GetName(), graph1->GetTitle(), graph2->GetName(), graph2->GetTitle()) << RESET << std::endl;
      return false;
   }
   if (graph1->IsA() != graph2->IsA())
   {
      std::cerr << FG_RED_B << Form(" !!! HistTools::Divide: type mismatch between graph1:%s (%s) and graph2:%s (%s)", graph1->GetName(), graph1->GetTitle(), graph2->GetName(), graph2->GetTitle()) << RESET << std::endl;
      return false;
   }

   UInt_t npoints = graph1->GetN();
   for (UInt_t ipoint = 0; ipoint < npoints; ++ipoint)
   {
      Double_t y1 = graph1->GetY()[ipoint];
      Double_t y2 = graph2->GetY()[ipoint];

      graph1->GetY()[ipoint] = y2 != 0. ? y1/y2 : 0.;

      if (graph1->GetEYlow() != NULL)
      {
         Double_t ey1l = graph1->GetEYlow()[ipoint];
         Double_t ey1u = graph1->GetEYhigh()[ipoint];
         Double_t ey2l = graph2->GetEYlow()[ipoint];
         Double_t ey2u = graph2->GetEYhigh()[ipoint];

         if (propagate_errors == 0)
         {
            graph1->GetEYlow()[ipoint]  = 0.;
            graph1->GetEYhigh()[ipoint] = 0.;
         }
         else if (propagate_errors == 1)
         {
            graph1->GetEYlow()[ipoint]  = y2 != 0. ? ey1l/y2 : 0.;
            graph1->GetEYhigh()[ipoint] = y2 != 0. ? ey1u/y2 : 0.;
         }
         else if (propagate_errors == 2)
         {
            graph1->GetEYlow()[ipoint]  = y2 != 0. ? TMath::Sqrt(ey1l/y2*ey1l/y2 + y1/y2/y2*ey2l*y1/y2/y2*ey2l) : 0.;
            graph1->GetEYhigh()[ipoint] = y2 != 0. ? TMath::Sqrt(ey1u/y2*ey1u/y2 + y1/y2/y2*ey2u*y1/y2/y2*ey2u) : 0.;
         }
      }
      else if (graph1->GetEY() != NULL)
      {
         Double_t ey1 = graph1->GetEY()[ipoint];
         Double_t ey2 = graph2->GetEY()[ipoint];

         if (propagate_errors == 0)
         {
            graph1->GetEY()[ipoint] = 0.;
         }
         else if (propagate_errors == 1)
         {
            graph1->GetEY()[ipoint] = y2 != 0. ? ey1/y2 : 0.;
         }
         else if (propagate_errors == 2)
         {
            graph1->GetEY()[ipoint] = y2 != 0. ? TMath::Sqrt(ey1/y2*ey1/y2 + y1/y2/y2*ey2*y1/y2/y2*ey2) : 0.;
         }
      }
   }

   return true;
}




//
TH1 *HistTools::DivideUnequalNew(TH1 *h1, TH1 *h2, const Char_t *name, Bool_t logx, Bool_t logy)
{
   UShort_t n1 = h1->GetNbinsX();
   UShort_t n2 = h2->GetNbinsX();

   TH1 *h_ratio = (TH1 *)h1->Clone(name);
   h_ratio->Reset("ICESM");

   for (Int_t bin1 = 1; bin1 <= n1; ++bin1)
   {
      Double_t y1 = h1->GetBinContent(bin1);
      if (y1 == 0.) continue;

      Double_t xu1 = h1->GetBinLowEdge(bin1 + 1);
      Double_t x1  = logx ? h1->GetXaxis()->GetBinCenterLog(bin1) : h1->GetBinCenter(bin1);
      Double_t dy1 = h1->GetBinError(bin1);

      Int_t bin2 = h2->FindBin(x1);
      if (bin2 < 1) continue;

      Double_t y2 = h2->GetBinContent(bin2);
      if (y2 == 0.) continue;

      Double_t xu2 = h2->GetBinLowEdge(bin2 + 1);
      Double_t x2  = logx ? h2->GetXaxis()->GetBinCenterLog(bin2) : h1->GetBinCenter(bin2);
      Double_t dy2 = h2->GetBinError(bin2);

      Double_t xi = x1; // interpolation point

      UShort_t bin12, bin22;
      if (xu1 < xu2) // use right bin for h1 and left bin for h2
      {
         bin12 = bin1 < n1 ? bin1 + 1 : (bin1 > 1 ? bin1 - 1 : bin1);
         bin22 = bin2 > 1  ? bin2 - 1 : (bin2 < n2 ? bin2 + 1 : bin2);
      }
      else // use left bin for h1 and right bin for h2
      {
         bin12 = bin1 > 1  ? bin1 - 1 : (bin1 < n1 ? bin1 + 1 : bin1);
         bin22 = bin2 < n2 ? bin2 + 1 : (bin2 > 1 ? bin2 - 1 : bin2);
      }

      Double_t yi1, dyi1, yi2, dyi2;
      if (bin12 == bin1)
      {
         yi1  = y1;
         dyi1 = dy1;
      }
      else
      {
         Double_t x12  = logx ? h1->GetXaxis()->GetBinCenterLog(bin12) : h1->GetBinCenter(bin12);
         Double_t y12  = h1->GetBinContent(bin12);
         Double_t dy12 = h1->GetBinError(bin12);
         Double_t fx1  = logx ? TMath::Log(xi/x1)/TMath::Log(x12/x1) : (xi-x1)/(x12-x1);
         yi1  = logy ? (y1 != 0. ? y1*TMath::Power(y12/y1, fx1) : 0.) : y1 + (y12 - y1)*fx1;
         dyi1 = dy1 + (y12 != 0. ? (y1*dy12/y12 - dy1)*fx1 : 0.);
      }

      if (bin22 == bin2)
      {
         yi2  = y2;
         dyi2 = dy2;
      }
      else
      {
         Double_t x22  = logx ? h2->GetXaxis()->GetBinCenterLog(bin22) : h2->GetBinCenter(bin22);
         Double_t y22  = h2->GetBinContent(bin22);
         Double_t dy22 = h2->GetBinError(bin22);
         Double_t fx2  = logx ? TMath::Log(xi/x2)/TMath::Log(x22/x2) : (xi-x2)/(x22-x2);
         yi2  = logy ? (y2 != 0. ? y2*TMath::Power(y22/y2, fx2) : 0.) : y2 + (y22 - y2)*fx2;
         dyi2 = dy2 + (y22 != 0. ? (y2*dy22/y22 - dy2)*fx2 : 0.);
      }

      Double_t r  = yi2 > 0. ? yi1 / yi2 : 0.;
      Double_t dr = r > 0. ? r*TMath::Sqrt(dyi1/yi1*dyi1/yi1 + dyi2/yi2*dyi2/yi2) : 0.;

      h_ratio->SetBinContent(bin1, r);
      h_ratio->SetBinError(bin1, dr);
   }

   return h_ratio;
}

TGraph *HistTools::DivideUnequalNew(TGraph *g1, TGraph *g2, const Char_t *name, Bool_t logx, Bool_t logy)
{
   UShort_t n1 = g1->GetN();
   UShort_t n2 = g2->GetN();

   TGraph *g_ratio = (TGraph *)g1->Clone(name);

   for (Int_t bin1 = 0; bin1 < n1; ++bin1)
   {
      Double_t x1, y1;
      g1->GetPoint(bin1, x1, y1);
      if (y1 == 0.) continue;

      Double_t xu1 = x1;
      Double_t dy1 = 0.;
      if (g1->GetEX() != NULL)
      {
         xu1 -= g1->GetEX()[bin1];
         dy1 = g1->GetErrorY(bin1);
      }
      else if (g1->GetEXlow() != NULL)
      {
         xu1 -= g1->GetEXlow()[bin1];
         dy1 = g1->GetErrorY(bin1);
      }

      UInt_t bin2 = HistTools::FindPoint(g2, x1);
      if (bin2 == UINT_MAX) continue;

      Double_t x2, y2;
      g2->GetPoint(bin2, x2, y2);
      if (y2 == 0.) continue;

      Double_t xu2 = x2;
      Double_t dy2 = 0.;
      if (g2->GetEX() != NULL)
      {
         xu2 -= g2->GetEX()[bin2];
         dy2 = g2->GetErrorY(bin2);
      }
      else if (g2->GetEXlow() != NULL)
      {
         xu2 -= g2->GetEXlow()[bin2];
         dy2 = g2->GetErrorY(bin2);
      }

      Double_t xi = x1; // interpolation point

      UShort_t bin12, bin22;
      if (xu1 < xu2) // use right bin for h1 and left bin for h2
      {
         bin12 = bin1 < n1 ? bin1 + 1 : (bin1 > 1 ? bin1 - 1 : bin1);
         bin22 = bin2 > 1  ? bin2 - 1 : (bin2 < n2 ? bin2 + 1 : bin2);
      }
      else // use left bin for h1 and right bin for h2
      {
         bin12 = bin1 > 1  ? bin1 - 1 : (bin1 < n1 ? bin1 + 1 : bin1);
         bin22 = bin2 < n2 ? bin2 + 1 : (bin2 > 1 ? bin2 - 1 : bin2);
      }

      Double_t yi1, dyi1, yi2, dyi2;
      if (bin12 == bin1)
      {
         yi1  = y1;
         dyi1 = dy1;
      }
      else
      {
         Double_t x12, y12;
         g1->GetPoint(bin12, x12, y12);
         Double_t dy12 = (g1->GetEY() != NULL || g1->GetEYlow() != NULL) ? g1->GetErrorY(bin12) : 0.;
         Double_t fx1  = logx ? TMath::Log(xi/x1)/TMath::Log(x12/x1) : (xi-x1)/(x12-x1);
         yi1  = logy ? (y1 != 0. ? y1*TMath::Power(y12/y1, fx1) : 0.) : y1 + (y12 - y1)*fx1;
         dyi1 = dy1 + (y12 != 0. ? (y1*dy12/y12 - dy1)*fx1 : 0.);
      }

      if (bin22 == bin2)
      {
         yi2  = y2;
         dyi2 = dy2;
      }
      else
      {
         Double_t x22, y22;
         g2->GetPoint(bin22, x22, y22);
         Double_t dy22 = (g2->GetEY() != NULL || g2->GetEYlow() != NULL) ? g2->GetErrorY(bin22) : 0.;
         Double_t fx2  = logx ? TMath::Log(xi/x2)/TMath::Log(x22/x2) : (xi-x2)/(x22-x2);
         yi2  = logy ? (y2 != 0. ? y2*TMath::Power(y22/y2, fx2) : 0.) : y2 + (y22 - y2)*fx2;
         dyi2 = dy2 + (y22 != 0. ? (y2*dy22/y22 - dy2)*fx2 : 0.);
      }

      Double_t r  = yi2 > 0. ? yi1 / yi2 : 0.;
      Double_t dr = r > 0. ? r*TMath::Sqrt(dyi1/yi1*dyi1/yi1 + dyi2/yi2*dyi2/yi2) : 0.;

      g_ratio->GetY()[bin1] = r;

      if (g1->GetEY() != NULL)
      {
         g_ratio->GetEY()[bin1] = dr;
      }
      else if (g1->GetEYlow() != NULL)
      {
         g_ratio->GetEYlow()[bin1] = dr;
         g_ratio->GetEYhigh()[bin1] = dr;
      }
   }

   return g_ratio;
}




//
TGraph *HistTools::RelativeDifferenceNew(TGraph *graph1, TGraph *graph2, UShort_t propagate_errors, Bool_t abs)
{
   TGraph *graph_reldiff = (TGraph *)graph1->Clone();
   ResetStyle(graph_reldiff);

   if (RelativeDifference(graph_reldiff, graph2, propagate_errors, abs)) return graph_reldiff;
   else
   {
      delete graph_reldiff;
      return NULL;
   }
}

TH1 *HistTools::RelativeDifferenceNew(TH1 *hist1, TH1 *hist2, UShort_t propagate_errors, Bool_t abs)
{
   TH1 *hist_reldiff = (TH1 *)hist1->Clone();
   ResetStyle(hist_reldiff);

   if (RelativeDifference(hist_reldiff, hist2, propagate_errors, abs)) return hist_reldiff;
   else
   {
      delete hist_reldiff;
      return NULL;
   }
}

Bool_t HistTools::RelativeDifference(TGraph *graph1, TGraph *graph2, UShort_t propagate_errors, Bool_t abs)
{
   if (graph1->GetN() != graph2->GetN())
   {
      std::cerr << FG_RED_B << Form(" !!! HistTools::RelativeDifference: size mismatch between graph1:%s (%s) and graph2:%s (%s)", graph1->GetName(), graph1->GetTitle(), graph2->GetName(), graph2->GetTitle()) << RESET << std::endl;
      return false;
   }
   //~ if (graph1->IsA() != graph2->IsA())
   //~ {
      //~ std::cerr << FG_RED_B << Form(" !!! HistTools::RelativeDifference: type mismatch between graph1:%s (%s) and graph2:%s (%s)", graph1->GetName(), graph1->GetTitle(), graph2->GetName(), graph2->GetTitle()) << RESET << std::endl;
      //~ return false;
   //~ }

   UInt_t npoints = graph1->GetN();
   for (UInt_t ipoint = 0; ipoint < npoints; ++ipoint)
   {
      Double_t y1 = graph1->GetY()[ipoint];
      Double_t y2 = graph2->GetY()[ipoint];

      Double_t rd = y2 != 0. ? y1/y2 - 1. : (y1 == 0. ? 0. : DBL_MAX);
      if (abs && rd < 0.) rd = -rd;
      graph1->GetY()[ipoint] = rd;

      if (graph1->GetEY() != NULL)
      {
         Double_t ey1 = graph1->GetEY()[ipoint];
         Double_t ey2 = graph2->GetEY() != NULL ? graph2->GetEY()[ipoint] : 0.;

         if (propagate_errors == 0)
         {
            graph1->GetEY()[ipoint]  = 0.;
         }
         else if (propagate_errors == 1)
         {
            graph1->GetEY()[ipoint]  = y2 != 0. ? ey1/y2 : 0.;
         }
         else if (propagate_errors == 2)
         {
            graph1->GetEY()[ipoint]  = (y2 != 0. && y1 != 0) ? y1/y2*TMath::Sqrt(ey1*ey1/y1/y1 + ey2*ey2/y2/y2) : 0.;
         }
      }
      else if (graph1->GetEYlow() != NULL)
      {
         Double_t ey1l = graph1->GetEYlow()[ipoint];
         Double_t ey1u = graph1->GetEYhigh()[ipoint];
         Double_t ey2l = graph2->GetEYlow() != NULL ? graph2->GetEYlow()[ipoint] : 0.;
         Double_t ey2u = graph2->GetEYhigh() != NULL ? graph2->GetEYhigh()[ipoint] : 0.;

         if (propagate_errors == 0)
         {
            graph1->GetEYlow()[ipoint]  = 0.;
            graph1->GetEYhigh()[ipoint] = 0.;
         }
         else if (propagate_errors == 1)
         {
            graph1->GetEYlow()[ipoint]  = y2 != 0. ? ey1l/y2 : 0.;
            graph1->GetEYhigh()[ipoint] = y2 != 0. ? ey1u/y2 : 0.;
         }
         else if (propagate_errors == 2)
         {
            graph1->GetEYlow()[ipoint]  = (y2 != 0. && y1 != 0) ? y1/y2*TMath::Sqrt(ey1l*ey1l/y1/y1 + ey2l*ey2l/y2/y2) : 0.;
            graph1->GetEYhigh()[ipoint] = (y2 != 0. && y1 != 0) ? y1/y2*TMath::Sqrt(ey1u*ey1u/y1/y1 + ey2u*ey2u/y2/y2) : 0.;
         }
      }
   }

   return true;
}

Bool_t HistTools::RelativeDifference(TH1 *hist1, TH1 *hist2, UShort_t propagate_errors, Bool_t abs)
{
   if (hist1->GetNbinsX() != hist2->GetNbinsX())
   {
      std::cerr << FG_RED_B << Form(" !!! HistTools::RelativeDifference: size mismatch between hist1:%s (%s) and hist2:%s (%s)", hist1->GetName(), hist1->GetTitle(), hist2->GetName(), hist2->GetTitle()) << RESET << std::endl;
      return false;
   }
   if (hist1->IsA() != hist2->IsA())
   {
      std::cerr << FG_RED_B << Form(" !!! HistTools::RelativeDifference: type mismatch between hist1:%s (%s) and hist2:%s (%s)", hist1->GetName(), hist1->GetTitle(), hist2->GetName(), hist2->GetTitle()) << RESET << std::endl;
      return false;
   }

   UInt_t nbins = hist1->GetNbinsX();
   for (UInt_t ibin = 1; ibin <= nbins; ++ibin)
   {
      Double_t y1 = hist1->GetBinContent(ibin);
      Double_t y2 = hist2->GetBinContent(ibin);

      Double_t rd = y2 != 0. ? y1/y2 - 1. : (y1 == 0. ? 0. : DBL_MAX);
      if (abs && rd < 0.) rd  = -rd;
      hist1->SetBinContent(ibin, rd);

      Double_t ey1 = hist1->GetBinError(ibin);
      Double_t ey2 = hist2->GetBinError(ibin);

      if (propagate_errors == 0)
      {
         hist1->SetBinError(ibin, 0.);
      }
      else if (propagate_errors == 1)
      {
         hist1->SetBinError(ibin, y2 != 0. ? ey1/y2 : 0.);
      }
      else if (propagate_errors == 2)
      {
         hist1->SetBinError(ibin, (y2 != 0. && y1 != 0) ? y1/y2*TMath::Sqrt(ey1*ey1/y1/y1 + ey2*ey2/y2/y2) : 0.);
      }
   }

   return true;
}




//
TGraph *HistTools::RelativeSigmaNew(TGraph *graph1, TGraph *graph2, UShort_t propagate_errors, Bool_t abs)
{
   TGraph *graph_relsigma = (TGraph *)graph1->Clone();
   ResetStyle(graph_relsigma);

   if (RelativeSigma(graph_relsigma, graph2, propagate_errors, abs)) return graph_relsigma;
   else
   {
      delete graph_relsigma;
      return NULL;
   }
}

TH1 *HistTools::RelativeSigmaNew(TH1 *hist1, TH1 *hist2, UShort_t propagate_errors, Bool_t abs)
{
   TH1 *hist_relsigma = (TH1 *)hist1->Clone();
   ResetStyle(hist_relsigma);

   if (RelativeSigma(hist_relsigma, hist2, propagate_errors, abs)) return hist_relsigma;
   else
   {
      delete hist_relsigma;
      return NULL;
   }
}

Bool_t HistTools::RelativeSigma(TGraph *graph1, TGraph *graph2, UShort_t propagate_errors, Bool_t abs)
{
   if (graph1->GetN() != graph2->GetN())
   {
      std::cerr << FG_RED_B << Form(" !!! HistTools::RelativeSigma: size mismatch between graph1:%s (%s) and graph2:%s (%s)", graph1->GetName(), graph1->GetTitle(), graph2->GetName(), graph2->GetTitle()) << RESET << std::endl;
      return false;
   }
   //~ if (graph1->IsA() != graph2->IsA())
   //~ {
      //~ std::cerr << FG_RED_B << Form(" !!! HistTools::RelativeSigma: type mismatch between graph1:%s (%s) and graph2:%s (%s)", graph1->GetName(), graph1->GetTitle(), graph2->GetName(), graph2->GetTitle()) << RESET << std::endl;
      //~ return false;
   //~ }

   UInt_t npoints = graph1->GetN();
   for (UInt_t ipoint = 0; ipoint < npoints; ++ipoint)
   {
      Double_t y1 = graph1->GetY()[ipoint];
      Double_t y2 = graph2->GetY()[ipoint];
      Double_t s  = 1.;

      Double_t rs = y1 - y2;
      if (abs && rs < 0.) rs = -rs;
      graph1->GetY()[ipoint] = rs;

      if (graph1->GetEY() != NULL)
      {
         Double_t ey1 = graph1->GetEY()[ipoint];
         Double_t ey2 = graph2->GetEY() != NULL ? graph2->GetEY()[ipoint] : 0.;

         if (propagate_errors == 1)
         {
            s = ey1;
         }
         else if (propagate_errors == 2)
         {
            s = sqrt(ey1*ey1 + ey2*ey2);
         }

         graph1->GetY()[ipoint] /= s;
         graph1->GetEY()[ipoint] = 0.;
      }
      else if (graph1->GetEYlow() != NULL)
      {
         Double_t ey1l = graph1->GetEYlow()[ipoint];
         Double_t ey1u = graph1->GetEYhigh()[ipoint];
         Double_t ey2l = graph2->GetEYlow() ? graph2->GetEYlow()[ipoint] : 0.;
         Double_t ey2u = graph2->GetEYhigh() ? graph2->GetEYhigh()[ipoint] : 0.;

         Double_t su = 1.;
         if (propagate_errors == 1)
         {
            s  = ey1l;
            su = ey1u;
         }
         else if (propagate_errors == 2)
         {
            s  = sqrt(ey1l*ey1l + ey2l*ey2l);
            su = sqrt(ey1u*ey1u + ey2u*ey2u);
         }

         graph1->GetY()[ipoint] /= sqrt(0.5*(s*s + su*su));
         graph1->GetEYlow()[ipoint]  = 0.;
         graph1->GetEYhigh()[ipoint] = 0.;
      }
   }

   return true;
}

Bool_t HistTools::RelativeSigma(TH1 *hist1, TH1 *hist2, UShort_t propagate_errors, Bool_t abs)
{
   if (hist1->GetNbinsX() != hist2->GetNbinsX())
   {
      std::cerr << FG_RED_B << Form(" !!! HistTools::RelativeSigma: size mismatch between hist1:%s (%s) and hist2:%s (%s)", hist1->GetName(), hist1->GetTitle(), hist2->GetName(), hist2->GetTitle()) << RESET << std::endl;
      return false;
   }
   if (hist1->IsA() != hist2->IsA())
   {
      std::cerr << FG_RED_B << Form(" !!! HistTools::RelativeSigma: type mismatch between hist1:%s (%s) and hist2:%s (%s)", hist1->GetName(), hist1->GetTitle(), hist2->GetName(), hist2->GetTitle()) << RESET << std::endl;
      return false;
   }

   UInt_t nbins = hist1->GetNbinsX();
   for (UInt_t ibin = 1; ibin <= nbins; ++ibin)
   {
      Double_t y1 = hist1->GetBinContent(ibin);
      Double_t y2 = hist2->GetBinContent(ibin);
      Double_t s  = 1.;

      Double_t rs = y1 - y2;
      if (abs && rs < 0.) rs = -rs;

      Double_t ey1 = hist1->GetBinError(ibin);
      Double_t ey2 = hist2->GetBinError(ibin);
      if (propagate_errors == 1)
      {
         s = ey1;
      }
      else if (propagate_errors == 2)
      {
         s = sqrt(ey1*ey1 + ey2*ey2);
      }

      hist1->SetBinContent(ibin, rs / s);
      hist1->SetBinError(ibin, 0.);
   }

   return true;
}




//
TH1 *HistTools::QuadratureDifferenceNew(TH1 *hist1, TH1 *hist2, UShort_t propagate_errors, Double_t min)
{
   TH1 *hist_quaddiff = (TH1 *)hist1->Clone();
   ResetStyle(hist_quaddiff);

   if (QuadratureDifference(hist_quaddiff, hist2, propagate_errors, min)) return hist_quaddiff;
   else
   {
      delete hist_quaddiff;
      return NULL;
   }
}

Bool_t HistTools::QuadratureDifference(TH1 *hist1, TH1 *hist2, UShort_t propagate_errors, Double_t min)
{
   if (hist1->GetNbinsX() != hist2->GetNbinsX())
   {
      std::cerr << FG_RED_B << Form(" !!! HistTools::RelativeDifference: size mismatch between hist1:%s (%s) and hist2:%s (%s)", hist1->GetName(), hist1->GetTitle(), hist2->GetName(), hist2->GetTitle()) << RESET << std::endl;
      return false;
   }
   if (hist1->IsA() != hist2->IsA())
   {
      std::cerr << FG_RED_B << Form(" !!! HistTools::RelativeDifference: type mismatch between hist1:%s (%s) and hist2:%s (%s)", hist1->GetName(), hist1->GetTitle(), hist2->GetName(), hist2->GetTitle()) << RESET << std::endl;
      return false;
   }

   UInt_t nbins = hist1->GetNbinsX();
   for (UInt_t ibin = 1; ibin <= nbins; ++ibin)
   {
      Double_t y1 = hist1->GetBinContent(ibin);
      Double_t y2 = hist2->GetBinContent(ibin);

      Double_t rd = y1*y1 - y2*y2;
      if (rd < 0.) rd = min;
      else rd = TMath::Sqrt(rd);
      hist1->SetBinContent(ibin, rd);

      Double_t ey1 = hist1->GetBinError(ibin);
      Double_t ey2 = hist2->GetBinError(ibin);

      if (propagate_errors == 0)
      {
         hist1->SetBinError(ibin, 0.);
      }
      else if (propagate_errors == 1)
      {
         hist1->SetBinError(ibin, rd > min ? y1*ey1/rd: 0.);
      }
      else if (propagate_errors == 2)
      {
         hist1->SetBinError(ibin, rd > min ? TMath::Sqrt(y1*ey1*y1*ey1/rd/rd + y2*ey2*y2*ey2/rd/rd): 0.);
      }
   }

   return true;
}




//
TH1 *HistTools::QuadratureSumNew(TH1 *hist1, TH1 *hist2, UShort_t propagate_errors)
{
   TH1 *hist_quadsum = (TH1 *)hist1->Clone();
   ResetStyle(hist_quadsum);

   if (QuadratureSum(hist_quadsum, hist2, propagate_errors)) return hist_quadsum;
   else
   {
      delete hist_quadsum;
      return NULL;
   }
}

Bool_t HistTools::QuadratureSum(TH1 *hist1, TH1 *hist2, UShort_t propagate_errors)
{
   if (hist1->GetNbinsX() != hist2->GetNbinsX())
   {
      std::cerr << FG_RED_B << Form(" !!! HistTools::QuadratureSum: size mismatch between hist1:%s (%s) and hist2:%s (%s)", hist1->GetName(), hist1->GetTitle(), hist2->GetName(), hist2->GetTitle()) << RESET << std::endl;
      return false;
   }
   if (hist1->IsA() != hist2->IsA())
   {
      std::cerr << FG_RED_B << Form(" !!! HistTools::QuadratureSum: type mismatch between hist1:%s (%s) and hist2:%s (%s)", hist1->GetName(), hist1->GetTitle(), hist2->GetName(), hist2->GetTitle()) << RESET << std::endl;
      return false;
   }

   UInt_t nbins = hist1->GetNbinsX();
   for (UInt_t ibin = 1; ibin <= nbins; ++ibin)
   {
      Double_t y1 = hist1->GetBinContent(ibin);
      Double_t y2 = hist2->GetBinContent(ibin);

      Double_t s = TMath::Sqrt(y1*y1 + y2*y2);
      hist1->SetBinContent(ibin, s);

      Double_t ey1 = hist1->GetBinError(ibin);
      Double_t ey2 = hist2->GetBinError(ibin);

      if (propagate_errors == 0)
      {
         hist1->SetBinError(ibin, 0.);
      }
      else if (propagate_errors == 1)
      {
         hist1->SetBinError(ibin, y1*ey1/s);
      }
      else if (propagate_errors == 2)
      {
         hist1->SetBinError(ibin, TMath::Sqrt(y1*ey1*y1*ey1/s/s + y2*ey2*y2*ey2/s/s));
      }
   }

   return true;
}




//
TGraph *HistTools::GetGraphFromDerivative(TF1 *f, Bool_t log)
{
   UShort_t npoints = f->GetNpx();
   TGraph *g = new TGraph(npoints);
   HistTools::CopyLineStyle(f, g);

   Double_t xmin, xmax;
   f->GetRange(xmin, xmax);

   Double_t dx = log ? TMath::Power(xmax/xmin, 1./(npoints - 1.)) : (xmax-xmin)/(npoints - 1.);
   for (UShort_t ipoint = 0; ipoint < npoints; ++ipoint)
   {
      Double_t x = log ? xmin*TMath::Power(dx, ipoint+0.5) : xmin + (ipoint+0.5)*dx;
      Double_t y = f->Derivative(x, NULL, 1e-6);

      g->SetPoint(ipoint, x, y);
   }

   return g;
}

TGraph *HistTools::GetGraphFromSecondDerivative(TF1 *f, Bool_t log)
{
   UShort_t npoints = f->GetNpx();
   TGraph *g = new TGraph(npoints);
   HistTools::CopyLineStyle(f, g);

   Double_t xmin, xmax;
   f->GetRange(xmin, xmax);

   Double_t dx = log ? TMath::Power(xmax/xmin, 1./(npoints - 1.)) : (xmax-xmin)/(npoints - 1.);
   for (UShort_t ipoint = 0; ipoint < npoints; ++ipoint)
   {
      Double_t x = log ? xmin*TMath::Power(dx, ipoint+0.5) : xmin + (ipoint+0.5)*dx;
      Double_t y = f->Derivative2(x, NULL, 1e-6);

      g->SetPoint(ipoint, x, y);
   }

   return g;
}

TGraph *HistTools::GetGraphFromIntegral(TF1 *f, Bool_t norm, Bool_t log)
{
   UShort_t npoints = f->GetNpx();
   TGraph *g = new TGraph(npoints);
   HistTools::CopyLineStyle(f, g);

   Double_t xmin, xmax;
   f->GetRange(xmin, xmax);

   Double_t dx = log ? TMath::Power(xmax/xmin, 1./(npoints - 1.)) : (xmax-xmin)/(npoints - 1.);
   Double_t integ = 0.;
   for (UShort_t ipoint = 0; ipoint < npoints; ++ipoint)
   {
      Double_t x = log ? xmin*TMath::Power(dx, ipoint+0.5) : xmin + (ipoint+0.5)*dx;
      Double_t y = integ + f->Integral(log ? x/dx : x - dx, x);
      integ = y;

      g->SetPoint(ipoint, x, y);
   }

   if (norm)
   {
      Scale(g, 1./integ);
   }

   return g;
}


//
TGraph *HistTools::AppendNew(TGraph *graph1, TGraph *graph2)
{
   TGraph *graph_app = (TGraph *)graph1->Clone();
   ResetStyle(graph_app);

   if (Append(graph_app, graph2)) return graph_app;
   else
   {
      delete graph_app;
      return NULL;
   }
}

TH1 *HistTools::AppendNew(TH1 *hist1, TH1 *hist2, const Char_t *name)
{
   TH1 *hist_app = (TH1 *)hist1->Clone(name != NULL && strlen(name) > 0 ? name : Form("%s_append", hist1->GetName()));
   ResetStyle(hist_app);

   if (Append(hist_app, hist2)) return hist_app;
   else
   {
      delete hist_app;
      return NULL;
   }
}

Bool_t HistTools::Append(TGraph *graph1, TGraph *graph2)
{
   if (graph1->IsA() != graph2->IsA())
   {
      std::cerr << FG_RED_B << Form(" !!! HistTools::Append: type mismatch between graph1:%s (%s) and graph2:%s (%s)", graph1->GetName(), graph1->GetTitle(), graph2->GetName(), graph2->GetTitle()) << RESET << std::endl;
      return false;
   }

   UInt_t npoints1 = graph1->GetN();
   UInt_t npoints2 = graph2->GetN();

   graph1->Set(npoints1 + npoints2);
   for (UInt_t ipoint = 0; ipoint < npoints2; ++ipoint)
   {
      graph1->GetX()[npoints1 + ipoint] = graph2->GetX()[ipoint];
      graph1->GetY()[npoints1 + ipoint] = graph2->GetY()[ipoint];

      if (graph1->GetEY() != NULL)
      {
         graph1->GetEX()[npoints1 + ipoint]  = graph2->GetEX()[ipoint];

         graph1->GetEY()[npoints1 + ipoint]  = graph2->GetEY()[ipoint];
      }
      else if (graph1->GetEYlow() != NULL)
      {
         graph1->GetEXlow()[npoints1 + ipoint]  = graph2->GetEXlow()[ipoint];
         graph1->GetEXhigh()[npoints1 + ipoint] = graph2->GetEXhigh()[ipoint];

         graph1->GetEYlow()[npoints1 + ipoint]  = graph2->GetEYlow()[ipoint];
         graph1->GetEYhigh()[npoints1 + ipoint] = graph2->GetEYhigh()[ipoint];
      }
   }

   return true;
}

Bool_t HistTools::Append(TH1 *hist1, TH1 *hist2)
{
   if (hist1->IsA() != hist2->IsA())
   {
      std::cerr << FG_RED_B << Form(" !!! HistTools::Append: type mismatch between hist1:%s (%s) and hist2:%s (%s)", hist1->GetName(), hist1->GetTitle(), hist2->GetName(), hist2->GetTitle()) << RESET << std::endl;
      return false;
   }

   UInt_t nbins1 = hist1->GetNbinsX();
   UInt_t nbins2 = hist2->GetNbinsX();
   if (hist1->GetBinLowEdge(nbins1+1) > hist2->GetBinLowEdge(1))
   {
      std::cerr << FG_RED_B << Form(" !!! HistTools::Append: the first bin of hist2:%s (%s) is lower than the last bin of hist1:%s (%s)", hist2->GetName(), hist2->GetTitle(), hist1->GetName(), hist1->GetTitle()) << RESET << std::endl;
      return false;
   }

   UInt_t nbins = nbins1 + nbins2 + 1;
   Double_t *bins = new Double_t[nbins + 1];
   for (UInt_t ibin = 1; ibin <= nbins1 + 1; ++ibin)
   {
      bins[ibin - 1] = hist1->GetBinLowEdge(ibin);
   }
   for (UInt_t ibin = 1; ibin <= nbins2 + 1; ++ibin)
   {
      bins[nbins1 + ibin] = hist2->GetBinLowEdge(ibin);
   }
   hist1->GetXaxis()->Set(nbins, bins);
   hist1->SetBinsLength(nbins+1);
   hist1->GetSumw2()->Set(nbins+1);

   hist1->SetBinContent(nbins1 + 1, 0.);
   hist1->SetBinError(nbins1 + 1, 0.);
   for (UInt_t ibin = 1; ibin <= nbins2; ++ibin)
   {
      hist1->SetBinContent(nbins1 + 1 + ibin, hist2->GetBinContent(ibin));
      hist1->SetBinError(nbins1 + 1 + ibin, hist2->GetBinError(ibin));
   }

   hist1->ResetStats();

   return true;
}




//
void HistTools::Modify(TGraph *graph, ModifyGraphFuncPtr modify)
{
   for (UInt_t ipoint = 0; ipoint < (UInt_t)graph->GetN(); ++ipoint)
   {
      modify(graph, ipoint);
   }
}

void HistTools::Modify(TH1 *hist, ModifyHistFuncPtr modify)
{
   for (UInt_t ibin = 1; ibin <= (UInt_t)hist->GetNbinsX(); ++ibin)
   {
      modify(hist, ibin);
   }
}




//
void HistTools::InterpolateZeros(TH1 *h, Bool_t logx, Bool_t logy)
{
   UShort_t nbins = h->GetNbinsX();

   if (nbins < 3) return;

   for (UShort_t bin = 1; bin <= nbins; ++bin)
   {
      if (h->GetBinContent(bin) == 0.)
      {
         UShort_t binl, binr;
         if (bin == 1)
         {
            binl = 2;
            binr = 3;
         }
         else if (bin == nbins)
         {
            binl = nbins - 2;
            binr = nbins - 1;
         }
         else
         {
            binl = bin - 1;
            binr = bin + 1;
         }

         Double_t xl  = logx ? h->GetXaxis()->GetBinCenterLog(binl) : h->GetBinCenter(binl);
         Double_t yl  = h->GetBinContent(binl);
         Double_t dyl = h->GetBinError(binl);

         Double_t xr  = logx ? h->GetXaxis()->GetBinCenterLog(binr) : h->GetBinCenter(binr);
         Double_t yr  = h->GetBinContent(binr);
         Double_t dyr = h->GetBinError(binr);

         Double_t xi  = logx ? h->GetXaxis()->GetBinCenterLog(bin) : h->GetBinCenter(bin);
         Double_t fxi = logx ? TMath::Log(xi/xl)/TMath::Log(xr/xl) : (xi-xl)/(xr-xl);
         Double_t yi  = logy ? (yl != 0. ? yl*TMath::Power(yr/yl, fxi) : 0.) : yl + (yr - yl)*fxi;

         // linear interpolation of relative error
         Double_t dyi = dyl + (yr != 0. ? (yl*dyr/yr - dyl)*fxi : 0.);

         h->SetBinContent(bin, yi);
         h->SetBinError(bin, dyi);
      }
   }
}




//
TGraph *HistTools::AverageNew(TGraph *g, vector<UInt_t> &ranges)
{
   TGraph *gav = new TGraph();
   gav->SetTitle(g->GetTitle());

   UShort_t ipoint = 0;
   for (UShort_t irange = 0; irange < ranges.size() - 1; ++irange)
   {
      UInt_t xmin = ranges[irange];
      UInt_t xmax = ranges[irange + 1];

      Double_t ym = 0.;
      UShort_t n = 0;
      for ( ; ipoint < g->GetN(); ++ipoint)
      {
         Double_t x = g->GetX()[ipoint];
         if (x < xmin) continue;
         if (x >= xmax) break;

         ym += g->GetY()[ipoint];
         ++n;
      }

      gav->SetPoint(irange, 0.5*(xmin+xmax), n > 0 ? ym/n : 0.);
   }

   return gav;
}

TGraph *HistTools::AverageNew(TGraph *g, vector<time_t> &ranges)
{
   TGraph *gav = new TGraph();
   gav->SetTitle(g->GetTitle());

   UShort_t ipoint = 0;
   for (UShort_t irange = 0; irange < ranges.size() - 1; ++irange)
   {
      time_t xmin = ranges[irange];
      time_t xmax = ranges[irange + 1];

      Double_t ym = 0.;
      UShort_t n = 0;
      for ( ; ipoint < g->GetN(); ++ipoint)
      {
         Double_t x = g->GetX()[ipoint];
         if (x < xmin) continue;
         if (x >= xmax) break;

         ym += g->GetY()[ipoint];
         ++n;
      }

      gav->SetPoint(irange, 0.5*(xmin+xmax), n > 0 ? ym/n : 0.);
   }

   return gav;
}

TGraph *HistTools::AverageNew(TGraph *g, vector< pair<time_t, time_t> > &ranges)
{
   TGraph *gav = new TGraph(ranges.size());
   gav->SetTitle(g->GetTitle());

   UInt_t ipoint = 0;
   for (UShort_t irange = 0; irange < ranges.size(); ++irange)
   {
      time_t xmin = ranges[irange].first;
      time_t xmax = ranges[irange].second;

      Double_t ym = 0.;
      UInt_t n = 0;
      for ( ; ipoint < (UInt_t)g->GetN(); ++ipoint)
      {
         Double_t x = g->GetX()[ipoint];

         if (x < xmin) continue;
         if (x >= xmax) break;

         ym += g->GetY()[ipoint];
         ++n;
      }

      gav->SetPoint(irange, 0.5*(xmin+xmax), n > 0 ? ym/n : 0.);
   }

   return gav;
}

TGraph *HistTools::AverageNew(TGraph *graph, UInt_t avg_points, const Char_t *suffix)
{
   TGraph *graph_averaged = (TGraph *)graph->Clone();

   if (strlen(graph->GetName()) > 0 && suffix != NULL && strlen(suffix) > 0)
   {
      graph_averaged->SetName(Form("%s%s", graph->GetName(), suffix));
   }

   Average(graph_averaged, avg_points);

   return graph_averaged;
}

void HistTools::Average(TGraph *graph, UInt_t avg_points)
{
   UInt_t npoints = graph->GetN();
   Double_t xdata = 0.;
   Double_t ydata = 0.;
   Double_t err2l = 0.;
   Double_t err2u = 0.;
   for (Short_t ipoint = npoints - 1; ipoint >= 0; --ipoint)
   {
      xdata += graph->GetX()[ipoint];
      ydata += graph->GetY()[ipoint];

      if (graph->GetEY() != NULL)
      {
         err2l += graph->GetEY()[ipoint]*graph->GetEY()[ipoint];
      }
      else if (graph->GetEYlow() != NULL)
      {
         err2l += graph->GetEYlow()[ipoint]*graph->GetEYlow()[ipoint];
         err2u += graph->GetEYhigh()[ipoint]*graph->GetEYhigh()[ipoint];
      }

      if (ipoint % avg_points == 0)
      {
         graph->GetX()[ipoint] = xdata / avg_points;
         graph->GetY()[ipoint] = ydata / avg_points;

         if (graph->GetEY() != NULL)
         {
            graph->GetEY()[ipoint] = TMath::Sqrt(err2l) / avg_points;
         }
         else if (graph->GetEYlow() != NULL)
         {
            graph->GetEYlow()[ipoint]  = TMath::Sqrt(err2l) / avg_points;
            graph->GetEYhigh()[ipoint] = TMath::Sqrt(err2u) / avg_points;
         }

         xdata = ydata = err2l = err2u = 0.;
      }
      else graph->RemovePoint(ipoint);
   }
}




//
TH1 *HistTools::GetAverageHist(const TH1 **hists, UInt_t nhists, const Char_t *name)
{
   TH1 *h_avg = (TH1 *)hists[0]->Clone(name);
   for (UInt_t ihist = 1; ihist < nhists; ++ihist)
   {
      h_avg->Add(hists[ihist]);
   }

   h_avg->Scale(1./nhists);

   return h_avg;
}

TH1 *HistTools::GetAverageHist(std::vector<const TH1 *> &hists, const Char_t *name)
{
   return GetAverageHist(&hists[0], hists.size(), name);
}




//
TGraph *HistTools::GetAverageGraph(const TGraph **graphs, UInt_t ngraphs, const Char_t *name, UShort_t propagate_errors)
{
   if (ngraphs == 0) return NULL;

   TGraph *g_avg;
   if (graphs[0]->GetEY() == NULL && graphs[0]->GetEYlow() == NULL && propagate_errors == 3)
   {
      g_avg = new TGraphErrors(graphs[0]->GetN(), graphs[0]->GetX(), graphs[0]->GetY());
      g_avg->SetName(name);
   }
   else
   {
      g_avg = (TGraph *)graphs[0]->Clone(name);
   }
   UInt_t npoints = g_avg->GetN();

   if (propagate_errors != 1)
   {
      for (UInt_t ipoint = 0; ipoint < npoints; ++ipoint)
      {
         if (propagate_errors == 0)
         {
            if (g_avg->GetEY() != NULL)
            {
               g_avg->GetEY()[ipoint] = 0.;
            }
            else if (g_avg->GetEYlow() != NULL)
            {
               g_avg->GetEYlow()[ipoint]  = 0.;
               g_avg->GetEYhigh()[ipoint] = 0.;
            }
         }
         else if (propagate_errors == 2)
         {
            if (g_avg->GetEY() != NULL)
            {
               Double_t err = g_avg->GetEY()[ipoint];
               g_avg->GetEY()[ipoint] = err*err;
            }
            else if (g_avg->GetEYlow() != NULL)
            {
               Double_t err = g_avg->GetEYlow()[ipoint];
               g_avg->GetEYlow()[ipoint] = err*err;
               err = g_avg->GetEYhigh()[ipoint];
               g_avg->GetEYhigh()[ipoint] = err*err;
            }
         }
         else if (propagate_errors == 3)
         {
            Double_t y = g_avg->GetY()[ipoint];
            if (g_avg->GetEY() != NULL)
            {
               g_avg->GetEY()[ipoint] = y*y;
            }
            else if (g_avg->GetEYlow() != NULL)
            {
               g_avg->GetEYlow()[ipoint] = y*y;
            }
         }
      }
   }

   for (UInt_t igraph = 1; igraph < ngraphs; ++igraph)
   {
      if ((UInt_t)graphs[igraph]->GetN() != npoints)
      {
         std::cerr << FG_RED_B << Form(" !!! HistTools::GetAverageGraph-E-Graph %u '%s' size mismatch (%u != %u)", igraph, graphs[igraph]->GetName(), graphs[igraph]->GetN(), npoints) << RESET << std::endl;

         delete g_avg;
         return NULL;
      }

      if (graphs[igraph]->IsA() != graphs[0]->IsA())
      {
         std::cerr << FG_RED_B << Form(" !!! HistTools::GetAverageGraph-E-Type mismatch between graph %u:%s (%s) and graph 0:%s (%s)", igraph, graphs[igraph]->GetName(), graphs[igraph]->GetTitle(), graphs[0]->GetName(), graphs[0]->GetTitle()) << RESET << std::endl;

         delete g_avg;
         return NULL;
      }

      for (UInt_t ipoint = 0; ipoint < npoints; ++ipoint)
      {
         g_avg->GetY()[ipoint] += graphs[igraph]->GetY()[ipoint];

         if (propagate_errors == 1)
         {
            if (g_avg->GetEY() != NULL)
            {
               g_avg->GetEY()[ipoint] += graphs[igraph]->GetEY()[ipoint];
            }
            else if (g_avg->GetEYlow() != NULL)
            {
               g_avg->GetEYlow()[ipoint]  += graphs[igraph]->GetEYlow()[ipoint];
               g_avg->GetEYhigh()[ipoint] += graphs[igraph]->GetEYhigh()[ipoint];
            }
         }
         else if (propagate_errors == 2)
         {
            if (g_avg->GetEY() != NULL)
            {
               Double_t err = graphs[igraph]->GetEY()[ipoint];
               g_avg->GetEY()[ipoint] += err*err;
            }
            else if (g_avg->GetEYlow() != NULL)
            {
               Double_t err = graphs[igraph]->GetEYlow()[ipoint];
               g_avg->GetEYlow()[ipoint] += err*err;
               err = graphs[igraph]->GetEYhigh()[ipoint];
               g_avg->GetEYhigh()[ipoint] += err*err;
            }
         }
         else if (propagate_errors == 3)
         {
            Double_t y = graphs[igraph]->GetY()[ipoint];
            if (g_avg->GetEY() != NULL)
            {
               g_avg->GetEY()[ipoint] += y*y;
            }
            else if (g_avg->GetEYlow() != NULL)
            {
               g_avg->GetEYlow()[ipoint] += y*y;
            }
         }
      }
   }

   for (UInt_t ipoint = 0; ipoint < npoints; ++ipoint)
   {
      g_avg->GetY()[ipoint] /= ngraphs;

      if (propagate_errors == 1)
      {
         if (g_avg->GetEY() != NULL)
         {
            g_avg->GetEY()[ipoint] /= ngraphs;
         }
         else if (g_avg->GetEYlow() != NULL)
         {
            g_avg->GetEYlow()[ipoint]  /= ngraphs;
            g_avg->GetEYhigh()[ipoint] /= ngraphs;
         }
      }
      else if (propagate_errors == 2)
      {
         if (g_avg->GetEY() != NULL)
         {
            Double_t err = TMath::Sqrt(g_avg->GetEY()[ipoint]);
            g_avg->GetEY()[ipoint] = err / ngraphs;
         }
         else if (g_avg->GetEYlow() != NULL)
         {
            Double_t err = TMath::Sqrt(g_avg->GetEYlow()[ipoint]);
            g_avg->GetEYlow()[ipoint]  = err / ngraphs;
            err = TMath::Sqrt(g_avg->GetEYhigh()[ipoint]);
            g_avg->GetEYhigh()[ipoint] = err / ngraphs;
         }
      }
      else if (propagate_errors == 3)
      {
         Double_t y = g_avg->GetY()[ipoint];
         if (g_avg->GetEY() != NULL)
         {
            Double_t y2 = g_avg->GetEY()[ipoint];
            g_avg->GetEY()[ipoint] = TMath::Sqrt((y2 - ngraphs*y*y) / (ngraphs - 1));
         }
         else if (g_avg->GetEYlow() != NULL)
         {
            Double_t y2 = g_avg->GetEYlow()[ipoint];
            g_avg->GetEYlow()[ipoint] = TMath::Sqrt((y2 - ngraphs*y*y) / (ngraphs - 1));
            g_avg->GetEYhigh()[ipoint] = g_avg->GetEYlow()[ipoint];
         }
      }
   }

   return g_avg;
}

TGraph *HistTools::GetAverageGraph(std::vector<const TGraph *> &graphs, const Char_t *name, UShort_t propagate_errors)
{
   return GetAverageGraph(&graphs[0], graphs.size(), name, propagate_errors);
}




//
TGraph *HistTools::MovingAverage(TGraph *g, UShort_t n, UShort_t type)
{
   TGraph *gma = (TGraph *)g->Clone();

   Int_t wls, wrs; // size of left and right sides of the window
   switch (type)
   {
      case 0:
         wls = n-1;
         wrs = 0;
         break;
      case 2:
         wls = 0;
         wrs = n-1;
         break;
      case 1:
      default:
         wls = n/2;
         wrs = (n-1)/2;
   }

   for (Int_t i = 0; i < g->GetN(); ++i)
   {
      Double_t y(0.), dy(0.), dyl(0.), dyh(0.);
      UShort_t n = 0;

      for (Int_t j = i - wls; j <= i + wrs; ++j)
      {
         if (j < 0) continue;

         y += g->GetY()[j];
         if (g->GetEY() != NULL)
         {
            dy += g->GetEY()[j];
         }
         else if (g->GetEYlow() != NULL)
         {
            dyl += g->GetEYlow()[j];
            dyh += g->GetEYhigh()[j];
         }

         ++n;
      }

      gma->GetY()[i] = y/n;
      if (g->GetEY() != NULL)
      {
         gma->GetEY()[i] = dy/n;
      }
      else if (g->GetEYlow() != NULL)
      {
         gma->GetEYlow()[i]  = dyl/n;
         gma->GetEYhigh()[i] = dyh/n;
      }
   }

   return gma;
}

TH1 *HistTools::MovingAverage(TH1 *h, UShort_t n, UShort_t type)
{
   TH1 *hma = (TH1 *)h->Clone(Form("%s_movavg", h->GetName()));
   hma->Reset("ICESM");

   Int_t wls, wrs; // size of left and right sides of the window
   switch (type)
   {
      case 0:
         wls = n-1;
         wrs = 0;
         break;
      case 2:
         wls = 0;
         wrs = n-1;
         break;
      case 1:
      default:
         wls = n/2;
         wrs = (n-1)/2;
   }

   for (Int_t i = 1; i <= h->GetNbinsX(); ++i)
   {
      Double_t y(0.), dy(0.);
      UShort_t n = 0;

      for (Int_t j = i - wls; j <= i + wrs; ++j)
      {
         if (j < 0) continue;

         y  += h->GetBinContent(j);
         dy += h->GetBinError(j);

         ++n;
      }

      hma->SetBinContent(i, y/n);
      hma->SetBinError(i, dy/n);
   }

   return hma;
}

TH2 *HistTools::MovingAverage(TH2 *h2, UShort_t n, UShort_t type, Bool_t by_row)
{
   TH2 *hma = (TH2 *)h2->Clone(Form("%s_movavg", h2->GetName()));
   hma->Reset("ICESM");

   Int_t wls, wrs; // size of left and right sides of the window
   switch (type)
   {
      case 0:
         wls = n-1;
         wrs = 0;
         break;
      case 2:
         wls = 0;
         wrs = n-1;
         break;
      case 1:
      default:
         wls = n/2;
         wrs = (n-1)/2;
   }

   Int_t nx = by_row ? h2->GetNbinsY() : h2->GetNbinsX();
   Int_t ny = by_row ? h2->GetNbinsX() : h2->GetNbinsY();
   for (Int_t k = 1; k <= ny; ++k)
   {
      for (Int_t i = 1; i <= nx; ++i)
      {
         Double_t y(0.), dy(0.);
         UShort_t n = 0;

         for (Int_t j = i - wls; j <= i + wrs; ++j)
         {
            if (j < 0) continue;

            if (by_row)
            {
               y  += h2->GetBinContent(k, j);
               dy += h2->GetBinError(k, j);
            }
            else
            {
               y  += h2->GetBinContent(j, k);
               dy += h2->GetBinError(j, k);
            }
            ++n;
         }

         if (by_row)
         {
            hma->SetBinContent(k, i, y/n);
            hma->SetBinError(k, i, dy/n);
         }
         else
         {
            hma->SetBinContent(i, k, y/n);
            hma->SetBinError(i, k, dy/n);
         }
      }
   }

   return hma;
}




//
TGraph *HistTools::LinearInterpolate(TGraph *g1, TGraph *g2, Double_t s)
{
   UShort_t npoints = g1->GetN();

   TGraph *gi = (TGraph *)g1->Clone();
   for (UShort_t ipoint = 0; ipoint < npoints; ++ipoint)
   {
      Double_t y1 = g1->GetY()[ipoint];
      Double_t y2 = g2->GetY()[ipoint];

      gi->GetY()[ipoint] = (1. - s)*y1 + s*y2;

      if (gi->GetEY() != NULL)
      {
         Double_t dy1 = g1->GetEY()[ipoint];
         Double_t dy2 = g2->GetEY()[ipoint];

         gi->GetEY()[ipoint] = (1. - s)*dy1 + s*dy2;
      }
      else if (gi->GetEYlow() != NULL)
      {
         Double_t dy1 = g1->GetEYlow()[ipoint];
         Double_t dy2 = g2->GetEYlow()[ipoint];

         gi->GetEYlow()[ipoint] = (1. - s)*dy1 + s*dy2;

         dy1 = g1->GetEYhigh()[ipoint];
         dy2 = g2->GetEYhigh()[ipoint];

         gi->GetEYhigh()[ipoint] = (1. - s)*dy1 + s*dy2;
      }
   }

   return gi;
}



// extract from g the points matching the given N sorted points, interpolating g in x (see rmode) if necessary
// rmode: 0 = consider the vector items as discrete points: x[i] = points[i]; g will have N points
//        1 = consider the vector items as range endpoints (all items must be ordered!): x[i] = 0.5*(ranges[i] + ranges[i+1]); g will have N-1 points
// imode: 0 = linear interpolation (from TGraph->Eval)
//        1 = cubic spline interpolation (from TGraph->Eval)
//        2 = cubic spline fit (from Spline class)
TGraph *HistTools::InterpolateOnPoints(TGraph *g, vector<time_t> &points, UShort_t rmode, UShort_t imode)
{
   vector<Double_t> d_points(points.begin(), points.end());
   return InterpolateOnPoints(g, d_points, rmode, imode);
}

TGraph *HistTools::InterpolateOnPoints(TGraph *g, vector< pair<time_t, time_t> > &ranges, UShort_t imode)
{
   vector<Double_t> d_points(ranges.size());
   for (UInt_t irange = 0; irange < ranges.size(); ++irange)
   {
      d_points[irange] = 0.5*(ranges[irange].first + ranges[irange].second);
   }
   return InterpolateOnPoints(g, d_points, 0, imode);
}

TGraph *HistTools::InterpolateOnPoints(TGraph *g, vector<UInt_t> &points, UShort_t rmode, UShort_t imode)
{
   vector<Double_t> d_points(points.begin(), points.end());
   return InterpolateOnPoints(g, d_points, rmode, imode);
}

TGraph *HistTools::InterpolateOnPoints(TGraph *g, vector<Double_t> &points, UShort_t rmode, UShort_t imode)
{
   UInt_t N = points.size();

   TSpline3 *s = NULL;
   TGraph *sp_fit_err = NULL;
   if (imode == 1)
   {
      UInt_t fp = TMath::Max(0U, FindFirstEdgeGreaterThan(g, points[0])-1);
      UInt_t lp = FindLastEdgeGreaterThan(g, points[N-1]);

      s = new TSpline3("", g->GetX() + fp, g->GetY() + fp, lp - fp + 1);
   }
   else if (imode >= 2)
   {
      UInt_t fp = TMath::Max(0U, FindFirstEdgeGreaterThan(g, points[0])-1);
      UInt_t lp = FindLastEdgeGreaterThan(g, points[N-1]);
      UInt_t nnodes = N/1.75;
      Double_t x1 = g->GetX()[fp];
      Double_t xN = g->GetX()[lp];
      Double_t dx = (xN-x1)/(nnodes-1);
      Double_t xn[nnodes], yn[nnodes];
      for (UShort_t inode = 0; inode < nnodes; ++inode)
      {
         xn[inode] = x1 + inode*dx;
         yn[inode] = g->Eval(xn[inode]);
      }

      Double_t b1 = (g->GetY()[fp+1] - g->GetY()[fp]) / (g->GetX()[fp+1] - g->GetX()[fp]);
      Double_t e1 = (g->GetY()[lp] - g->GetY()[lp-1]) / (g->GetX()[lp] - g->GetX()[lp-1]);

      Spline sp("", nnodes, Spline::Normal, xn, yn, b1, e1);
      TF1 *f_fit = sp.GetTF1Pointer();
      f_fit->FixParameter(0, f_fit->GetParameter(0));
      f_fit->FixParameter(1, f_fit->GetParameter(1));
      f_fit->SetRange(x1-dx, xN+dx);
      g->Fit(f_fit, "RNQ");
      s = sp.GetSpline();

      if (imode > 2)
      {
         Double_t chi2 = f_fit->GetChisquare();
         Double_t ndf = f_fit->GetNDF();
         Double_t cl = 0.683;
         // chi2/ndf will most likely be >> 1, so the confidence interval will be much larger than the difference between interpolation and actual data
         // because ROOT internally rescale the fit error by sqrt(chi2/ndf)*TMath::StudentQuantile(0.5 + cl/2, ndf)
         // confint is the CL needed for the rescaling factor to be the same of a fit with chi2/ndf = 1
         Double_t confint = -1 + 2*TMath::StudentI(sqrt(ndf/chi2)*TMath::StudentQuantile(0.5 + cl/2, ndf), ndf);

         UInt_t npx = 10*nnodes;
         sp_fit_err = new TGraphErrors(npx);
         Double_t x0 = x1 - dx;
         Double_t Dx = (xN+2*dx-x1) / (npx-1.);
         for (UInt_t ipoint = 0; ipoint < npx; ++ipoint)
         {
            Double_t x = x0 + ipoint*Dx;
            sp_fit_err->SetPoint(ipoint, x, f_fit->Eval(x));
         }
         TVirtualFitter::Fitter(g)->GetConfidenceIntervals(sp_fit_err, confint);
         for (UInt_t ipoint = 0; ipoint < npx; ++ipoint)
         {
            sp_fit_err->GetY()[ipoint] = sp_fit_err->GetEY()[ipoint];
         }
      }
   }

   TGraph *gi = new TGraph(N-rmode);
   for (UInt_t jpoint = 0; jpoint < (UInt_t)gi->GetN(); ++jpoint)
   {
      Double_t x = rmode ? 0.5*(points[jpoint] + points[jpoint+1]) : points[jpoint];
      Double_t y;
      if (imode == 0)
      {
         y = g->Eval(x);
      }
      else if (imode >= 1)
      {
         y = s->Eval(x);

         if (imode == 3) y += sp_fit_err->Eval(x);
         else if (imode == 4) y -= sp_fit_err->Eval(x);
      }

      gi->SetPoint(jpoint, x, y);
   }

   if (sp_fit_err != NULL) delete sp_fit_err;

   return gi;
}



//
TGraph *HistTools::GetCorrelation(TGraph *g1, TGraph *g2, UInt_t first_point, UInt_t last_point)
{
   TGraph *g;

   if (g1->GetN() != g2->GetN() && ((UInt_t)g1->GetN() < last_point || (UInt_t)g2->GetN() < last_point))
   {
      std::cerr << FG_RED_B << Form(" !!! HistTools::GetCorrelation: size mismatch between graph1:%s (%s) and graph2:%s (%s)", g1->GetName(), g1->GetTitle(), g2->GetName(), g2->GetTitle()) << RESET << std::endl;

      return NULL;
   }

   UInt_t npoints = g1->GetN();
   if (last_point == 0) last_point = npoints - 1;
   npoints = last_point + 1 - first_point;

   if (g1->GetEYlow() != NULL || g2->GetEYlow() != NULL)
   {
      g = new TGraphAsymmErrors(npoints);
   }
   else if (g1->GetEY() != NULL || g2->GetEY() != NULL)
   {
      g = new TGraphErrors(npoints);
   }
   else
   {
      g = new TGraph(npoints);
   }

   g->SetTitle(Form("Correlation;%s;%s", g1->GetYaxis()->GetTitle(), g2->GetYaxis()->GetTitle()));

   for (UInt_t ipoint = first_point; ipoint <= last_point; ++ipoint)
   {
      Double_t y1   = g1->GetY()[ipoint];
      Double_t dy1l = g1->GetEYlow() != NULL ? g1->GetEYlow()[ipoint] : (g1->GetEY() != NULL ? g1->GetEY()[ipoint] : 0.);
      Double_t dy1u = g1->GetEYhigh() != NULL ? g1->GetEYhigh()[ipoint] : dy1l;

      Double_t y2   = g2->GetY()[ipoint];
      Double_t dy2l = g2->GetEYlow() != NULL ? g2->GetEYlow()[ipoint] : (g2->GetEY() != NULL ? g2->GetEY()[ipoint] : 0.);
      Double_t dy2u = g2->GetEYhigh() != NULL ? g2->GetEYhigh()[ipoint] : dy2l;

      g->SetPoint(ipoint - first_point, y1, y2);
      if (g->GetEY() != NULL)
      {
         g->GetEX()[ipoint - first_point] = dy1l;
         g->GetEY()[ipoint - first_point] = dy2l;
      }
      else if (g->GetEYlow() != NULL)
      {
         g->GetEXlow()[ipoint - first_point]  = dy1l;
         g->GetEXhigh()[ipoint - first_point] = dy1u;
         g->GetEYlow()[ipoint - first_point]  = dy2l;
         g->GetEYhigh()[ipoint - first_point] = dy2u;
      }
   }

   return g;
}

TGraph *HistTools::GetCorrelationDelay(TGraph *g1, TGraph *g2, Int_t shift, UInt_t first_point, UInt_t last_point)
{
   TGraph *g;

   //~ if (g1->GetN() != g2->GetN() && ((UInt_t)g1->GetN() < last_point || (UInt_t)g2->GetN() < last_point))
   //~ {
      //~ std::cerr << FG_RED_B << Form(" !!! HistTools::Add: size mismatch between graph1:%s (%s) and graph2:%s (%s)", g1->GetName(), g1->GetTitle(), g2->GetName(), g2->GetTitle()) << RESET << std::endl;

      //~ return NULL;
   //~ }
   UInt_t npoints = shift > 0 ? g2->GetN() : g1->GetN();
   if (last_point == 0) last_point = npoints - 1;
   npoints = last_point + 1 - first_point - shift;
   if (shift < 0) first_point -= shift;

   if (g1->GetEYlow() != NULL || g2->GetEYlow() != NULL)
   {
      g = new TGraphAsymmErrors(npoints);
   }
   else if (g1->GetEY() != NULL || g2->GetEY() != NULL)
   {
      g = new TGraphErrors(npoints);
   }
   else
   {
      g = new TGraph(npoints);
   }

   for (UInt_t ipoint = first_point; ipoint <= last_point; ++ipoint)
   {
      Double_t y1   = g1->GetY()[ipoint + shift];
      Double_t dy1l = g1->GetEYlow() != NULL ? g1->GetEYlow()[ipoint + shift] : (g1->GetEY() != NULL ? g1->GetEY()[ipoint + shift] : 0.);
      Double_t dy1u = g1->GetEYhigh() != NULL ? g1->GetEYhigh()[ipoint + shift] : dy1l;

      Double_t y2   = g2->GetY()[ipoint];
      Double_t dy2l = g2->GetEYlow() != NULL ? g2->GetEYlow()[ipoint] : (g2->GetEY() != NULL ? g2->GetEY()[ipoint] : 0.);
      Double_t dy2u = g2->GetEYhigh() != NULL ? g2->GetEYhigh()[ipoint] : dy2l;

      g->SetPoint(ipoint - first_point, y1, y2);
      if (g->GetEY() != NULL)
      {
         g->GetEX()[ipoint - first_point] = dy1l;
         g->GetEY()[ipoint - first_point] = dy2l;
      }
      else if (g->GetEYlow() != NULL)
      {
         g->GetEXlow()[ipoint - first_point]  = dy1l;
         g->GetEXhigh()[ipoint - first_point] = dy1u;
         g->GetEYlow()[ipoint - first_point]  = dy2l;
         g->GetEYhigh()[ipoint - first_point] = dy2u;
      }
   }

   return g;
}



//
void HistTools::RankVector(Int_t N, Double_t *vec, Double_t *rank)
{
   Int_t *ix = new Int_t[N];
   TMath::Sort(N, vec, ix);

   Double_t lx = vec[ix[0]] + 1;
   UShort_t n = 0;
   Int_t lix = 0;
   Bool_t tie = false;
   for (Int_t i = 0; i < N; ++i)
   {
      if (vec[ix[i]] == lx)
      {
         if (!tie)
         {
            tie = true;
            lix = i - 1;
            n   = 1;
         }
         ++n;
      }
      else if (tie)
      {
         tie = false;
         Double_t r = -0.5*(lix - i)*(lix + i - 1)/n;
         for (Int_t j = lix; j < i; ++j)
         {
            rank[ix[j]] = r;
         }
      }

      rank[ix[i]] = i;

      lx = vec[ix[i]];
   }

   delete[] ix;
}

Double_t HistTools::GetSpearmanCorrelationFactor(TGraph *g)
{
   UInt_t N = g->GetN();

   TGraph gs(N);
   RankVector(N, g->GetX(), gs.GetX());
   RankVector(N, g->GetY(), gs.GetY());

   return gs.GetCorrelationFactor();
}

TGraph *HistTools::GetSpearmanCorrelation(TGraph *g)
{
   UInt_t N = g->GetN();

   TGraph *gs = new TGraph(N);
   gs->SetTitle(Form("Spearman %s", g->GetTitle()));
   RankVector(N, g->GetX(), gs->GetX());
   RankVector(N, g->GetY(), gs->GetY());

   return gs;
}

TGraph *HistTools::GetSpearmanCorrelation(TGraph *g1, TGraph *g2, UInt_t first_point, UInt_t last_point)
{
   if (g1->GetN() != g2->GetN())
   {
      std::cerr << FG_RED_B << Form(" !!! HistTools::GetCorrelation: size mismatch between graph1:%s (%s) and graph2:%s (%s)", g1->GetName(), g1->GetTitle(), g2->GetName(), g2->GetTitle()) << RESET << std::endl;

      return NULL;
   }

   UInt_t N = g1->GetN();
   if (last_point == 0) last_point = N - 1;
   N = last_point + 1 - first_point;

   TGraph *gs = new TGraph(N);
   gs->SetTitle(Form("Spearman correlation;%s;%s", g1->GetYaxis()->GetTitle(), g2->GetYaxis()->GetTitle()));
   RankVector(N, g1->GetY() + first_point, gs->GetX());
   RankVector(N, g2->GetY() + first_point, gs->GetY());

   return gs;
}



//
Double_t HistTools::CorrelationTTest(Double_t r, UInt_t n, Double_t &rlow, Double_t &rup, Double_t cl)
{
   Double_t p = 0.5*(1-cl);

   Double_t t = r*sqrt((n-2)/(1-r*r));

   Double_t pvalue = 2*(1 - TMath::StudentI(TMath::Abs(t), n-2));

   Double_t tcl = TMath::StudentQuantile(p, n-2, false);
   Double_t rcl = tcl/sqrt(n-2 + tcl*tcl);

   rlow = r - rcl;
   rup  = r + rcl;

   return pvalue;
}

Double_t HistTools::CorrelationZTest(Double_t r, UInt_t n, Double_t &rlow, Double_t &rup, Double_t cl)
{
   Double_t p = 0.5*(1-cl);

   Double_t SE = sqrt(1./(n-3));
   Double_t z = TMath::ATanH(r)/SE;

   Double_t pvalue = TMath::Erfc(TMath::Abs(z)/sqrt(2.));

   Double_t zcl = TMath::Abs(TMath::NormQuantile(p));

   rlow = TMath::TanH(SE*(z-zcl));
   rup  = TMath::TanH(SE*(z+zcl));

   return pvalue;
}



//
TGraph *HistTools::GetResiduals(TGraph *graph, TF1 *fit, const Char_t *suffix, Bool_t use_range, UShort_t use_integral, Bool_t is_log, UShort_t residual_type, UShort_t propagate_errors, Double_t confint, ROOT::Fit::Fitter *fitter, Int_t *idx)
{
   TGraph *g;

   if (!use_range)
   {
      g = (TGraph *)graph->Clone();
      if (strlen(graph->GetName()) > 0 && suffix != NULL && strlen(suffix) > 0)
      {
         g->SetName(Form("%s%s", graph->GetName(), suffix));
      }
   }
   else
   {
      Double_t x1, x2;
      fit->GetRange(x1, x2);
      UInt_t nbins = fit->GetNpx();
      Double_t *xbins = is_log ? BuildLogBins(x1, x2, nbins) : BuildLinearBins(x1, x2, nbins);
      if (graph->GetEY() != NULL) g = new TGraphErrors(nbins);
      else if (graph->GetEYlow() != NULL) g = new TGraphAsymmErrors(nbins);
      else g = new TGraph(nbins);
      g->SetName(Form("%s%s", graph->GetName(), suffix != 0 ? suffix : ""));
      g->SetTitle(graph->GetTitle());
      for (UInt_t i = 0; i < nbins; ++i)
      {
         Double_t x = TMath::Sqrt(xbins[i]*xbins[i+1]);
         g->SetPoint(i, x, 0.);
         if (g->GetEX() != NULL)
         {
            g->GetEX()[i] = 0.5*(xbins[i+1] - xbins[i]);
         }
         else if (g->GetEXlow() != NULL)
         {
            g->GetEXlow()[i]  = x - xbins[i];
            g->GetEXhigh()[i] = xbins[i+1] - x;
         }
      }
   }

   Double_t *covmat = NULL;
   TMatrixDSym *mat = NULL;
   TGraphErrors *g_confint = NULL;
   if ((propagate_errors >= 2 || (residual_type >= 2 && residual_type <= 3)) && !use_integral)
   {
      g_confint = new TGraphErrors(graph->GetN());
      for (UInt_t ipoint = 0; ipoint < (UInt_t)graph->GetN(); ++ipoint)
      {
         g_confint->SetPoint(ipoint, g->GetX()[ipoint], fit->Eval(g->GetX()[ipoint]));
      }

      if (fitter == NULL)
      {
         TVirtualFitter::Fitter(graph)->GetConfidenceIntervals(g_confint, confint);
      }
      else
      {
         MyFitResult result(fitter->Result(), fit, idx);
         result.GetConfidenceIntervals(g_confint->GetN(), 1, 1, g_confint->GetX(), g_confint->GetEY(), confint);
      }
   }
   else if (fitter != NULL)
   {
      UInt_t npar = fitter->Result().NPar();
      mat = new TMatrixDSym(npar);
      fitter->Result().GetCovarianceMatrix(*mat);
      covmat = mat->GetMatrixArray();
   }

   Bool_t use_abs = residual_type >= 10;
   residual_type %= 10;
   for (UInt_t ipoint = 0; ipoint < (UInt_t)g->GetN(); ++ipoint)
   {
      Double_t x = graph->GetX()[ipoint];
      Double_t xl = x, xu = x, dx = 0.;
      Double_t y = graph->GetY()[ipoint];
      Double_t fy;
      Double_t dy  = 1.;
      Double_t dfy = 1.;
      Double_t res, dres;

      if (use_integral)
      {
         if (graph->GetEX() != NULL)
         {
            dx = graph->GetEX()[ipoint];
            if (dx > 0)
            {
               Double_t bv = use_integral == 2 ? 1. : 2*dx;
               fy = fit->Integral(x - dx, x + dx)/bv;

               if (propagate_errors >= 2 || (residual_type >= 2 && residual_type <= 3))
               {
                  dfy = fit->IntegralError(x - dx, x + dx, NULL, covmat)/bv;
               }
            }
            else
            {
               goto NO_INTEGRAL;
            }
         }
         else if (graph->GetEXlow() != NULL)
         {
            xl = graph->GetEXlow()[ipoint];
            xu = graph->GetEXhigh()[ipoint];
            if (xl > 0 || xu > 0)
            {
               Double_t bv = use_integral == 2 ? 1. : xu + xl;
               fy = fit->Integral(x - xl, x + xu)/bv;

               if (propagate_errors >= 2 || (residual_type >= 2 && residual_type <= 3))
               {
                  dfy = fit->IntegralError(x - xl, x + xu, NULL, covmat)/bv;
               }
            }
            else
            {
               goto NO_INTEGRAL;
            }
         }
         else
         {
            goto NO_INTEGRAL;
         }
      }
      else
      {
NO_INTEGRAL:
         fy = fit->Eval(x);

         if (propagate_errors >= 2 || (residual_type >= 2 && residual_type <= 3))
         {
            dfy = g_confint->GetEY()[ipoint];
         }
      }

      if (((propagate_errors % 2) || (residual_type % 2)) && (graph->GetEY() != NULL || graph->GetEYlow() != NULL))
      {
         dy = graph->GetErrorY(ipoint);
      }

      res = y - fy;

      if (residual_type == 1) res /= dy;
      else if (residual_type == 2) res /= dfy;
      else if (residual_type == 3) res /= TMath::Sqrt(dy*dy + dfy*dfy);
      else if (residual_type == 4 || residual_type == 5) res = y / fy - (residual_type == 5);

      if (use_abs) res = TMath::Abs(res);

      g->SetPoint(ipoint, x, res);

      if (propagate_errors > 0 && (graph->GetEY() != NULL || graph->GetEYlow() != NULL))
      {
         if (residual_type == 0)
         {
            if (propagate_errors == 1) dres = dy;
            else if (propagate_errors == 2) dres = dfy;
            else if (propagate_errors == 3) dres = TMath::Sqrt(dy*dy + dfy*dfy);
         }
         else if (residual_type == 1)
         {
            if (propagate_errors == 1) dres = 1.;
            else if (propagate_errors == 2) dres = dfy/dy;
            else if (propagate_errors == 3) dres = TMath::Sqrt(1. + dfy/dy);
         }
         else if (residual_type == 2)
         {
            if (propagate_errors == 1) dres = dy/dfy;
            else if (propagate_errors == 2) dres = 1.;
            else if (propagate_errors == 3) dres = TMath::Sqrt(dy/dfy + 1.);
         }
         else if (residual_type == 3)
         {
            if (propagate_errors == 1) dres = dy/TMath::Sqrt(dy*dy + dfy*dfy);
            else if (propagate_errors == 2) dres = dfy/TMath::Sqrt(dy*dy + dfy*dfy);
            else if (propagate_errors == 3) dres = 1.;
         }
         else if (residual_type == 4 || residual_type == 5)
         {
            res = y / fy - (residual_type == 5);

            if (propagate_errors == 1) dres = dy/fy;
            else if (propagate_errors == 2) dres = y*dfy/fy/fy;
            else if (propagate_errors == 3) dres = TMath::Sqrt(dy*dy/fy/fy + y*y*dfy*dfy/fy/fy/fy/fy);
         }

         if (g->GetEX() != NULL) dynamic_cast<TGraphErrors *>(g)->SetPointError(ipoint, dx, dres);
         else if (g->GetEXlow() != NULL) dynamic_cast<TGraphAsymmErrors *>(g)->SetPointError(ipoint, x - xl, xu - x, dres, dres);
      }
      else if (g->GetEX() != NULL)
      {
         dynamic_cast<TGraphErrors *>(g)->SetPointError(ipoint, 0., 0.);
      }
      else if (g->GetEXlow() != NULL)
      {
         dynamic_cast<TGraphAsymmErrors *>(g)->SetPointError(ipoint, 0., 0., 0., 0.);
      }
   }

   if (g_confint != NULL) delete g_confint;
   if (covmat != NULL) delete[] covmat;

   return g;
}

TH1 *HistTools::GetResiduals(TH1 *hist, TF1 *fit, const Char_t *suffix, Bool_t use_range, UShort_t use_integral, Bool_t is_log, UShort_t residual_type, UShort_t propagate_errors, Double_t confint, ROOT::Fit::Fitter *fitter, Int_t *idx)
{
   TH1 *h;

   if (!use_range)
   {
      h = (TH1 *)hist->Clone();
      if (strlen(hist->GetName()) > 0 && suffix != NULL && strlen(suffix) > 0)
      {
         h->SetName(Form("%s%s", hist->GetName(), suffix));
      }
      h->Reset("ICESM");
      ResetStyle(h);
   }
   else
   {
      Double_t x1, x2;
      fit->GetRange(x1, x2);
      UInt_t nbins = fit->GetNpx();
      Double_t *xbins = is_log ? BuildLogBins(x1, x2, nbins) : BuildLinearBins(x1, x2, nbins);
      h = new TH1D(Form("%s%s", hist->GetName(), suffix != 0 ? suffix : ""), hist->GetTitle(), nbins, xbins);
   }

   Double_t *covmat = NULL;
   TMatrixDSym *mat = NULL;
   TH1D *h_confint = NULL;
   if ((propagate_errors >= 2 || (residual_type >= 2 && residual_type <= 3)) && !use_integral)
   {
      h_confint = (TH1D *)h->Clone("temp_confint");

      if (fitter == NULL)
      {
         TVirtualFitter::Fitter(hist)->GetConfidenceIntervals(h_confint, confint);
      }
      else
      {
         MyFitResult result(fitter->Result(), fit, idx);
         Double_t *ci = new Double_t[h_confint->GetNbinsX()];
         result.GetConfidenceIntervals(h_confint->GetNbinsX(), 1, 1, h_confint->GetXaxis()->GetXbins()->GetArray(), ci, confint);
         for (UInt_t ibin = 1; ibin <= (UInt_t)h_confint->GetNbinsX(); ++ibin)
         {
            Double_t x = is_log ? h->GetXaxis()->GetBinCenterLog(ibin) : h->GetBinCenter(ibin);
            h_confint->SetBinContent(ibin, fit->Eval(x));
            h_confint->SetBinError(ibin, ci[ibin-1]);
         }
         delete ci;
      }
   }
   else if (fitter != NULL)
   {
      UInt_t npar = fitter->Result().NPar();
      mat = new TMatrixDSym(npar);
      fitter->Result().GetCovarianceMatrix(*mat);
      covmat = mat->GetMatrixArray();
   }

   Bool_t use_abs = residual_type >= 10;
   residual_type %= 10;
   for (UInt_t ibin = 1; ibin <= (UInt_t)h->GetNbinsX(); ++ibin)
   {
      Double_t x   = is_log ? h->GetXaxis()->GetBinCenterLog(ibin) : h->GetBinCenter(ibin);
      Double_t xl  = h->GetBinLowEdge(ibin);
      Double_t xh  = h->GetBinLowEdge(ibin + 1);
      Double_t dx  = use_integral == 2 ? 1. : h->GetBinWidth(ibin);
      Int_t jbin   = hist->FindBin(x);
      Double_t y   = (jbin <= 0. || jbin > hist->GetNbinsX()) ? 0. : hist->GetBinContent(jbin);

      if (y == 0) continue;

      Double_t dy  = (jbin <= 0. || jbin > hist->GetNbinsX()) ? 0. : hist->GetBinError(jbin);
      Double_t fy  = use_integral ? fit->Integral(xl, xh)/dx : fit->Eval(x);
      Double_t dfy = (propagate_errors >= 2 || (residual_type >= 2 && residual_type <= 3)) ? (use_integral ? fit->IntegralError(xl, xh, NULL, covmat)/dx : h_confint->GetBinError(ibin)) : 1.;
      if (TMath::IsNaN(fy) || TMath::IsNaN(dfy))
      {
         fy = dfy = 0.;
      }
      Double_t res  = y - fy;
      Double_t dres = 0.;

      if (residual_type == 0)
      {
         if (propagate_errors == 1) dres = dy;
         else if (propagate_errors == 2) dres = dfy;
         else if (propagate_errors == 3) dres = TMath::Sqrt(dy*dy + dfy*dfy);
      }
      else if (residual_type == 1)
      {
         res /= dy;

         if (propagate_errors == 1) dres = 1.;
         else if (propagate_errors == 2) dres = dfy/dy;
         else if (propagate_errors == 3) dres = TMath::Sqrt(1. + dfy/dy);
      }
      else if (residual_type == 2)
      {
         res /= dfy;

         if (propagate_errors == 1) dres = dy/dfy;
         else if (propagate_errors == 2) dres = 1.;
         else if (propagate_errors == 3) dres = TMath::Sqrt(dy/dfy + 1.);
      }
      else if (residual_type == 3)
      {
         res /= TMath::Sqrt(dy*dy + dfy*dfy);

         if (propagate_errors == 1) dres = dy/TMath::Sqrt(dy*dy + dfy*dfy);
         else if (propagate_errors == 2) dres = dfy/TMath::Sqrt(dy*dy + dfy*dfy);
         else if (propagate_errors == 3) dres = 1.;
      }
      else if (residual_type == 4 || residual_type == 5)
      {
         res = y / fy - (residual_type == 5);

         if (propagate_errors == 1) dres = dy/fy;
         else if (propagate_errors == 2) dres = y*dfy/fy/fy;
         else if (propagate_errors == 3) dres = TMath::Sqrt(dy*dy/fy/fy + y*y*dfy*dfy/fy/fy/fy/fy);
      }

      if (use_abs) res = TMath::Abs(res);

      h->SetBinContent(ibin, res);
      h->SetBinError(ibin, dres);
   }

   if (h_confint != NULL) delete h_confint;
   if (mat != NULL) delete mat;

   return h;
}



//
TGraph *HistTools::GetFitError(TGraph *graph, TF1 *fit, const Char_t *suffix, Bool_t use_range, UShort_t use_integral, Bool_t is_log, UShort_t use_error, Double_t value, Double_t confint, ROOT::Fit::Fitter *fitter, Int_t *idx)
{
   TGraph *g;

   Bool_t   use_value  = use_error >= 10;
   UShort_t error_type = use_error % 10;

   if (!use_range)
   {
      g = (TGraph *)graph->Clone();
      if (strlen(graph->GetName()) > 0 && suffix != NULL && strlen(suffix) > 0)
      {
         g->SetName(Form("%s%s", graph->GetName(), suffix));
      }
   }
   else
   {
      Double_t x1, x2;
      fit->GetRange(x1, x2);
      UInt_t nbins = fit->GetNpx();

      Double_t *xbins = is_log ? BuildLogBins(x1, x2, nbins) : BuildLinearBins(x1, x2, nbins);
      if (graph->GetEY() != NULL || use_value) g = new TGraphErrors(nbins);
      else if (graph->GetEYlow() != NULL) g = new TGraphAsymmErrors(nbins);
      else g = new TGraph(nbins);
      g->SetName(Form("%s%s", graph->GetName(), suffix != 0 ? suffix : ""));
      g->SetTitle(graph->GetTitle());
      for (UInt_t i = 0; i < nbins; ++i)
      {
         Double_t x = TMath::Sqrt(xbins[i]*xbins[i+1]);
         g->SetPoint(i, x, 0.);
         if (g->GetEX() != NULL)
         {
            g->GetEX()[i] = 0.5*(xbins[i+1] - xbins[i]);
         }
         else if (g->GetEXlow() != NULL)
         {
            g->GetEXlow()[i]  = x - xbins[i];
            g->GetEXhigh()[i] = xbins[i+1] - x;
         }
      }
   }

   Double_t *covmat = NULL;
   TMatrixDSym *mat = NULL;
   TGraphErrors *g_confint = NULL;
   if (!use_integral)
   {
      g_confint = new TGraphErrors(g->GetN());
      for (UInt_t ipoint = 0; ipoint < (UInt_t)g->GetN(); ++ipoint)
      {
         g_confint->SetPoint(ipoint, g->GetX()[ipoint], fit->Eval(g->GetX()[ipoint]));
      }

      if (fitter == NULL)
      {
         TVirtualFitter::Fitter(graph)->GetConfidenceIntervals(g_confint, confint);
      }
      else
      {
         MyFitResult result(fitter->Result(), fit, idx);
         result.GetConfidenceIntervals(g_confint->GetN(), 1, 1, g_confint->GetX(), g_confint->GetEY(), confint);
      }
   }
   else if (fitter != NULL)
   {
      UInt_t npar = fitter->Result().NPar();
      mat = new TMatrixDSym(npar);
      fitter->Result().GetCovarianceMatrix(*mat);
      covmat = mat->GetMatrixArray();
   }

   for (UInt_t ipoint = 0; ipoint < (UInt_t)g->GetN(); ++ipoint)
   {
      Double_t x = g->GetX()[ipoint];
      Double_t xl = x, xu = x, dx = 0.;
      UInt_t jpoint = FindPoint(graph, x);
      Double_t y = jpoint != UINT_MAX ? graph->GetY()[jpoint] : 0.;
      Double_t fy;
      Double_t dy = 1.;
      Double_t dfy;
      Double_t v, dv;

      if (graph->GetEY() != NULL || graph->GetEYlow() != NULL)
      {
         dy = jpoint != UINT_MAX ? graph->GetErrorY(jpoint) : 0.;
      }

      if (use_integral)
      {
         if (g->GetEX() != NULL)
         {
            dx = g->GetEX()[ipoint];
            if (dx > 0)
            {
               Double_t bv = use_integral == 2 ? 1. : 2*dx;
               dfy = fit->IntegralError(x - dx, x + dx, NULL, covmat)/bv;
               if (error_type == 1 || value == DBL_MAX) fy = fit->Integral(x - dx, x + dx)/bv;
            }
            else
            {
               goto NO_INTEGRAL;
            }
         }
         else if (g->GetEXlow() != NULL)
         {
            xl = g->GetEXlow()[ipoint];
            xu = g->GetEXhigh()[ipoint];
            if (xl > 0 || xu > 0)
            {
               Double_t bv = use_integral == 2 ? 1. : xu + xl;
               dfy = fit->IntegralError(x - xl, x + xu, NULL, covmat)/bv;
               if (error_type == 1 || value == DBL_MAX) fy = fit->Integral(x - xl, x + xu)/bv;
            }
            else
            {
               goto NO_INTEGRAL;
            }
         }
         else
         {
            goto NO_INTEGRAL;
         }
      }
      else
      {
NO_INTEGRAL:
         dfy = g_confint->GetEY()[ipoint];
         if (error_type == 1 || value == DBL_MAX) fy = fit->Eval(x);
      }

      Double_t val = value == DBL_MAX ? fy : (value == DBL_MIN ? y : value);
      switch (error_type)
      {
         case 0:
            v  = use_value ? val : dfy;
            dv = use_value ? dfy : 0.;
            break;
         case 1:
            v  = use_value ? val : (fy != 0 ? dfy / fy : 0.);
            dv = use_value ? (fy != 0. ? dfy / fy : 0.) : 0.;
            break;
         case 2:
            v  = use_value ? val : (y != 0.? dfy / y : 0.);
            dv = use_value ? (y != 0.? dfy / y : 0.) : 0.;
            break;
         case 3:
            v  = use_value ? val : (dy != 0.? dfy / dy : 0.);
            dv = use_value ? (dy != 0.? dfy / dy : 0.) : 0.;
      }

      g->SetPoint(ipoint, x, v);
      if (g->GetEX() != NULL) dynamic_cast<TGraphErrors *>(g)->SetPointError(ipoint, dx, dv);
      else if (g->GetEXlow() != NULL) dynamic_cast<TGraphAsymmErrors *>(g)->SetPointError(ipoint, x - xl, xu - x, dv, dv);
   }

   if (g_confint != NULL) delete g_confint;
   if (mat != NULL) delete mat;

   return g;
}

TH1 *HistTools::GetFitError(TH1 *hist, TF1 *fit, const Char_t *suffix, Bool_t use_range, UShort_t use_integral, Bool_t is_log, UShort_t use_error, Double_t value, Double_t confint, ROOT::Fit::Fitter *fitter, Int_t *idx)
{
   TH1 *h;
   if (!use_range)
   {
      h = (TH1 *)hist->Clone();
      if (strlen(hist->GetName()) > 0 && suffix != NULL && strlen(suffix) > 0)
      {
         h->SetName(Form("%s%s", hist->GetName(), suffix));
      }
      h->Reset("ICESM");
      ResetStyle(h);
   }
   else
   {
      Double_t x1, x2;
      fit->GetRange(x1, x2);
      UInt_t nbins = fit->GetNpx();
      Double_t *xbins = is_log ? BuildLogBins(x1, x2, nbins) : BuildLinearBins(x1, x2, nbins);
      h = new TH1D(Form("%s%s", hist->GetName(), suffix != 0 ? suffix : ""), hist->GetTitle(), nbins, xbins);
   }

   Double_t *covmat = NULL;
   TMatrixDSym *mat = NULL;
   TH1D *h_confint = NULL;
   if (!use_integral)
   {
      h_confint = (TH1D *)h->Clone("temp_confint");
      if (fitter == NULL)
      {
         TVirtualFitter::Fitter(hist)->GetConfidenceIntervals(h_confint, confint);
      }
      else
      {
         MyFitResult result(fitter->Result(), fit, idx);
         Double_t *ci = new Double_t[h_confint->GetNbinsX()];
         result.GetConfidenceIntervals(h_confint->GetNbinsX(), 1, 1, h_confint->GetXaxis()->GetXbins()->GetArray(), ci, confint);
         for (UInt_t ibin = 1; ibin <= (UInt_t)h_confint->GetNbinsX(); ++ibin)
         {
            Double_t x = is_log ? h->GetXaxis()->GetBinCenterLog(ibin) : h->GetBinCenter(ibin);
            h_confint->SetBinContent(ibin, fit->Eval(x));
            h_confint->SetBinError(ibin, ci[ibin-1]);
         }
         delete ci;
      }
   }
   else if (fitter != NULL)
   {
      // TODO if (idx != NULL) select only used parameters in covariance matrix
      UInt_t npar = fitter->Result().NPar();
      mat = new TMatrixDSym(npar);
      fitter->Result().GetCovarianceMatrix(*mat);
      covmat = mat->GetMatrixArray();
   }

   Bool_t   use_value  = use_error >= 10;
   UShort_t error_type = use_error % 10;
   for (UInt_t ibin = 1; ibin <= (UInt_t)h->GetNbinsX(); ++ibin)
   {
      Double_t x   = is_log ? h->GetXaxis()->GetBinCenterLog(ibin) : h->GetBinCenter(ibin);
      Double_t xl  = h->GetBinLowEdge(ibin);
      Double_t xh  = h->GetBinLowEdge(ibin + 1);
      Double_t dx  = use_integral == 2 ? 1. : h->GetBinWidth(ibin);
      Int_t jbin   = hist->FindBin(x);
      Double_t y   = (jbin <= 0 || jbin > hist->GetNbinsX()) ? 0. : hist->GetBinContent(jbin);
      Double_t dy  = (jbin <= 0 || jbin > hist->GetNbinsX()) ? 0. : hist->GetBinError(jbin);
      Double_t fy  = use_integral ? fit->Integral(xl, xh)/dx : fit->Eval(x);
      Double_t dfy = use_integral ? fit->IntegralError(xl, xh, NULL, covmat)/dx : h_confint->GetBinError(ibin);

      Double_t v, dv;
      Double_t val = value == DBL_MAX ? fy : (value == DBL_MIN ? y : value);
      switch (error_type)
      {
         case 0:
            v  = use_value ? val : dfy;
            dv = use_value ? dfy : 0.;
            break;
         case 1:
            v  = use_value ? val : (fy != 0 ? dfy / fy : 0.);
            dv = use_value ? (fy != 0. ? dfy / fy : 0.) : 0.;
            break;
         case 2:
            v  = use_value ? val : (y != 0.? dfy / y : 0.);
            dv = use_value ? (y != 0.? dfy / y : 0.) : 0.;
            break;
         case 3:
            v  = use_value ? val : (dy != 0.? dfy / dy : 0.);
            dv = use_value ? (dy != 0.? dfy / dy : 0.) : 0.;
      }

      h->SetBinContent(ibin, v);
      h->SetBinError(ibin, dv);
   }

   if (h_confint != NULL) delete h_confint;
   if (mat != NULL) delete mat;

   return h;
}



//
TMultiGraph *HistTools::GetQQPlot(TH1 *hist, TF1 *fmodel, Double_t &p1, Double_t &p2, UInt_t first_bin, UInt_t last_bin)
{
   if (first_bin == UINT_MAX) first_bin = 1;
   if (last_bin == UINT_MAX) last_bin = hist->GetNbinsX();

   UInt_t nbins = last_bin - first_bin + 1;

   Double_t *x = new Double_t[nbins];
   for (UInt_t bin = first_bin; bin <= last_bin; ++bin)
   {
      x[bin - first_bin] = hist->GetBinContent(bin);
   }

   TGraphQQ *gqq = new TGraphQQ(nbins, x, fmodel);
   gqq->SetTitle(hist->GetTitle());
   HistTools::CopyStyle(hist, gqq);

   gRandom->SetSeed();

   UInt_t nplots = 1e5;
   Double_t *x_mc = new Double_t[nbins];
   TGraphQQ **gqq_mc = new TGraphQQ *[nplots];
   Double_t scale_mc     = 0.;
   Double_t scale_mc2    = 0.;
   Double_t location_mc  = 0.;
   Double_t location_mc2 = 0.;
   Double_t corr_mc      = 0.;
   Double_t corr_mc2     = 0.;
   for (UInt_t i = 0; i < nplots; ++i)
   {
      for (UInt_t j = 0; j < nbins; ++j) x_mc[j] = fmodel->GetRandom();
      gqq_mc[i] = new TGraphQQ(nbins, x_mc, fmodel);

      Double_t scale    = (gqq_mc[i]->GetYq2() - gqq_mc[i]->GetYq1()) / (gqq_mc[i]->GetXq2() - gqq_mc[i]->GetXq1());
      Double_t location = (gqq_mc[i]->GetYq1()*gqq_mc[i]->GetXq2() - gqq_mc[i]->GetYq2()*gqq_mc[i]->GetXq1()) / (gqq_mc[i]->GetXq2() - gqq_mc[i]->GetXq1());
      Double_t corr     = gqq_mc[i]->GetCorrelationFactor();

      scale_mc  += scale;
      scale_mc2 += scale*scale;
      location_mc  += location;
      location_mc2 += location*location;
      corr_mc  += corr;
      corr_mc2 += corr*corr;
   }
   Double_t scale_mc_mean = scale_mc / nplots;
   Double_t scale_mc_std  = TMath::Sqrt((scale_mc2 - nplots*scale_mc_mean*scale_mc_mean) / (nplots - 1));
   Double_t location_mc_mean = location_mc / nplots;
   Double_t location_mc_std  = TMath::Sqrt((location_mc2 - nplots*location_mc_mean*location_mc_mean) / (nplots - 1));
   Double_t corr_mc_mean = corr_mc / nplots;
   Double_t corr_mc_std  = TMath::Sqrt((corr_mc2 - nplots*corr_mc_mean*corr_mc_mean) / (nplots - 1));

   cout << FG_BLUE_B << "QQ-plot - MC average" << RESET << endl;
   cout << Form(" ### mu    = %s", Format::Measurement(location_mc_mean, location_mc_std, (UShort_t)0).c_str()) << endl;
   cout << Form(" ### sigma = %s", Format::Measurement(scale_mc_mean, scale_mc_std, (UShort_t)0).c_str()) << endl;
   cout << Form(" ### corr. = %s", Format::Measurement(corr_mc_mean, corr_mc_std, (UShort_t)0).c_str()) << endl;

   Double_t scale    = (gqq->GetYq2() - gqq->GetYq1()) / (gqq->GetXq2() - gqq->GetXq1());
   Double_t location = (gqq->GetYq1()*gqq->GetXq2() - gqq->GetYq2()*gqq->GetXq1()) / (gqq->GetXq2() - gqq->GetXq1());
   Double_t corr     = gqq->GetCorrelationFactor();
   cout << FG_BLUE_B << "QQ-plot - Data" << RESET << endl;
   cout << Form(" ### mu    = %s", Format::ToPrecision(location).c_str()) << endl;
   cout << Form(" ### sigma = %s", Format::ToPrecision(scale).c_str()) << endl;
   cout << Form(" ### corr. = %s", Format::ToPrecision(corr).c_str()) << endl;

   TGraphErrors *gqq_mc_avg = (TGraphErrors *)GetAverageGraph((const TGraph **)gqq_mc, nplots, "gqq_mc_avg", 3);
   gqq_mc_avg->SetName("gqq_mc_avg");
   gqq_mc_avg->SetFillColor(kGray);
   gqq_mc_avg->SetFillStyle(1001);
   gqq_mc_avg->SetLineColor(kBlack);
   gqq_mc_avg->SetLineWidth(2);
   gqq_mc_avg->SetLineStyle(7);

   TH2D *h_qq_dist = new TH2D("h_qq_dist", "Distribution of QQ MC plots", nbins, 0, nbins, 50, -3, 3);
   for (UInt_t i = 0; i < nplots; ++i)
   {
      for (UInt_t j = 0; j < nbins; ++j)
      {
         h_qq_dist->Fill(j, gqq_mc[i]->GetY()[j] - gqq_mc_avg->GetY()[j]);
      }
   }

   TGraphErrors *g_mc_sigma  = (TGraphErrors *)gqq_mc_avg->Clone();
   g_mc_sigma->SetFillColor(kGreen);
   g_mc_sigma->SetLineColor(kBlack);
   g_mc_sigma->SetLineStyle(1);
   g_mc_sigma->SetLineWidth(1);
   TGraphErrors *g_mc_sigma2 = (TGraphErrors *)gqq_mc_avg->Clone();
   g_mc_sigma2->SetFillColor(kYellow);
   g_mc_sigma2->SetLineColor(kBlack);
   g_mc_sigma2->SetLineStyle(1);
   g_mc_sigma2->SetLineWidth(1);
   p1 = 0.;
   p2 = 0.;
   for (UInt_t i = 1; i <= nbins; ++i)
   {
      TH1D *h_py = h_qq_dist->ProjectionY("_py", i, i, "e");
      TFitResultPtr frp = h_py->Fit("gaus", "IQNS");
      g_mc_sigma->SetPointError(i - 1, 0., frp->Parameter(2));
      g_mc_sigma2->SetPointError(i - 1, 0., 2*frp->Parameter(2));
      delete h_py;

      Double_t dy = TMath::Abs(gqq->GetY()[i - 1] - gqq_mc_avg->GetY()[i - 1]);
      if (dy <= frp->Parameter(2)) ++p1;
      if (dy <= 2*frp->Parameter(2)) ++p2;
   }
   p1 /= nbins;
   p2 /= nbins;
   delete h_qq_dist;

   TMultiGraph *mg = new TMultiGraph();
   mg->SetTitle(";Theoretical quantiles;Data quantiles");
   mg->Add(g_mc_sigma2, "3");
   mg->Add(g_mc_sigma, "3");
   mg->Add(gqq_mc_avg, "LX");
   mg->Add(new TGraph(*gqq), "P");

   return mg;
}




//
TH1 *HistTools::GetFoldedCumulative(TH1 *hist, const Char_t *name)
{
   Double_t N = hist->GetSumOfWeights();
   Int_t xM = hist->GetMaximumBin();

   TH1 *h = (TH1 *)hist->Clone(name);
   for (Int_t bin = xM+1; bin <= h->GetNbinsX(); ++bin)
   {
      Double_t y = h->GetBinContent(bin);
      h->SetBinContent(bin, h->GetBinContent(bin-1) + y);
   }
   for (Int_t bin = xM-2; bin > 0; --bin)
   {
      Double_t y = h->GetBinContent(bin);
      h->SetBinContent(bin, h->GetBinContent(bin+1) + y);
   }
   h->Scale(1./N);

   return h;
}
TH1 *HistTools::GetFoldedCumulative(TH1 *hist, TF1 *fmodel, const Char_t *name)
{
   Double_t N = hist->GetSumOfWeights();
   Int_t xM = hist->GetMaximumBin();

   TH1 *h = (TH1 *)hist->Clone(name);
   h->SetBinContent(xM, fmodel->Integral(h->GetBinLowEdge(xM), h->GetBinLowEdge(xM+1))/h->GetBinWidth(xM));
   for (Int_t bin = xM+1; bin <= h->GetNbinsX(); ++bin)
   {
      Double_t y = fmodel->Integral(h->GetBinLowEdge(bin), h->GetBinLowEdge(bin+1))/h->GetBinWidth(bin);
      h->SetBinContent(bin, h->GetBinContent(bin-1) + y);
   }
   h->SetBinContent(xM-1, fmodel->Integral(h->GetBinLowEdge(xM-1), h->GetBinLowEdge(xM))/h->GetBinWidth(xM-1));
   for (Int_t bin = xM-2; bin > 0; --bin)
   {
      Double_t y = fmodel->Integral(h->GetBinLowEdge(bin), h->GetBinLowEdge(bin+1))/h->GetBinWidth(bin);
      h->SetBinContent(bin, h->GetBinContent(bin+1) + y);
   }
   h->Scale(1./N);

   return h;
}



//
TF1 *HistTools::GetSpectralIndex(TF1 *f, const Char_t *name, Double_t xmin, Double_t xmax)
{
   static TF1 *f_x = new TF1("f_x", "x");
   TF1 *f_gamma = HistTools::CombineTF1(HistTools::CombineTF1(HistTools::CombineTF1(f, HistTools::Derivative), f, HistTools::Divide), f_x, HistTools::Multiply, name, xmin, xmax);

   return f_gamma;
}

TGraphAsymmErrors *HistTools::GetSpectralIndex(TH1 *hist, UShort_t size, UShort_t step)
{
   UInt_t nbins   = hist->GetNbinsX();
   UInt_t npoints = (nbins - size + 1) / step;

   TF1 *f_pl_fit = new TF1("f_pl_fit", "[0]*x**[1]");

   TGraphAsymmErrors *g_gamma = new TGraphAsymmErrors(npoints);
   UInt_t jpoint = 0;
   for (UInt_t ipoint = 0; true; ++ipoint)
   {
      UInt_t bin1 = ipoint*step + 1;
      UInt_t bin2 = bin1 + size - 1;

      if (bin2 > nbins) break;

      Bool_t valid = true;
      for (UInt_t ibin = bin1; ibin <= bin2; ++ibin)
      {
         Double_t y = hist->GetBinContent(ibin);
         if (TMath::IsNaN(y) || TMath::Abs(y) == TMath::Infinity())
         {
            valid = false;
            break;
         }
      }
      if (!valid) continue;

      Double_t xm = hist->GetBinLowEdge(bin1);
      Double_t xM = hist->GetBinLowEdge(bin2 + 1);
      Double_t x1 = hist->GetXaxis()->GetBinCenterLog(bin1);
      Double_t x2 = hist->GetXaxis()->GetBinCenterLog(bin2);
      Double_t y1 = hist->GetBinContent(bin1);
      Double_t y2 = hist->GetBinContent(bin2);

      Double_t gamma = (y2 > 0. && y1 > 0.) ? TMath::Log(y2/y1)/TMath::Log(x2/x1) : 1.;
      Double_t N     = y1 > 0. ? y1*TMath::Power(x1, -gamma) : 1.;

      f_pl_fit->SetParameters(N, gamma);
      f_pl_fit->SetRange(xm, xM);

      hist->Fit(f_pl_fit, "RNQ");
      hist->Fit(f_pl_fit, "RNQI");
      TFitResultPtr frp = hist->Fit(f_pl_fit, "RNQIS");

      N     = frp->Parameter(0);
      gamma = frp->Parameter(1);
      //~ Double_t dN = frp->ParError(0);
      Double_t dgamma = frp->ParError(1);

      Double_t xt = TMath::Power((TMath::Power(xM, gamma + 1.) - TMath::Power(xm, gamma + 1.))/(gamma + 1.)/(xM - xm), 1./gamma);
      g_gamma->SetPoint(jpoint, xt, gamma);
      //~ g_gamma->SetPointError(jpoint, xt - xm, xM - xt, dgamma, dgamma);
      g_gamma->SetPointError(jpoint, 0., 0., dgamma, dgamma);
      ++jpoint;
   }
   g_gamma->Set(jpoint);

   delete f_pl_fit;

   return g_gamma;
}



//
UInt_t HistTools::FindPoint(TGraph *graph, Double_t x, UInt_t start_point)
{
   UInt_t npoints = graph->GetN();

   UInt_t best_point = npoints;
   Double_t min_diff = DBL_MAX;

   if (start_point >= npoints) return best_point;

   Double_t x0 = graph->GetX()[start_point];
   Double_t x1 = graph->GetX()[npoints - 1];
   if (graph->GetEX() != NULL)
   {
      x0 -= graph->GetEX()[start_point];
      x1 += graph->GetEX()[npoints-1];
   }
   else if (graph->GetEXlow() != NULL)
   {
      x0 -= graph->GetEXlow()[start_point];
      x1 += graph->GetEXhigh()[npoints-1];
   }

   if (x >= x0 && x <= x1)
   {
      for (UInt_t ipoint = start_point; ipoint < npoints; ++ipoint)
      {
         Double_t curr_x = graph->GetX()[ipoint];
         Double_t diff   = TMath::Abs(curr_x - x);

         if (diff < min_diff)
         {
            min_diff   = diff;
            best_point = ipoint;
         }

         if (curr_x > x) break;
      }
   }

   return best_point;
}

UInt_t HistTools::FindFirstEdgeGreaterThan(TGraph *graph, Double_t x, UInt_t start_point)
{
   UInt_t ipoint;
   for (ipoint = start_point; ipoint < (UInt_t)graph->GetN(); ++ipoint)
   {
      Double_t curr_x = graph->GetX()[ipoint];
      if (graph->GetEX() != NULL)
      {
         curr_x -= graph->GetEX()[ipoint];
      }
      else if (graph->GetEXlow() != NULL)
      {
         curr_x -= graph->GetEXlow()[ipoint];
      }

      if (curr_x >= x) break;
   }

   return ipoint;
}

UInt_t HistTools::FindLastEdgeGreaterThan(TGraph *graph, Double_t x, UInt_t start_point)
{
   Int_t ipoint;
   for (ipoint = start_point == 0 ? graph->GetN() - 1 : start_point; ipoint >= 0; --ipoint)
   {
      Double_t curr_x = graph->GetX()[ipoint];
      if (graph->GetEX() != NULL)
      {
         curr_x += graph->GetEX()[ipoint];
      }
      else if (graph->GetEXhigh() != NULL)
      {
         curr_x += graph->GetEXhigh()[ipoint];
      }

      if (curr_x <= x) break;
   }

   return ++ipoint;
}

UInt_t HistTools::FindPointGreaterThan(TGraph *graph, Double_t y, UShort_t start_point, Bool_t use_err)
{
   UInt_t ipoint = start_point;

   for ( ; ipoint < (UInt_t)graph->GetN(); ++ipoint)
   {
      Double_t curr_y = graph->GetY()[ipoint];
      if (use_err && graph->GetEY() != NULL)
      {
         curr_y += graph->GetEY()[ipoint];
      }
      else if (use_err && graph->GetEYhigh() != NULL)
      {
         curr_y += graph->GetEYhigh()[ipoint];
      }

      if (curr_y >= y) break;
   }

   return ipoint;
}



//
UInt_t HistTools::CountLessThan(TGraph *g, Double_t value)
{
   UInt_t n = 0;
   for (UInt_t ipoint = 0; ipoint < (UInt_t)g->GetN(); ++ipoint)
   {
      if (g->GetY()[ipoint] < value) ++n;
   }

   return n;
}

UInt_t HistTools::CountLessThan(TH1 *h, Double_t value)
{
   UInt_t n = 0;
   for (UInt_t ibin = 1; ibin <= (UInt_t)h->GetNbinsX(); ++ibin)
   {
      if (h->GetBinContent(ibin) < value) ++n;
   }

   return n;
}

UInt_t HistTools::CountLessOrEqualThan(TGraph *g, Double_t value)
{
   UInt_t n = 0;
   for (UInt_t ipoint = 0; ipoint < (UInt_t)g->GetN(); ++ipoint)
   {
      if (g->GetY()[ipoint] <= value) ++n;
   }

   return n;
}

UInt_t HistTools::CountLessOrEqualThan(TH1 *h, Double_t value)
{
   UInt_t n = 0;
   for (UInt_t ibin = 1; ibin <= (UInt_t)h->GetNbinsX(); ++ibin)
   {
      if (h->GetBinContent(ibin) <= value) ++n;
   }

   return n;
}

UInt_t HistTools::CountGreaterThan(TGraph *g, Double_t value)
{
   UInt_t n = 0;
   for (UInt_t ipoint = 0; ipoint < (UInt_t)g->GetN(); ++ipoint)
   {
      if (g->GetY()[ipoint] > value) ++n;
   }

   return n;
}

UInt_t HistTools::CountGreaterThan(TH1 *h, Double_t value)
{
   UInt_t n = 0;
   for (UInt_t ibin = 1; ibin <= (UInt_t)h->GetNbinsX(); ++ibin)
   {
      if (h->GetBinContent(ibin) > value) ++n;
   }

   return n;
}

UInt_t HistTools::CountGreaterOrEqualThan(TGraph *g, Double_t value)
{
   UInt_t n = 0;
   for (UInt_t ipoint = 0; ipoint < (UInt_t)g->GetN(); ++ipoint)
   {
      if (g->GetY()[ipoint] >= value) ++n;
   }

   return n;
}

UInt_t HistTools::CountGreaterOrEqualThan(TH1 *h, Double_t value)
{
   UInt_t n = 0;
   for (UInt_t ibin = 1; ibin < (UInt_t)h->GetNbinsX(); ++ibin)
   {
      if (h->GetBinContent(ibin) >= value) ++n;
   }

   return n;
}



//
void HistTools::CloseGraph(TGraph *g, Double_t ymin)
{
   UInt_t npoints = g->GetN();

   Double_t x1 = g->GetX()[0];
   Double_t x2 = g->GetX()[npoints - 1];

   g->SetPoint(npoints, x2, ymin);
   g->SetPoint(npoints + 1, x1, ymin);
}



//
Double_t HistTools::GetMinimum(TH1 *hist, Double_t min_val)
{
   Double_t min = DBL_MAX;

   for (UInt_t bin = 1; bin <= (UInt_t)hist->GetNbinsX(); ++bin)
   {
      Double_t y  = hist->GetBinContent(bin);
      Double_t dy = hist->GetBinError(bin);
      if (dy > 0.) y-= dy;

      if (y > min_val && y < min)
      {
         min = y;
      }
   }

   return min;
}

Double_t HistTools::GetMaximum(TH1 *hist, Double_t max_val)
{
   Double_t max = -DBL_MAX;

   for (UInt_t bin = 1; bin <= (UInt_t)hist->GetNbinsX(); ++bin)
   {
      Double_t y  = hist->GetBinContent(bin);
      Double_t dy = hist->GetBinError(bin);
      if (dy > 0.) y += dy;

      if (y < max_val && y > max)
      {
         max = y;
      }
   }

   return max;
}

Double_t HistTools::GetMinimum(TGraph *graph, Double_t min_val)
{
   Double_t min = DBL_MAX;

   for (UInt_t ipoint = 0; ipoint < (UInt_t)graph->GetN(); ++ipoint)
   {
      Double_t y = graph->GetY()[ipoint];

      if (y > min_val && y < min)
      {
         min = y;
      }
   }

   return min;
}

Double_t HistTools::GetMinimum(TGraph *graph, UInt_t &min_point, Double_t min_val)
{
   Double_t min = graph->GetY()[0];
   min_point = 0;

   for (UInt_t ipoint = 1; ipoint < (UInt_t)graph->GetN(); ++ipoint)
   {
      Double_t y = graph->GetY()[ipoint];

      if (y > min_val && y < min)
      {
         min = y;
         min_point = ipoint;
      }
   }

   return min;
}

Double_t HistTools::GetMaximum(TGraph *graph, Double_t max_val)
{
   Double_t max = -DBL_MAX;

   for (UInt_t ipoint = 0; ipoint < (UInt_t)graph->GetN(); ++ipoint)
   {
      Double_t y = graph->GetY()[ipoint];

      if (y < max_val && y > max)
      {
         max = y;
      }
   }

   return max;
}

Double_t HistTools::GetMaximum(TGraph *graph, UInt_t &max_point, Double_t max_val)
{
   Double_t max = graph->GetY()[0];
   max_point = 0;

   for (UInt_t ipoint = 1; ipoint < (UInt_t)graph->GetN(); ++ipoint)
   {
      Double_t y = graph->GetY()[ipoint];

      if (y < max_val && y > max)
      {
         max = y;
         max_point = ipoint;
      }
   }

   return max;
}



//
Double_t HistTools::GetKurtosis(TGraph *graph)
{
   UInt_t n = graph->GetN();
   Double_t y = 0., y2 = 0., y3 = 0., y4 = 0.;
   for (UInt_t ipoint = 0; ipoint < n; ++ipoint)
   {
      Double_t v = graph->GetY()[ipoint];

      y  += v;
      y2 += v*v;
      y3 += v*v*v;
      y4 += v*v*v*v;
   }
   Double_t m   = y/n;
   Double_t s2  = y2/n - m*m;
   Double_t s3g = (y3/n - 3*m*s2 - m*m*m);
   Double_t k   = (y4/n - m*m*m*m - 6*m*m*s2 - 4*m*s3g) / (s2*s2);

   return k;
}

Double_t HistTools::GetSkewness(TGraph *graph)
{
   UInt_t n = graph->GetN();
   Double_t y = 0., y2 = 0., y3 = 0.;
   for (UInt_t ipoint = 0; ipoint < n; ++ipoint)
   {
      Double_t v = graph->GetY()[ipoint];

      y  += v;
      y2 += v*v;
      y3 += v*v*v;
   }
   Double_t m  = y/n;
   Double_t s2 = y2/n - m*m;
   Double_t g  = (y3/n - 3*m*s2 - m*m*m) / pow(s2, 1.5);

   return g;
}



//
TGraph *HistTools::GetMaxGraph(TGraph **graph, UInt_t ngraphs, Bool_t use_abs)
{
   TGraph *g_max = new TGraph(graph[0]->GetN());
   for (UInt_t ipoint = 0; ipoint < (UInt_t)g_max->GetN(); ++ipoint)
   {
      Double_t x = graph[0]->GetX()[ipoint];
      Double_t ymax = -DBL_MAX;
      for (UInt_t igraph = 0; igraph < ngraphs; ++igraph)
      {
         Double_t y = graph[igraph]->GetY()[ipoint];
         if (use_abs)
         {
            y = TMath::Abs(y);
         }
         if (y > ymax)
         {
            ymax = y;
         }
      }
      g_max->SetPoint(ipoint, x, ymax);
   }

   return g_max;
}



//
TH1D *HistTools::GraphToHist(TGraph *graph, Double_t xmin, Double_t xmax, Bool_t is_log, Double_t frac, Double_t tolerance, Bool_t random_frac)
{
   if (xmax != -DBL_MAX)
   {
      Double_t x = graph->GetX()[0];
      if (graph->GetEX() != NULL) x -= graph->GetEX()[0];
      if (graph->GetEXlow() != NULL) x -= graph->GetEXlow()[0];

      if (xmax < x) return NULL;
   }
   UInt_t first_point = xmin == DBL_MAX ? 0 : FindFirstEdgeGreaterThan(graph, xmin);
   UInt_t last_point  = xmax == -DBL_MAX ? graph->GetN() - 1 : FindLastEdgeGreaterThan(graph, xmax);

   UInt_t ipoint = first_point;
   UInt_t ibin   = 0;
   std::vector<Double_t> bins;
   std::vector<Double_t> y;
   std::vector<Double_t> ey;

   if (graph->GetEX() != NULL && graph->GetEX()[0] > 0.) // binned TGraphError
   {
      bins.push_back(graph->GetX()[ipoint] - graph->GetEX()[ipoint]);
      for ( ; ipoint < last_point; ++ipoint)
      {
         bins.push_back(graph->GetX()[ipoint] + graph->GetEX()[ipoint]);
         y.push_back(graph->GetY()[ipoint]);
         ey.push_back(graph->GetEY()[ipoint]);
         if (TMath::Abs((graph->GetX()[ipoint + 1] - graph->GetEX()[ipoint + 1])/(graph->GetX()[ipoint] + graph->GetEX()[ipoint])-1) > tolerance)
         {
            bins.push_back(graph->GetX()[ipoint + 1] - graph->GetEX()[ipoint + 1]);
            y.push_back(0.);
            ey.push_back(0.);
         }
      }
      bins.push_back(graph->GetX()[ipoint] + graph->GetEX()[ipoint]);
      y.push_back(graph->GetY()[ipoint]);
      ey.push_back(graph->GetEY()[ipoint]);
   }
   else if (graph->GetEXlow() != NULL && graph->GetEXlow()[0] > 0. && graph->GetEXhigh()[0] > 0.) // binned TGraphAsymmErrors
   {
      bins.push_back(graph->GetX()[ipoint] - graph->GetEXlow()[ipoint]);
      for ( ; ipoint < last_point; ++ipoint)
      {
         bins.push_back(graph->GetX()[ipoint] + graph->GetEXhigh()[ipoint]);
         y.push_back(graph->GetY()[ipoint]);
         ey.push_back(graph->GetErrorY(ipoint));

         if (TMath::Abs((graph->GetX()[ipoint + 1] - graph->GetEXlow()[ipoint + 1])/(graph->GetX()[ipoint] + graph->GetEXhigh()[ipoint])-1) > tolerance)
         {
            bins.push_back(graph->GetX()[ipoint + 1] - graph->GetEXlow()[ipoint + 1]);
            y.push_back(0.);
            ey.push_back(0.);
         }
      }
      bins.push_back(graph->GetX()[ipoint] + graph->GetEXhigh()[ipoint]);
      y.push_back(graph->GetY()[ipoint]);
      ey.push_back(graph->GetErrorY(ipoint));
   }
   else // unbinned TGraph: assume uniform binning in log or linear scale depending on is_log
   {
      if (random_frac) frac = gRandom->Gaus(0.5, 0.1);
      Double_t xg1 = graph->GetX()[ipoint];
      Double_t xg2 = graph->GetX()[ipoint + 1];
      Double_t err = graph->GetErrorY(ipoint);
      Double_t x   = is_log ? TMath::Power(TMath::Power(xg1, 1 - frac + frac*frac) / TMath::Power(xg2, 1 - 2*frac + frac*frac), 1/frac) :
                              ((1 - frac + frac*frac)*xg1 - (1 - 2*frac + frac*frac)*xg2) / frac;
      bins.push_back(x); // left edge of first bin
      y.push_back(graph->GetY()[ipoint]);
      ey.push_back(err < 0. ? 0. : err);
      for ( ; ipoint < last_point; ++ipoint)
      {
         if (random_frac) frac = gRandom->Gaus(0.5, 0.1);
         xg1 = graph->GetX()[ipoint];
         xg2 = graph->GetX()[ipoint + 1];
         err = graph->GetErrorY(ipoint + 1);
         x   = is_log ? TMath::Power(xg1, frac)*TMath::Power(xg2, 1 - frac) : frac*xg1 + (1 - frac)*xg2;

         bins.push_back(x); // right edge of bin i, left edge of bin i+1
         y.push_back(graph->GetY()[ipoint + 1]);
         ey.push_back(err < 0. ? 0. : err);
      }
      if (random_frac) frac = gRandom->Gaus(0.5, 0.1);
      x = is_log ? TMath::Power(TMath::Power(xg2, 1 - frac + frac*frac) / TMath::Power(xg1, frac*frac), 1/(1 - frac)) :
                   ((1 - frac + frac*frac)*xg1 - frac*frac*xg2) / (1 - frac);
      bins.push_back(x); // right edge of last bin
   }

   UInt_t nbins = bins.size() - 1;
   Double_t *xbins = new Double_t[nbins + 1];
   std::copy(bins.begin(), bins.end(), xbins);

   std::string name = graph->GetName();
   name[0] = 'h';
   TH1D *hist = new TH1D(name.c_str(), graph->GetTitle(), nbins, xbins);
   CopyStyle(graph, hist);

   for (ibin = 0; ibin < nbins; ++ibin)
   {
      hist->SetBinContent(ibin + 1, y[ibin]);
      hist->SetBinError(ibin + 1, ey[ibin]);
   }

   return hist;
}



//
TH1D *HistTools::GetOccupancyHist(TGraph *g, Bool_t weighted, UInt_t xrange[2], Double_t min, Double_t max, Bool_t log, UInt_t nbins, UInt_t bin_scale)
{
   UInt_t first_point;
   UInt_t last_point;
   if (xrange == NULL)
   {
      first_point = 0;
      last_point  = g->GetN() - 1;
   }
   else
   {
      first_point = xrange[0];
      last_point  = xrange[1];
   }
   UInt_t npoints = last_point - first_point + 1;

   if (min == -DBL_MAX || max == -DBL_MAX)
   {
      min = *std::min_element(g->GetY() + first_point, g->GetY() + last_point + 1);
      max = *std::max_element(g->GetY() + first_point, g->GetY() + last_point + 1);
   }

   /*if (log)
   {
      Double_t margin = TMath::Exp(0.02*(TMath::Log(max) - TMath::Log(min)));
      min /= margin;
      max *= margin;
   }
   else
   {
      Double_t margin = 0.02*(max - min);
      min -= margin;
      max += margin;
   }*/

   if (nbins == 0) nbins = npoints / bin_scale;
   Double_t *xbins = new Double_t[nbins + 1];
   if (log) BuildLogBins(min, max, nbins, xbins);
   else BuildLinearBins(min, max, nbins, xbins);

   std::string name = g->GetName();
   name[0] = 'h';
   name += "_occ";

   std::string title = g->GetTitle();
   size_t p = title.find(Form(";%s;%s", g->GetXaxis()->GetTitle(), g->GetYaxis()->GetTitle()));
   if (p != string::npos && p > 0)
   {
      title.erase(p);
   }
   title += " - Occupancy";

   TH1D *h_occ = new TH1D(name.c_str(), title.c_str(), nbins, xbins);
   h_occ->SetXTitle(g->GetYaxis()->GetTitle());
   h_occ->SetYTitle("# entries");
   h_occ->Sumw2();
   CopyStyle(g, h_occ);

   for (UInt_t ipoint = first_point; ipoint <= last_point; ++ipoint)
   {
      Double_t y  = g->GetY()[ipoint];
      Double_t dy = g->GetErrorY(ipoint);
      Double_t w = weighted ? (dy > 0. ? 1./dy : 1.) : 1.;

      h_occ->Fill(y, w);
   }

   return h_occ;
}

TH1D *HistTools::GetOccupancyHist(TGraph *g, Bool_t weighted, Double_t xrange[2], Double_t min, Double_t max, Bool_t log, UInt_t nbins, UInt_t bin_scale)
{
   UInt_t range[2];
   if (xrange != NULL)
   {
      range[0] = FindPoint(g, xrange[0]);
      range[1] = FindPoint(g, xrange[1], range[0] + 1);
   }

   return GetOccupancyHist(g, weighted, xrange != NULL ? range : NULL, nbins, log, min, max, bin_scale);
}

TH1D *HistTools::GetOccupancyHist(TH1 *h, Bool_t weighted, Bool_t nozero, Double_t min, Double_t max, Bool_t log, UInt_t nbins)
{
   if (min == -DBL_MAX || max == -DBL_MAX)
   {
      min = h->GetMinimum();
      max = h->GetMaximum();
   }

   Int_t first_bin_x = h->GetXaxis()->GetFirst();
   Int_t last_bin_x  = h->GetXaxis()->GetLast();
   Int_t first_bin_y = 0;
   Int_t last_bin_y  = 0;
   Int_t first_bin_z = 0;
   Int_t last_bin_z  = 0;
   if (h->GetDimension() > 1)
   {
      first_bin_y = h->GetYaxis()->GetFirst();
      last_bin_y  = h->GetYaxis()->GetLast();
   }
   if (h->GetDimension() > 2)
   {
      first_bin_z = h->GetZaxis()->GetFirst();
      last_bin_z  = h->GetZaxis()->GetLast();
   }
   UInt_t nbinsx = last_bin_x - first_bin_x + 1;
   UInt_t nbinsy = last_bin_y - first_bin_y + 1;
   UInt_t nbinsz = last_bin_z - first_bin_z + 1;

   /*if (log)
   {
      Double_t margin = TMath::Exp(0.02*(TMath::Log(max) - TMath::Log(min)));
      min /= margin;
      max *= margin;
   }
   else
   {
      Double_t margin = 0.02*(max - min);
      min -= margin;
      max += margin;
   }*/

   Double_t *xbins = new Double_t[nbins + 1];
   if (log) BuildLogBins(min, max, nbins, xbins);
   else BuildLinearBins(min, max, nbins, xbins);

   std::string name = h->GetName();
   name += "_occ";

   std::string title = h->GetTitle();
   size_t p = title.find(Form(";%s;%s", h->GetXaxis()->GetTitle(), h->GetYaxis()->GetTitle()));
   if (p != string::npos && p > 0)
   {
      title.erase(p);
   }
   title += " - Occupancy";

   TH1D *h_occ = new TH1D(name.c_str(), title.c_str(), nbins, xbins);
   h_occ->Sumw2();
   CopyStyle(h, h_occ);

   UInt_t ibin;
   for (UInt_t ibinz = 1; ibinz <= nbinsz; ++ibinz)
   {
      for (UInt_t ibiny = 1; ibiny <= nbinsy; ++ibiny)
      {
         for (UInt_t ibinx = 1; ibinx <= nbinsx; ++ibinx)
         {
            ibin = h->GetBin(ibinx, ibiny, ibinz);

            Double_t y  = h->GetBinContent(ibin);
            Double_t dy = h->GetBinError(ibin);
            Double_t w  = weighted ? (dy > 0. ? 1./dy : 1.) : 1.;

            if (nozero && y == 0.) continue;

            h_occ->Fill(y, w);
         }
      }
   }

   return h_occ;
}



//
TGraph *HistTools::SampleWithReplacement(TGraph *g, UShort_t random_sampling, Double_t scale_err)
{
   UInt_t npoints = g->GetN();

   Bool_t has_errors = g->GetEY() != NULL || g->GetEYlow() != NULL;

   TGraph *g_sample = new TGraph(npoints);

   for (UInt_t ipoint = 0; ipoint < npoints; ++ipoint)
   {
      UInt_t jpoint = gRandom->Integer(npoints);

      Double_t x = g->GetX()[jpoint];
      Double_t y = g->GetY()[jpoint];
      if (random_sampling > 0 && has_errors)
      {
         Double_t ex = g->GetErrorX(jpoint);
         Double_t ey = g->GetErrorY(jpoint);

         x = gRandom->Gaus(x, ex*scale_err);
         y = gRandom->Gaus(y, ey*scale_err);
      }

      g_sample->SetPoint(ipoint, x, y);
   }

   return g_sample;
}

TGraph *HistTools::SampleWithNoReplacement(TGraph *g, Double_t scale_err)
{
   UInt_t npoints = g->GetN();

   Bool_t has_errors = g->GetEY() != NULL || g->GetEYlow() != NULL;
   if (!has_errors)
   {
      std::cerr << FG_RED_B << Form(" !!! HistTools::SampleWithNoReplacement: graph '%s' has no errors, cannot sample it!", g->GetName()) << RESET << std::endl;
      return NULL;
   }

   TGraph *g_sample = new TGraph(npoints);

   for (UInt_t ipoint = 0; ipoint < npoints; ++ipoint)
   {
      Double_t x = g->GetX()[ipoint];
      Double_t y = g->GetY()[ipoint];
      Double_t ex = g->GetErrorX(ipoint);
      Double_t ey = g->GetErrorY(ipoint);

      x = gRandom->Gaus(x, ex*scale_err);
      y = gRandom->Gaus(y, ey*scale_err);

      g_sample->SetPoint(ipoint, x, y);
   }

   return g_sample;
}



//
void HistTools::GetRange(TH1 *hist, Double_t &xmin, Double_t &xmax)
{
   xmin = hist->GetBinLowEdge(1);
   xmax = hist->GetBinLowEdge(hist->GetNbinsX() + 1);
}

void HistTools::GetRange(TGraph *graph, Double_t &xmin, Double_t &xmax)
{
   xmin = DBL_MAX;
   xmax = -DBL_MAX;

   for (UInt_t ipoint = 0; ipoint < (UInt_t)graph->GetN(); ++ipoint)
   {
      Double_t x = graph->GetX()[ipoint];
      if (graph->GetEX() != NULL) x -= graph->GetEX()[ipoint];
      else if (graph->GetEXlow() != NULL) x -= graph->GetEXlow()[ipoint];
      if (x < xmin)
      {
         xmin = x;
      }

      x = graph->GetX()[ipoint];
      if (graph->GetEX() != NULL) x += graph->GetEX()[ipoint];
      else if (graph->GetEXlow() != NULL) x += graph->GetEXhigh()[ipoint];
      if (x > xmax)
      {
         xmax = x;
      }
   }
}



//
TGraphErrors *HistTools::RotateHist(TH1 *hist, Bool_t normalize, Double_t ymin, Double_t ymax)
{
   Double_t nbins = hist->GetNbinsX();

   Double_t sum = normalize ? hist->GetSumOfWeights() : 1.;

   Double_t xmin = hist->GetBinLowEdge(1);
   Double_t xmax = hist->GetBinLowEdge(nbins + 1);

   if (ymin == -DBL_MAX || ymax == -DBL_MAX)
   {
      ymin = hist->GetMinimum() / sum;
      ymax = hist->GetMaximum() / sum;
   }

   UInt_t ipoint = 0;

   TGraphErrors *ge = new TGraphErrors(2*nbins + 2);
   CopyStyle(hist, ge);

   ge->SetPoint(ipoint++, 0., xmin);
   for (UShort_t ibin = 1; ibin <= nbins; ++ibin)
   {
      Double_t x1 = hist->GetBinLowEdge(ibin);
      Double_t x2 = hist->GetBinLowEdge(ibin + 1);

      Double_t y  = hist->GetBinContent(ibin) / sum;
      //~ Double_t dy = hist->GetBinError(ibin) / sum;

      ge->SetPoint(ipoint++, y, x1);
      ge->SetPoint(ipoint++, y, x2);
   }
   ge->SetPoint(ipoint++, 0., xmax);

   return ge;
}

TGraph *HistTools::RotateGraph(TGraph *g)
{
   TGraph *gs = (TGraph *)g->Clone();

   for (UShort_t ipoint = 0; ipoint < g->GetN(); ++ipoint)
   {
      Double_t x = g->GetX()[ipoint];
      Double_t y = g->GetY()[ipoint];
      gs->GetX()[ipoint] = y;
      gs->GetY()[ipoint] = x;

      if (g->GetEY() != NULL)
      {
         x = g->GetEX()[ipoint];
         y = g->GetEY()[ipoint];
         gs->GetEX()[ipoint] = y;
         gs->GetEY()[ipoint] = x;
      }
      else if (g->GetEYlow() != NULL)
      {
         x = g->GetEXlow()[ipoint];
         y = g->GetEYlow()[ipoint];
         gs->GetEXlow()[ipoint] = y;
         gs->GetEYlow()[ipoint] = x;

         x = g->GetEXhigh()[ipoint];
         y = g->GetEYhigh()[ipoint];
         gs->GetEXhigh()[ipoint] = y;
         gs->GetEYhigh()[ipoint] = x;
      }
   }

   return gs;
}



//
TH1D *HistTools::Invert(TH1 *hist)
{
   UInt_t nbins = hist->GetNbinsX();
   Double_t *bins = new Double_t[nbins + 1];
   for (UInt_t ibin = nbins + 1; ibin > 0; --ibin)
   {
      Double_t xl = hist->GetBinLowEdge(ibin);
      bins[nbins + 1 - ibin] = 1./xl;
   }

   TH1D *h_inv = new TH1D(Form("%s_inv", hist->GetName()), hist->GetTitle(), nbins, bins);
   for (UInt_t ibin = 1; ibin <= nbins; ++ibin)
   {
      h_inv->SetBinContent(nbins + 1 - ibin, hist->GetBinContent(ibin));
      h_inv->SetBinError(nbins + 1 - ibin, hist->GetBinError(ibin));
   }

   return h_inv;
}



//
TGraph *HistTools::RebinTimeNew(TGraph *graph1, TGraph *graph2, Bool_t error_is_statistical, const Char_t *suffix)
{
   TGraph *graph_rebin = (TGraph *)graph1->Clone();

   if (strlen(graph1->GetName()) > 0 && suffix != NULL && strlen(suffix) > 0)
   {
      graph_rebin->SetName(Form("%s%s", graph1->GetName(), suffix));
   }

   if (RebinTime(graph_rebin, graph2, error_is_statistical)) return graph_rebin;
   else
   {
      delete graph_rebin;
      return NULL;
   }
}

TGraph *HistTools::RebinTimeNew(TGraph *graph1, time_t *time_bins, UInt_t nbins, Bool_t error_is_statistical, const Char_t *suffix)
{
   TGraph *graph_rebin = (TGraph *)graph1->Clone();

   if (strlen(graph1->GetName()) > 0 && suffix != NULL && strlen(suffix) > 0)
   {
      graph_rebin->SetName(Form("%s%s", graph1->GetName(), suffix));
   }

   if (RebinTime(graph_rebin, time_bins, nbins, error_is_statistical)) return graph_rebin;
   else
   {
      delete graph_rebin;
      return NULL;
   }
}

TGraph *HistTools::RebinTimeNew(TGraph *graph1, Double_t *time_bins, UInt_t nbins, Bool_t error_is_statistical, const Char_t *suffix)
{
   TGraph *graph_rebin = (TGraph *)graph1->Clone();

   if (strlen(graph1->GetName()) > 0 && suffix != NULL && strlen(suffix) > 0)
   {
      graph_rebin->SetName(Form("%s%s", graph1->GetName(), suffix));
   }

   if (RebinTime(graph_rebin, time_bins, nbins, error_is_statistical)) return graph_rebin;
   else
   {
      delete graph_rebin;
      return NULL;
   }
}

TGraph *HistTools::RebinTimeNew(TGraph *graph1, const std::vector<TimeInterval> &time_bins, Bool_t error_is_statistical, const Char_t *suffix)
{
   TGraph *graph_rebin = (TGraph *)graph1->Clone();

   if (strlen(graph1->GetName()) > 0 && suffix != NULL && strlen(suffix) > 0)
   {
      graph_rebin->SetName(Form("%s%s", graph1->GetName(), suffix));
   }

   if (RebinTime(graph_rebin, time_bins, error_is_statistical)) return graph_rebin;
   else
   {
      delete graph_rebin;
      return NULL;
   }
}

Bool_t HistTools::RebinTime(TGraph *graph1, TGraph *graph2, Bool_t error_is_statistical)
{
   return RebinTime(graph1, graph2->GetX(), graph2->GetN(), error_is_statistical);
}

Bool_t HistTools::RebinTime(TGraph *graph1, time_t *time_bins, UInt_t nbins, Bool_t error_is_statistical)
{
   UInt_t npoints = graph1->GetN();
   if (npoints < nbins)
   {
      std::cerr << FG_RED_B << Form(" !!! HistTools::RebinTime: graph1:%s (%s) has less points (%u) than requested new time bins (%u)", graph1->GetName(), graph1->GetTitle(), npoints, nbins) << RESET << std::endl;
      return false;
   }

   time_t xbinb = 0;
   time_t xbine = 0;
   time_t xdata = 0;

   UInt_t avg_points = 0;
   UInt_t cur_point  = 0;
   UInt_t cur_bin    = 0;

   Double_t ydata  = 0.;
   Double_t ydata2 = 0.;
   Double_t ydata3 = 0.;
   Double_t ydata4 = 0.;
   Double_t err2l  = 0.;
   Double_t err2u  = 0.;
   Double_t disp;

   for (UInt_t ipoint = 0; ipoint < npoints; ++ipoint)
   {
      xbinb = time_bins[cur_bin];
      xbine = cur_bin + 1 < nbins ? time_bins[cur_bin + 1] : INT_MAX;
      xdata = graph1->GetX()[cur_point];

      if (xbinb <= xdata && xdata < xbine)
      {
         Double_t y = graph1->GetY()[cur_point];
         ydata  += y;

         if (!error_is_statistical)
         {
            ydata2 += y*y;
            ydata3 += y*y*y;
            ydata4 += y*y*y*y;
         }

         if (graph1->GetEY() != NULL)
         {
            err2l += graph1->GetEY()[cur_point]*graph1->GetEY()[cur_point];
         }
         else if (graph1->GetEYlow() != NULL)
         {
            err2l += graph1->GetEYlow()[cur_point]*graph1->GetEYlow()[cur_point];
            err2u += graph1->GetEYhigh()[cur_point]*graph1->GetEYhigh()[cur_point];
         }

         ++avg_points;

         graph1->RemovePoint(cur_point);
      }
      else
      {
         Double_t y  = ydata / avg_points;
         graph1->GetX()[cur_point] = xbinb;
         graph1->GetY()[cur_point] = y;

         if (error_is_statistical)
         {
            err2l = TMath::Sqrt(err2l) / avg_points;
            err2u = TMath::Sqrt(err2u) / avg_points;
         }
         else
         {
            disp = 0.;

            Double_t y2 = ydata2 / avg_points; // second central moment
            Double_t y3 = ydata3 / avg_points; // third central moment
            Double_t y4 = ydata4 / avg_points; // fourth central moment
            Double_t g2 = (avg_points > 1. ? (y4 - 4*y3*y + 6*y2*y*y - 3*y*y*y*y) / (y2*y2 + y*y*y*y - 2*y2*y*y) : 0) - 3; // sample excess kurtosis
            Double_t uc = avg_points - 1.5 - g2/4; // correction for unbiased sample standard deviation
            if (TMath::IsNaN(uc) || uc <= 0.)
            {
               //~ std::cerr << FG_RED_B << Form(" !!! HistTools::RebinTime: correction for unbiased sample standard deviation is zero, negative or NaN for time bin %u in %s", cur_bin, graph1->GetName()) << RESET << std::endl;
            }
            else
            {
               disp = TMath::Sqrt(avg_points/uc*(y2 - y*y)); // unbiased sample standard deviation
            }

            err2l = disp;
            err2u = disp;
         }

         if (graph1->GetEY() != NULL)
         {
            graph1->GetEY()[cur_point] = err2l;
         }
         else if (graph1->GetEYlow() != NULL)
         {
            graph1->GetEYlow()[cur_point]  = err2l;
            graph1->GetEYhigh()[cur_point] = err2u;
         }

         avg_points = 0;
         ydata = err2l = err2u = 0.;
         if (error_is_statistical) ydata2 = ydata3 = ydata4 = 0.;

         ++cur_bin;
         ++cur_point;
      }
   }

   Double_t y = ydata / avg_points;
   if (error_is_statistical)
   {
      err2l = TMath::Sqrt(err2l) / avg_points;
      err2u = TMath::Sqrt(err2u) / avg_points;
   }
   else
   {
      disp = 0.;

      Double_t y2 = ydata2 / avg_points; // second central moment
      Double_t y3 = ydata3 / avg_points; // third central moment
      Double_t y4 = ydata4 / avg_points; // fourth central moment
      Double_t g2 = (avg_points > 1. ? (y4 - 4*y3*y + 6*y2*y*y - 3*y*y*y*y) / (y2*y2 + y*y*y*y - 2*y2*y*y) : 0) - 3; // sample excess kurtosis
      Double_t uc = avg_points - 1.5 - g2/4; // correction for unbiased sample standard deviation
      if (TMath::IsNaN(uc) || uc <= 0.)
      {
         //~ std::cerr << " !!! HistTools::RebinTime: correction for unbiased sample standard deviation is zero, negative or NaN" << RESET << std::endl;
      }
      else
      {
         disp = TMath::Sqrt(avg_points/uc*(y2 - y*y)); // unbiased sample standard deviation
      }

      err2l = disp;
      err2u = disp;
   }

   graph1->SetPoint(cur_point, xbinb, y);
   if (graph1->GetEY() != NULL)
   {
      dynamic_cast<TGraphErrors *>(graph1)->SetPointError(cur_point, 0., err2l);
   }
   else if (graph1->GetEYlow() != NULL)
   {
      dynamic_cast<TGraphAsymmErrors *>(graph1)->SetPointError(cur_point, 0., 0., err2l, err2u);
   }

   return true;
}

Bool_t HistTools::RebinTime(TGraph *graph1, Double_t *time_bins, UInt_t nbins, Bool_t error_is_statistical)
{
   time_t *bins = new time_t[nbins];
   for (UInt_t ibin = 0; ibin < nbins; ++ibin)
   {
      bins[ibin] = time_bins[ibin];
   }

   return RebinTime(graph1, bins, nbins, error_is_statistical);
}

Bool_t HistTools::RebinTime(TGraph *graph1, const std::vector<TimeInterval> &time_bins, Bool_t error_is_statistical)
{
   UInt_t nbins = time_bins.size()-1;
   time_t *bins = new time_t[nbins];
   for (UInt_t ibin = 0; ibin < nbins; ++ibin)
   {
      bins[ibin] = time_bins[ibin].first;
   }

   return RebinTime(graph1, bins, nbins, error_is_statistical);
}



//
TGraph *HistTools::RebinNew(TGraph *graph1, TGraph *graph2, Bool_t error_is_statistical, const Char_t *suffix)
{
   TGraph *graph_rebin = (TGraph *)graph1->Clone();

   if (strlen(graph1->GetName()) > 0 && suffix != NULL && strlen(suffix) > 0)
   {
      graph_rebin->SetName(Form("%s%s", graph1->GetName(), suffix));
   }

   if (Rebin(graph_rebin, graph2, error_is_statistical)) return graph_rebin;
   else
   {
      delete graph_rebin;
      return NULL;
   }
}

TGraph *HistTools::RebinNew(TGraph *graph1, Double_t *new_bins, UInt_t nbins, Bool_t error_is_statistical, const Char_t *suffix)
{
   TGraph *graph_rebin = (TGraph *)graph1->Clone();

   if (strlen(graph1->GetName()) > 0 && suffix != NULL && strlen(suffix) > 0)
   {
      graph_rebin->SetName(Form("%s%s", graph1->GetName(), suffix));
   }

   if (Rebin(graph_rebin, new_bins, nbins, error_is_statistical)) return graph_rebin;
   else
   {
      delete graph_rebin;
      return NULL;
   }
}

Bool_t HistTools::Rebin(TGraph *graph1, TGraph *graph2, Bool_t error_is_statistical)
{
   return Rebin(graph1, graph2->GetX(), graph2->GetN(), error_is_statistical);
}

Bool_t HistTools::Rebin(TGraph *graph1, Double_t *new_bins, UInt_t nbins, Bool_t error_is_statistical)
{
   UInt_t npoints = graph1->GetN();

   Double_t xbinb  = 0.;
   Double_t xbine  = 0.;
   Double_t xdatab = 0.;
   Double_t xdatae = 0.;

   UInt_t avg_points = 0;
   UInt_t cur_point  = 0;
   UInt_t cur_bin    = 0;

   Double_t ydata  = 0.;
   Double_t ydata2 = 0.;
   Double_t ydata3 = 0.;
   Double_t ydata4 = 0.;
   Double_t err2l  = 0.;
   Double_t err2u  = 0.;
   Double_t disp;

   Double_t *val  = new Double_t[nbins]();
   Double_t *errl = new Double_t[nbins]();
   Double_t *erru = new Double_t[nbins]();
   Bool_t   *fill = new Bool_t[nbins]();

   while (cur_point < npoints && cur_bin < nbins)
   {
      xbinb = new_bins[cur_bin];
      xbine = cur_bin + 1 <= nbins ? new_bins[cur_bin + 1] : DBL_MAX;
      xdatae = xdatab = graph1->GetX()[cur_point];
      if (graph1->GetEX() != NULL)
      {
         xdatab -= graph1->GetEX()[cur_point];
         xdatae += graph1->GetEX()[cur_point];
      }
      if (graph1->GetEXlow() != NULL)
      {
         xdatab -= graph1->GetEXlow()[cur_point];
         xdatae -= graph1->GetEXhigh()[cur_point];
      }
PRINT_STRING(Form("OLDBIN[%03u]=(%13.10f,%13.10f)   NEWBIN[%03u]=(%13.10f,%13.10f)", cur_point, xdatab, xdatae, cur_bin, xbinb, xbine))
      if (xdatab < xbinb && xdatae < xbine)
      {
PRINT_STRING("INCREASE OLDBIN")
         ++cur_point;

         continue;
      }
      else if (xbinb <= xdatab && xdatae <= xbine)
      {
         Double_t y = graph1->GetY()[cur_point];
         ydata  += y;
PRINT_STRING(Form("SUMMING: %02u   y=%+12.6e   sum=%+12.6e", avg_points+1, y, ydata))
         if (!error_is_statistical)
         {
            ydata2 += y*y;
            ydata3 += y*y*y;
            ydata4 += y*y*y*y;
         }

         if (graph1->GetEY() != NULL)
         {
            err2l += graph1->GetEY()[cur_point]*graph1->GetEY()[cur_point];
         }
         else if (graph1->GetEYlow() != NULL)
         {
            err2l += graph1->GetEYlow()[cur_point]*graph1->GetEYlow()[cur_point];
            err2u += graph1->GetEYhigh()[cur_point]*graph1->GetEYhigh()[cur_point];
         }

         ++cur_point;
         ++avg_points;
      }
      else if (xdatab > xbinb && avg_points > 0)
      {
         Double_t y = ydata / avg_points;
         val[cur_bin] = y;
         fill[cur_bin] = true;
PRINT_STRING(Form("AVERAGE: %02u   avg=%+12.6e", avg_points, y))
         if (error_is_statistical)
         {
            err2l = TMath::Sqrt(err2l) / avg_points;
            err2u = TMath::Sqrt(err2u) / avg_points;
         }
         else
         {
            disp = 0.;

            Double_t y2 = ydata2 / avg_points; // second central moment
            Double_t y3 = ydata3 / avg_points; // third central moment
            Double_t y4 = ydata4 / avg_points; // fourth central moment
            Double_t g2 = (avg_points > 1. ? (y4 - 4*y3*y + 6*y2*y*y - 3*y*y*y*y) / (y2*y2 + y*y*y*y - 2*y2*y*y) : 0) - 3; // sample excess kurtosis
            Double_t uc = avg_points - 1.5 - g2/4; // correction for unbiased sample standard deviation
            if (TMath::IsNaN(uc) || uc <= 0.)
            {
               //~ std::cerr << FG_RED_B << Form(" !!! HistTools::Rebin: correction for unbiased sample standard deviation is zero, negative or NaN for time bin %u in %s", cur_bin, graph1->GetName()) << RESET << std::endl;
            }
            else
            {
               disp = TMath::Sqrt(avg_points/uc*(y2 - y*y)); // unbiased sample standard deviation
            }

            err2l = disp;
            err2u = disp;
         }

         if (graph1->GetEY() != NULL)
         {
            errl[cur_bin] = err2l;
         }
         else if (graph1->GetEYlow() != NULL)
         {
            errl[cur_bin] = err2l;
            erru[cur_bin] = err2u;
         }

         avg_points = 0;
         ydata = err2l = err2u = 0.;
         if (!error_is_statistical) ydata2 = ydata3 = ydata4 = 0.;

         ++cur_bin;
      }
      else
      {
PRINT_STRING("INCREASE NEWBIN")
         ++cur_bin;

         continue;
      }
   }

   if (avg_points > 0)
   {
      Double_t y = ydata / avg_points;
      val[cur_bin] = y;
      fill[cur_bin] = true;

      if (error_is_statistical)
      {
         err2l = TMath::Sqrt(err2l) / avg_points;
         err2u = TMath::Sqrt(err2u) / avg_points;
      }
      else
      {
         disp = 0.;

         Double_t y2 = ydata2 / avg_points; // second central moment
         Double_t y3 = ydata3 / avg_points; // third central moment
         Double_t y4 = ydata4 / avg_points; // fourth central moment
         Double_t g2 = (avg_points > 1. ? (y4 - 4*y3*y + 6*y2*y*y - 3*y*y*y*y) / (y2*y2 + y*y*y*y - 2*y2*y*y) : 0) - 3; // sample excess kurtosis
         Double_t uc = avg_points - 1.5 - g2/4; // correction for unbiased sample standard deviation
         if (TMath::IsNaN(uc) || uc <= 0.)
         {
            //~ std::cerr << " !!! HistTools::Rebin: correction for unbiased sample standard deviation is zero, negative or NaN" << RESET << std::endl;
         }
         else
         {
            disp = TMath::Sqrt(avg_points/uc*(y2 - y*y)); // unbiased sample standard deviation
         }

         err2l = disp;
         err2u = disp;
      }

      if (graph1->GetEY() != NULL)
      {
         errl[cur_bin] = err2l;
      }
      else if (graph1->GetEYlow() != NULL)
      {
         errl[cur_bin] = err2l;
         erru[cur_bin] = err2u;
      }
   }

   cur_point = 0;
   for (cur_bin = 0; cur_bin < nbins; ++cur_bin)
   {
      if (!fill[cur_bin]) continue;

      graph1->GetX()[cur_point] = graph1->GetEXlow() != NULL ? TMath::Sqrt(new_bins[cur_bin]*new_bins[cur_bin+1]) : 0.5*(new_bins[cur_bin] + new_bins[cur_bin+1]);
      graph1->GetY()[cur_point] = val[cur_bin];

      if (graph1->GetEY() != NULL)
      {
         graph1->GetEX()[cur_point] = graph1->GetX()[cur_point] - new_bins[cur_bin];
         graph1->GetEY()[cur_point] = errl[cur_bin];
      }
      else if (graph1->GetEYlow() != NULL)
      {
         graph1->GetEXlow()[cur_point] = graph1->GetX()[cur_point] - new_bins[cur_bin];
         graph1->GetEXlow()[cur_point] = new_bins[cur_bin+1] - graph1->GetX()[cur_point];
         graph1->GetEYlow()[cur_point] = errl[cur_bin];
         graph1->GetEYhigh()[cur_point] = erru[cur_bin];
      }

      ++cur_point;
   }

   for (UInt_t ipoint = cur_point; ipoint < npoints; ++ipoint) graph1->RemovePoint(cur_point);

   delete [] val;
   delete [] errl;
   delete [] erru;
   delete [] fill;

   return true;
}



//
TGraph *HistTools::RelativeErrorNew(TGraph *graph, const Char_t *suffix, UShort_t use_error, Double_t value)
{
   TGraph *graph_relerr = (TGraph *)graph->Clone();

   if (strlen(graph->GetName()) > 0 && suffix != NULL && strlen(suffix) > 0)
   {
      graph_relerr->SetName(Form("%s%s", graph->GetName(), suffix));
   }

   if (RelativeError(graph_relerr, use_error, value)) return graph_relerr;
   else
   {
      delete graph_relerr;
      return NULL;
   }
}

TH1 *HistTools::RelativeErrorNew(TH1 *hist, const Char_t *suffix, UShort_t use_error, Double_t value)
{
   TH1 *hist_relerr = (TH1 *)hist->Clone(Form("%s%s", hist->GetName(), suffix));

   if (RelativeError(hist_relerr, use_error, value)) return hist_relerr;
   else
   {
      delete hist_relerr;
      return NULL;
   }
}

Bool_t HistTools::RelativeError(TGraph *graph, UShort_t use_error, Double_t value)
{
   if (graph->GetEY() == NULL && graph->GetEYlow() == NULL)
   {
      std::cerr << FG_RED_B << Form(" !!! HistTools::RelativeError: graph:%s (%s) cannot be a TGraph\n", graph->GetName(), graph->GetTitle()) << RESET << std::endl;
      return false;
   }

   UInt_t npoints = graph->GetN();
   for (UInt_t ipoint = 0; ipoint < npoints; ++ipoint)
   {
      Double_t y  = graph->GetY()[ipoint];
      Double_t dy = graph->GetErrorY(ipoint);

      switch (use_error)
      {
         case 0:
            dy = y != 0. ? dy / y : 0.;
            y  = value;
            break;
         case 1:
            y  = dy;
            dy = 0.;
            break;
         case 2:
            y  = y != 0. ? dy / y : 0.;
            dy = 0;
            break;
      }

      graph->GetY()[ipoint] = y;
      if (graph->GetEY() != NULL)
      {
         graph->GetEY()[ipoint] = dy;
      }
      else if (graph->GetEYlow() != NULL)
      {
         graph->GetEYlow()[ipoint]  = dy;
         graph->GetEYhigh()[ipoint] = dy;
      }
   }

   return true;
}

Bool_t HistTools::RelativeError(TH1 *hist, UShort_t use_error, Double_t value)
{
   if (hist->GetDimension() != 1)
   {
      std::cerr << FG_RED_B << Form(" !!! HistTools::RelativeError: %s (%s) must be a 1D histogram\n", hist->GetName(), hist->GetTitle()) << RESET << std::endl;
      return false;
   }

   UInt_t nbins = hist->GetNbinsX();
   for (UInt_t ibin = 1; ibin <= nbins; ++ibin)
   {
      Double_t y  = hist->GetBinContent(ibin);
      Double_t dy = hist->GetBinError(ibin);

      switch (use_error)
      {
         case 0:
            dy = y != 0. ? dy / y : 0.;
            y  = value;
            break;
         case 1:
            y  = dy;
            dy = 0.;
            break;
         case 2:
            y  = y != 0. ? dy / y : 0.;
            dy = 0;
            break;
      }

      hist->SetBinContent(ibin, y);
      hist->SetBinError(ibin, dy);
   }

   return true;
}



//
TGraph *HistTools::RemoveDataConsistentWithZeroNew(TGraph *graph, const Char_t *suffix)
{
   TGraph *graph_mod = (TGraph *)graph->Clone();

   if (strlen(graph->GetName()) > 0 && suffix != NULL && strlen(suffix) > 0)
   {
      graph_mod->SetName(Form("%s%s", graph->GetName(), suffix));
   }

   if (RemoveDataConsistentWithZero(graph_mod)) return graph_mod;
   else
   {
      delete graph_mod;
      return NULL;
   }
}

TH1 *HistTools::RemoveDataConsistentWithZeroNew(TH1 *hist, const Char_t *suffix)
{
   TH1 *hist_mod = (TH1 *)hist->Clone(Form("%s%s", hist->GetName(), suffix));

   RemoveDataConsistentWithZero(hist);

   return hist_mod;
}

Bool_t HistTools::RemoveDataConsistentWithZero(TGraph *graph)
{
   if (graph->GetEY() == NULL && graph->GetEYlow() == NULL)
   {
      std::cerr << FG_RED_B << Form(" !!! HistTools::RemoveDataConsistentWithZero: graph:%s (%s) cannot be a TGraph\n", graph->GetName(), graph->GetTitle()) << RESET << std::endl;
      return false;
   }

   UInt_t npoints = graph->GetN();
   for (Int_t ipoint = npoints - 1; ipoint >= 0; --ipoint)
   {
      if (graph->GetY()[ipoint] <= graph->GetErrorY(ipoint) || TMath::IsNaN(graph->GetErrorY(ipoint)))
      {
         graph->RemovePoint(ipoint);
      }
   }

   return true;
}

void HistTools::RemoveDataConsistentWithZero(TH1 *hist)
{
   Int_t nbinsx = hist->GetNbinsX();
   Int_t nbinsy = hist->GetNbinsY();
   Int_t nbinsz = hist->GetNbinsZ();

   if (hist->GetDimension() < 2) nbinsy = -1;
   if (hist->GetDimension() < 3) nbinsz = -1;

   Int_t ibin;
   for (Int_t ibinz = 0; ibinz <= nbinsz + 1; ++ibinz)
   {
      for (Int_t ibiny = 0; ibiny <= nbinsy + 1; ++ibiny)
      {
         for (Int_t ibinx = 0; ibinx <= nbinsx + 1; ++ibinx)
         {
            ibin = hist->GetBin(ibinx, ibiny, ibinz);
            if (hist->GetBinContent(ibin) <= hist->GetBinError(ibin))
            {
               hist->SetBinContent(ibin, 0.);
               hist->SetBinError(ibin, 0.);
            }
         }
      }
   }

   hist->ResetStats();
}



//
TGraph *HistTools::RemoveZeroNew(TGraph *graph, Bool_t use_error, const Char_t *suffix)
{
   TGraph *graph_nozero = (TGraph *)graph->Clone();

   if (strlen(graph->GetName()) > 0 && suffix != NULL && strlen(suffix) > 0)
   {
      graph_nozero->SetName(Form("%s%s", graph->GetName(), suffix));
   }

   RemoveZero(graph_nozero, use_error);

   return graph_nozero;
}

void HistTools::RemoveZero(TGraph *graph, Bool_t use_error)
{
   UInt_t npoints = graph->GetN();

   for (Int_t ipoint = npoints - 1; ipoint >= 0; --ipoint)
   {
      if ((!use_error && graph->GetY()[ipoint] == 0.) ||
          (use_error && graph->GetErrorY(ipoint) == 0.))
      {
         graph->RemovePoint(ipoint);
      }
   }
}

TGraph *HistTools::RemoveZeroXNew(TGraph *graph, Bool_t use_error, const Char_t *suffix)
{
   TGraph *graph_nozero = (TGraph *)graph->Clone();

   if (strlen(graph->GetName()) > 0 && suffix != NULL && strlen(suffix) > 0)
   {
      graph_nozero->SetName(Form("%s%s", graph->GetName(), suffix));
   }

   RemoveZeroX(graph_nozero, use_error);

   return graph_nozero;
}

void HistTools::RemoveZeroX(TGraph *graph, Bool_t use_error)
{
   UInt_t npoints = graph->GetN();

   for (Int_t ipoint = npoints - 1; ipoint >= 0; --ipoint)
   {
      if ((!use_error && graph->GetX()[ipoint] == 0.) ||
          (use_error && graph->GetErrorX(ipoint) == 0.))
      {
         graph->RemovePoint(ipoint);
      }
   }
}



//
TGraph *HistTools::RemoveNaNNew(TGraph *graph, const Char_t *suffix)
{
   TGraph *graph_nonan = (TGraph *)graph->Clone();

   if (strlen(graph->GetName()) > 0 && suffix != NULL && strlen(suffix) > 0)
   {
      graph_nonan->SetName(Form("%s%s", graph->GetName(), suffix));
   }

   RemoveNaN(graph_nonan);

   return graph_nonan;
}

void HistTools::RemoveNaN(TGraph *graph)
{
   UInt_t npoints = graph->GetN();

   for (Int_t ipoint = npoints - 1; ipoint >= 0; --ipoint)
   {
      if (TMath::IsNaN(graph->GetY()[ipoint]))
      {
         graph->RemovePoint(ipoint);
      }
   }
}



//
void HistTools::RemovePoints(TGraph *g, UInt_t first, UInt_t last)
{
   for (UInt_t ipoint = first; ipoint <= last; ++ipoint)
   {
      g->RemovePoint(first);
   }
}



//
TGraph *HistTools::RemoveInfinityNew(TGraph *graph, const Char_t *suffix)
{
   TGraph *graph_noinf = (TGraph *)graph->Clone();

   if (strlen(graph->GetName()) > 0 && suffix != NULL && strlen(suffix) > 0)
   {
      graph_noinf->SetName(Form("%s%s", graph->GetName(), suffix));
   }

   RemoveInfinity(graph_noinf);

   return graph_noinf;
}

void HistTools::RemoveInfinity(TGraph *graph)
{
   UInt_t npoints = graph->GetN();

   for (Int_t ipoint = npoints - 1; ipoint >= 0; --ipoint)
   {
      if (fabs(graph->GetY()[ipoint]) == TMath::Infinity())
      {
         graph->RemovePoint(ipoint);
      }
   }
}



//
TH1 *HistTools::RemoveInfinityNew(TH1 *hist, const Char_t *suffix)
{
   TH1 *hist_noinf = (TH1 *)hist->Clone();

   if (strlen(hist->GetName()) > 0 && suffix != NULL && strlen(suffix) > 0)
   {
      hist_noinf->SetName(Form("%s%s", hist->GetName(), suffix));
   }

   RemoveInfinity(hist_noinf);

   return hist_noinf;
}

void HistTools::RemoveInfinity(TH1 *hist)
{
   for (UInt_t ibin = 1; ibin <= (UInt_t)hist->GetNbinsX(); ++ibin)
   {
      if (hist->GetBinContent(ibin) == TMath::Infinity())
      {
         hist->SetBinContent(ibin, 0.);
      }
      else if (hist->GetBinContent(ibin) == -TMath::Infinity())
      {
         hist->SetBinContent(ibin, -0.);
      }

      if (hist->GetBinError(ibin) == TMath::Infinity())
      {
         hist->SetBinError(ibin, 0.);
      }
   }
}



//
TGraph *HistTools::ZeroErrorNew(TGraph *graph, const Char_t *suffix)
{
   TGraph *graph_err0 = (TGraph *)graph->Clone();

   if (strlen(graph->GetName()) > 0 && suffix != NULL && strlen(suffix) > 0)
   {
      graph_err0->SetName(Form("%s%s", graph->GetName(), suffix));
   }

   if (ZeroError(graph_err0)) return graph_err0;
   else
   {
      delete graph_err0;
      return NULL;
   }
}

Bool_t HistTools::ZeroError(TGraph *graph)
{
   if (graph->GetEY() == NULL && graph->GetEYlow() == NULL)
   {
      std::cerr << FG_RED_B << Form(" !!! HistTools::RemoveDataConsistentWithZero: graph:%s (%s) cannot be a TGraph\n", graph->GetName(), graph->GetTitle()) << RESET << std::endl;
      return false;
   }

   UInt_t npoints = graph->GetN();
   for (Int_t ipoint = npoints - 1; ipoint >= 0; --ipoint)
   {
      if (graph->GetEY() != NULL)
      {
         graph->GetEY()[ipoint] = 0.;
      }
      else if (graph->GetEYlow() != NULL)
      {
         graph->GetEYlow()[ipoint]  = 0.;
         graph->GetEYhigh()[ipoint] = 0.;
      }
   }

   return true;
}



//
TGraph *HistTools::ClipNew(TGraph *graph, Double_t min, Double_t max, const Char_t *suffix)
{
   TGraph *graph_clipped = (TGraph *)graph->Clone();

   if (strlen(graph->GetName()) > 0 && suffix != NULL && strlen(suffix) > 0)
   {
      graph_clipped->SetName(Form("%s%s", graph->GetName(), suffix));
   }

   if (Clip(graph_clipped, min, max)) return graph_clipped;
   else
   {
      delete graph_clipped;
      return NULL;
   }
}

Bool_t HistTools::Clip(TGraph *graph, Double_t min, Double_t max)
{
   UInt_t npoints = graph->GetN();

   for (Int_t ipoint = npoints - 1; ipoint >= 0; --ipoint)
   {
      if (graph->GetY()[ipoint] < min)
      {
         graph->GetY()[ipoint] = min;
      }
      else if (graph->GetY()[ipoint] > max)
      {
         graph->GetY()[ipoint] = max;
      }
   }

   return true;
}



//
TH2 *HistTools::NormalizeSliceNew(TH2 *hist, Bool_t by_row, Bool_t use_underover, const Char_t *suffix)
{
   TH2 *hist_norm = (TH2 *)hist->Clone(Form("%s%s", hist->GetName(), suffix));

   if (NormalizeSlice(hist_norm, by_row, use_underover)) return hist_norm;
   else
   {
      delete hist_norm;
      return NULL;
   }
}

Bool_t HistTools::NormalizeSlice(TH2 *hist, Bool_t by_row, Bool_t use_underover)
{
   UInt_t nrows = hist->GetNbinsY();
   UInt_t ncols = hist->GetNbinsX();

   UInt_t nbins1 = (by_row ? nrows : ncols) + use_underover;
   UInt_t nbins2 = (by_row ? ncols : nrows) + use_underover;
   UInt_t first1 = 1 - use_underover;
   UInt_t first2 = 1 - use_underover;

   for (UInt_t ibin = first1; ibin <= nbins1; ++ibin)
   {
      Double_t norm = 0.;
      for (UInt_t jbin = first2; jbin <= nbins2; ++jbin)
      {
         norm += by_row ? hist->GetBinContent(jbin, ibin) : hist->GetBinContent(ibin, jbin);
      }

      if (norm != 0.)
      {
         for (UInt_t jbin = first2; jbin <= nbins2; ++jbin)
         {
            if (by_row)
            {
               Double_t val = hist->GetBinContent(jbin, ibin);
               Double_t err = hist->GetBinError(jbin, ibin);
               hist->SetBinContent(jbin, ibin, val / norm);
               hist->SetBinError(jbin, ibin, err / norm);
            }
            else
            {
               Double_t val = hist->GetBinContent(ibin, jbin);
               Double_t err = hist->GetBinError(ibin, jbin);
               hist->SetBinContent(ibin, jbin, val / norm);
               hist->SetBinError(ibin, jbin, err / norm);
            }
         }
      }
   }

   return true;
}



//
TGraph *HistTools::TransformEnergyNew(TGraph *graph, Particle::Type particle, const Char_t *from_energy_unit, const Char_t *to_energy_unit, const Char_t *suffix)
{
   TGraph *graph_mod = (TGraph *)graph->Clone();

   if (strlen(graph->GetName()) > 0 && suffix != NULL && strlen(suffix) > 0)
   {
      graph_mod->SetName(Form("%s%s", graph->GetName(), suffix));
   }

   if (TransformEnergy(graph_mod, particle, from_energy_unit, to_energy_unit)) return graph_mod;
   else
   {
      delete graph_mod;
      return NULL;
   }
}

TH1 *HistTools::TransformEnergyNew(TH1 *hist, Particle::Type particle, const Char_t *from_energy_unit, const Char_t *to_energy_unit, const Char_t *suffix)
{
   TH1 *hist_mod = (TH1 *)hist->Clone(Form("%s%s", hist->GetName(), suffix));

   if (TransformEnergy(hist_mod, particle, from_energy_unit, to_energy_unit)) return hist_mod;
   else
   {
      delete hist_mod;
      return NULL;
   }
}

TGraph *HistTools::TransformEnergyNew(TGraph *graph, Particle::Type particle, Energy::Type from_energy_type, SIPrefix::Type from_energy_prefix, Energy::Type to_energy_type, SIPrefix::Type to_energy_prefix, const Char_t *suffix)
{
   TGraph *graph_mod = (TGraph *)graph->Clone();

   if (strlen(graph->GetName()) > 0 && suffix != NULL && strlen(suffix) > 0)
   {
      graph_mod->SetName(Form("%s%s", graph->GetName(), suffix));
   }

   if (TransformEnergy(graph_mod, particle, from_energy_type, from_energy_prefix, to_energy_type, to_energy_prefix)) return graph_mod;
   else
   {
      delete graph_mod;
      return NULL;
   }
}

TH1 *HistTools::TransformEnergyNew(TH1 *hist, Particle::Type particle, Energy::Type from_energy_type, SIPrefix::Type from_energy_prefix, Energy::Type to_energy_type, SIPrefix::Type to_energy_prefix, const Char_t *suffix)
{
   TH1 *hist_mod = (TH1 *)hist->Clone(Form("%s%s", hist->GetName(), suffix));

   if (TransformEnergy(hist_mod, particle, from_energy_type, from_energy_prefix, to_energy_type, to_energy_prefix)) return hist_mod;
   else
   {
      delete hist_mod;
      return NULL;
   }
}

Bool_t HistTools::TransformEnergy(TGraph *graph, Particle::Type particle, const Char_t *from_energy_unit, const Char_t *to_energy_unit)
{
   Energy::Type from_energy_type;
   SIPrefix::Type from_energy_prefix;
   if (!Unit::ParseEnergyUnit(from_energy_unit, from_energy_type, from_energy_prefix)) return false;

   Energy::Type to_energy_type;
   SIPrefix::Type to_energy_prefix;
   if (!Unit::ParseEnergyUnit(to_energy_unit, to_energy_type, to_energy_prefix)) return false;

   return TransformEnergy(graph, particle, from_energy_type, from_energy_prefix, to_energy_type, to_energy_prefix);
}

Bool_t HistTools::TransformEnergy(TH1 *hist, Particle::Type particle, const Char_t *from_energy_unit, const Char_t *to_energy_unit)
{
   Energy::Type from_energy_type;
   SIPrefix::Type from_energy_prefix;
   if (!Unit::ParseEnergyUnit(from_energy_unit, from_energy_type, from_energy_prefix)) return false;

   Energy::Type to_energy_type;
   SIPrefix::Type to_energy_prefix;
   if (!Unit::ParseEnergyUnit(to_energy_unit, to_energy_type, to_energy_prefix)) return false;

   return TransformEnergy(hist, particle, from_energy_type, from_energy_prefix, to_energy_type, to_energy_prefix);
}

Bool_t HistTools::TransformEnergy(TH1 *hist, Particle::Type particle, Energy::Type from_energy_type, SIPrefix::Type from_energy_prefix, Energy::Type to_energy_type, SIPrefix::Type to_energy_prefix)
{
   if (hist->GetDimension()!= 1)
   {
      std::cerr << FG_RED_B << Form(" !!! HistTools::TransformEnergy: hist:%s (%s) must be 1D.", hist->GetName(), hist->GetTitle()) << RESET << std::endl;
      return false;
   }

   Int_t nbins = hist->GetNbinsX();
   TArrayD axis(*(hist->GetXaxis()->GetXbins()));
   for (Int_t ibin = 1; ibin <= nbins + 1; ++ibin)
   {
      axis[ibin-1] = Unit::ConvertEnergy(Unit::ConvertEnergyType(hist->GetBinLowEdge(ibin), particle, from_energy_type, from_energy_prefix, to_energy_type), from_energy_prefix, to_energy_prefix);
   }
   hist->GetXaxis()->Set(nbins, axis.GetArray());

   hist->ResetStats();

   return true;
}

Bool_t HistTools::TransformEnergy(TGraph *graph, Particle::Type particle, Energy::Type from_energy_type, SIPrefix::Type from_energy_prefix, Energy::Type to_energy_type, SIPrefix::Type to_energy_prefix)
{
   if (graph->GetEY() == NULL && graph->GetEYlow() == NULL)
   {
      std::cerr << FG_RED_B << Form(" !!! HistTools::TransformEnergy: graph:%s (%s) cannot be a TGraph.", graph->GetName(), graph->GetTitle()) << RESET << std::endl;
      return false;
   }

   UInt_t npoints = graph->GetN();
   for (UInt_t ipoint = 0; ipoint < npoints; ++ipoint)
   {
      Double_t x = graph->GetX()[ipoint];
      Double_t range[2];

      if (graph->GetEY() != NULL)
      {
         range[0] = x - graph->GetEX()[ipoint];
         range[0] = x + graph->GetEX()[ipoint];
      }
      else if (graph->GetEYlow() != NULL)
      {
         range[0] = x - graph->GetEXlow()[ipoint];
         range[1] = x + graph->GetEXhigh()[ipoint];
      }

      x = Unit::ConvertEnergy(Unit::ConvertEnergyType(x, particle, from_energy_type, from_energy_prefix, to_energy_type), from_energy_prefix, to_energy_prefix);

      range[0] = Unit::ConvertEnergy(Unit::ConvertEnergyType(range[0], particle, from_energy_type, from_energy_prefix, to_energy_type), from_energy_prefix, to_energy_prefix);
      range[1] = Unit::ConvertEnergy(Unit::ConvertEnergyType(range[1], particle, from_energy_type, from_energy_prefix, to_energy_type), from_energy_prefix, to_energy_prefix);

      graph->GetX()[ipoint] = x;

      if (graph->GetEY() != NULL)
      {
         graph->GetEX()[ipoint] = range[1] - x;
      }
      else if (graph->GetEYlow() != NULL)
      {
         graph->GetEXlow()[ipoint]  = x - range[0];
         graph->GetEXhigh()[ipoint] = range[1] - x;
      }
   }

   return true;
}



//
TGraph *HistTools::TransformEnergyAndDifferentialFluxNew(TGraph *graph, Particle::Type particle, const Char_t *from_energy_unit, const Char_t *from_flux_unit, const Char_t *to_energy_unit, const Char_t *to_flux_unit, const Char_t *suffix)
{
   TGraph *graph_mod = (TGraph *)graph->Clone();

   if (strlen(graph->GetName()) > 0 && suffix != NULL && strlen(suffix) > 0)
   {
      graph_mod->SetName(Form("%s%s", graph->GetName(), suffix));
   }

   if (TransformEnergyAndDifferentialFlux(graph_mod, particle, from_energy_unit, from_flux_unit, to_energy_unit, to_flux_unit)) return graph_mod;
   else
   {
      delete graph_mod;
      return NULL;
   }
}

TH1 *HistTools::TransformEnergyAndDifferentialFluxNew(TH1 *hist, Particle::Type particle, const Char_t *from_energy_unit, const Char_t *from_flux_unit, const Char_t *to_energy_unit, const Char_t *to_flux_unit, const Char_t *suffix)
{
   TH1 *hist_mod = (TH1 *)hist->Clone(Form("%s%s", hist->GetName(), suffix));

   if (TransformEnergyAndDifferentialFlux(hist_mod, particle, from_energy_unit, from_flux_unit, to_energy_unit, to_flux_unit)) return hist_mod;
   else
   {
      delete hist_mod;
      return NULL;
   }
}

TGraph *HistTools::TransformEnergyAndDifferentialFluxNew(TGraph *graph, Particle::Type particle, const Char_t *from_flux_unit, const Char_t *to_flux_unit, const Char_t *suffix)
{
   TGraph *graph_mod = (TGraph *)graph->Clone();

   if (strlen(graph->GetName()) > 0 && suffix != NULL && strlen(suffix) > 0)
   {
      graph_mod->SetName(Form("%s%s", graph->GetName(), suffix));
   }

   if (TransformEnergyAndDifferentialFlux(graph_mod, particle, from_flux_unit, to_flux_unit)) return graph_mod;
   else
   {
      delete graph_mod;
      return NULL;
   }
}

TH1 *HistTools::TransformEnergyAndDifferentialFluxNew(TH1 *hist, Particle::Type particle, const Char_t *from_flux_unit, const Char_t *to_flux_unit, const Char_t *suffix)
{
   TH1 *hist_mod = (TH1 *)hist->Clone(Form("%s%s", hist->GetName(), suffix));

   if (TransformEnergyAndDifferentialFlux(hist_mod, particle, from_flux_unit, to_flux_unit)) return hist_mod;
   else
   {
      delete hist_mod;
      return NULL;
   }
}

TGraph *HistTools::TransformEnergyAndDifferentialFluxNew(TGraph *graph, Particle::Type particle, Energy::Type from_energy_type, SIPrefix::Type from_energy_prefix, Energy::Type from_flux_energy_type, SIPrefix::Type from_flux_energy_prefix,
   SIPrefix::Type from_flux_length_prefix, Energy::Type to_energy_type, SIPrefix::Type to_energy_prefix, Energy::Type to_flux_energy_type, SIPrefix::Type to_flux_energy_prefix, SIPrefix::Type to_flux_length_prefix, const Char_t *suffix)
{
   TGraph *graph_mod = (TGraph *)graph->Clone();

   if (strlen(graph->GetName()) > 0 && suffix != NULL && strlen(suffix) > 0)
   {
      graph_mod->SetName(Form("%s%s", graph->GetName(), suffix));
   }

   if (TransformEnergyAndDifferentialFlux(graph_mod, particle, from_energy_type, from_energy_prefix, from_flux_energy_type, from_flux_energy_prefix, from_flux_length_prefix, to_energy_type, to_energy_prefix, to_flux_energy_type,
      to_flux_energy_prefix, to_flux_length_prefix)) return graph_mod;
   else
   {
      delete graph_mod;
      return NULL;
   }
}

TH1 *HistTools::TransformEnergyAndDifferentialFluxNew(TH1 *hist, Particle::Type particle, Energy::Type from_energy_type, SIPrefix::Type from_energy_prefix, Energy::Type from_flux_energy_type, SIPrefix::Type from_flux_energy_prefix,
   SIPrefix::Type from_flux_length_prefix, Energy::Type to_energy_type, SIPrefix::Type to_energy_prefix, Energy::Type to_flux_energy_type, SIPrefix::Type to_flux_energy_prefix, SIPrefix::Type to_flux_length_prefix, const Char_t *suffix)
{
   TH1 *hist_mod = (TH1 *)hist->Clone(Form("%s%s", hist->GetName(), suffix));

   if (TransformEnergyAndDifferentialFlux(hist_mod, particle, from_energy_type, from_energy_prefix, from_flux_energy_type, from_flux_energy_prefix, from_flux_length_prefix, to_energy_type, to_energy_prefix, to_flux_energy_type,
      to_flux_energy_prefix, to_flux_length_prefix)) return hist_mod;
   else
   {
      delete hist_mod;
      return NULL;
   }
}

Bool_t HistTools::TransformEnergyAndDifferentialFlux(TGraph *graph, Particle::Type particle, const Char_t *from_energy_unit, const Char_t *from_flux_unit, const Char_t *to_energy_unit, const Char_t *to_flux_unit)
{
   Energy::Type from_energy_type;
   SIPrefix::Type from_energy_prefix;
   if (!Unit::ParseEnergyUnit(from_energy_unit, from_energy_type, from_energy_prefix)) return false;

   Energy::Type to_energy_type;
   SIPrefix::Type to_energy_prefix;
   if (!Unit::ParseEnergyUnit(to_energy_unit, to_energy_type, to_energy_prefix)) return false;

   Energy::Type from_flux_energy_type;
   SIPrefix::Type from_flux_energy_prefix;
   SIPrefix::Type from_flux_length_prefix;
   if (!Unit::ParseDifferentialFluxUnit(from_flux_unit, from_flux_energy_type, from_flux_energy_prefix, from_flux_length_prefix)) return false;

   Energy::Type to_flux_energy_type;
   SIPrefix::Type to_flux_energy_prefix;
   SIPrefix::Type to_flux_length_prefix;
   if (!Unit::ParseDifferentialFluxUnit(to_flux_unit, to_flux_energy_type, to_flux_energy_prefix, to_flux_length_prefix)) return false;

   return TransformEnergyAndDifferentialFlux(graph, particle, from_energy_type, from_energy_prefix, from_flux_energy_type, from_flux_energy_prefix, from_flux_length_prefix,
      to_energy_type, to_energy_prefix, to_flux_energy_type, to_flux_energy_prefix, to_flux_length_prefix);
}

Bool_t HistTools::TransformEnergyAndDifferentialFlux(TH1 *hist, Particle::Type particle, const Char_t *from_energy_unit, const Char_t *from_flux_unit, const Char_t *to_energy_unit, const Char_t *to_flux_unit)
{
   Energy::Type from_energy_type;
   SIPrefix::Type from_energy_prefix;
   if (!Unit::ParseEnergyUnit(from_energy_unit, from_energy_type, from_energy_prefix)) return false;

   Energy::Type to_energy_type;
   SIPrefix::Type to_energy_prefix;
   if (!Unit::ParseEnergyUnit(to_energy_unit, to_energy_type, to_energy_prefix)) return false;

   Energy::Type from_flux_energy_type;
   SIPrefix::Type from_flux_energy_prefix;
   SIPrefix::Type from_flux_length_prefix;
   if (!Unit::ParseDifferentialFluxUnit(from_flux_unit, from_flux_energy_type, from_flux_energy_prefix, from_flux_length_prefix)) return false;

   Energy::Type to_flux_energy_type;
   SIPrefix::Type to_flux_energy_prefix;
   SIPrefix::Type to_flux_length_prefix;
   if (!Unit::ParseDifferentialFluxUnit(to_flux_unit, to_flux_energy_type, to_flux_energy_prefix, to_flux_length_prefix)) return false;

   return TransformEnergyAndDifferentialFlux(hist, particle, from_energy_type, from_energy_prefix, from_flux_energy_type, from_flux_energy_prefix, from_flux_length_prefix,
      to_energy_type, to_energy_prefix, to_flux_energy_type, to_flux_energy_prefix, to_flux_length_prefix);
}

Bool_t HistTools::TransformEnergyAndDifferentialFlux(TGraph *graph, Particle::Type particle, const Char_t *from_flux_unit, const Char_t *to_flux_unit)
{
   Energy::Type from_flux_energy_type;
   SIPrefix::Type from_flux_energy_prefix;
   SIPrefix::Type from_flux_length_prefix;
   if (!Unit::ParseDifferentialFluxUnit(from_flux_unit, from_flux_energy_type, from_flux_energy_prefix, from_flux_length_prefix)) return false;

   Energy::Type to_flux_energy_type;
   SIPrefix::Type to_flux_energy_prefix;
   SIPrefix::Type to_flux_length_prefix;
   if (!Unit::ParseDifferentialFluxUnit(to_flux_unit, to_flux_energy_type, to_flux_energy_prefix, to_flux_length_prefix)) return false;

   return TransformEnergyAndDifferentialFlux(graph, particle, from_flux_energy_type, from_flux_energy_prefix, from_flux_energy_type, from_flux_energy_prefix, from_flux_length_prefix,
      to_flux_energy_type, to_flux_energy_prefix, to_flux_energy_type, to_flux_energy_prefix, to_flux_length_prefix);
}

Bool_t HistTools::TransformEnergyAndDifferentialFlux(TH1 *hist, Particle::Type particle, const Char_t *from_flux_unit, const Char_t *to_flux_unit)
{
   Energy::Type from_flux_energy_type;
   SIPrefix::Type from_flux_energy_prefix;
   SIPrefix::Type from_flux_length_prefix;
   if (!Unit::ParseDifferentialFluxUnit(from_flux_unit, from_flux_energy_type, from_flux_energy_prefix, from_flux_length_prefix)) return false;

   Energy::Type to_flux_energy_type;
   SIPrefix::Type to_flux_energy_prefix;
   SIPrefix::Type to_flux_length_prefix;
   if (!Unit::ParseDifferentialFluxUnit(to_flux_unit, to_flux_energy_type, to_flux_energy_prefix, to_flux_length_prefix)) return false;

   return TransformEnergyAndDifferentialFlux(hist, particle, from_flux_energy_type, from_flux_energy_prefix, from_flux_energy_type, from_flux_energy_prefix, from_flux_length_prefix,
      to_flux_energy_type, to_flux_energy_prefix, to_flux_energy_type, to_flux_energy_prefix, to_flux_length_prefix);
}

Bool_t HistTools::TransformEnergyAndDifferentialFlux(TH1 *hist, Particle::Type particle, Energy::Type from_energy_type, SIPrefix::Type from_energy_prefix, Energy::Type from_flux_energy_type, SIPrefix::Type from_flux_energy_prefix,
         SIPrefix::Type from_flux_length_prefix, Energy::Type to_energy_type, SIPrefix::Type to_energy_prefix, Energy::Type to_flux_energy_type, SIPrefix::Type to_flux_energy_prefix, SIPrefix::Type to_flux_length_prefix)
{
   if (hist->GetDimension()!= 1)
   {
      std::cerr << FG_RED_B << Form(" !!! HistTools::TransformEnergyAndDifferentialFlux: hist:%s (%s) must be 1D.", hist->GetName(), hist->GetTitle()) << RESET << std::endl;
      return false;
   }

   Int_t nbins = hist->GetNbinsX();
   TArrayD axis(*(hist->GetXaxis()->GetXbins()));
   for (Int_t ibin = 1; ibin <= nbins; ++ibin)
   {
      Double_t range[2];
      range[0] = hist->GetBinLowEdge(ibin);
      range[1] = range[0] + hist->GetBinWidth(ibin);

      Double_t y  = hist->GetBinContent(ibin);
      Double_t yl = y - hist->GetBinError(ibin);

      if (y > 0)
      {
         Double_t yt = Unit::ConvertDifferentialFlux(Unit::ConvertDifferentialFluxType(y, range, particle, from_flux_energy_type, from_flux_energy_prefix, to_flux_energy_type), from_flux_energy_prefix, from_flux_length_prefix, to_flux_energy_prefix, to_flux_length_prefix);
         yl *= yt/y;

         hist->SetBinContent(ibin, yt);
         hist->SetBinError(ibin, yt - yl);
      }

      axis[ibin-1] = Unit::ConvertEnergy(Unit::ConvertEnergyType(range[0], particle, from_energy_type, from_energy_prefix, to_energy_type), from_energy_prefix, to_energy_prefix);
   }
   axis[nbins] = Unit::ConvertEnergy(Unit::ConvertEnergyType(hist->GetBinLowEdge(nbins+1), particle, from_energy_type, from_energy_prefix, to_energy_type), from_energy_prefix, to_energy_prefix);
   hist->GetXaxis()->Set(nbins, axis.GetArray());

   hist->ResetStats();

   return true;
}

Bool_t HistTools::TransformEnergyAndDifferentialFlux(TGraph *graph, Particle::Type particle, Energy::Type from_energy_type, SIPrefix::Type from_energy_prefix, Energy::Type from_flux_energy_type, SIPrefix::Type from_flux_energy_prefix,
         SIPrefix::Type from_flux_length_prefix, Energy::Type to_energy_type, SIPrefix::Type to_energy_prefix, Energy::Type to_flux_energy_type, SIPrefix::Type to_flux_energy_prefix, SIPrefix::Type to_flux_length_prefix)
{
   //~ if (graph->GetEY() == NULL && graph->GetEYlow() == NULL)
   //~ {
      //~ std::cerr << FG_RED_B << Form(" !!! HistTools::TransformEnergyAndDifferentialFlux: graph:%s (%s) cannot be a TGraph", graph->GetName(), graph->GetTitle()) << RESET << std::endl;
      //~ return false;
   //~ }

   UInt_t npoints = graph->GetN();
   for (UInt_t ipoint = 0; ipoint < npoints; ++ipoint)
   {
      Double_t x = graph->GetX()[ipoint];
      Double_t y = graph->GetY()[ipoint];
      Double_t range[2] = { x, x };
      Double_t yl, yu, yt = 0;

      if (graph->GetEY() != NULL)
      {
         Double_t ex = graph->GetEX()[ipoint];
         range[0] -= ex;
         range[1] += ex;

         Double_t ey = graph->GetEY()[ipoint];
         yl = y - ey;
         yu = y + ey;
      }
      else if (graph->GetEYlow() != NULL)
      {
         Double_t exl = graph->GetEXlow()[ipoint];
         Double_t exu = graph->GetEXhigh()[ipoint];
         range[0] -= exl;
         range[1] += exu;

         Double_t eyl = graph->GetEYlow()[ipoint];
         Double_t eyu = graph->GetEYhigh()[ipoint];
         yl = y - eyl;
         yu = y + eyu;
      }

      if (y > 0)
      {
         if (range[0] == range[1])
         {
            yt = Unit::ConvertDifferentialFlux(
                     Unit::ConvertDifferentialFluxType(y, x, particle, from_flux_energy_type, from_flux_energy_prefix, to_flux_energy_type),
                     from_flux_energy_prefix, from_flux_length_prefix, to_flux_energy_prefix, to_flux_length_prefix);
         }
         else
         {
            yt = Unit::ConvertDifferentialFlux(
                     Unit::ConvertDifferentialFluxType(y, range, particle, from_flux_energy_type, from_flux_energy_prefix, to_flux_energy_type),
                     from_flux_energy_prefix, from_flux_length_prefix, to_flux_energy_prefix, to_flux_length_prefix);
         }
         yl *= yt/y;
         yu *= yt/y;
      }

      x = Unit::ConvertEnergy(Unit::ConvertEnergyType(x, particle, from_energy_type, from_energy_prefix, to_energy_type), from_energy_prefix, to_energy_prefix);
      range[0] = Unit::ConvertEnergy(Unit::ConvertEnergyType(range[0], particle, from_energy_type, from_energy_prefix, to_energy_type), from_energy_prefix, to_energy_prefix);
      range[1] = Unit::ConvertEnergy(Unit::ConvertEnergyType(range[1], particle, from_energy_type, from_energy_prefix, to_energy_type), from_energy_prefix, to_energy_prefix);

      graph->GetX()[ipoint] = x;
      graph->GetY()[ipoint] = yt;

      if (graph->GetEY() != NULL)
      {
         graph->GetEX()[ipoint] = range[1] - x;
         graph->GetEY()[ipoint] = yl - yt;
      }
      else if (graph->GetEYlow() != NULL)
      {
         graph->GetEXlow()[ipoint]  = x - range[0];
         graph->GetEXhigh()[ipoint] = range[1] - x;

         graph->GetEYlow()[ipoint]  = yt - yl;
         graph->GetEYhigh()[ipoint] = yu - yt;
      }
   }

   return true;
}



//
TGraph *HistTools::TransformEnergyAndIntegralFluxNew(TGraph *graph, Particle::Type particle, const Char_t *from_energy_unit, const Char_t *from_flux_unit, const Char_t *to_energy_unit, const Char_t *to_flux_unit, const Char_t *suffix)
{
   TGraph *graph_mod = (TGraph *)graph->Clone();

   if (strlen(graph->GetName()) > 0 && suffix != NULL && strlen(suffix) > 0)
   {
      graph_mod->SetName(Form("%s%s", graph->GetName(), suffix));
   }

   if (TransformEnergyAndIntegralFlux(graph_mod, particle, from_energy_unit, from_flux_unit, to_energy_unit, to_flux_unit)) return graph_mod;
   else
   {
      delete graph_mod;
      return NULL;
   }
}

TH1 *HistTools::TransformEnergyAndIntegralFluxNew(TH1 *hist, Particle::Type particle, const Char_t *from_energy_unit, const Char_t *from_flux_unit, const Char_t *to_energy_unit, const Char_t *to_flux_unit, const Char_t *suffix)
{
   TH1 *hist_mod = (TH1 *)hist->Clone(Form("%s%s", hist->GetName(), suffix));

   if (TransformEnergyAndIntegralFlux(hist_mod, particle, from_energy_unit, from_flux_unit, to_energy_unit, to_flux_unit)) return hist_mod;
   else
   {
      delete hist_mod;
      return NULL;
   }
}

TGraph *HistTools::TransformEnergyAndIntegralFluxNew(TGraph *graph, Particle::Type particle, Energy::Type from_energy_type, SIPrefix::Type from_energy_prefix, SIPrefix::Type from_flux_length_prefix, Energy::Type to_energy_type,
   SIPrefix::Type to_energy_prefix, SIPrefix::Type to_flux_length_prefix, const Char_t *suffix)
{
   TGraph *graph_mod = (TGraph *)graph->Clone();

   if (strlen(graph->GetName()) > 0 && suffix != NULL && strlen(suffix) > 0)
   {
      graph_mod->SetName(Form("%s%s", graph->GetName(), suffix));
   }

   if (TransformEnergyAndIntegralFlux(graph_mod, particle, from_energy_type, from_energy_prefix, from_flux_length_prefix, to_energy_type, to_energy_prefix, to_flux_length_prefix)) return graph_mod;
   else
   {
      delete graph_mod;
      return NULL;
   }
}

TH1 *HistTools::TransformEnergyAndIntegralFluxNew(TH1 *hist, Particle::Type particle, Energy::Type from_energy_type, SIPrefix::Type from_energy_prefix, SIPrefix::Type from_flux_length_prefix, Energy::Type to_energy_type,
   SIPrefix::Type to_energy_prefix, SIPrefix::Type to_flux_length_prefix, const Char_t *suffix)
{
   TH1 *hist_mod = (TH1 *)hist->Clone(Form("%s%s", hist->GetName(), suffix));

   if (TransformEnergyAndIntegralFlux(hist_mod, particle, from_energy_type, from_energy_prefix, from_flux_length_prefix, to_energy_type, to_energy_prefix, to_flux_length_prefix)) return hist_mod;
   else
   {
      delete hist_mod;
      return NULL;
   }
}

Bool_t HistTools::TransformEnergyAndIntegralFlux(TGraph *graph, Particle::Type particle, const Char_t *from_energy_unit, const Char_t *from_flux_unit, const Char_t *to_energy_unit, const Char_t *to_flux_unit)
{
   Energy::Type from_energy_type;
   SIPrefix::Type from_energy_prefix;
   if (!Unit::ParseEnergyUnit(from_energy_unit, from_energy_type, from_energy_prefix)) return false;

   Energy::Type to_energy_type;
   SIPrefix::Type to_energy_prefix;
   if (!Unit::ParseEnergyUnit(to_energy_unit, to_energy_type, to_energy_prefix)) return false;

   SIPrefix::Type from_flux_length_prefix;
   if (!Unit::ParseIntegralFluxUnit(from_flux_unit, from_flux_length_prefix)) return false;

   SIPrefix::Type to_flux_length_prefix;
   if (!Unit::ParseIntegralFluxUnit(to_flux_unit, to_flux_length_prefix)) return false;

   return TransformEnergyAndIntegralFlux(graph, particle, from_energy_type, from_energy_prefix, from_flux_length_prefix, to_energy_type, to_energy_prefix, to_flux_length_prefix);
}

Bool_t HistTools::TransformEnergyAndIntegralFlux(TH1 *hist, Particle::Type particle, const Char_t *from_energy_unit, const Char_t *from_flux_unit, const Char_t *to_energy_unit, const Char_t *to_flux_unit)
{
   Energy::Type from_energy_type;
   SIPrefix::Type from_energy_prefix;
   if (!Unit::ParseEnergyUnit(from_energy_unit, from_energy_type, from_energy_prefix)) return false;

   Energy::Type to_energy_type;
   SIPrefix::Type to_energy_prefix;
   if (!Unit::ParseEnergyUnit(to_energy_unit, to_energy_type, to_energy_prefix)) return false;

   SIPrefix::Type from_flux_length_prefix;
   if (!Unit::ParseIntegralFluxUnit(from_flux_unit, from_flux_length_prefix)) return false;

   SIPrefix::Type to_flux_length_prefix;
   if (!Unit::ParseIntegralFluxUnit(to_flux_unit, to_flux_length_prefix)) return false;

   return TransformEnergyAndIntegralFlux(hist, particle, from_energy_type, from_energy_prefix, from_flux_length_prefix, to_energy_type, to_energy_prefix, to_flux_length_prefix);
}

Bool_t HistTools::TransformEnergyAndIntegralFlux(TH1 *hist, Particle::Type particle, Energy::Type from_energy_type, SIPrefix::Type from_energy_prefix, SIPrefix::Type from_flux_length_prefix, Energy::Type to_energy_type,
   SIPrefix::Type to_energy_prefix, SIPrefix::Type to_flux_length_prefix)
{
   if (hist->GetDimension()!= 1)
   {
      std::cerr << FG_RED_B << Form(" !!! HistTools::TransformEnergyAndIntegralFlux: hist:%s (%s) must be 1D", hist->GetName(), hist->GetTitle()) << RESET << std::endl;
      return false;
   }

   Int_t nbins = hist->GetNbinsX();
   TArrayD axis(*(hist->GetXaxis()->GetXbins()));
   for (Int_t ibin = 1; ibin <= nbins; ++ibin)
   {
      Double_t range[2];
      range[0] = hist->GetBinLowEdge(ibin);
      range[1] = range[0] + hist->GetBinWidth(ibin);

      Double_t y  = hist->GetBinContent(ibin);
      Double_t yl = y - hist->GetBinError(ibin);

      axis[ibin-1] = Unit::ConvertEnergy(Unit::ConvertEnergyType(range[0], particle, from_energy_type, from_energy_prefix, to_energy_type), from_energy_prefix, to_energy_prefix);

      Double_t yt = Unit::ConvertIntegralFlux(y, from_flux_length_prefix, to_flux_length_prefix);
      yl *= yt/y;

      hist->SetBinContent(ibin, yt);
      hist->SetBinError(ibin, yt - yl);
   }
   axis[nbins] = Unit::ConvertEnergy(Unit::ConvertEnergyType(hist->GetBinLowEdge(nbins+1), particle, from_energy_type, from_energy_prefix, to_energy_type), from_energy_prefix, to_energy_prefix);
   hist->GetXaxis()->Set(nbins, axis.GetArray());

   hist->ResetStats();

   return true;
}

Bool_t HistTools::TransformEnergyAndIntegralFlux(TGraph *graph, Particle::Type particle, Energy::Type from_energy_type, SIPrefix::Type from_energy_prefix, SIPrefix::Type from_flux_length_prefix, Energy::Type to_energy_type,
   SIPrefix::Type to_energy_prefix, SIPrefix::Type to_flux_length_prefix)
{
   UInt_t npoints = graph->GetN();
   for (UInt_t ipoint = 0; ipoint < npoints; ++ipoint)
   {
      Double_t x = graph->GetX()[ipoint];
      Double_t y = graph->GetY()[ipoint];
      Double_t range[2];
      Double_t yl, yu, yt;

      if (graph->GetEY() != NULL)
      {
         Double_t ex = graph->GetEX()[ipoint];
         range[0] = Unit::ConvertEnergy(Unit::ConvertEnergyType(x - ex, particle, from_energy_type, from_energy_prefix, to_energy_type), from_energy_prefix, to_energy_prefix);
         range[1] = Unit::ConvertEnergy(Unit::ConvertEnergyType(x + ex, particle, from_energy_type, from_energy_prefix, to_energy_type), from_energy_prefix, to_energy_prefix);

         Double_t ey = graph->GetEY()[ipoint];
         yl = y - ey;
         yu = y + ey;
      }
      else if (graph->GetEYlow() != NULL)
      {
         Double_t exl = graph->GetEXlow()[ipoint];
         Double_t exu = graph->GetEXhigh()[ipoint];
         range[0] = Unit::ConvertEnergy(Unit::ConvertEnergyType(x - exl, particle, from_energy_type, from_energy_prefix, to_energy_type), from_energy_prefix, to_energy_prefix);
         range[1] = Unit::ConvertEnergy(Unit::ConvertEnergyType(x + exu, particle, from_energy_type, from_energy_prefix, to_energy_type), from_energy_prefix, to_energy_prefix);

         Double_t eyl = graph->GetEYlow()[ipoint];
         Double_t eyu = graph->GetEYhigh()[ipoint];
         yl = y - eyl;
         yu = y + eyu;
      }

      x = Unit::ConvertEnergy(Unit::ConvertEnergyType(x, particle, from_energy_type, from_energy_prefix, to_energy_type), from_energy_prefix, to_energy_prefix);
      yt = Unit::ConvertIntegralFlux(y, from_flux_length_prefix, to_flux_length_prefix);
      yl *= yt/y;
      yu *= yt/y;

      graph->GetX()[ipoint] = x;
      graph->GetY()[ipoint] = yt;

      if (graph->GetEY() != NULL)
      {
         graph->GetEX()[ipoint] = range[1] - x;
         graph->GetEY()[ipoint] = yl - y;
      }
      else if (graph->GetEYlow() != NULL)
      {
         graph->GetEXlow()[ipoint]  = x - range[0];
         graph->GetEXhigh()[ipoint] = range[1] - x;

         graph->GetEYlow()[ipoint]  = yt - yl;
         graph->GetEYhigh()[ipoint] = yu - yt;
      }
   }

   return true;
}



//
TGraph *HistTools::TransformDifferentialFluxNew(TGraph *graph, Particle::Type particle, Energy::Range range, const Char_t *from_flux_unit, const Char_t *to_flux_unit, const Char_t *suffix)
{
   TGraph *graph_mod = (TGraph *)graph->Clone();

   if (strlen(graph->GetName()) > 0 && suffix != NULL && strlen(suffix) > 0)
   {
      graph_mod->SetName(Form("%s%s", graph->GetName(), suffix));
   }

   if (TransformDifferentialFlux(graph_mod, particle, range, from_flux_unit, to_flux_unit)) return graph_mod;
   else
   {
      delete graph_mod;
      return NULL;
   }
}

TH1 *HistTools::TransformDifferentialFluxNew(TH1 *hist, Particle::Type particle, Energy::Range range, const Char_t *from_flux_unit, const Char_t *to_flux_unit, const Char_t *suffix)
{
   TH1 *hist_mod = (TH1 *)hist->Clone(Form("%s%s", hist->GetName(), suffix));

   if (TransformDifferentialFlux(hist_mod, particle, range, from_flux_unit, to_flux_unit)) return hist_mod;
   else
   {
      delete hist_mod;
      return NULL;
   }
}

TGraph *HistTools::TransformDifferentialFluxNew(TGraph *graph, Particle::Type particle, Energy::Range range, Energy::Type from_flux_energy_type, SIPrefix::Type from_flux_energy_prefix, SIPrefix::Type from_flux_length_prefix,
   Energy::Type to_flux_energy_type, SIPrefix::Type to_flux_energy_prefix, SIPrefix::Type to_flux_length_prefix, const Char_t *suffix)
{
   TGraph *graph_mod = (TGraph *)graph->Clone();

   if (strlen(graph->GetName()) > 0 && suffix != NULL && strlen(suffix) > 0)
   {
      graph_mod->SetName(Form("%s%s", graph->GetName(), suffix));
   }

   if (TransformDifferentialFlux(graph_mod, particle, range, from_flux_energy_type, from_flux_energy_prefix, from_flux_length_prefix, to_flux_energy_type, to_flux_energy_prefix, to_flux_length_prefix)) return graph_mod;
   else
   {
      delete graph_mod;
      return NULL;
   }
}

TH1 *HistTools::TransformDifferentialFluxNew(TH1 *hist, Particle::Type particle, Energy::Range range, Energy::Type from_flux_energy_type, SIPrefix::Type from_flux_energy_prefix, SIPrefix::Type from_flux_length_prefix,
   Energy::Type to_flux_energy_type, SIPrefix::Type to_flux_energy_prefix, SIPrefix::Type to_flux_length_prefix, const Char_t *suffix)
{
   TH1 *hist_mod = (TH1 *)hist->Clone(Form("%s%s", hist->GetName(), suffix));

   if (TransformDifferentialFlux(hist_mod, particle, range, from_flux_energy_type, from_flux_energy_prefix, from_flux_length_prefix, to_flux_energy_type, to_flux_energy_prefix, to_flux_length_prefix)) return hist_mod;
   else
   {
      delete hist_mod;
      return NULL;
   }
}

Bool_t HistTools::TransformDifferentialFlux(TGraph *graph, Particle::Type particle, Energy::Range range, const Char_t *from_flux_unit, const Char_t *to_flux_unit)
{
   Energy::Type from_flux_energy_type;
   SIPrefix::Type from_flux_energy_prefix;
   SIPrefix::Type from_flux_length_prefix;
   if (!Unit::ParseDifferentialFluxUnit(from_flux_unit, from_flux_energy_type, from_flux_energy_prefix, from_flux_length_prefix)) return false;

   Energy::Type to_flux_energy_type;
   SIPrefix::Type to_flux_energy_prefix;
   SIPrefix::Type to_flux_length_prefix;
   if (!Unit::ParseDifferentialFluxUnit(to_flux_unit, to_flux_energy_type, to_flux_energy_prefix, to_flux_length_prefix)) return false;

   return TransformDifferentialFlux(graph, particle, range, from_flux_energy_type, from_flux_energy_prefix, from_flux_length_prefix, to_flux_energy_type, to_flux_energy_prefix, to_flux_length_prefix);
}

Bool_t HistTools::TransformDifferentialFlux(TH1 *hist, Particle::Type particle, Energy::Range range, const Char_t *from_flux_unit, const Char_t *to_flux_unit)
{
   Energy::Type from_flux_energy_type;
   SIPrefix::Type from_flux_energy_prefix;
   SIPrefix::Type from_flux_length_prefix;
   if (!Unit::ParseDifferentialFluxUnit(from_flux_unit, from_flux_energy_type, from_flux_energy_prefix, from_flux_length_prefix)) return false;

   Energy::Type to_flux_energy_type;
   SIPrefix::Type to_flux_energy_prefix;
   SIPrefix::Type to_flux_length_prefix;
   if (!Unit::ParseDifferentialFluxUnit(to_flux_unit, to_flux_energy_type, to_flux_energy_prefix, to_flux_length_prefix)) return false;

   return TransformDifferentialFlux(hist, particle, range, from_flux_energy_type, from_flux_energy_prefix, from_flux_length_prefix, to_flux_energy_type, to_flux_energy_prefix, to_flux_length_prefix);
}

Bool_t HistTools::TransformDifferentialFlux(TH1 *hist, Particle::Type particle, Energy::Range range, Energy::Type from_flux_energy_type, SIPrefix::Type from_flux_energy_prefix, SIPrefix::Type from_flux_length_prefix,
   Energy::Type to_flux_energy_type, SIPrefix::Type to_flux_energy_prefix, SIPrefix::Type to_flux_length_prefix)
{
   if (hist->GetDimension()!= 1)
   {
      std::cerr << FG_RED_B << Form(" !!! HistTools::TransformDifferentialFlux: hist:%s (%s) must be 1D", hist->GetName(), hist->GetTitle()) << RESET << std::endl;
      return false;
   }

   Int_t nbins = hist->GetNbinsX();
   for (Int_t ibin = 1; ibin <= nbins; ++ibin)
   {
      Double_t y  = hist->GetBinContent(ibin);
      Double_t yl = y - hist->GetBinError(ibin);

      Double_t yt = Unit::ConvertDifferentialFlux(Unit::ConvertDifferentialFluxType(y, range, particle, from_flux_energy_type, from_flux_energy_prefix, to_flux_energy_type), from_flux_energy_prefix, from_flux_length_prefix, to_flux_energy_prefix, to_flux_length_prefix);
      yl *= yt/y;

      hist->SetBinContent(ibin, yt);
      hist->SetBinError(ibin, yt - yl);
   }

   hist->ResetStats();

   return true;
}

Bool_t HistTools::TransformDifferentialFlux(TGraph *graph, Particle::Type particle, Energy::Range range, Energy::Type from_flux_energy_type, SIPrefix::Type from_flux_energy_prefix, SIPrefix::Type from_flux_length_prefix,
   Energy::Type to_flux_energy_type, SIPrefix::Type to_flux_energy_prefix, SIPrefix::Type to_flux_length_prefix)
{
   if (graph->GetEY() == NULL && graph->GetEYlow() == NULL)
   {
      std::cerr << FG_RED_B << Form(" !!! HistTools::TransformDifferentialFlux: graph:%s (%s) cannot be a TGraph", graph->GetName(), graph->GetTitle()) << RESET << std::endl;
      return false;
   }

   UInt_t npoints = graph->GetN();
   for (UInt_t ipoint = 0; ipoint < npoints; ++ipoint)
   {
      Double_t y = graph->GetY()[ipoint];
      Double_t yl, yu, yt;

      if (graph->GetEY() != NULL)
      {
         Double_t ey = graph->GetEY()[ipoint];
         yl = y - ey;
         yu = y + ey;
      }
      else if (graph->GetEYlow() != NULL)
      {
         Double_t eyl = graph->GetEYlow()[ipoint];
         Double_t eyu = graph->GetEYhigh()[ipoint];
         yl = y - eyl;
         yu = y + eyu;
      }

      /* F' = a*F => a = F'/F => dF' = a*dF = F'*dF/F
       * Fl = F-dF, Fu = F+dF
       * Fl' = a*Fl = a*F-a*dF, Fu' = a*Fu = a*F+a*dF
       * F'-Fl' = a*F - a*F + a*dF = a*dF
       */

      yt = Unit::ConvertDifferentialFlux(Unit::ConvertDifferentialFluxType(y, range, particle, from_flux_energy_type, from_flux_energy_prefix, to_flux_energy_type), from_flux_energy_prefix, from_flux_length_prefix, to_flux_energy_prefix, to_flux_length_prefix);
      yl *= yt/y;
      yu *= yt/y;

      graph->GetY()[ipoint] = yt;

      if (graph->GetEY() != NULL)
      {
         graph->GetEY()[ipoint] = yu - yt;
      }
      else if (graph->GetEYlow() != NULL)
      {
         graph->GetEYlow()[ipoint]  = yt - yl;
         graph->GetEYhigh()[ipoint] = yu - yt;
      }
   }

   return true;
}



//
TGraph *HistTools::TransformIntegralFluxNew(TGraph *graph, const Char_t *from_flux_unit, const Char_t *to_flux_unit, const Char_t *suffix)
{
   TGraph *graph_mod = (TGraph *)graph->Clone();

   if (strlen(graph->GetName()) > 0 && suffix != NULL && strlen(suffix) > 0)
   {
      graph_mod->SetName(Form("%s%s", graph->GetName(), suffix));
   }

   if (TransformIntegralFlux(graph_mod, from_flux_unit, to_flux_unit)) return graph_mod;
   else
   {
      delete graph_mod;
      return NULL;
   }
}

TH1 *HistTools::TransformIntegralFluxNew(TH1 *hist, const Char_t *from_flux_unit, const Char_t *to_flux_unit, const Char_t *suffix)
{
   TH1 *hist_mod = (TH1 *)hist->Clone(Form("%s%s", hist->GetName(), suffix));

   if (TransformIntegralFlux(hist_mod, from_flux_unit, to_flux_unit)) return hist_mod;
   else
   {
      delete hist_mod;
      return NULL;
   }
}

TGraph *HistTools::TransformIntegralFluxNew(TGraph *graph, SIPrefix::Type from_flux_length_prefix, SIPrefix::Type to_flux_length_prefix, const Char_t *suffix)
{
   TGraph *graph_mod = (TGraph *)graph->Clone();

   if (strlen(graph->GetName()) > 0 && suffix != NULL && strlen(suffix) > 0)
   {
      graph_mod->SetName(Form("%s%s", graph->GetName(), suffix));
   }

   if (TransformIntegralFlux(graph_mod, from_flux_length_prefix, to_flux_length_prefix)) return graph_mod;
   else
   {
      delete graph_mod;
      return NULL;
   }
}

TH1 *HistTools::TransformIntegralFluxNew(TH1 *hist, SIPrefix::Type from_flux_length_prefix, SIPrefix::Type to_flux_length_prefix, const Char_t *suffix)
{
   TH1 *hist_mod = (TH1 *)hist->Clone(Form("%s%s", hist->GetName(), suffix));

   if (TransformIntegralFlux(hist_mod, from_flux_length_prefix, to_flux_length_prefix)) return hist_mod;
   else
   {
      delete hist_mod;
      return NULL;
   }
}

Bool_t HistTools::TransformIntegralFlux(TGraph *graph, const Char_t *from_flux_unit, const Char_t *to_flux_unit)
{
   SIPrefix::Type from_flux_length_prefix;
   if (!Unit::ParseIntegralFluxUnit(from_flux_unit, from_flux_length_prefix)) return false;

   SIPrefix::Type to_flux_length_prefix;
   if (!Unit::ParseIntegralFluxUnit(to_flux_unit, to_flux_length_prefix)) return false;

   return TransformIntegralFlux(graph, from_flux_length_prefix, to_flux_length_prefix);
}

Bool_t HistTools::TransformIntegralFlux(TH1 *hist, const Char_t *from_flux_unit, const Char_t *to_flux_unit)
{
   SIPrefix::Type from_flux_length_prefix;
   if (!Unit::ParseIntegralFluxUnit(from_flux_unit, from_flux_length_prefix)) return false;

   SIPrefix::Type to_flux_length_prefix;
   if (!Unit::ParseIntegralFluxUnit(to_flux_unit, to_flux_length_prefix)) return false;

   return TransformIntegralFlux(hist, from_flux_length_prefix, to_flux_length_prefix);
}

Bool_t HistTools::TransformIntegralFlux(TH1 *hist, SIPrefix::Type from_flux_length_prefix, SIPrefix::Type to_flux_length_prefix)
{
   if (hist->GetDimension()!= 1)
   {
      std::cerr << FG_RED_B << Form(" !!! HistTools::TransformIntegralFlux: hist:%s (%s) must be 1D", hist->GetName(), hist->GetTitle()) << RESET << std::endl;
      return false;
   }

   Int_t nbins = hist->GetNbinsX();
   for (Int_t ibin = 1; ibin <= nbins; ++ibin)
   {
      Double_t y  = hist->GetBinContent(ibin);
      Double_t yl = y - hist->GetBinError(ibin);

      Double_t yt = Unit::ConvertIntegralFlux(y, from_flux_length_prefix, to_flux_length_prefix);
      yl *= yt/y;

      hist->SetBinContent(ibin, yt);
      hist->SetBinError(ibin, yt - yl);
   }

   hist->ResetStats();

   return true;
}

Bool_t HistTools::TransformIntegralFlux(TGraph *graph, SIPrefix::Type from_flux_length_prefix, SIPrefix::Type to_flux_length_prefix)
{
   UInt_t npoints = graph->GetN();
   for (UInt_t ipoint = 0; ipoint < npoints; ++ipoint)
   {
      Double_t y = graph->GetY()[ipoint];
      Double_t yl, yu, yt;

      if (graph->GetEY() != NULL)
      {
         Double_t ey = graph->GetEY()[ipoint];
         yl = y - ey;
         yu = y + ey;
      }
      else if (graph->GetEYlow() != NULL)
      {
         Double_t eyl = graph->GetEYlow()[ipoint];
         Double_t eyu = graph->GetEYhigh()[ipoint];
         yl = y - eyl;
         yu = y + eyu;
      }

      yt = Unit::ConvertIntegralFlux(y, from_flux_length_prefix, to_flux_length_prefix);
      yl *= yt/y;
      yu *= yt/y;

      graph->GetY()[ipoint] = yt;

      if (graph->GetEY() != NULL)
      {
         graph->GetEY()[ipoint] = yu - yt;
      }
      else if (graph->GetEYlow() != NULL)
      {
         graph->GetEYlow()[ipoint]  = yt - yl;
         graph->GetEYhigh()[ipoint] = yu - yt;
      }
   }

   return true;
}



//
TH1 *HistTools::AddUnderAndOverflowBins(TH1 *hist, const Char_t *suffix)
{
   UShort_t nbinsx = hist->GetNbinsX() + 2;
   Double_t binsx[nbinsx + 1];
   binsx[0]      = hist->GetXaxis()->GetBinLowEdge(1) - hist->GetXaxis()->GetBinWidth(1);
   binsx[nbinsx] = hist->GetXaxis()->GetBinLowEdge(nbinsx - 1) + hist->GetXaxis()->GetBinWidth(nbinsx - 1);

   for (UShort_t ibin = 1; ibin < nbinsx; ibin++)
   {
      binsx[ibin] = hist->GetXaxis()->GetBinLowEdge(ibin);
   }

   TH1D *hist_uo = new TH1D(Form("%s_%s", hist->GetName(), suffix), hist->GetTitle(), nbinsx, binsx);
   hist_uo->SetXTitle(hist->GetXaxis()->GetTitle());
   hist_uo->SetYTitle(hist->GetYaxis()->GetTitle());
   for (UShort_t ibin = 1; ibin <= hist_uo->GetNbinsX(); ++ibin)
   {
      hist_uo->SetBinContent(ibin, hist->GetBinContent(ibin - 1));
      hist_uo->SetBinError(ibin, hist->GetBinError(ibin - 1));
   }

   return hist_uo;
}

TH2 *HistTools::AddUnderAndOverflowBins(TH2 *hist, const Char_t *suffix)
{
   UShort_t nbinsx = hist->GetNbinsX() + 2;
   UShort_t nbinsy = hist->GetNbinsY() + 2;
   Double_t binsx[nbinsx + 1];
   Double_t binsy[nbinsy + 1];
   binsx[0]      = hist->GetXaxis()->GetBinLowEdge(1) - hist->GetXaxis()->GetBinWidth(1);
   binsx[nbinsx] = hist->GetXaxis()->GetBinLowEdge(nbinsx - 1) + hist->GetXaxis()->GetBinWidth(nbinsx - 1);
   binsy[0]      = hist->GetYaxis()->GetBinLowEdge(1) - hist->GetYaxis()->GetBinWidth(1);
   binsy[nbinsy] = hist->GetYaxis()->GetBinLowEdge(nbinsy - 1) + hist->GetYaxis()->GetBinWidth(nbinsy - 1);

   for (UShort_t ibin = 1; ibin < nbinsx; ibin++)
   {
      binsx[ibin] = hist->GetXaxis()->GetBinLowEdge(ibin);
   }
   for (UShort_t ibin = 1; ibin < nbinsy; ibin++)
   {
      binsy[ibin] = hist->GetYaxis()->GetBinLowEdge(ibin);
   }

   TH2D *hist_uo = new TH2D(Form("%s_%s", hist->GetName(), suffix), hist->GetTitle(), nbinsx, binsx, nbinsy, binsy);
   hist_uo->SetXTitle(hist->GetXaxis()->GetTitle());
   hist_uo->SetYTitle(hist->GetYaxis()->GetTitle());
   hist_uo->SetZTitle(hist->GetZaxis()->GetTitle());
   for (UShort_t ibin = 1; ibin <= hist_uo->GetNbinsX(); ++ibin)
   {
      for (UShort_t jbin = 1; jbin <= hist_uo->GetNbinsY(); ++jbin)
      {
         hist_uo->SetBinContent(ibin, jbin, hist->GetBinContent(ibin - 1, jbin - 1));
         hist_uo->SetBinError(ibin, jbin, hist->GetBinError(ibin - 1, jbin - 1));
      }
   }

   return hist_uo;
}



//
void HistTools::BuildLinearBins(Double_t min, Double_t max, UInt_t nbins, Double_t *&bins)
{
   bins[0] = min;

   Double_t width = (max - min) / nbins;

   for (UInt_t ibin = 1; ibin <= nbins; ++ibin)
   {
      bins[ibin] = bins[ibin - 1] + width;
   }
}

void HistTools::BuildLinearBins(time_t min, time_t max, UInt_t nbins, time_t *&bins)
{
   bins[0] = min;

   time_t width = (max - min) / nbins;

   for (UInt_t ibin = 1; ibin <= nbins; ++ibin)
   {
      bins[ibin] = bins[ibin - 1] + width;
   }
}

Double_t *HistTools::BuildLinearBins(Double_t min, Double_t max, UInt_t nbins)
{
   Double_t *bins = new Double_t[nbins+1];
   BuildLinearBins(min, max, nbins, bins);

   return bins;
}

time_t *HistTools::BuildLinearBins(time_t min, time_t max, UInt_t nbins)
{
   time_t *bins = new time_t[nbins+1];
   BuildLinearBins(min, max, nbins, bins);

   return bins;
}



//
void HistTools::BuildLogBins(Double_t min, Double_t max, UInt_t nbins, Double_t *&bins)
{
   bins[0] = min;

   Double_t width = TMath::Exp((TMath::Log(max) - TMath::Log(min)) / nbins);

   for (UInt_t ibin = 1; ibin <= nbins; ++ibin)
   {
      bins[ibin] = bins[ibin - 1]*width;
   }
}

Double_t *HistTools::BuildLogBins(Double_t min, Double_t max, UInt_t nbins)
{
   Double_t *bins = new Double_t[nbins+1];
   BuildLogBins(min, max, nbins, bins);

   return bins;
}



//
Double_t HistTools::UserXToNDC(Double_t x, TVirtualPad *pad)
{
   if (pad == NULL) pad = gPad;

   if (pad->GetLogx()) x = TMath::Log10(x);

   return (x - pad->GetX1())/(pad->GetX2() - pad->GetX1());
}

Double_t HistTools::UserYToNDC(Double_t y, TVirtualPad *pad)
{
   if (pad == NULL) pad = gPad;

   if (pad->GetLogy()) y = TMath::Log10(y);

   return (y - pad->GetY1())/(pad->GetY2() - pad->GetY1());
}



//
Double_t HistTools::UserFXToNDC(Double_t x, TVirtualPad *pad)
{
   if (pad == NULL) pad = gPad;

   Double_t plm = pad->GetLeftMargin();
   Double_t prm = pad->GetRightMargin();
   Double_t pw  = 1. - prm - plm;

   return plm + x*pw;
}
Double_t HistTools::UserFYToNDC(Double_t y, TVirtualPad *pad)
{
   if (pad == NULL) pad = gPad;

   Double_t pbm = pad->GetBottomMargin();
   Double_t ptm = pad->GetTopMargin();
   Double_t pw  = 1. - ptm - pbm;

   return pbm + y*pw;
}



//
Double_t HistTools::UserFXToX(Double_t x, TVirtualPad *pad)
{
   if (pad == NULL) pad = gPad;

   Double_t plm = pad->GetLeftMargin();
   Double_t prm = pad->GetRightMargin();
   Double_t pw  = 1. - prm - plm;

   return pad->GetX1() + (pad->GetX2() - pad->GetX1())*(plm + x*pw);
}
Double_t HistTools::UserFYToY(Double_t y, TVirtualPad *pad)
{
   if (pad == NULL) pad = gPad;

   Double_t pbm = pad->GetBottomMargin();
   Double_t ptm = pad->GetTopMargin();
   Double_t pw  = 1. - ptm - pbm;

   return pad->GetY1() + (pad->GetY2() - pad->GetY1())*(pbm + y*pw);
}



//
TLegend *HistTools::CreateLegend(TH1 *ha, Double_t x1, Double_t y1, Double_t x2, Double_t y2, UInt_t nlines, UInt_t nminlines, Bool_t ndc, const Char_t *header)
{
   TLegend *leg;

   if (!ndc)
   {
      Double_t plm, prm, ptm, pbm, pw, ph;
      Double_t xm, xM, ym, yM, dx, dy, dh;

      plm = gPad->GetLeftMargin();
      prm = gPad->GetRightMargin();
      ptm = gPad->GetTopMargin();
      pbm = gPad->GetBottomMargin();
      pw  = 1. - prm - plm;
      ph  = 1. - pbm - ptm;

      xm = ha->GetBinLowEdge(1);
      xM = ha->GetBinLowEdge(ha->GetNbinsX()+1);
      ym = ha->GetMinimum();
      yM = ha->GetMaximum();
      dx = xM - xm;
      dy = yM - ym;

      if (gPad->GetLogx())
      {
         dx = TMath::Log10(xM) - TMath::Log10(xm);
         xm = TMath::Log10(xm);
         x1 = TMath::Log10(x1);
         x2 = TMath::Log10(x2);
      }

      if (gPad->GetLogy())
      {
         dy = TMath::Log10(yM) - TMath::Log10(ym);
         ym = TMath::Log10(ym);
         y1 = TMath::Log10(y1);
         y2 = TMath::Log10(y2);
      }

      if (nminlines > 0)
      {
         dh = (y2 - y1)/nminlines;
         y1 = y2 - dh*nlines;
      }

      leg = new TLegend(plm + (x1 - xm)/dx*pw, pbm + (y1 - ym)/dy*ph, plm + (x2 - xm)/dx*pw, pbm + (y2 - ym)/dy*ph, header, "NDC");
   }
   else
   {
      leg = new TLegend(UserFXToNDC(x1), UserFYToNDC(y1), UserFXToNDC(x2), UserFYToNDC(y2), header, "NDC");
   }

   leg->SetFillColor(kWhite);
   //~ leg->SetFillStyle(0);
   leg->SetBorderSize(1);
   leg->SetMargin(0.25);
   leg->SetTextFont(gStyle->GetTitleFont());//42
   leg->SetTextSize(gStyle->GetTitleSize());//0.03

   return leg;
}



//
TPaveText *HistTools::CreatePaveText(TH1 *ha, Float_t x1, Float_t y1, Float_t x2, Float_t y2, UInt_t nlines, UInt_t nminlines, Bool_t ndc)
{
   TPaveText *pavetext;

   if (!ndc)
   {
      Float_t plm, prm, ptm, pbm, pw, ph;
      Float_t xm, xM, ym, yM, dx, dy, dh;

      plm = gPad->GetLeftMargin();
      prm = gPad->GetRightMargin();
      ptm = gPad->GetTopMargin();
      pbm = gPad->GetBottomMargin();
      pw  = 1. - prm - plm;
      ph  = 1. - pbm - ptm;

      xm = ha->GetBinLowEdge(1);
      xM = ha->GetBinLowEdge(ha->GetNbinsX()+1);
      ym = ha->GetMinimum();
      yM = ha->GetMaximum();
      dx = xM - xm;
      dy = yM - ym;

      if (gPad->GetLogx())
      {
         dx = TMath::Log10(xM) - TMath::Log10(xm);
         xm = TMath::Log10(xm);
         x1 = TMath::Log10(x1);
         x2 = TMath::Log10(x2);
      }

      if (gPad->GetLogy())
      {
         dy = TMath::Log10(yM) - TMath::Log10(ym);
         ym = TMath::Log10(ym);
         y1 = TMath::Log10(y1);
         y2 = TMath::Log10(y2);
      }

      if (nminlines > 0)
      {
         dh = (y2 - y1)/nminlines;
         y1 = y2 - dh*nlines;
      }

      pavetext = new TPaveText(plm + (x1 - xm)/dx*pw, pbm + (y1 - ym)/dy*ph, plm + (x2 - xm)/dx*pw, pbm + (y2 - ym)/dy*ph, "NDC");
   }
   else
   {
      pavetext = new TPaveText(UserFXToNDC(x1), UserFYToNDC(y1), UserFXToNDC(x2), UserFYToNDC(y2), "NDC");
   }

   pavetext->SetFillColor(kWhite);
   //~ pavetext->SetFillStyle(0);
   pavetext->SetBorderSize(1);
   pavetext->SetMargin(0.02);
   pavetext->SetTextFont(gStyle->GetTitleFont()); // 72
   pavetext->SetTextSize(gStyle->GetTitleSize()); // 0.030
   pavetext->SetTextAlign(12);

   return pavetext;
}



//
TH1D *HistTools::CreateTimeAxis(const Char_t *name, const Char_t *title, time_t start_time, time_t end_time, UInt_t bin_size, Double_t ymin, Double_t ymax)
{
   UInt_t nbins = (end_time + 1 - start_time);
   nbins = nbins < bin_size ? nbins : nbins / bin_size + 1;

   TH1D *ha = new TH1D(name, title, nbins, start_time, end_time);

   ha->SetDirectory(0);
   ha->SetStats(kFALSE);

   ha->SetLineColor(kBlack);

   ha->SetXTitle("Time");

   ha->SetMinimum(ymin);
   ha->SetMaximum(ymax);
   ha->GetYaxis()->SetRangeUser(ymin, ymax);

   ha->GetXaxis()->SetTimeOffset(0, "gmt");
   ha->GetXaxis()->SetTimeFormat("%H:%M");
   ha->GetXaxis()->SetTimeDisplay(1);

   if (ymin < 0.)
   {
      for (UInt_t ibin = 1; ibin <= (UInt_t)ha->GetNbinsX(); ++ibin)
      {
         ha->SetBinContent(ibin, 10*ymin);
      }
   }

   return ha;
}

TH2D *HistTools::CreateTimeAxis(const Char_t *name, const Char_t *title, time_t start_time, time_t end_time, UInt_t bin_size, UInt_t nbinsy, Double_t ymin, Double_t ymax, Bool_t log)
{
   UInt_t nbinsx = (end_time + 1 - start_time);
   nbinsx = nbinsx < bin_size ? nbinsx : nbinsx / bin_size + 1;

   Double_t *binsy = new Double_t[nbinsy + 1];
   if (log) HistTools::BuildLogBins(ymin, ymax, nbinsy, binsy);
   else HistTools::BuildLinearBins(ymin, ymax, nbinsy, binsy);

   TH2D *ha = new TH2D(name, title, nbinsx, start_time, end_time, nbinsy, binsy);

   ha->SetDirectory(0);
   ha->SetStats(kFALSE);

   ha->SetXTitle("Time");

   ha->GetXaxis()->SetTimeOffset(0, "gmt");
   ha->GetXaxis()->SetTimeFormat("%H:%M");
   ha->GetXaxis()->SetTimeDisplay(1);

   return ha;
}

TH2D *HistTools::CreateTimeAxis(const Char_t *name, const Char_t *title, time_t start_timex, time_t end_timex, UInt_t bin_sizex, time_t start_timey, time_t end_timey, UInt_t bin_sizey)
{
   UInt_t nbinsx = (end_timex + 1 - start_timex);
   nbinsx = nbinsx < bin_sizex ? nbinsx : nbinsx / bin_sizex + 1;

   UInt_t nbinsy = (end_timey + 1 - start_timey);
   nbinsy = nbinsy < bin_sizey ? nbinsy : nbinsy / bin_sizey + 1;

   TH2D *ha = new TH2D(name, title, nbinsx, start_timex, end_timex, nbinsy, start_timey, end_timey);

   ha->SetDirectory(0);
   ha->SetStats(kFALSE);

   ha->GetXaxis()->SetTimeOffset(0, "gmt");
   ha->GetXaxis()->SetTimeFormat("%Y");
   ha->GetXaxis()->SetTimeDisplay(1);

   ha->GetYaxis()->SetTimeOffset(0, "gmt");
   ha->GetYaxis()->SetTimeFormat("%Y");
   ha->GetYaxis()->SetTimeDisplay(1);

   return ha;
}

TH1D *HistTools::CreateAxis(const Char_t *name, const Char_t *title, Double_t xmin, Double_t xmax, UInt_t nbins, Double_t ymin, Double_t ymax, Bool_t log)
{
   Double_t *bins = new Double_t[nbins + 1];
   if (log) HistTools::BuildLogBins(xmin, xmax, nbins, bins);
   else HistTools::BuildLinearBins(xmin, xmax, nbins, bins);
   TH1D *ha = new TH1D(name, title, nbins, bins);

   ha->SetDirectory(0);
   ha->SetStats(kFALSE);

   ha->SetLineColor(kBlack);

   ha->SetMinimum(ymin);
   ha->SetMaximum(ymax);
   ha->GetYaxis()->SetRangeUser(ymin, ymax);

   if (ymin < 0.)
   {
      for (UInt_t ibin = 1; ibin <= (UInt_t)ha->GetNbinsX(); ++ibin)
      {
         ha->SetBinContent(ibin, 10*ymin);
      }
   }

   delete [] bins;

   return ha;
}



//
TPad **HistTools::DivideCanvas(TVirtualPad *canvas, UShort_t ncols, UShort_t nrows, const Float_t *margins, Float_t xgap, Float_t ygap, const Char_t *suffix)
{
   Char_t name[STR_LENGTH];
   Char_t title[STR_LENGTH];

   Float_t ml = margins[0]; // left margin
   Float_t mr = margins[1]; // right margin
   Float_t mb = margins[2]; // bottom margin
   Float_t mt = margins[3]; // top margin

   /*    0,1                                   1,1
    *     ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓---------
    *     ┃                                                              ┃      | mt
    *     ┃      ┏━━━━━━━┳━━━━━━━┳━━━━━━━┓      ┃---------
    *     ┃      ┃              ┃              ┃              ┃      ┃      | h0
    *     ┃      ┣━━━━━━━╋━━━━━━━╋━━━━━━━┫      ┃---------y0
    *     ┃      ┃              ┃              ┃              ┃      ┃      |
    *     ┃      ┣━━━━━━━╋━━━━━━━╋━━━━━━━┫      ┃---------
    *     ┃      ┃              ┃              ┃              ┃      ┃      |
    *     ┃      ┣━━━━━━━╋━━━━━━━╋━━━━━━━┫      ┃---------
    *     ┃      ┃              ┃              ┃              ┃      ┃      | h{M-1}
    *     ┃      ┗━━━━━━━┻━━━━━━━┻━━━━━━━┛      ┃---------y{M-1}
    *     ┃                                                              ┃      | mb
    *     ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛---------
    *    0,0   |        |        |        |   1,0
    *     |____|________|________|________|____|
    *     | ml |   w0   |        | w{N-1} | mr |
    *     x0            x1     x{N-1}
    *
    * ml + mr + N*w = 1 => w = (1 - ml - mr) / N
    * mb + mt + N*h = 1 => h = (1 - mb - mt) / M
    *
    * x0 = 0
    * x1 = ml + w
    * xi = i == 0 ? 0 : ml + i*w
    * wi = i == 0 ? ml + w : (i == N-1 ?  mr + w : w)
    *
    * y0 = 1 - mt - h
    * y1 = 1 - mt - 2*h
    * yj = 1 - mt - (j+1)*h
    * hj = j == 0 ? mt + h : (j == M-1 ? mb + h : h)
    *
    * cij = (xi, yj, xi + wi, yj + wj)
    *
    */

   UShort_t npads = nrows*ncols;

   TPad **pads = new TPad *[npads];

   Double_t w = (1 - ml - mr) / ncols;
   Double_t h = (1 - mb - mt) / nrows;

   Double_t yt = 1.;

   canvas->SetMargin(0., 0., 0., 0.);

   for (UShort_t irow = 0; irow < nrows; ++irow)
   {
      Double_t hp = h;
      if (irow == 0) hp += mt;
      if (irow == nrows - 1) hp += mb;
      Double_t yb = yt - hp;
      if (yb < 0.) yb = 0.;

      Double_t xl = 0.;

      for (UShort_t icol = 0; icol < ncols; ++icol)
      {
         canvas->cd(0);

         UShort_t ipad = irow*ncols + icol;
         //~ UShort_t icol = ipad % ncols;
         //~ UShort_t irow = ipad / ncols;

         Double_t wp = w;
         if (icol == 0) wp += ml;
         if (icol == ncols - 1) wp += mr;
         Double_t xr = xl + wp;
         if (xr > 1.) xr = 1.;

         snprintf(name, STR_LENGTH, "%s_%02u_%02u%s", canvas->GetName(), irow + 1, icol + 1, suffix);
         snprintf(title, STR_LENGTH, "[%02u:%02u] %s", irow + 1, icol + 1, canvas->GetTitle());
         TPad *pad = new TPad(name, title, xl, yb, xr, yt);
         pad->SetMargin(icol == 0 ? ml/wp : xgap/2., icol == ncols -1 ? mr/wp : xgap/2., irow == nrows - 1 ? mb/hp : ygap/2., irow == 0 ? mt/hp : ygap/2.);
         pad->SetFrameBorderMode(0);
         pad->SetBorderMode(0);
         pad->SetBorderSize(0);
         pad->SetFillColor(0);
         pad->SetFillStyle(4000);
         pad->SetFrameFillColor(0);
         pad->SetFrameFillStyle(4000);
         pad->Draw();
         pad->SetNumber(ipad+1);

         pads[ipad] = pad;

         xl = xr;
      }

      yt = yb;
   }

   return pads;
}

TPad **HistTools::DivideCanvas(TVirtualPad *canvas, UShort_t ncols, UShort_t nrows, const Float_t *widths, const Float_t *heights, const Float_t *margins, Float_t xgap, Float_t ygap, const Char_t *suffix)
{
   Char_t name[STR_LENGTH];
   Char_t title[STR_LENGTH];

   Float_t ml = margins[0]; // left margin
   Float_t mr = margins[1]; // right margin
   Float_t mb = margins[2]; // bottom margin
   Float_t mt = margins[3]; // top margin

   UShort_t npads = nrows*ncols;

   TPad **pads = new TPad *[npads];

   Double_t w = (1 - ml - mr) / ncols;
   Double_t h = (1 - mb - mt) / nrows;

   Double_t *pad_widths = new Double_t[ncols];
   Double_t tot_width  = 0.;
   Double_t norm_width = 1. / ncols;
   for (UShort_t icol = 0; icol < ncols; ++icol)
   {
      pad_widths[icol] = widths[icol];
      tot_width += pad_widths[icol];
   }
   for (UShort_t icol = 0; icol < ncols; ++icol)
   {
      pad_widths[icol] *= w / tot_width / norm_width; // pw = ((pw / tot_width) / norm_width) * w
   }

   Double_t *pad_heights = new Double_t[nrows];
   Double_t tot_height  = 0.;
   Double_t norm_height = 1. / nrows;
   for (UShort_t irow = 0; irow < nrows; ++irow)
   {
      pad_heights[irow] = heights[irow];
      tot_height += pad_heights[irow];
   }
   for (UShort_t irow = 0; irow < nrows; ++irow)
   {
      pad_heights[irow] *= h / tot_height / norm_height; // ph = ((ph / tot_height) / norm_height) * h
   }

   Double_t yt = 1.;

   canvas->SetMargin(0., 0., 0., 0.);

   for (UShort_t irow = 0; irow < nrows; ++irow)
   {
      Double_t hp = pad_heights[irow];
      if (irow == 0) hp += mt;
      if (irow == nrows - 1) hp += mb;
      Double_t yb = yt - hp;
      if (yb < 0.) yb = 0.;

      Double_t xl = 0.;

      for (UShort_t icol = 0; icol < ncols; ++icol)
      {
         canvas->cd(0);

         UShort_t ipad = irow*ncols + icol;
         //~ UShort_t irow = ipad % ncols;
         //~ UShort_t icol = ipad / ncols;

         Double_t wp = pad_widths[icol];
         if (icol == 0) wp += ml;
         if (icol == ncols - 1) wp += mr;
         Double_t xr = xl + wp;
         if (xr > 1.) xr = 1.;

         snprintf(name, STR_LENGTH, "%s_%02u_%02u%s", canvas->GetName(), irow + 1, icol + 1, suffix);
         snprintf(title, STR_LENGTH, "[%02u:%02u] %s", irow + 1, icol + 1, canvas->GetTitle());
         TPad *pad = new TPad(name, title, xl, yb, xr, yt);
         pad->SetMargin(icol == 0 ? ml/wp : xgap/2., icol == ncols -1 ? mr/wp : xgap/2., irow == nrows - 1 ? mb/hp : ygap/2., irow == 0 ? mt/hp : ygap/2.);
         pad->SetFrameBorderMode(0);
         pad->SetBorderMode(0);
         pad->SetBorderSize(0);
         pad->SetFillStyle(4000);
         pad->Draw();
         pad->SetNumber(ipad+1);

         pads[ipad] = pad;

         xl = xr;
      }

      yt = yb;
   }

   delete [] pad_widths;
   delete [] pad_heights;

   return pads;
}

TPad **HistTools::DivideCanvas(TVirtualPad *canvas, UShort_t ncols, UShort_t nrows, const Float_t **widths, const Float_t **heights, const Float_t *margins, const Char_t *suffix)
{
   Char_t name[STR_LENGTH];
   Char_t title[STR_LENGTH];

   Float_t ml = margins[0]; // left margin
   Float_t mr = margins[1]; // right margin
   Float_t mb = margins[2]; // bottom margin
   Float_t mt = margins[3]; // top margin

   UShort_t npads = nrows*ncols;

   TPad **pads = new TPad *[npads]();

   Double_t w = (1 - ml - mr) / ncols;
   Double_t h = (1 - mb - mt) / nrows;

   Double_t **pad_widths  = new Double_t *[nrows]();
   Double_t **pad_heights = new Double_t *[nrows]();
   Double_t *tot_width   = new Double_t[nrows]();
   Double_t *tot_height  = new Double_t[ncols]();
   Double_t norm_width  = 1. / ncols;
   Double_t norm_height = 1. / nrows;
   UShort_t *neffrows = new UShort_t[ncols]();
   UShort_t *neffcols = new UShort_t[nrows]();

   for (UShort_t irow = 0; irow < nrows; ++irow)
   {
      pad_widths[irow]  = new Double_t[ncols]();
      pad_heights[irow] = new Double_t[ncols]();

      for (UShort_t icol = 0; icol < ncols; ++icol)
      {
         pad_widths[irow][icol] = widths[irow][icol];
         tot_width[irow] += pad_widths[irow][icol];

         pad_heights[irow][icol] = heights[irow][icol];
         tot_height[icol] += pad_heights[irow][icol];

         if (pad_widths[irow][icol] > 0.) ++neffcols[irow];
         if (pad_heights[irow][icol] > 0.) ++neffrows[icol];
      }
   }
   for (UShort_t irow = 0; irow < nrows; ++irow)
   {
      for (UShort_t icol = 0; icol < ncols; ++icol)
      {
         pad_widths[irow][icol]  *= w / tot_width[irow] / norm_width; // pw = ((pw / tot_width) / norm_width) * w
         pad_heights[irow][icol] *= h / tot_height[icol] / norm_height; // ph = ((ph / tot_height) / norm_height) * h
      }
   }

   Double_t *yt = new Double_t[ncols];
   Double_t *yb = new Double_t[ncols];
   Double_t *xl = new Double_t[nrows]();
   Double_t *xr = new Double_t[nrows];
   for (UShort_t icol = 0; icol < ncols; ++icol)
   {
      yt[icol] = 1.;
   }

   canvas->SetMargin(0., 0., 0., 0.);
   Double_t pml, pmr, pmb, pmt;

   for (UShort_t irow = 0; irow < nrows; ++irow)
   {
      for (UShort_t icol = 0; icol < ncols; ++icol)
      {
         canvas->cd(0);

         UShort_t ipad = irow*ncols + icol;
         //~ UShort_t irow = ipad % ncols;
         //~ UShort_t icol = ipad / ncols;

         Double_t hp = pad_heights[irow][icol];
         pmt = pmb = 0.;
         if (hp > 0.)
         {
            if (irow == 0)
            {
               hp += mt;
               pmt = mt / hp;
            }
            if (irow >= neffrows[icol] - 1)
            {
               hp += mb;
               pmb = mb / hp;
            }
         }
         yb[icol] = yt[icol] - hp;
         if (yb[icol] < 0.) yb[icol] = 0.;

         Double_t wp = pad_widths[irow][icol];
         pml = pmr = 0.;
         if (wp > 0.)
         {
            if (icol == 0)
            {
               wp += ml;
               pml = ml / wp;
            }
            if (icol >= neffcols[irow] - 1)
            {
               wp += mr;
               pmr = mr / wp;
            }
         }
         xr[irow] = xl[irow] + wp;
         if (xr[irow] > 1.) xr[irow] = 1.;

         snprintf(name, STR_LENGTH, "%s_%02u_%02u%s", canvas->GetName(), irow + 1, icol + 1, suffix);
         snprintf(title, STR_LENGTH, "[%02u:%02u] %s", irow + 1, icol + 1, canvas->GetTitle());
         if (hp > 0. && wp > 0.)
         {
            TPad *pad = new TPad(name, title, xl[irow], yb[icol], xr[irow], yt[icol]);
            pad->SetMargin(pml, pmr, pmb, pmt);
            pad->SetFrameBorderMode(0);
            pad->SetBorderMode(0);
            pad->SetBorderSize(0);
            pad->SetFillStyle(4000);
            pad->Draw();
            pad->SetNumber(ipad+1);

            pads[ipad] = pad;

            yt[icol] = yb[icol];
         }

         xl[irow] = xr[irow];
      }
   }

   for (UShort_t irow = nrows; irow > 0; --irow)
   {
      delete [] pad_widths[irow-1];
      delete [] pad_heights[irow-1];
   }
   delete [] pad_widths;
   delete [] pad_heights;
   delete [] neffrows;
   delete [] neffcols;
   delete [] xl;
   delete [] xr;
   delete [] yb;
   delete [] yt;

   return pads;
}



//
TCanvas *HistTools::CreateSquareCanvas(const Char_t *name, const Char_t *title, Int_t w, Float_t l, Float_t r, Float_t b, Float_t t)
{
   Int_t h = ((1. - (l + r))*w) / (1. - (b + t));

   TCanvas *c = new TCanvas(name, title, w, h);
   c->SetMargin(l, r, b, t);

   return c;
}



//
void HistTools::SetAxis(TVirtualPad *pad, TH1 *ha, UShort_t hide_axis, UShort_t log_axis, UShort_t time_axis, Bool_t need_redraw, Bool_t same, Bool_t no_exponent, Bool_t optimize_divisions, Bool_t center_title)
{
   ha->Draw(same ? "SAME" : "");

   if (log_axis & X_AXIS) pad->SetLogx();
   if (log_axis & Y_AXIS) pad->SetLogy();

   UShort_t dim = ha->GetDimension();

   TAxis *xaxis = ha->GetXaxis();
   TAxis *yaxis = ha->GetYaxis();

   Double_t ymin = dim == 1 ? ha->GetMinimum() : yaxis->GetBinLowEdge(1);
   Double_t ymax = dim == 1 ? ha->GetMaximum() : yaxis->GetBinLowEdge(ha->GetNbinsY()+1);
   Double_t xmin = xaxis->GetBinLowEdge(1);
   Double_t xmax = xaxis->GetBinLowEdge(ha->GetNbinsX()+1);

   Style_t yfont   = yaxis->GetLabelFont();
   Float_t ysize   = yaxis->GetLabelSize();
   Float_t yoffset = yaxis->GetLabelOffset();

   TGaxis *axis;

   if (hide_axis & X_AXIS)
   {
      xaxis->SetLabelSize(0);
      xaxis->SetLabelOffset(100);
      xaxis->SetTitleSize(0);
   }
   else if (log_axis & X_AXIS)
   {
      xaxis->SetLabelOffset(0);
      xaxis->SetTitleOffset(xaxis->GetTitleOffset() + 0.1);
   }

   yaxis->SetLabelSize(0);
   if (hide_axis & Y_AXIS)
   {
      yaxis->SetLabelSize(0);
      yaxis->SetLabelOffset(100);
      yaxis->SetTitleSize(0);
   }
   else if (log_axis & Y_AXIS)
   {
      yaxis->SetTitleOffset(yaxis->GetTitleOffset() + 0.1);
   }

   if (!(hide_axis & Y_AXIS))
   {
      Int_t ndivs = TMath::Abs(yaxis->GetNdivisions());
      Int_t n1    = (ndivs % 10000) % 100;
      Int_t n2    = (ndivs % 10000) / 100;
      Int_t n3    = ndivs / 10000;
      ndivs = (n1 - 2) + 100*n2 + 10000*n3;
      Double_t min_offset = log_axis & Y_AXIS ? ymin : (ymax - ymin)/n1;
      Double_t max_offset = log_axis & Y_AXIS ? ymax/2. : min_offset;
      axis = new TGaxis(xmin, ymin + min_offset, xmin, ymax - max_offset, ymin + min_offset, ymax - max_offset, ndivs,
         log_axis & Y_AXIS ? (optimize_divisions ? "G" : "NG") : (time_axis & Y_AXIS ? (optimize_divisions ? "t" : "Nt") : (optimize_divisions ? "" : "N")));
      axis->ImportAxisAttributes(yaxis);
      axis->SetTitle("");
      axis->SetLabelFont(yfont);
      axis->SetLabelSize(ysize);
      if (log_axis & Y_AXIS)
      {
         axis->SetLabelOffset(0);
      }
      else
      {
         axis->SetLabelOffset(yoffset);
      }
      axis->SetTickSize(0);
      axis->SetNoExponent(no_exponent);
      axis->Draw();
   }

   if (!need_redraw)
   {
      Bool_t optdivsx = xaxis->GetNdivisions() > 0;
      axis = new TGaxis(xmin, ymax, xmax, ymax, xmin, xmax, TMath::Abs(xaxis->GetNdivisions()),
         Form("%s-", log_axis & X_AXIS ? (optdivsx ? "G" : "NG") : (time_axis & X_AXIS ? (optdivsx ? "t" : "Nt") : (optdivsx ? "" : "N"))));
      axis->ImportAxisAttributes(xaxis);
      axis->SetTitle("");
      axis->SetLabelSize(0);
      axis->Draw();

      axis = new TGaxis(xmax, ymin, xmax, ymax, ymin, ymax, TMath::Abs(yaxis->GetNdivisions()),
         Form("%s+", log_axis & Y_AXIS ? (optimize_divisions ? "G" : "NG") : (time_axis & Y_AXIS ? (optimize_divisions ? "t" : "Nt") : (optimize_divisions ? "" : "N"))));
      axis->ImportAxisAttributes(yaxis);
      axis->SetTitle("");
      axis->SetLabelSize(0);
      axis->SetLabelOffset(100);
      axis->Draw();
   }

   if (center_title) CenterTitle(pad);
}



//
void HistTools::RedrawAxis(TVirtualPad *pad, TH1 *ha, Bool_t optimize_divisions)
{
   UShort_t dim = ha->GetDimension();

   TAxis *xaxis = ha->GetXaxis();
   TAxis *yaxis = ha->GetYaxis();

   Double_t ymin = dim == 1 ? ha->GetMinimum() : yaxis->GetBinLowEdge(1);
   Double_t ymax = dim == 1 ? ha->GetMaximum() : yaxis->GetBinLowEdge(ha->GetNbinsY()+1);
   Double_t xmin = xaxis->GetBinLowEdge(1);
   Double_t xmax = xaxis->GetBinLowEdge(ha->GetNbinsX()+1);

   TGaxis *axis;

   //~ pad->RedrawAxis();
   ha->DrawCopy("AXIS SAME")->SetLabelOffset(100);
   //~ ha->Draw("AXIS SAME");

   axis = new TGaxis(xmin, ymax, xmax, ymax, xmin, xmax, TMath::Abs(xaxis->GetNdivisions()),
      Form("%s-", pad->GetLogx() ? (optimize_divisions ? "G" : "NG") : (xaxis->GetTimeDisplay() ? (optimize_divisions ? "t" : "Nt") : (optimize_divisions ? "" : "N"))));
   axis->ImportAxisAttributes(xaxis);
   axis->SetLabelSize(0);
   axis->SetLabelOffset(100);
   axis->SetTitle("");
   axis->Draw();

   axis = new TGaxis(xmax, ymin, xmax, ymax, ymin, ymax, TMath::Abs(yaxis->GetNdivisions()),
      Form("%s+", pad->GetLogy() ? (optimize_divisions ? "G" : "NG") : (yaxis->GetTimeDisplay() ? (optimize_divisions ? "t" : "Nt") : (optimize_divisions ? "" : "N"))));
   axis->ImportAxisAttributes(yaxis);
   axis->SetLabelSize(0);
   axis->SetLabelOffset(100);
   axis->SetTitle("");
   axis->Draw();

   CenterTitle(pad);
}

TGaxis *HistTools::DrawTopAxis(TVirtualPad *pad, TH1 *ha, Bool_t optimize_divisions)
{
   UShort_t dim = ha->GetDimension();

   TAxis *xaxis = ha->GetXaxis();
   TAxis *yaxis = ha->GetYaxis();

   Double_t ymax = dim == 1 ? ha->GetMaximum() : yaxis->GetBinLowEdge(ha->GetNbinsY()+1);
   Double_t xmin = xaxis->GetBinLowEdge(1);
   Double_t xmax = xaxis->GetBinLowEdge(ha->GetNbinsX()+1);

   TGaxis *axis = new TGaxis(xmin, ymax, xmax, ymax, xmin, xmax, TMath::Abs(xaxis->GetNdivisions()),
      Form("%s-", pad->GetLogx() ? (optimize_divisions ? "G" : "NG") : (xaxis->GetTimeDisplay() ? (optimize_divisions ? "t" : "tN") : (optimize_divisions ? "" : "N"))));
   axis->SetLabelSize(0);
   axis->Draw();

   return axis;
}

TGaxis *HistTools::DrawRightAxis(TVirtualPad *pad, TH1 *ha, Bool_t optimize_divisions)
{
   UShort_t dim = ha->GetDimension();

   TAxis *xaxis = ha->GetXaxis();
   TAxis *yaxis = ha->GetYaxis();

   Double_t ymin = dim == 1 ? ha->GetMinimum() : yaxis->GetBinLowEdge(1);
   Double_t ymax = dim == 1 ? ha->GetMaximum() : yaxis->GetBinLowEdge(ha->GetNbinsY()+1);
   Double_t xmax = xaxis->GetBinLowEdge(ha->GetNbinsX()+1);

   TGaxis *axis = new TGaxis(xmax, ymin, xmax, ymax, ymin, ymax, TMath::Abs(yaxis->GetNdivisions()),
      Form("%s+", pad->GetLogy() ? (optimize_divisions ? "G" : "NG") : (yaxis->GetTimeDisplay() ? (optimize_divisions ? "t" : "tN") : (optimize_divisions ? "" : "N"))));
   axis->SetLabelSize(0);
   axis->Draw();

   return axis;
}

TGaxis *HistTools::DrawVerticalAxis(TVirtualPad *pad, TGraph *g, Double_t rmin, Double_t rmax, UShort_t ndivs, Bool_t left_axis, const Char_t *tickpos, Bool_t optimize_divisions)
{
   pad->Modified();

   Double_t lmin  = gPad->GetUymin();
   Double_t lmax  = gPad->GetUymax();

   Double_t x = left_axis ? gPad->GetUxmin() : gPad->GetUxmax();

   TGaxis *axis = new TGaxis(x, lmin, x, lmax, rmin, rmax, ndivs, Form("%sL%s", tickpos, optimize_divisions ? "" : "N"));
   if (g != NULL)
   {
      axis->ImportAxisAttributes(g->GetYaxis());
      axis->SetLineColor(g->GetLineColor());
      axis->SetLabelColor(g->GetLineColor());
      axis->SetTitleColor(g->GetLineColor());
   }

   axis->Draw();

   return axis;
}



//
void HistTools::CenterTitle(TVirtualPad *pad)
{
   if (pad == NULL) pad = gPad;

   pad->Update();
   TPaveText *title = (TPaveText *)pad->FindObject("title");
   if (title != NULL)
   {
      TText *text = title->GetLine(0);
      if (text != NULL && strlen(text->GetTitle()) > 0)
      {
         text->SetTextFont(gStyle->GetTitleFont());
         text->SetTextSize(gStyle->GetTitleSize());
         title->SetY1NDC(1 - pad->GetTopMargin());
         title->SetX1NDC(gPad->GetLeftMargin() + (1 - (gPad->GetLeftMargin() + gPad->GetRightMargin()) - (title->GetX2NDC() - title->GetX1NDC()))/2.);
         pad->Modified();
      }
   }
}



//
void HistTools::PadAxisLimits(Double_t x1, Double_t x2, Double_t f, Double_t &nx1, Double_t &nx2, Bool_t log)
{
   if (log)
   {
      nx1 = x1*pow(x1/x2, 0.5*f);
      nx2 = x2*pow(x2/x1, 0.5*f);
   }
   else
   {
      nx1 = 0.5*(x1 + x2 - (1.+f)*(x2-x1));
      nx2 = 0.5*(x1 + x2 + (1.+f)*(x2-x1));
   }
}
