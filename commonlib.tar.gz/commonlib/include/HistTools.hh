#ifndef _HIST_TOOLS_H_
#define _HIST_TOOLS_H_

#include "headers.hh"
#include "Units.hh"
#include "DateTimeTools.hh"

class FunctionSum
{
   public:
      FunctionSum(const Char_t *name, Double_t xmin = DBL_MIN, Double_t xmax = DBL_MAX);

      void Add(TF1 *f, Double_t c = 1.);
      void CopyParametersToFunctions();
      void Reset();
      void SetFreeNormalization();
      void SetWeight(UShort_t ifunc, Double_t w);
      UShort_t nFunctions();

      TF1 *GetTF1Pointer();
      TF1 *GetFunction(UShort_t ifunc);

      Double_t operator()(Double_t *x, Double_t *par);

   private:
      std::vector<TF1 *> _funcs;
      std::vector<Double_t > _factors;
      std::vector<UShort_t> _npars;

      TString _name;
      Double_t _xmin, _xmax;

      UShort_t _ntotpars;

      Bool_t _modified;
      Bool_t _free_norm;

      TF1 *_fpointer;
};

class PowerLawInterpolation
{
   public:
      PowerLawInterpolation() : logx(NULL), logy(NULL) {};
      PowerLawInterpolation(TGraph *g);
      PowerLawInterpolation(TH1 *h);
      PowerLawInterpolation(const PowerLawInterpolation &obj);

      PowerLawInterpolation& operator=(PowerLawInterpolation obj);

      ~PowerLawInterpolation();

      Double_t operator()(Double_t *x, Double_t *par) const;

      TF1 *GetTF1Pointer(const Char_t *name, Double_t xmin, Double_t xmax) { return new TF1(name, this, xmin, xmax, 0); }

      Double_t Eval(Double_t x) { return operator ()(&x,NULL); }

   private:
      UInt_t N;
      Double_t *logx;
      Double_t *logy;

      Int_t find_nearest(Double_t x) const;
};

class HistTools
{
   public:
      enum AxisType
      {
         NO_AXIS = 0,
         X_AXIS  = 1 << 0,
         Y_AXIS  = 1 << 1
      };

      /// === [START] STYLE MANIPULATION ===
      template <class TS, class TD>
      static void CopyLineStyle(TS *source, TD *destination)
      {
         destination->SetLineColor(source->GetLineColor());
         destination->SetLineStyle(source->GetLineStyle());
         destination->SetLineWidth(source->GetLineWidth());
      }

      template <class TS, class TD>
      static void CopyMarkerStyle(TS *source, TD *destination)
      {
         destination->SetMarkerColor(source->GetMarkerColor());
         destination->SetMarkerStyle(source->GetMarkerStyle());
         destination->SetMarkerSize(source->GetMarkerSize());
      }

      template <class TS, class TD>
      static void CopyFillStyle(TS *source, TD *destination)
      {
         destination->SetFillColor(source->GetFillColor());
         destination->SetFillStyle(source->GetFillStyle());
      }

      template <class TS, class TD>
      static void CopyStyle(TS *source, TD *destination)
      {
         CopyLineStyle(source, destination);
         CopyMarkerStyle(source, destination);
         CopyFillStyle(source, destination);
      }

      template <class T>
      static void ResetLineStyle(T *object)
      {
         object->ResetAttLine();
      }

      template <class T>
      static void ResetMarkerStyle(T *object)
      {
         object->ResetAttMarker();
      }

      template <class T>
      static void ResetFillStyle(T *object)
      {
         object->ResetAttFill();
      }

      template <class T>
      static void ResetStyle(T *object)
      {
         ResetLineStyle(object);
         ResetMarkerStyle(object);
         ResetFillStyle(object);
      }

      template <class T>
      static void SetColors(T **objs, UShort_t nobjs, Style_t marker = kDot, Size_t size = 1, Bool_t inverse = false)
      {
         Int_t ncolors = gStyle->GetNumberOfColors();

         for (UShort_t iobj = 0; iobj < nobjs; ++iobj)
         {
            Color_t color = gStyle->GetColorPalette((inverse ? nobjs - 1 - iobj : iobj)/(nobjs - 1.)*(ncolors - 1.));

            objs[iobj]->SetLineColor(color);
            objs[iobj]->SetMarkerColor(color);
            objs[iobj]->SetMarkerStyle(marker);
            objs[iobj]->SetMarkerSize(size);
         }
      }
      template <class T>
      static void SetColors(T **objs, UShort_t nobjs, Style_t *marker, Size_t size = 1, Bool_t inverse = false)
      {
         Int_t ncolors = gStyle->GetNumberOfColors();

         for (UShort_t iobj = 0; iobj < nobjs; ++iobj)
         {
            Color_t color = gStyle->GetColorPalette((inverse ? nobjs - 1 - iobj : iobj)/(nobjs - 1.)*(ncolors - 1.));

            objs[iobj]->SetLineColor(color);
            objs[iobj]->SetMarkerColor(color);
            objs[iobj]->SetMarkerStyle(marker[iobj]);
            objs[iobj]->SetMarkerSize(size);
         }
      }
      template <class T>
      static void SetLineColors(T **objs, UShort_t nobjs, Style_t line = 1, Width_t width = 1, Bool_t inverse = false)
      {
         Int_t ncolors = gStyle->GetNumberOfColors();

         for (UShort_t iobj = 0; iobj < nobjs; ++iobj)
         {
            Color_t color = gStyle->GetColorPalette((inverse ? nobjs - 1 - iobj : iobj)/(nobjs - 1.)*(ncolors - 1.));

            objs[iobj]->SetLineColor(color);
            objs[iobj]->SetLineStyle(line);
            objs[iobj]->SetLineWidth(width);
         }
      }
      template <class T>
      static void SetLineColors(T **objs, UShort_t nobjs, Style_t *line, Width_t width = 1, Bool_t inverse = false)
      {
         Int_t ncolors = gStyle->GetNumberOfColors();

         for (UShort_t iobj = 0; iobj < nobjs; ++iobj)
         {
            Color_t color = gStyle->GetColorPalette((inverse ? nobjs - 1 - iobj : iobj)/(nobjs - 1.)*(ncolors - 1.));

            objs[iobj]->SetLineColor(color);
            objs[iobj]->SetLineStyle(line[iobj]);
            objs[iobj]->SetLineWidth(width);
         }
      }

      template <class T>
      static void SetLineStyle(T *obj, Color_t color, Style_t style, Width_t width)
      {
         obj->SetLineColor(color);
         obj->SetLineStyle(style);
         obj->SetLineWidth(width);
      }

      template <class T>
      static void SetMarkerStyle(T *obj, Color_t color, Style_t style, Size_t size)
      {
         obj->SetMarkerColor(color);
         obj->SetMarkerStyle(style);
         obj->SetMarkerSize(size);
      }

      template <class T>
      static void SetFillStyle(T *obj, Color_t color, Style_t style = 1001)
      {
         obj->SetFillColor(color);
         obj->SetFillStyle(style);
      }

      template <class T>
      static void SetStyle(T *obj, Color_t color, Style_t mstyle, Size_t size, Style_t lstyle, Width_t width)
      {
         obj->SetMarkerColor(color);
         obj->SetMarkerStyle(mstyle);
         obj->SetMarkerSize(size);

         obj->SetLineColor(color);
         obj->SetLineStyle(lstyle);
         obj->SetLineWidth(width);
      }

      static Color_t GetColorPalette(UShort_t iobj, UShort_t nobjs, Bool_t inverse = false)
      {
         Int_t ncolors = gStyle->GetNumberOfColors();

         return gStyle->GetColorPalette((inverse ? nobjs - 1 - iobj : iobj)/(nobjs - 1.)*(ncolors - 1.));
      }
      /// === [END] STYLE MANIPULATION ===



      /// === [START] TF1 MANIPULATION ===
      typedef Double_t (*CFunctionPtr)(Double_t *, Double_t *);

      // 1: take the pointers of 2 TF1s created from C functions as input and perform the given operation; can't be used for fitting!
      // 2: take the pointer of a TF1 created from C functions as input and perform the given operation; can't be used for fitting!
      // 3: take the pointer of a TF1 created from C functions as input and perform the given operation with the given number; can't be used for fitting!
      static TF1 *CombineTF1(TF1 *f1, TF1 *f2, CFunctionPtr operation, const Char_t *name = "", Double_t xmin = DBL_MIN, Double_t xmax = DBL_MAX);
      static TF1 *CombineTF1(TF1 *f1, CFunctionPtr operation, const Char_t *name = "", Double_t xmin = DBL_MIN, Double_t xmax = DBL_MAX);
      static TF1 *CombineTF1Const(TF1 *f1, Double_t number, CFunctionPtr operation, const Char_t *name = "", Double_t xmin = DBL_MIN, Double_t xmax = DBL_MAX);

      // f1(f2(x))
      static Double_t Compose(Double_t *x, Double_t *par);

      // f1(x)*f2(x)
      static Double_t Multiply(Double_t *x, Double_t *par);

      // f1(x)/f2(x)
      static Double_t Divide(Double_t *x, Double_t *par);

      // f1(x) + f2(x)
      static Double_t Add(Double_t *x, Double_t *par);

      // f1(x) - f2(x)
      static Double_t Subtract(Double_t *x, Double_t *par);

      // 1/f(x)
      static Double_t Reciprocal(Double_t *x, Double_t *par);

      // int(f(x)dx)
      static Double_t Integral(Double_t *x, Double_t *par);

      // df(x)/dx
      static Double_t Derivative(Double_t *x, Double_t *par);

      // d^2f(x)/dx^2
      static Double_t Derivative2(Double_t *x, Double_t *par);

      // d^3f(x)/dx^3
      static Double_t Derivative3(Double_t *x, Double_t *par);

      // x = f^-1(y)
      static Double_t Inverse(Double_t *x, Double_t *par);

      // c*f(x)
      static Double_t MultiplyConst(Double_t *x, Double_t *par);

      // f(x)/c
      static Double_t DivideConst(Double_t *x, Double_t *par);

      // f(x) + c
      static Double_t AddConst(Double_t *x, Double_t *par);

      static TF1 *CreateTF1FromGraph(TGraph *g, const Char_t *name = "", Double_t xmin = DBL_MIN, Double_t xmax = DBL_MAX);

      static Bool_t IsParameterFixed(const TF1 *f, UShort_t ipar);
      static Bool_t IsParameterBound(const TF1 *f, UShort_t ipar);
      static void   FixParameters(TF1 *f);
      static void   CopyParameters(TF1 *f_src, TF1 *f_dst, UShort_t first_dst = 0, UShort_t npars = 0, UShort_t first_src = 0, const Char_t *suf = "", Bool_t force_fixed = false, Bool_t copy_names = true);
      static void   CopyParametersValue(TF1 *f_src, TF1 *f_dst, UShort_t first_dst = 0, UShort_t npars = 0, UShort_t first_src = 0, Bool_t force_fixed = false);

      static void PrintFunction(const TF1 *f);
      /// === [END] TF1 MANIPULATION ===



      /// === [START] TH1 AND TGRAPH MANIPULATION ===
      static Bool_t IsHist(TObject *obj);
      static Bool_t IsGraph(TObject *obj);

      static TH1    *ToHist(TObject *obj);
      static TGraph *ToGraph(TObject *obj);

      // y(x) -> norm*y(x)
      static TGraph *ScaleNew(TGraph *graph, Double_t norm, const Char_t *suffix = "_rescaled");
      static void    Scale(TGraph *graph, Double_t norm);

      // y(x) -> y(x)*pow(x,gamma)
      static TH1  *PowerLawRescaleNew(TH1 *hist, Double_t gamma, const Char_t *suffix = "_rescaled");
      static void  PowerLawRescale(TH1 *hist, Double_t gamma);

      // 1: rescale g so that its minimum and maximum are the same as gnorm's minimum and maximum
      // 2: rescale g so that its minimum and maximum (given by rmin and rmax) are the same as gPad's minimum and maximum
      // 3: rescale g so that its minimum and maximum (given by rmin and rmax) are the same as the given lmin and lmax
      static void Rescale(TGraph *g, TGraph *gnorm);
      static void Rescale(TGraph *g, Double_t rmin, Double_t rmax);
      static void Rescale(TGraph *g, Double_t lmin, Double_t lmax, Double_t rmin, Double_t rmax);

      // x -> ln(x)
      static TGraph *LogXNew(TGraph *graph, const Char_t *suffix = "_logx");
      static TH1    *LogXNew(TH1 *hist, const Char_t *suffix = "_logx");
      static void    LogX(TGraph *graph);
      static void    LogX(TH1 *hist);

      // y(x) -> ln(y(x))
      static TGraph *LogYNew(TGraph *graph, const Char_t *suffix = "_logy");
      static TH1    *LogYNew(TH1 *hist, const Char_t *suffix = "_logy");
      static void    LogY(TGraph *graph);
      static void    LogY(TH1 *hist);

      // x -> exp(x)
      static TGraph *ExpXNew(TGraph *graph, const Char_t *suffix = "_expx");
      static TH1    *ExpXNew(TH1 *hist, const Char_t *suffix = "_expx");
      static void    ExpX(TGraph *graph);
      static void    ExpX(TH1 *hist);

      // y(x) -> exp(y(x))
      static TGraph *ExpYNew(TGraph *graph, const Char_t *suffix = "_expy");
      static TH1    *ExpYNew(TH1 *hist, const Char_t *suffix = "_expy");
      static void    ExpY(TGraph *graph);
      static void    ExpY(TH1 *hist);

      // x -> f(x)
      static TGraph *ComposeNew(TGraph *graph, TF1 *func, const Char_t *suffix = "");
      static TH1    *ComposeNew(TH1 *hist, TF1 *func, const Char_t *suffix = "");
      static void    Compose(TGraph *graph, TF1 *func);
      static void    Compose(TH1 *hist, TF1 *func);

      // f1*g1(x) + f2*g2(x)
      // propagate_errors: 0 = do not propagate (i.e. errors are set to zero); 1 = consider only errors from graph1; 2 = consider errors from both graph1 and graph2; x10 = compute error squared
      static TGraph *AddNew(TGraph *graph1, Double_t f1, TGraph *graph2, Double_t f2, UShort_t propagate_errors = 2);
      static TGraph *AddNew(TGraph *graph1, Double_t f1, Double_t y, Double_t ey, UShort_t propagate_errors = 2);
      static Bool_t  Add(TGraph *graph1, Double_t f1, const TGraph *graph2, Double_t f2, UShort_t propagate_errors = 2);
      static Bool_t  Add(TGraph *graph1, Double_t f1, Double_t y, Double_t ey, UShort_t propagate_errors = 2);

      // dy(x) -> sqrt(dy(x))
      static TGraph *SqrtErrorNew(TGraph *graph, const Char_t *suffix = "_sqrterr");
      static void    SqrtError(TGraph *graph);

      // 1: g1(x)*f1(x)
      // 2: g1(x)*g2(x)
      // propagate_errors: 0 = do not propagate (i.e. errors are set to zero); 1 = consider errors from graph1; 2 = consider errors from both graph1 and graph2
      static TGraph *MultiplyNew(TGraph *graph, TF1 *func, UShort_t propagate_errors = 1);
      static TGraph *MultiplyNew(TGraph *graph1, TGraph *graph2, UShort_t propagate_errors = 1);
      static void    Multiply(TGraph *graph, TF1 *func, UShort_t propagate_errors = 1);
      static Bool_t  Multiply(TGraph *graph1, const TGraph *graph2, UShort_t propagate_errors = 1);

      // 1: g1(x)/f1(x)
      // 2: g1(x)/g2(x)
      // propagate_errors: 0 = do not propagate (i.e. errors are set to zero); 1 = consider errors from graph1; 2 = consider errors from both graph1 and graph2
      static TGraph *DivideNew(TGraph *graph, TF1 *func, UShort_t propagate_errors = 1);
      static TGraph *DivideNew(TGraph *graph1, TGraph *graph2, UShort_t propagate_errors = 1);
      static void    Divide(TGraph *graph, TF1 *func, UShort_t propagate_errors = 1);
      static Bool_t  Divide(TGraph *graph1, const TGraph *graph2, UShort_t propagate_errors = 1);

      // y1(x)/y2(x); if h1 and h2 have different bins, interpolate linearly h2 on h1 bins
      static TH1    *DivideUnequalNew(TH1 *h1, TH1 *h2, const Char_t *name, Bool_t logx = true, Bool_t logy = true);
      static TGraph *DivideUnequalNew(TGraph *g1, TGraph *g2, const Char_t *name, Bool_t logx = true, Bool_t logy = true);

      // y1(x)/y2(x) - 1
      // propagate_errors: 0 = do not propagate (i.e. errors are set to zero); 1 = consider only errors from graph1; 2 = consider errors from both graph1 and graph2
      static TGraph *RelativeDifferenceNew(TGraph *graph1, TGraph *graph2, UShort_t propagate_errors = 2, Bool_t abs = false);
      static Bool_t  RelativeDifference(TGraph *graph1, TGraph *graph2, UShort_t propagate_errors = 2, Bool_t abs = false);
      static TH1    *RelativeDifferenceNew(TH1 *hist1, TH1 *hist2, UShort_t propagate_errors = 2, Bool_t abs = false);
      static Bool_t  RelativeDifference(TH1 *hist1, TH1 *hist2, UShort_t propagate_errors = 2, Bool_t abs = false);

      // (y1(x) - y2(x)) / s
      // propagate_errors: 0 = s equal to 1; 1 = s equal to errors of graph1; 2 = s equal to sum in quadrature of errors of graph1 and graph2
      static TGraph *RelativeSigmaNew(TGraph *graph1, TGraph *graph2, UShort_t propagate_errors = 2, Bool_t abs = false);
      static Bool_t  RelativeSigma(TGraph *graph1, TGraph *graph2, UShort_t propagate_errors = 2, Bool_t abs = false);
      static TH1    *RelativeSigmaNew(TH1 *hist1, TH1 *hist2, UShort_t propagate_errors = 2, Bool_t abs = false);
      static Bool_t  RelativeSigma(TH1 *hist1, TH1 *hist2, UShort_t propagate_errors = 2, Bool_t abs = false);

      // sqrt(y1(x)^2 - y2(x)^2)
      // propagate_errors: 0 = do not propagate (i.e. errors are set to zero); 1 = consider only errors from graph1; 2 = consider errors from both graph1 and graph2
      static TH1    *QuadratureDifferenceNew(TH1 *hist1, TH1 *hist2, UShort_t propagate_errors = 2, Double_t min = DBL_MIN);
      static Bool_t  QuadratureDifference(TH1 *hist1, TH1 *hist2, UShort_t propagate_errors = 2, Double_t min = DBL_MIN);

      // sqrt(y1(x)^2 + y2(x)^2)
      // propagate_errors: 0 = do not propagate (i.e. errors are set to zero); 1 = consider only errors from graph1; 2 = consider errors from both graph1 and graph2
      static TH1    *QuadratureSumNew(TH1 *hist1, TH1 *hist2, UShort_t propagate_errors = 2);
      static Bool_t  QuadratureSum(TH1 *hist1, TH1 *hist2, UShort_t propagate_errors = 2);

      // g(x) = df(x)/dx
      static TGraph *GetGraphFromDerivative(TF1 *f, Bool_t log = true);

      // g(x) = d^2f(x)/dx^2
      static TGraph *GetGraphFromSecondDerivative(TF1 *f, Bool_t log = true);

      // g(x) = int_0^{x_i} f(x)/dx
      // norm = true: normalize to integral in range
      static TGraph *GetGraphFromIntegral(TF1 *f, Bool_t norm, Bool_t log = true);

      //
      static TGraph *AverageNew(TGraph *g, std::vector<UInt_t> &ranges);
      static TGraph *AverageNew(TGraph *g, std::vector<time_t> &ranges);
      static TGraph *AverageNew(TGraph *g, std::vector< std::pair<time_t, time_t> > &ranges);
      static TGraph *AverageNew(TGraph *graph, UInt_t avg_points, const Char_t *suffix = "_avg");
      static void    Average(TGraph *graph, UInt_t avg_points);

      //
      static TH1 *GetAverageHist(const TH1 **hists, UInt_t nhists, const Char_t *name);
      static TH1 *GetAverageHist(std::vector<const TH1 *> &hists, const Char_t *name);

      // propagate_errors: 0 = do not propagete (i.e. errors are set to zero); 1 = linear sum; 2 = quadrature sum; 3 = use sample standard deviation
      static TGraph *GetAverageGraph(const TGraph **graphs, UInt_t ngraphs, const Char_t *name, UShort_t propagate_errors = 2);
      static TGraph *GetAverageGraph(std::vector<const TGraph *> &graphs, const Char_t *name, UShort_t propagate_errors = 2);

      // compute the moving average of the graph g: the resulting graph will have the same number of points
      // type: 0 = backward average: n points window before (and including) current one
      //       1 = centered average: n points window centered on current one; if n is even, the right side of the window will have one point less
      //       2 = forward average:  n points window after (and including) current one
      // the average is applied to the Y errors as well
      // if the window is wider than the number of available points, the average will be computed on those points only
      static TGraph *MovingAverage(TGraph *g, UShort_t n, UShort_t type = 1);
      static TH1    *MovingAverage(TH1 *h, UShort_t n, UShort_t type = 1);
      // by_row: true = average the rows; false = average the columns
      static TH2    *MovingAverage(TH2 *h2, UShort_t n, UShort_t type = 1, Bool_t by_row = false);

      // creates a TGraph which is the linear interpolation between the two given TGraph using the interpolation parameter s
      // gint = (1-s)*g1 + s*g2
      // g1 and g2 must have the same number of points and the same X values; no sanity check is performed
      // errors are linearly interpolated as well
      static TGraph *LinearInterpolate(TGraph *g1, TGraph *g2, Double_t s);

      // extract from g the points matching the given N sorted points, interpolating g in x (see rmode) if necessary; errors are ignored
      // rmode: 0 = consider the vector items as discrete points: x[i] = points[i]; g will have N points
      //        1 = consider the vector items as range endpoints: x[i] = 0.5*(points[i] + points[i+1]); g will have N-1 points
      //        the vector< pair<time_t, time_t> > variant automatically uses rmode = 0 on 0.5*(ranges[i].first + ranges[i].second)
      // imode: 0 = linear interpolation (from TGraph->Eval)
      //        1 = cubic spline interpolation (from TGraph->Eval)
      //        2 = cubic spline fit with N/1.75 knots (from Spline class)
      //        3 = cubic spline fit with N/1.75 knots (from Spline class) + fit error
      //        4 = cubic spline fit with N/1.75 knots (from Spline class) - fit error
      static TGraph *InterpolateOnPoints(TGraph *g, std::vector<time_t> &points, UShort_t rmode, UShort_t imode);
      static TGraph *InterpolateOnPoints(TGraph *g, std::vector< std::pair<time_t, time_t> > &ranges, UShort_t imode);
      static TGraph *InterpolateOnPoints(TGraph *g, std::vector<UInt_t> &points, UShort_t rmode, UShort_t imode);
      static TGraph *InterpolateOnPoints(TGraph *g, std::vector<Double_t> &points, UShort_t rmode, UShort_t imode);

      // g2[i] vs g1[i]
      static TGraph *GetCorrelation(TGraph *g1, TGraph *g2, UInt_t first_point = 0, UInt_t last_point = 0);

      // g2[i] vs g1[i+shift]
      static TGraph *GetCorrelationDelay(TGraph *g1, TGraph *g2, Int_t shift, UInt_t first_point = 0, UInt_t last_point = 0);

      //
      static void RankVector(Int_t N, Double_t *vec, Double_t *rank);
      static Double_t GetSpearmanCorrelationFactor(TGraph *g);
      static TGraph *GetSpearmanCorrelation(TGraph *g);
      static TGraph *GetSpearmanCorrelation(TGraph *g1, TGraph *g2, UInt_t first_point = 0, UInt_t last_point = 0);

      //
      static Double_t CorrelationTTest(Double_t r, UInt_t n, Double_t &rlow, Double_t &rup, Double_t cl = 0.95);
      static Double_t CorrelationZTest(Double_t r, UInt_t n, Double_t &rlow, Double_t &rup, Double_t cl = 0.95);

      // residual_type:    0 = g-f; 1 =(g-f)/dg; 2 = (g-f)/df; 3 = (g-f)/sqrt(dg*dg+df*df); 4 = g/f; 5 = g/f - 1; +10 = absolute value of (residual_type % 10)
      // propagate_errors: 0 = do not propagate (i.e. errors are set to zero); 1 = consider only errors from graph; 2 = consider only errors from fit; 3 = consider errors from both graph and fit
      // use_integral:     0 = do not use integral; 1 = use integral, normalized by bin volume; 2 = use integral, not normalized by bin volume
      static TGraph *GetResiduals(TGraph *graph, TF1 *fit, const Char_t *suffix, Bool_t use_range, UShort_t use_integral, Bool_t is_log, UShort_t residual_type, UShort_t propagate_errors, Double_t confint = 0.68,
         ROOT::Fit::Fitter *fitter = NULL, Int_t *idx = NULL);
      static TH1    *GetResiduals(TH1 *hist, TF1 *fit, const Char_t *suffix, Bool_t use_range, UShort_t use_integral, Bool_t is_log, UShort_t residual_type, UShort_t propagate_errors, Double_t confint = 0.68,
         ROOT::Fit::Fitter *fitter = NULL, Int_t *idx = NULL);

      // use_error:    0 = dfy; 1 = dfy/fy; 2 = dfy/y; 3 = dfy/dy; +10 = value +- (use_error % 10); value: DBL_MAX = use the function value; DBL_MIN = use the graph/hist value
      // use_integral: 0 = do not use integral; 1 = use integral, normalized by bin volume; 2 = use integral, not normalized by bin volume
      static TGraph *GetFitError(TGraph *hist, TF1 *fit, const Char_t *suffix, Bool_t use_range, UShort_t use_integral, Bool_t is_log, UShort_t use_error, Double_t value = 0., Double_t confint = 0.68,
         ROOT::Fit::Fitter *fitter = NULL, Int_t *idx = NULL);
      static TH1    *GetFitError(TH1 *hist, TF1 *fit, const Char_t *suffix, Bool_t use_range, UShort_t use_integral, Bool_t is_log, UShort_t use_error, Double_t value = 0., Double_t confint = 0.68,
         ROOT::Fit::Fitter *fitter = NULL, Int_t *idx = NULL);

      // return { expected QQ 2 sigma band, expected QQ 1 sigma band, expected QQ, observed QQ }
      static TMultiGraph *GetQQPlot(TH1 *hist, TF1 *fmodel, Double_t &p1, Double_t &p2, UInt_t first_bin = UINT_MAX, UInt_t last_bin = UINT_MAX);

      // folded cumulative distribution centered on the maximum bin: FC(bin) = if (bin<MaxBin) integral(bin,MaxBin-1) else integral(MaxBin,bin), normalized to histogram integral (GetSumOfWeights)
      // in case of TF1, compute TF1::Integral(hist->GetBinLowEdge(bin),hist->GetBinLowEdge(bin+1))/hist->GetBinWidth(bin)
      static TH1 *GetFoldedCumulative(TH1 *hist, const Char_t *name);
      static TH1 *GetFoldedCumulative(TH1 *hist, TF1 *fmodel, const Char_t *name);

      //
      static TF1               *GetSpectralIndex(TF1 *f, const Char_t *name = "", Double_t xmin = DBL_MIN, Double_t xmax = DBL_MAX);
      static TGraphAsymmErrors *GetSpectralIndex(TH1 *hist, UShort_t size = 4, UShort_t step = 4);

      //
      static void GetRange(TH1 *hist, Double_t &xmin, Double_t &xmax);
      static void GetRange(TGraph *graph, Double_t &xmin, Double_t &xmax);

      // use_error: 0 = value +- dy/y; 1 = dy; 2 = dy/y
      static TGraph *RelativeErrorNew(TGraph *graph, const Char_t *suffix, UShort_t use_error, Double_t value = 0.);
      static Bool_t  RelativeError(TGraph *graph, UShort_t use_error, Double_t value = 0.);
      static TH1    *RelativeErrorNew(TH1 *hist, const Char_t *suffix, UShort_t use_error, Double_t value = 0.);
      static Bool_t  RelativeError(TH1 *hist, UShort_t use_error, Double_t value = 0.);

      //
      static UInt_t FindPoint(TGraph *graph, Double_t x, UInt_t start_point = 0);
      static UInt_t FindFirstEdgeGreaterThan(TGraph *graph, Double_t x, UInt_t start_point = 0);
      static UInt_t FindLastEdgeGreaterThan(TGraph *graph, Double_t x, UInt_t start_point = 0);
      static UInt_t FindPointGreaterThan(TGraph *graph, Double_t y, UShort_t start_point = 0, Bool_t use_err = false);

      //
      static UInt_t CountLessThan(TGraph *g, Double_t value);
      static UInt_t CountLessOrEqualThan(TGraph *g, Double_t value);
      static UInt_t CountGreaterThan(TGraph *g, Double_t value);
      static UInt_t CountGreaterOrEqualThan(TGraph *g, Double_t value);

      //
      static UInt_t CountLessThan(TH1 *h, Double_t value);
      static UInt_t CountLessOrEqualThan(TH1 *h, Double_t value);
      static UInt_t CountGreaterThan(TH1 *h, Double_t value);
      static UInt_t CountGreaterOrEqualThan(TH1 *h, Double_t value);

      // add two more points to a graph, so that the with fill option only the area below the graph will be filled
      static void CloseGraph(TGraph *g, Double_t ymin = 0.);

      //
      static Double_t GetMinimum(TH1 *hist, Double_t min_val = -DBL_MAX);
      static Double_t GetMaximum(TH1 *hist, Double_t max_val = DBL_MAX);
      static Double_t GetMinimum(TGraph *graph, Double_t min_val = -DBL_MAX);
      static Double_t GetMaximum(TGraph *graph, Double_t max_val = DBL_MAX);
      static Double_t GetMinimum(TGraph *graph, UInt_t &min_point, Double_t min_val = -DBL_MAX);
      static Double_t GetMaximum(TGraph *graph, UInt_t &max_point, Double_t max_val = DBL_MAX);

      //
      static Double_t GetSkewness(TGraph *graph);

      //
      static Double_t GetKurtosis(TGraph *graph);

      //
      static TGraph *GetMaxGraph(TGraph **graph, UInt_t ngraphs, Bool_t use_abs = false);

      //
      static TH1D *GraphToHist(TGraph *graph, Double_t xmin = DBL_MAX, Double_t xmax = -DBL_MAX, Bool_t is_log = true, Double_t frac = 0.5, Double_t tolerance = 5e-3, Bool_t random_frac = false);

      //
      static TH1D *GetOccupancyHist(TGraph *g, Bool_t weighted, UInt_t xrange[2] = NULL, Double_t min = -DBL_MAX, Double_t max = -DBL_MAX, Bool_t log = 0, UInt_t nbins = 0, UInt_t bin_scale = 3);
      static TH1D *GetOccupancyHist(TGraph *g, Bool_t weighted, Double_t xrange[2], Double_t min = -DBL_MAX, Double_t max = -DBL_MAX, Bool_t log = 0, UInt_t nbins = 0, UInt_t bin_scale = 3);
      static TH1D *GetOccupancyHist(TH1 *h, Bool_t weighted, Bool_t nozero, Double_t min = -DBL_MAX, Double_t max = -DBL_MAX, Bool_t log = 0, UInt_t nbins = 100);

      //
      static TGraph *SampleWithReplacement(TGraph *g, UShort_t random_sampling = 0, Double_t scale_err = 1.);

      //
      static TGraph *SampleWithNoReplacement(TGraph *g, Double_t scale_err = 1.);

      //
      static TGraphErrors *RotateHist(TH1 *hist, Bool_t normalize = false, Double_t ymin = -DBL_MAX, Double_t ymax = -DBL_MAX);
      static TGraph       *RotateGraph(TGraph *g);

      //
      static TH1D *Invert(TH1 *hist);

      //
      static TGraph *RebinTimeNew(TGraph *graph1, TGraph *graph2, Bool_t error_is_statistical = true, const Char_t *suffix = "_rebin");
      static TGraph *RebinTimeNew(TGraph *graph1, time_t *time_bins, UInt_t nbins, Bool_t error_is_statistical = true, const Char_t *suffix = "_rebin");
      static TGraph *RebinTimeNew(TGraph *graph1, Double_t *time_bins, UInt_t nbins, Bool_t error_is_statistical = true, const Char_t *suffix = "_rebin");
      static TGraph *RebinTimeNew(TGraph *graph1, const std::vector<TimeInterval> &time_bins, Bool_t error_is_statistical = true, const Char_t *suffix = "_rebin");
      static Bool_t  RebinTime(TGraph *graph1, TGraph *graph2, Bool_t error_is_statistical = true);
      static Bool_t  RebinTime(TGraph *graph1, time_t *time_bins, UInt_t nbins, Bool_t error_is_statistical = true);
      static Bool_t  RebinTime(TGraph *graph1, Double_t *time_bins, UInt_t nbins, Bool_t error_is_statistical = true);
      static Bool_t  RebinTime(TGraph *graph1, const std::vector<TimeInterval> &time_bins, Bool_t error_is_statistical = true);

      //
      static TGraph *RebinNew(TGraph *graph1, TGraph *graph2, Bool_t error_is_statistical = true, const Char_t *suffix = "_rebin");
      static TGraph *RebinNew(TGraph *graph1, Double_t *time_bins, UInt_t nbins, Bool_t error_is_statistical = true, const Char_t *suffix = "_rebin");
      static Bool_t  Rebin(TGraph *graph1, TGraph *graph2, Bool_t error_is_statistical = true);
      static Bool_t  Rebin(TGraph *graph1, Double_t *time_bins, UInt_t nbins, Bool_t error_is_statistical = true);

      //
      static TGraph *AppendNew(TGraph *graph1, TGraph *graph2);
      static Bool_t  Append(TGraph *graph1, TGraph *graph2);
      static TH1    *AppendNew(TH1 *hist1, TH1 *hist2, const Char_t *name = "");
      static Bool_t  Append(TH1 *hist1, TH1 *hist2);

      //
      typedef Bool_t (*ModifyHistFuncPtr)(TH1 *, UInt_t);
      typedef Bool_t (*ModifyGraphFuncPtr)(TGraph *, UInt_t);
      static void Modify(TGraph *graph, ModifyGraphFuncPtr modify);
      static void Modify(TH1 *hist, ModifyHistFuncPtr modify);

      //
      static void InterpolateZeros(TH1 *h, Bool_t logx = true, Bool_t logy = true);

      //
      static TGraph *RemoveDataConsistentWithZeroNew(TGraph *graph, const Char_t *suffix = "_gterr");
      static TH1    *RemoveDataConsistentWithZeroNew(TH1 *hist, const Char_t *suffix = "_gterr");
      static Bool_t  RemoveDataConsistentWithZero(TGraph *graph);
      static void    RemoveDataConsistentWithZero(TH1 *hist);

      //
      static TGraph *RemoveZeroNew(TGraph *graph, Bool_t use_error = false, const Char_t *suffix = "_gt0");
      static void    RemoveZero(TGraph *graph, Bool_t use_error = false);
      static TGraph *RemoveZeroXNew(TGraph *graph, Bool_t use_error = false, const Char_t *suffix = "_gt0");
      static void    RemoveZeroX(TGraph *graph, Bool_t use_error = false);

      //
      static TGraph *RemoveNaNNew(TGraph *hist, const Char_t *suffix = "_nonan");
      static void    RemoveNaN(TGraph *hist);


      //
      static void RemovePoints(TGraph *g, UInt_t first, UInt_t last);

      //
      //
      static TGraph *RemoveInfinityNew(TGraph *hist, const Char_t *suffix = "_noinf");
      static void    RemoveInfinity(TGraph *hist);
      static TH1 *RemoveInfinityNew(TH1 *hist, const Char_t *suffix = "_noinf");
      static void RemoveInfinity(TH1 *hist);

      //
      static TGraph *ZeroErrorNew(TGraph *graph, const Char_t *suffix = "_err0");
      static Bool_t  ZeroError(TGraph *graph);

      //
      static TGraph *ClipNew(TGraph *graph, Double_t min, Double_t max, const Char_t *suffix = "_clipped");
      static Bool_t  Clip(TGraph *graph, Double_t min, Double_t max);

      //
      static TH2    *NormalizeSliceNew(TH2 *hist, Bool_t by_row, Bool_t use_underover = false, const Char_t *suffix = "_norm");
      static Bool_t  NormalizeSlice(TH2 *hist, Bool_t by_row, Bool_t use_underover = false);

      //
      static TGraph *TransformEnergyNew(TGraph *graph, Particle::Type particle, const Char_t *from_energy_unit, const Char_t *to_energy_unit, const Char_t *suffix);
      static TH1    *TransformEnergyNew(TH1    *hist,  Particle::Type particle, const Char_t *from_energy_unit, const Char_t *to_energy_unit, const Char_t *suffix);
      static TGraph *TransformEnergyNew(TGraph *graph, Particle::Type particle,
         Energy::Type from_energy_type, SIPrefix::Type from_energy_prefix,
         Energy::Type to_energy_type,   SIPrefix::Type to_energy_prefix,
         const Char_t *suffix);
      static TH1    *TransformEnergyNew(TH1     *hist, Particle::Type particle,
         Energy::Type from_energy_type, SIPrefix::Type from_energy_prefix,
         Energy::Type to_energy_type,   SIPrefix::Type to_energy_prefix,
         const Char_t *suffix);

      static Bool_t TransformEnergy(TGraph *graph, Particle::Type particle, const Char_t *from_energy_unit, const Char_t *to_energy_unit);
      static Bool_t TransformEnergy(TH1    *hist,  Particle::Type particle, const Char_t *from_energy_unit, const Char_t *to_energy_unit);
      static Bool_t TransformEnergy(TGraph *graph, Particle::Type particle,
         Energy::Type from_energy_type, SIPrefix::Type from_energy_prefix,
         Energy::Type to_energy_type,   SIPrefix::Type to_energy_prefix);
      static Bool_t TransformEnergy(TH1    *hist,  Particle::Type particle,
         Energy::Type from_energy_type, SIPrefix::Type from_energy_prefix,
         Energy::Type to_energy_type,   SIPrefix::Type to_energy_prefix);

      //
      static TGraph *TransformEnergyAndDifferentialFluxNew(TGraph *graph, Particle::Type particle,
         const Char_t *from_energy_unit, const Char_t *from_flux_unit,
         const Char_t *to_energy_unit,   const Char_t *to_flux_unit,
         const Char_t *suffix);
      static TH1    *TransformEnergyAndDifferentialFluxNew(TH1    *hist,  Particle::Type particle,
         const Char_t *from_energy_unit, const Char_t *from_flux_unit,
         const Char_t *to_energy_unit,   const Char_t *to_flux_unit,
         const Char_t *suffix);
      static TGraph *TransformEnergyAndDifferentialFluxNew(TGraph *graph, Particle::Type particle, const Char_t *from_flux_unit, const Char_t *to_flux_unit, const Char_t *suffix);
      static TH1    *TransformEnergyAndDifferentialFluxNew(TH1    *hist,  Particle::Type particle, const Char_t *from_flux_unit, const Char_t *to_flux_unit, const Char_t *suffix);
      static TGraph *TransformEnergyAndDifferentialFluxNew(TGraph *graph, Particle::Type particle,
         Energy::Type from_energy_type, SIPrefix::Type from_energy_prefix, Energy::Type from_flux_energy_type, SIPrefix::Type from_flux_energy_prefix, SIPrefix::Type from_flux_length_prefix,
         Energy::Type to_energy_type,   SIPrefix::Type to_energy_prefix,   Energy::Type to_flux_energy_type,   SIPrefix::Type to_flux_energy_prefix,   SIPrefix::Type to_flux_length_prefix,
         const Char_t *suffix);
      static TH1    *TransformEnergyAndDifferentialFluxNew(TH1    *hist,  Particle::Type particle,
         Energy::Type from_energy_type, SIPrefix::Type from_energy_prefix, Energy::Type from_flux_energy_type, SIPrefix::Type from_flux_energy_prefix, SIPrefix::Type from_flux_length_prefix,
         Energy::Type to_energy_type,   SIPrefix::Type to_energy_prefix,   Energy::Type to_flux_energy_type,   SIPrefix::Type to_flux_energy_prefix,   SIPrefix::Type to_flux_length_prefix,
         const Char_t *suffix);

      static Bool_t TransformEnergyAndDifferentialFlux(TGraph *graph, Particle::Type particle,
         const Char_t *from_energy_unit, const Char_t *from_flux_unit,
         const Char_t *to_energy_unit,   const Char_t *to_flux_unit);
      static Bool_t TransformEnergyAndDifferentialFlux(TH1    *hist,  Particle::Type particle,
         const Char_t *from_energy_unit, const Char_t *from_flux_unit,
         const Char_t *to_energy_unit,   const Char_t *to_flux_unit);
      static Bool_t TransformEnergyAndDifferentialFlux(TGraph *graph, Particle::Type particle, const Char_t *from_flux_unit, const Char_t *to_flux_unit);
      static Bool_t TransformEnergyAndDifferentialFlux(TH1    *hist,  Particle::Type particle, const Char_t *from_flux_unit, const Char_t *to_flux_unit);
      static Bool_t TransformEnergyAndDifferentialFlux(TGraph *graph, Particle::Type particle,
         Energy::Type from_energy_type, SIPrefix::Type from_energy_prefix, Energy::Type from_flux_energy_type, SIPrefix::Type from_flux_energy_prefix, SIPrefix::Type from_flux_length_prefix,
         Energy::Type to_energy_type,   SIPrefix::Type to_energy_prefix,   Energy::Type to_flux_energy_type,   SIPrefix::Type to_flux_energy_prefix,   SIPrefix::Type to_flux_length_prefix);
      static Bool_t TransformEnergyAndDifferentialFlux(TH1    *hist,  Particle::Type particle,
         Energy::Type from_energy_type, SIPrefix::Type from_energy_prefix, Energy::Type from_flux_energy_type, SIPrefix::Type from_flux_energy_prefix, SIPrefix::Type from_flux_length_prefix,
         Energy::Type to_energy_type,   SIPrefix::Type to_energy_prefix,   Energy::Type to_flux_energy_type,   SIPrefix::Type to_flux_energy_prefix,   SIPrefix::Type to_flux_length_prefix);

      //
      static TGraph *TransformEnergyAndIntegralFluxNew(TGraph *graph, Particle::Type particle, const Char_t *from_energy_unit, const Char_t *from_flux_unit, const Char_t *to_energy_unit, const Char_t *to_flux_unit, const Char_t *suffix);
      static TH1 *TransformEnergyAndIntegralFluxNew(TH1 *hist, Particle::Type particle, const Char_t *from_energy_unit, const Char_t *from_flux_unit, const Char_t *to_energy_unit, const Char_t *to_flux_unit, const Char_t *suffix);
      static TGraph *TransformEnergyAndIntegralFluxNew(TGraph *graph, Particle::Type particle, Energy::Type from_energy_type, SIPrefix::Type from_energy_prefix, SIPrefix::Type from_flux_length_prefix, Energy::Type to_energy_type,
         SIPrefix::Type to_energy_prefix, SIPrefix::Type to_flux_length_prefix, const Char_t *suffix);
      static TH1 *TransformEnergyAndIntegralFluxNew(TH1 *hist, Particle::Type particle, Energy::Type from_energy_type, SIPrefix::Type from_energy_prefix, SIPrefix::Type from_flux_length_prefix, Energy::Type to_energy_type,
         SIPrefix::Type to_energy_prefix, SIPrefix::Type to_flux_length_prefix, const Char_t *suffix);

      static Bool_t TransformEnergyAndIntegralFlux(TGraph *graph, Particle::Type particle, const Char_t *from_energy_unit, const Char_t *from_flux_unit, const Char_t *to_energy_unit, const Char_t *to_flux_unit);
      static Bool_t TransformEnergyAndIntegralFlux(TH1 *hist, Particle::Type particle, const Char_t *from_energy_unit, const Char_t *from_flux_unit, const Char_t *to_energy_unit, const Char_t *to_flux_unit);
      static Bool_t TransformEnergyAndIntegralFlux(TGraph *graph, Particle::Type particle, Energy::Type from_energy_type, SIPrefix::Type from_energy_prefix, SIPrefix::Type from_flux_length_prefix, Energy::Type to_energy_type,
         SIPrefix::Type to_energy_prefix, SIPrefix::Type to_flux_length_prefix);
      static Bool_t TransformEnergyAndIntegralFlux(TH1 *hist, Particle::Type particle, Energy::Type from_energy_type, SIPrefix::Type from_energy_prefix, SIPrefix::Type from_flux_length_prefix, Energy::Type to_energy_type,
         SIPrefix::Type to_energy_prefix, SIPrefix::Type to_flux_length_prefix);

      //
      static TGraph *TransformDifferentialFluxNew(TGraph *graph, Particle::Type particle, Energy::Range range, const Char_t *from_flux_unit, const Char_t *to_flux_unit, const Char_t *suffix);
      static TH1 *TransformDifferentialFluxNew(TH1 *hist, Particle::Type particle, Energy::Range range, const Char_t *from_flux_unit, const Char_t *to_flux_unit, const Char_t *suffix);
      static TGraph *TransformDifferentialFluxNew(TGraph *graph, Particle::Type particle, Energy::Range range, Energy::Type from_flux_energy_type, SIPrefix::Type from_flux_energy_prefix, SIPrefix::Type from_flux_length_prefix,
         Energy::Type to_flux_energy_type, SIPrefix::Type to_flux_energy_prefix, SIPrefix::Type to_flux_length_prefix, const Char_t *suffix);
      static TH1 *TransformDifferentialFluxNew(TH1 *hist, Particle::Type particle, Energy::Range range, Energy::Type from_flux_energy_type, SIPrefix::Type from_flux_energy_prefix, SIPrefix::Type from_flux_length_prefix,
         Energy::Type to_flux_energy_type, SIPrefix::Type to_flux_energy_prefix, SIPrefix::Type to_flux_length_prefix, const Char_t *suffix);

      static Bool_t TransformDifferentialFlux(TGraph *graph, Particle::Type particle, Energy::Range range, const Char_t *from_flux_unit, const Char_t *to_flux_unit);
      static Bool_t TransformDifferentialFlux(TH1 *hist, Particle::Type particle, Energy::Range range, const Char_t *from_flux_unit, const Char_t *to_flux_unit);
      static Bool_t TransformDifferentialFlux(TGraph *graph, Particle::Type particle, Energy::Range range, Energy::Type from_flux_energy_type, SIPrefix::Type from_flux_energy_prefix, SIPrefix::Type from_flux_length_prefix,
         Energy::Type to_flux_energy_type, SIPrefix::Type to_flux_energy_prefix, SIPrefix::Type to_flux_length_prefix);
      static Bool_t TransformDifferentialFlux(TH1 *hist, Particle::Type particle, Energy::Range range, Energy::Type from_flux_energy_type, SIPrefix::Type from_flux_energy_prefix, SIPrefix::Type from_flux_length_prefix,
         Energy::Type to_flux_energy_type, SIPrefix::Type to_flux_energy_prefix, SIPrefix::Type to_flux_length_prefix);

      //
      static TGraph *TransformIntegralFluxNew(TGraph *graph, const Char_t *from_flux_unit, const Char_t *to_flux_unit, const Char_t *suffix);
      static TH1 *TransformIntegralFluxNew(TH1 *hist, const Char_t *from_flux_unit, const Char_t *to_flux_unit, const Char_t *suffix);
      static TGraph *TransformIntegralFluxNew(TGraph *graph, SIPrefix::Type from_flux_length_prefix, SIPrefix::Type to_flux_length_prefix, const Char_t *suffix);
      static TH1 *TransformIntegralFluxNew(TH1 *hist, SIPrefix::Type from_flux_length_prefix, SIPrefix::Type to_flux_length_prefix, const Char_t *suffix);

      static Bool_t TransformIntegralFlux(TGraph *graph, const Char_t *from_flux_unit, const Char_t *to_flux_unit);
      static Bool_t TransformIntegralFlux(TH1 *hist, const Char_t *from_flux_unit, const Char_t *to_flux_unit);
      static Bool_t TransformIntegralFlux(TGraph *graph, SIPrefix::Type from_flux_length_prefix, SIPrefix::Type to_flux_length_prefix);
      static Bool_t TransformIntegralFlux(TH1 *hist, SIPrefix::Type from_flux_length_prefix, SIPrefix::Type to_flux_length_prefix);

      //
      static TH1 *AddUnderAndOverflowBins(TH1 *hist, const Char_t *suffix = "uo");
      static TH2 *AddUnderAndOverflowBins(TH2 *hist, const Char_t *suffix = "uo");

      //
      static void      BuildLinearBins(Double_t min, Double_t max, UInt_t nbins, Double_t *&bins);
      static void      BuildLinearBins(time_t min, time_t max, UInt_t nbins, time_t *&bins);
      static Double_t *BuildLinearBins(Double_t min, Double_t max, UInt_t nbins);
      static time_t   *BuildLinearBins(time_t min, time_t max, UInt_t nbins);

      //
      static void      BuildLogBins(Double_t min, Double_t max, UInt_t nbins, Double_t *&bins);
      static Double_t *BuildLogBins(Double_t min, Double_t max, UInt_t nbins);

      //
      static Double_t UserXToNDC(Double_t x, TVirtualPad *pad = NULL);
      static Double_t UserYToNDC(Double_t y, TVirtualPad *pad = NULL);

      //
      static Double_t UserFXToNDC(Double_t x, TVirtualPad *pad = NULL);
      static Double_t UserFYToNDC(Double_t y, TVirtualPad *pad = NULL);

      //
      static Double_t UserFXToX(Double_t x, TVirtualPad *pad = NULL);
      static Double_t UserFYToY(Double_t y, TVirtualPad *pad = NULL);

      //
      static TLegend   *CreateLegend(TH1 *ha, Double_t x1, Double_t y1, Double_t x2, Double_t y2, UInt_t nlines = 0, UInt_t nminlines = 0, Bool_t ndc = false, const Char_t *header = "");
      static TPaveText *CreatePaveText(TH1 *ha, Float_t x1, Float_t y1, Float_t x2, Float_t y2, UInt_t nlines = 0, UInt_t nminlines = 0, Bool_t ndc = false);

      //
      static TH1D *CreateTimeAxis(const Char_t *name, const Char_t *title, time_t start_time, time_t end_time, UInt_t bin_size, Double_t ymin, Double_t ymax);
      static TH2D *CreateTimeAxis(const Char_t *name, const Char_t *title, time_t start_time, time_t end_time, UInt_t bin_size, UInt_t nbinsy, Double_t ymin, Double_t ymax, Bool_t log = true);
      static TH2D *CreateTimeAxis(const Char_t *name, const Char_t *title, time_t start_timex, time_t end_timex, UInt_t bin_sizex, time_t start_timey, time_t end_timey, UInt_t bin_sizey);
      static TH1D *CreateAxis(const Char_t *name, const Char_t *title, Double_t xmin, Double_t xmax, UInt_t nbins, Double_t ymin, Double_t ymax, Bool_t log = true);


      // from Olivier Couet: https://root-forum.cern.ch/t/draw-square-th2/29135/6
      static TCanvas *CreateSquareCanvas(const Char_t *name, const Char_t *title, Int_t w, Float_t l = 0.1, Float_t r = 0.1, Float_t b = 0.1, Float_t t = 0.1);



      //
      // ipad = irow*ncols + icol
      static TPad **DivideCanvas(TVirtualPad *canvas, UShort_t ncols, UShort_t nrows, const Float_t *margins, Float_t xgap = 0., Float_t ygap = 0., const Char_t *suffix = "");
      static TPad **DivideCanvas(TVirtualPad *canvas, UShort_t ncols, UShort_t nrows, const Float_t *widths, const Float_t *heights, const Float_t *margins, Float_t xgap = 0., Float_t ygap = 0., const Char_t *suffix = "");
      static TPad **DivideCanvas(TVirtualPad *canvas, UShort_t ncols, UShort_t nrows, const Float_t **widths, const Float_t **heights, const Float_t *margins, const Char_t *suffix = "");

      //
      static void SetAxis(TVirtualPad *pad, TH1 *hist_axis, UShort_t hide_axis, UShort_t log_axis, UShort_t time_axis, Bool_t needs_redraw = false, Bool_t same = false, Bool_t no_exponent = true, Bool_t optimize_divisions = false, Bool_t center_title = true);

      //
      static void    RedrawAxis(TVirtualPad *pad, TH1 *hist_axis, Bool_t optimize_divisions = false);
      static TGaxis *DrawTopAxis(TVirtualPad *pad, TH1 *hist_axis, Bool_t optimize_divisions = false);
      static TGaxis *DrawRightAxis(TVirtualPad *pad, TH1 *hist_axis, Bool_t optimize_divisions = false);
      static TGaxis *DrawVerticalAxis(TVirtualPad *pad, TGraph *g, Double_t rmin, Double_t rmax, UShort_t ndivs, Bool_t left_axis, const Char_t *tickpos, Bool_t optimize_divisions);

      //
      static void CenterTitle(TVirtualPad *pad = NULL);

      // compute new limits for the axis, padded equally on the right and left (or above and beyond) by the fraction f of the width (or height) of the original axis
      static void PadAxisLimits(Double_t x1, Double_t x2, Double_t f, Double_t &nx1, Double_t &nx2, Bool_t log = true);
};

#endif
