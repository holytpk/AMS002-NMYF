#ifndef LIS_MODELS_H_
#define LIS_MODELS_H_

#include "headers.hh"
#include "ParameterInfo.hh"

// All the fluxes are in 1/(m^2 sr s GeV/GV)
// Energy/rigidity is in GeV/GV
namespace LISModels
{
   namespace Models
   {
      Double_t PowerLawKin(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy);
      Double_t PowerLawRig(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy);
      Double_t BESS07(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy);
      Double_t BPH00U05(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy);
      Double_t GMS75(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy);
      Double_t WH03U05(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy);
      Double_t L04(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy);
      //~ Double_t WH09M14(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy);
      Double_t BO11M14(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy);
      Double_t M14(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy);
      Double_t AMS15(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy);
      Double_t AMS15V1(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy);
      Double_t AMS15BESS07(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy);
      Double_t AMS15BPH00U05(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy);
      Double_t AMS15GMS75(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy);
      Double_t AMS15WH03U05(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy);
      Double_t AMS15L04(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy);
      Double_t ThreePowerLawRig(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy);
      Double_t Corti16(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy);
      Double_t Vos15(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy);
      Double_t BON14(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy);
      Double_t Ghelfi16(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy);
      Double_t Bisschoff16(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy);
      Double_t Herbst17(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy);
      Double_t SmoothPLRig3(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy);
      Double_t SmoothPLRig4(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy);
      Double_t SmoothPLRig4Log(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy);
      Double_t GalpropKinNuc(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy);

      namespace GTF
      {
         Double_t PowerLawKin(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy);
         Double_t PowerLawRig(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy);
         Double_t BESS07(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy);
         Double_t BPH00U05(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy);
         Double_t GMS75(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy);
         Double_t WH03U05(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy);
         Double_t L04(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy);
         Double_t BO11M14(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy);
         Double_t M14(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy);
         Double_t AMS15(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy);
         Double_t AMS15V1(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy);
         Double_t AMS15BESS07(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy);
         Double_t AMS15BPH00U05(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy);
         Double_t AMS15GMS75(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy);
         Double_t AMS15WH03U05(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy);
         Double_t AMS15L04(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy);
         Double_t ThreePowerLawRig(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy);
         Double_t Corti16(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy);
         Double_t Vos15(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy);
         Double_t BON14(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy);
         Double_t Ghelfi16(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy);
         Double_t Bisschoff16(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy);
         Double_t Herbst17(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy);
         Double_t SmoothPLRig3(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy);
         Double_t SmoothPLRig4(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy);
         Double_t SmoothPLRig4Log(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy);
         Double_t GalpropKinNuc(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy);
      }

      namespace Galprop
      {
         extern std::string DataPath;

         enum Type
         {
            BMP55,       // version 55, BMP (by S. Kunz, 2015)
            Cholis16,    // Cholis et al, 2016
            Bisschoff17, // updated LIS from Bisschoff & Potgieter, 2016
            nTypes
         };

         const Char_t * const DataPrefix[nTypes] = { "55_BMP", "cholis16", "bisschoff17" };

         const UInt_t nMaxModels = 30;
         const UInt_t nModels[nTypes] = { 30, 1, 1 };

         const UInt_t nMaxParameters = 7;
         const UInt_t nParameters[nTypes] = { 7, 7, 0 };

#if !defined(__CINT__)
#pragma GCC diagnostic ignored "-Wwrite-strings"
         const ParameterInfo Info[nTypes][nMaxParameters] = {
            {
               { "L",     "Galaxy halo half thickness",           "L",             "kpc",             0., 50., 100. },
               { "D0",    "Diffusion coefficient",                "D_{0}",         "1e28 cm^2/s",     0., 50., 100. },
               { "delta", "Diffusion coefficient rigidity index", "#delta",        "",                0., 50., 100. },
               { "alpha", "Spectral index",                       "#alpha",        "",                0., 50., 100. },
               { "vA",    "Alfven speed",                         "v_{A}",         "km/s",            0., 50., 100. },
               { "eta",   "Diffusion coefficient #beta index",    "#eta",          "",              -10.,  0., 100. },
               { "dvdz",  "Convection velocity gradient",         "#frac{dv}{dz}", "km/s/kpc",        0., 50., 100. }
            }
         };
#pragma GCC diagnostic warning "-Wwrite-strings"
#else
         ParameterInfo Info[nTypes];
#endif

         const Double_t Parameter[nTypes][nMaxModels][nMaxParameters] = {
            {
               {  0.85109, 0.57805, 0.61022, 2.23156,  7.36501, -0.21694,  0.00000 },
               {  2.14750, 1.78764, 0.57010, 2.27358, 10.41830, -0.00021,  0.00000 },
               {  7.56988, 5.68393, 0.54510, 2.27170, 14.27130,  0.00000,  0.00000 },
               { 15.10340, 6.81151, 0.54147, 2.32142,  7.02991,  0.37473,  0.00000 },
               { 29.64250, 6.50145, 0.61316, 2.20521,  0.78544,  0.00019,  0.00000 },
               { 16.60290, 7.81445, 0.50365, 2.34346, 14.92570, -0.00126,  0.00000 },
               {  3.64406, 3.70777, 0.48615, 2.36315, 18.64810,  0.43926,  0.00000 },
               {  1.36608, 0.87453, 0.68119, 2.14703,  3.40205, -1.50444,  0.00000 },
               {  3.17917, 2.24008, 0.66306, 2.13617,  9.92981, -1.73768,  0.00000 },
               {  9.27576, 5.61939, 0.55545, 2.29742,  0.00188, -0.00562,  0.00000 },
               {  2.12440, 1.65176, 0.60988, 2.24114,  5.19691, -0.40390,  0.00000 },
               {  4.19772, 3.42771, 0.56289, 2.25567, 10.08502, -0.50706,  0.00000 },
               {  3.97896, 3.59154, 0.52659, 2.31049, 15.38997,  0.05575,  0.00000 },
               {  2.21743, 1.56534, 0.65307, 2.16968,  7.90371, -1.53992,  0.00000 },
               {  6.83213, 4.43136, 0.62017, 2.20957,  7.32885, -1.04888,  0.00000 },
               {  4.49981, 3.79126, 0.53539, 2.30864,  4.33255,  1.07358,  0.00000 },
               {  5.80484, 3.92557, 0.61446, 2.21550,  3.31901, -0.66801,  0.00000 },
               {  4.00766, 3.06738, 0.59088, 2.26108,  6.66928, -0.40166,  0.00000 },
               { 11.08590, 6.52006, 0.52917, 2.31479, 12.14485,  0.05211,  0.00000 },
               { 23.08676, 6.81780, 0.56098, 2.28087,  5.94450,  0.02260,  0.00000 },
               {  2.14750, 1.78764, 0.57010, 2.27358, 10.41830,  0.00000,  2.00000 },
               {  7.56988, 5.68393, 0.54510, 2.27170, 14.27130, -0.00021,  5.00000 },
               {  2.14750, 1.78764, 0.57010, 2.27358, 10.41830, -0.00021, 12.00000 },
               {  2.14750, 1.78764, 0.57010, 2.27358, 10.41830, -0.00021, 20.00000 },
               {  2.14750, 1.78764, 0.57010, 2.27358, 10.41830, -0.00021, 40.00000 },
               {  4.90000, 3.00000, 0.20000, 2.00000, 10.00000, -2.00000,  3.00000 },
               {  6.30000, 2.00000, 0.30000, 2.10000, 20.00000, -1.00000,  7.00000 },
               {  9.40000, 5.00000, 0.40000, 2.20000, 30.00000,  0.00000,  2.00000 },
               {  3.70000, 9.00000, 0.60000, 2.30000, 40.00000,  1.00000, 15.00000 },
               {  7.00000, 1.00000, 0.70000, 2.40000, 50.00000,  2.00000, 30.00000 },
            },
            {
               { 5.6, 4.85, 0.40, 2.38, 24.0, 0., 1.0 }, // + alpha1 = 1.88, Rbr = 11.7 GV
            },
            {
            },
         };
      }
   }

   enum Type
   {
      PowerLawKin = 0,  // Simple power law in kinetic energy
      PowerLawRig,      // Simple power law in rigidity
      BESS07,           // Shikaze et al, 2007 (BESS collaboration)
      BPH00U05,         // Burger et al, 2000 (as used in Usoskin et al, 2005)
      GMS75,            // Garcia-Munoz et al, 1975 [in the paper: flux in 1/(m^2 sr s MeV) and energy in MeV]
      WH03U05,          // Webber and Higbie, 2003 (as used in Usoskin et al, 2005)
      L04,              // Langner, 2004 (as used in Usoskin et al, 2005) [in the paper: flux in 1/(m^2 sr s MeV) and energy in GeV]
      //~ WH09M14,         // Webber and Higbie, 2009 (as used in Maurin et al, 2014) [energy in MeV]
      BO11M14,          // O'Neill, 2010 (as used in Maurin et al, 2014)
      M14,              // Maurin et al, 2014 (variation of Shikaze et al, 2007)
      AMS15,            // Aguilar et al, 2015 (AMS-02 collaboration, proton paper)
      AMS15V1,          // Aguilar et al, 2015 + Voyager 1 (CC parametrization)
      AMS15BESS07,      // Aguilar et al, 2015 + Shikaze et al, 2007
      AMS15BPH00U05,    // Aguilar et al, 2015 + Burger et al, 2000
      AMS15GMS75,       // Aguilar et al, 2015 + Garcia-Munoz et al, 1975
      AMS15WH03U05,     // Aguilar et al, 2015 + Webber and Higbie, 2003
      AMS15L04,         // Aguilar et al, 2015 + Langner, 2004
      ThreePowerLawRig, // Corti, 2015
      Corti16HFFA,      // Corti et al, 2016, H LIS, ForceFieldApproximation
      Corti16HDFFK,     // Corti et al, 2016, H LIS, DoubleForceField
      Corti16HDFFR,     // Corti et al, 2016, H LIS, DoubleForceFieldRig
      Corti16HeFFA,     // Corti et al, 2016, He LIS, ForceFieldApproximation
      Corti16HeDFFK,    // Corti et al, 2016, He LIS, DoubleForceField
      Corti16HeDFFR,    // Corti et al, 2016, He LIS, DoubleForceFieldRig
      Vos15,            // E. Vos, 2015
      BON14,            // Badhwar - O'Neill, 2014
      Ghelfi16H,        // Ghelfi et al, 2016, H LIS
      Ghelfi16He,       // Ghelfi et al, 2016, He LIS
      Ghelfi16HV1,      // Ghelfi et al, 2016, H LIS [Voyager 1 fit]
      Ghelfi16HeV1,     // Ghelfi et al, 2016, He LIS [Voyager 1 fit]
      Bisschoff16H,     // Bisschoff & Potgieter, 2016, H LIS
      Bisschoff16He,    // Bisschoff & Potgieter, 2016, He LIS
      Herbst17,         // Herbst et al, 2017 [original flux in 1/(m^2 sr s MeV), energy in GeV]
      SmoothPLRig3,     // 3 power-laws in rigidity smoothly connected
      Corti18HFFA,      // Corti et al, 2018, H LIS, 4 power-laws in rigidity smoothly connected, ForceFieldApproximation
      Corti18HDFFR,     // Corti et al, 2018, H LIS, 4 power-laws in rigidity smoothly connected, DoubleForceFieldRig
      Corti18He3FFA,    // Corti et al, 2018, He3 LIS, 4 power-laws in rigidity smoothly connected, ForceFieldApproximation
      Corti18He3DFFR,   // Corti et al, 2018, He3 LIS, 4 power-laws in rigidity smoothly connected, DoubleForceFieldRig
      Corti18He4FFA,    // Corti et al, 2018, He4 LIS, 4 power-laws in rigidity smoothly connected, ForceFieldApproximation
      Corti18He4DFFR,   // Corti et al, 2018, He4 LIS, 4 power-laws in rigidity smoothly connected, DoubleForceFieldRig
      SmoothPLRig4Log,  // 4 power-laws in rigidity smoothly connected, smoothing parametrized as log10
      /// Add all Galprop models after GALPROP55BMP
      GALPROP55BMP,     // Models generated by Galprop with version 55 (by Simon Kunz)
      Cholis16,         // Cholis et al, 2016 [original flux in 1/(cm^2 sr s MeV), energy in MeV]
      Bisschoff17,      // updated LIS from Bisschoff & Potgieter, 2016
      /// Add all non-Galprop models before GALPROP55BMP
      nTypes
   };

   template <typename T>
   Type cast(T iprefix)
   {
      return static_cast<Type>(iprefix);
   }

#if !defined(__CINT__)
#pragma GCC diagnostic ignored "-Wwrite-strings"
   const ModelInfo Info[nTypes] = {
      { "powerlawkin", "Power law (Kinetic energy)", "N T^{-#gamma}", "(m^{2} sr s GeV^{1-#gamma})^{-1}", 20000., Models::PowerLawKin, Models::GTF::PowerLawKin, 1, {
            { "gamma", "Spectral index", "#gamma", "", 0., 2.83, 10. }
         }
      },
      { "powerlawrig", "Power law (Rigidity)", "N R^{-#gamma}", "(m^{2} sr s GeV^{1-#gamma})^{-1}", 20000., Models::PowerLawRig, Models::GTF::PowerLawRig, 1, {
            { "gamma", "Spectral index", "#gamma", "", 0., 2.83, 10. }
         }
      },
      { "bess07", "Shikaze et al (2007)", "N #beta^{#gamma_{2}}R^{-#gamma_{1}}", "(m^{2} sr s GeV^{1-#gamma_{1}})^{-1}", 19400., Models::BESS07, Models::GTF::BESS07, 2, {
            { "gamma1", "Spectral index", "#gamma_{1}", "", 0., 2.76, 10. },
            { "gamma2", "Beta index",     "#gamma_{2}", "", 0., 0.70, 10. }
         }
      },
      { "bph00u05", "Burger et al (2000), Usoskin et al (2005)", "N R^{-#gamma_{1}}/(1 + N_{2} R^{-#gamma_{2}})", "(m^{2} sr s GeV^{1-#gamma_{1}})^{-1}", 19400., Models::BPH00U05, Models::GTF::BPH00U05, 3, {
            { "gamma1", "First spectral index",        "#gamma_{1}", "",                 0., 2.78,   10. },
            { "N2",     "Second normalization factor", "N_{2}",      "GV^{#gamma_{2}}", 0., 0.4866, 1000. },
            { "gamma2", "Second spectral index",       "#gamma_{2}", "",                 0., 2.51,   10. }
         }
      },
      { "gms75", "Garcia-Munoz et al (1975)", "N (T + N_{2} e^{-a T})^{-#gamma}", "(m^{2} sr s GeV^{1-#gamma})^{-1}", 9.9e8*TMath::Power(10.,-3*(2.65-1.)), Models::GMS75, Models::GTF::GMS75, 3, {
            { "N2",    "Second normalization factor", "N_{2}",  "GeV",          0., 0.78, 10. },
            { "a",     "Energy scale",                "a",      "GeV^{-1}",     0., 0.25, 100. },
            { "gamma", "Spectral index",              "#gamma", "",             0., 2.65, 10. }
         }
      },
      { "wh03u05", "Webber and Higbie (2003)", "N T^{-#gamma_{1}}/(1 + N_{2} T^{-#gamma_{2}} + N_{3} T^{-#gamma_{3}})", "(m^{2} sr s GeV^{1-#gamma_{1}})^{-1}", 21100., Models::WH03U05, Models::GTF::WH03U05, 5, {
            { "gamma1", "First spectral index",        "#gamma_{1}", "",                 0., 2.80, 10. },
            { "N2",     "Second normalization factor", "N_{2}",      "GeV^{#gamma_{2}}", 0., 5.85, 1000. },
            { "gamma2", "Second spectral index",       "#gamma_{2}", "",                 0., 1.22, 10. },
            { "N3",     "Third normalization factor",  "N_{3}",      "GeV^{#gamma_{3}}", 0., 1.18, 1000. },
            { "gamma3", "Third spectral index",        "#gamma_{3}", "",                 0., 2.54, 10. }
         }
      },
      { "l04", "Langner (2004)", "Galprop parametrization", "(m^{2} sr s GeV)^{-1}", TMath::Exp(3.22)*1000., Models::L04, Models::GTF::L04, 3, {
            { "a",     "Energy scale",                "a",      "", -10., 0.08,                    10. },
            { "N2",    "Second normalization factor", "N_{2}",  "",   0., TMath::Exp(4.64 - 3.22), 1000. },
            { "gamma", "Spectral index",              "#gamma", "",   0., 2.86,                    10. }
         }
      },
      /*{ "wh09m14", "Webber and Higbie (2009), Maurin et al (2014)", "MCDM parametrization", "(m^{2} sr s GeV)^{-1}", 1000, Models::WH09M14, 7, {
            { "a1", "First energy scale",  "a_{1}", "", -2000.,    51.68, 2000. },
            { "b1", "Second energy scale", "b_{1}", "", -2000.,  -103.6,  2000. },
            { "c1", "Third energy scale",  "c_{1}", "", -2000.,   709.7,  2000. },
            { "d1", "Fourth energy scale", "d_{1}", "", -2000., -1162.,   2000. },
            { "a2", "Fifth energy scale",  "a_{2}", "", -2000.,    51.84, 2000. },
            { "b2", "Sixth energy scale",  "b_{2}", "", -2000.,  -131.6,  2000. },
            { "d2", "Eight energy scale",  "d_{2}", "", -2000.,  -376.7,  2000. }
         }
      },*/
      { "bo11m14", "O'Neill (2010), Maurin et al (2014)", "N #beta^{-#gamma_{2}} (T + 0.938)^{-#gamma_{1}}", "(m^{2} sr s GeV^{1-#gamma_{1}})^{-1}", 4.502e12*TMath::Power(10, -3*2.7748), Models::BO11M14, Models::GTF::BO11M14, 2, {
            { "gamma1", "Spectral index", "#gamma_{1}", "", 0., 2.7748, 10. },
            { "gamma2", "Beta index",     "#gamma_{2}", "", 0., 1.7708, 10. }
         }
      },
      { "m14", "Maurin et al (2014)", "N #beta^{#gamma_{2}}R^{-#gamma_{1}}", "(m^{2} sr s GeV^{1-#gamma_{1}})^{-1}", 23350., Models::M14, Models::GTF::M14, 2, {
            { "gamma1", "Spectral index", "#gamma_{1}", "", 0., 2.839, 10. },
            { "gamma2", "Beta index",     "#gamma_{2}", "", 0., 1.1,   10. }
         }
      },
      { "ams15", "Aguilar et al (2015)", "N #left(#frac{R}{45 GV}#right)^{-#gamma} #[]{1 + #left(#frac{R}{R_{0}}#right)^{#frac{#Delta#gamma}{s}}}^{s}", "(m^{2} sr s GV)^{-1}", 0.4544, Models::AMS15, Models::GTF::AMS15, 4, {
            { "gamma",    "Spectral index",           "#gamma",       "",     2.4,  2.849,   3.2 },
            { "rigbreak", "Rigidity break",           "R_{0}",        "GV",   50.,    336,  600. },
            { "delta",    "Spetral index difference", "#Delta#gamma", "",      0.,  0.133,   0.5 },
            { "s",        "Transition smoothness",    "s",            "",    1e-2,   0.024,   10. },
         }
      },
      { "ams15v1", "AMS-02 (2015) + Voyager 1 (2012)", "N / (1 + e^{-(ln(x)-#mu)/#sigma})^{1/#rho} #left(#frac{R}{45 GV}#right)^{#gamma} #[]{1 + #left(#frac{R}{R_{0}}#right)^{#frac{#Delta#gamma}{s}}}^{s}", "(m^{2} sr s GV)^{-1}", 0.4544/*1e4*/, Models::AMS15V1, Models::GTF::AMS15V1, 7, {
            { "gamma",    "Spectral index",           "#gamma",       "",    -3.5,  2.819789,  -2.5 },
            { "rigbreak", "Rigidity break",           "R_{0}",        "GV",   10.,  379.547692, 800. },
            { "delta",    "Spetral index difference", "#Delta#gamma", "",     -1.,  0.115850,  1. },
            { "s",        "Transition smoothness",    "s",            "",     0.,  0.009000,  1. },
            { "mu",       "Effective cutoff",         "#mu",          "",     -1.0,  -0.470203,  0.5 },
            { "sigma",    "Penumbra width",           "#sigma",       "",      0.1,  0.665264,    1. },
            { "rho",      "Asymmetry",                "#rho",         "",      0.01,  0.325302,    1. },
            //~ { "gamma",    "Spectral index",           "#gamma",       "",    -3.5,  -3., 0 },
            //~ { "rigbreak", "Rigidity break",           "R_{0}",        "GV",   100.,  379.547692, 800. },
            //~ { "delta",    "Spetral index difference", "#Delta#gamma", "",     -1.,  0.115850,  1. },
            //~ { "s",        "Transition smoothness",    "s",            "",     9e-3,  0.009000,  10. },
            //~ { "mu",       "Effective cutoff",         "#mu",          "",      0.01,  0.57,  2. },
            //~ { "sigma",    "Penumbra width",           "#sigma",       "",      -1,  -0.7,    0. },
            //~ { "rho",      "Asymmetry",                "#rho",         "",      0.,  4.9,    10. },
         }
      },
      { "ams15bess07", "AMS-02 (2015) + Shikaze et al (2007)", "N #beta^{#gamma_{2}} #left(#frac{R}{45 GV}#right)^{-#gamma} #[]{1 + #left(#frac{R}{R_{0}}#right)^{#frac{#Delta#gamma}{s}}}^{s}", "(m^{2} sr s GV)^{-1}", 0.4544, Models::AMS15BESS07, Models::GTF::AMS15BESS07, 5, {
            { "gamma",    "Spectral index",           "#gamma",       "",     2.8,  2.849,   2.9 },
            { "rigbreak", "Rigidity break",           "R_{0}",        "GV",   200.,   336,  500. },
            { "delta",    "Spetral index difference", "#Delta#gamma", "",     0.1,  0.133,   0.2 },
            { "s",        "Transition smoothness",    "s",            "",    0.01,  0.024,  0.03 },
            { "gamma2",   "Beta index",               "#gamma_{2}",   "",      0.,   1.43,   10. }
         }
      },
      { "ams15bph00u05", "AMS-02 (2015) + Burget et al (2000)", "N / (1 + N_{2} R^{-#gamma_{2}}) #left(#frac{R}{45 GV}#right)^{-#gamma} #[]{1 + #left(#frac{R}{R_{0}}#right)^{#frac{#Delta#gamma}{s}}}^{s}", "(m^{2} sr s GV)^{-1}", 0.4544, Models::AMS15BPH00U05, Models::GTF::AMS15BPH00U05, 6, {
            { "gamma",    "Spectral index",              "#gamma",       "",                 2.8,  2.849,   2.9 },
            { "rigbreak", "Rigidity break",              "R_{0}",        "GV",              200.,    336,  500. },
            { "delta",    "Spetral index difference",    "#Delta#gamma", "",                 0.1,  0.133,   0.2 },
            { "s",        "Transition smoothness",       "s",            "",                0.01,  0.024,  0.03 },
            { "N2",       "Second normalization factor", "N_{2}",        "GV^{#gamma_{2}}",   0., 0.0531, 1000. },
            { "gamma2",   "Second spectral index",       "#gamma_{2}",   "",                  0.,   2.67,   10. }
         }
      },
      { "ams15gms75", "AMS-02 (2015) + Garcia-Munoz et al (1975)", "N (1 + N_{2}/T e^{-a T})^{-#gamma} #left(#frac{R}{45 GV}#right)^{-#gamma} #[]{1 + #left(#frac{R}{R_{0}}#right)^{#frac{#Delta#gamma}{s}}}^{s}", "(m^{2} sr s GV)^{-1}", 0.4544, Models::AMS15GMS75, Models::GTF::AMS15GMS75, 6, {
            { "gamma",    "Spectral index",              "#gamma",       "",         2.8, 2.849,  2.9 },
            { "rigbreak", "Rigidity break",              "R_{0}",        "GV",      200.,   336, 500. },
            { "delta",    "Spetral index difference",    "#Delta#gamma", "",         0.1, 0.133,  0.2 },
            { "s",        "Transition smoothness",       "s",            "",        0.01, 0.024, 0.03 },
            { "N2",       "Second normalization factor", "N_{2}",        "GeV",       0.,  0.08,  10. },
            { "a",        "Energy scale",                "a",            "GeV^{-1}",  0.,  11.3, 100. },
         }
      },
      { "ams15wh03u05", "AMS-02 (2015) + Webber and Higbie (2003)", "N / (1 + N_{2} T^{-#gamma_{2}} + N_{3} T^{-#gamma_{3}}) #left(#frac{R}{45 GV}#right)^{-#gamma} #[]{1 + #left(#frac{R}{R_{0}}#right)^{#frac{#Delta#gamma}{s}}}^{s}", "(m^{2} sr s GV)^{-1}", 0.4544, Models::AMS15WH03U05, Models::GTF::AMS15WH03U05, 8, {
            { "gamma",    "Spectral index",              "#gamma",       "",                  2.8, 2.849,   2.9 },
            { "rigbreak", "Rigidity break",              "R_{0}",        "GV",               200.,   336,  500. },
            { "delta",    "Spetral index difference",    "#Delta#gamma", "",                  0.1, 0.133,   0.2 },
            { "s",        "Transition smoothness",       "s",            "",                 0.01, 0.024,  0.03 },
            { "N2",       "Second normalization factor", "N_{2}",        "GeV^{#gamma_{2}}",   0.,  0.02, 1000. },
            { "gamma2",   "Second spectral index",       "#gamma_{2}",   "",                   0.,  1.35,   10. },
            { "N3",       "Third normalization factor",  "N_{3}",        "GeV^{#gamma_{3}}",   0.,  7e-4, 1000. },
            { "gamma3",   "Third spectral index",        "#gamma_{3}",                 "",     0.,  1.35,   10. }
         }
      },
      { "ams15l04", "AMS-02 (2015) + Langner (2004)", "N (Galprop parametrization) #left(#frac{R}{45 GV}#right)^{-#gamma} #[]{1 + #left(#frac{R}{R_{0}}#right)^{#frac{#Delta#gamma}{s}}}^{s}", "(m^{2} sr s GV)^{-1}", 0.4544, Models::AMS15L04, Models::GTF::AMS15L04, 6, {
            { "gamma",    "Spectral index",              "#gamma",       "",     2.8, 2.849,   2.9 },
            { "rigbreak", "Rigidity break",              "R_{0}",        "GV",  200.,   336,  500. },
            { "delta",    "Spetral index difference",    "#Delta#gamma", "",     0.1, 0.133,   0.2 },
            { "s",        "Transition smoothness",       "s",            "",    0.01, 0.024,  0.03 },
            { "a",        "Energy scale",                "a",            "",    -10., 0.068,   10. },
            { "N2",       "Second normalization factor", "N_{2}",        "",      0.,   7.7, 1000. },
         }
      },
      { "threepowerlawrig", "Corti (2015)", "N R^{#gamma} #{}{1 + #[]{#frac{R}{R_{b1}} #(){1 + #(){#frac{R}{R_{b2}}}^{#frac{#Delta#gamma_{2}}{s_{2}}}}^{s_{2}}}^{#frac{#Delta#gamma_{1}}{s_{1}}}}^{s_{1}}", "(m^{2} sr s GV^{1+#gamma})^{-1}", 1., Models::ThreePowerLawRig, Models::GTF::ThreePowerLawRig, 12, {
            /// Voyager (0.78) + AMS02
            { "gb",        "Spectral index extrapolation",     "#gamma_{b}",       "",                         0.,     1.50694,     2.    },
            { "x0",        "First node position",              "x_{0}",            "GV",                       0.,     0.0919144,   0.1    },
            { "x1",        "Second node position",             "x_{1}",            "GV",                       0.7,    0.78,        0.8    },
            { "y0",        "First node value",                 "y_{0}",            "(m^{2} sr s GV)^{-1}",     1e3,     2000.67,        3e3    },
            { "y1",        "Second node value",                "y_{1}",            "(m^{2} sr s GV)^{-1}",     6e3,     7509.69,        8e3    },
            { "ge",        "Spectral index extrapolation",     "#gamma_{e}",       "",                        -3.,    -1.01768,   -0.1 },
            { "rigbreak1", "First rigidity break",             "R_{b1}",           "GV",                       0.5,    1.39043,    3. },
            { "delta1",    "First spectral index difference",  "#Delta#gamma_{1}", "",                        -4.,    -2.36948,      -1. },
            { "s1",        "First transition smoothness",      "s_{1}",            "",                       -20.,    -1.1762,    -0.01 },
            { "rigbreak2", "Second rigidity break",            "R_{b2}",           "GV",                      50.,   384.886,        800. },
            { "delta2",    "Second spectral index difference", "#Delta#gamma_{2}", "",                        -1.,    -0.0535226,        1. },
            { "s2",        "Second transition smoothness",     "s_{2}",            "",                        -1.,    -0.009,       -0.009 }
         }
      },
      { "corti16hffa", "Corti et al (2016), H, FFA", "N R^{#gamma} #{}{1 + #[]{#frac{R}{R_{b1}} #(){1 + #(){#frac{R}{R_{b2}}}^{#frac{#Delta#gamma_{2}}{s_{2}}}}^{s_{2}}}^{#frac{#Delta#gamma_{1}}{s_{1}}}}^{s_{1}}", "(m^{2} sr s GV^{1+#gamma})^{-1}", 11744, Models::Corti16, Models::GTF::Corti16, 10, {
            /// Voyager + AMS02 + ForceFieldApproximation (phi = 0.600116) - Proton
            { "mu",        "Effective cutoff",                 "#mu",          "",        -1.0,   -0.559354,  -0.2 },
            { "sigma",     "Penumbra width",                   "#sigma",       "",         0.1,    0.563003,   1.0 },
            { "rho",       "Asymmetry",                        "#rho",         "",         0.1,    0.431411,   1.0 },
            { "g1",        "First Spectral index",             "#gamma_{1}",       "",    -3.,    -2.44829,   -0.1 },
            { "rigbreak1", "First rigidity break",             "R_{b1}",           "GV",   0.5,    6.21544,   20. },
            { "delta1",    "First spectral index difference",  "#Delta#gamma_{1}", "",    -4.,    -0.42257,   -0.1 },
            { "s1",        "First transition smoothness",      "s_{1}",            "",   -20.,    -0.108436,   0.01 },
            { "rigbreak2", "Second rigidity break",            "R_{b2}",           "GV",  50.,   543.576,    800. },
            { "delta2",    "Second spectral index difference", "#Delta#gamma_{2}", "",    -1.,    -0.604922,   1. },
            { "s2",        "Second transition smoothness",     "s_{2}",            "",    -1.,    -0.395863,  -0.009 }
         }
      },
      { "corti16hdffk", "Corti et al (2016), H, DFFK", "N R^{#gamma} #{}{1 + #[]{#frac{R}{R_{b1}} #(){1 + #(){#frac{R}{R_{b2}}}^{#frac{#Delta#gamma_{2}}{s_{2}}}}^{s_{2}}}^{#frac{#Delta#gamma_{1}}{s_{1}}}}^{s_{1}}", "(m^{2} sr s GV^{1+#gamma})^{-1}", 13017.8, Models::Corti16, Models::GTF::Corti16, 10, {
            /// Voyager + AMS02 + DoubleForceField (phi1 = 0.588862; phi2 = 0.485356; R1 = 0.5; R2 = 5.5) - Proton
            { "mu",        "Effective cutoff",                 "#mu",          "",        -1.0,   -0.526029,   -0.2 },
            { "sigma",     "Penumbra width",                   "#sigma",       "",         0.1,    0.57897,     1.0 },
            { "rho",       "Asymmetry",                        "#rho",         "",         0.1,    0.405239,    1.0 },
            { "g1",        "First Spectral index",             "#gamma_{1}",       "",    -3.,    -2.5793,     -0.1 },
            { "rigbreak1", "First rigidity break",             "R_{b1}",           "GV",   0.5,    8.68846,    20. },
            { "delta1",    "First spectral index difference",  "#Delta#gamma_{1}", "",    -4.,    -0.273584,   -0.1 },
            { "s1",        "First transition smoothness",      "s_{1}",            "",   -20.,    -0.0680109,   0.01 },
            { "rigbreak2", "Second rigidity break",            "R_{b2}",           "GV",  50.,   411.187,     800. },
            { "delta2",    "Second spectral index difference", "#Delta#gamma_{2}", "",    -1.,    -0.654698,    1. },
            { "s2",        "Second transition smoothness",     "s_{2}",            "",    -1.,    -0.269408,   -0.009 }
         }
      },
      { "corti16hdffr", "Corti et al (2016), H, DFFR", "N R^{#gamma} #{}{1 + #[]{#frac{R}{R_{b1}} #(){1 + #(){#frac{R}{R_{b2}}}^{#frac{#Delta#gamma_{2}}{s_{2}}}}^{s_{2}}}^{#frac{#Delta#gamma_{1}}{s_{1}}}}^{s_{1}}", "(m^{2} sr s GV^{1+#gamma})^{-1}", 12186.3, Models::Corti16, Models::GTF::Corti16, 10, {
            /// Voyager + AMS02 + DoubleForceFieldRig (phi1 = 0.587442; phi2 = 0.480909; R1 = 0.5; R2 = 5.5) - Proton
            { "mu",        "Effective cutoff",                 "#mu",          "",        -1.0,   -0.533809,   -0.2 },
            { "sigma",     "Penumbra width",                   "#sigma",       "",         0.1,    0.563041,     1.0 },
            { "rho",       "Asymmetry",                        "#rho",         "",         0.1,    0.422133,    1.0 },
            { "g1",        "First Spectral index",             "#gamma_{1}",       "",    -3.,    -2.54621,     -0.1 },
            { "rigbreak1", "First rigidity break",             "R_{b1}",           "GV",   0.5,    8.43993,    20. },
            { "delta1",    "First spectral index difference",  "#Delta#gamma_{1}", "",    -4.,    -0.305102,   -0.1 },
            { "s1",        "First transition smoothness",      "s_{1}",            "",   -20.,    -0.0781336,   0.01 },
            { "rigbreak2", "Second rigidity break",            "R_{b2}",           "GV",  50.,   399.327,     800. },
            { "delta2",    "Second spectral index difference", "#Delta#gamma_{2}", "",    -1.,    -0.563572,    1. },
            { "s2",        "Second transition smoothness",     "s_{2}",            "",    -1.,    -0.215158,   -0.009 }
         }
      },
      { "corti16heffa", "Corti et al (2016), He, FFA", "N R^{#gamma} #{}{1 + #[]{#frac{R}{R_{b1}} #(){1 + #(){#frac{R}{R_{b2}}}^{#frac{#Delta#gamma_{2}}{s_{2}}}}^{s_{2}}}^{#frac{#Delta#gamma_{1}}{s_{1}}}}^{s_{1}}", "(m^{2} sr s GV^{1+#gamma})^{-1}", 11223, Models::Corti16, Models::GTF::Corti16, 10, {
            /// Voyager + AMS02 + ForceFieldApproximation (phi = 0.568184) - Helium
            { "mu",        "Effective cutoff",                 "#mu",          "",        -1.0,    0.196622,   1. },
            { "sigma",     "Penumbra width",                   "#sigma",       "",         0.1,    0.477471,   1.0 },
            { "rho",       "Asymmetry",                        "#rho",         "",         0.1,    0.559177,   1.0 },
            { "g1",        "First Spectral index",             "#gamma_{1}",       "",    -3.,    -1.90172,   -0.1 },
            { "rigbreak1", "First rigidity break",             "R_{b1}",           "GV",   0.5,    2.1372,  20. },
            { "delta1",    "First spectral index difference",  "#Delta#gamma_{1}", "",    -4.,    -1.19581,  -0.1 },
            { "s1",        "First transition smoothness",      "s_{1}",            "",   -20.,    -3.07524,    0.01 },
            { "rigbreak2", "Second rigidity break",            "R_{b2}",           "GV",  50.,   188.65,    800. },
            { "delta2",    "Second spectral index difference", "#Delta#gamma_{2}", "",    -3.,    -0.332545,    0. },
            { "s2",        "Second transition smoothness",     "s_{2}",            "",    -1.,    -0.231699,   -0.009 }
         }
      },
      { "corti16hedffk", "Corti et al (2016), He, DFFK", "N R^{#gamma} #{}{1 + #[]{#frac{R}{R_{b1}} #(){1 + #(){#frac{R}{R_{b2}}}^{#frac{#Delta#gamma_{2}}{s_{2}}}}^{s_{2}}}^{#frac{#Delta#gamma_{1}}{s_{1}}}}^{s_{1}}", "(m^{2} sr s GV^{1+#gamma})^{-1}", 12573.3, Models::Corti16, Models::GTF::Corti16, 10, {
            /// Voyager + AMS02 + DoubleForceField (phi1 = 0.569478; phi2 = 0.574578; R1 = 0.5; R2 = 5.5) - Helium
            { "mu",        "Effective cutoff",                 "#mu",          "",        -1.0,   0.196137,    1. },
            { "sigma",     "Penumbra width",                   "#sigma",       "",         0.1,    0.488416,    1.0 },
            { "rho",       "Asymmetry",                        "#rho",         "",         0.1,    0.537809,   1.0 },
            { "g1",        "First Spectral index",             "#gamma_{1}",       "",    -3.,    -1.94132,   -0.1 },
            { "rigbreak1", "First rigidity break",             "R_{b1}",           "GV",   0.2,    1.7901,   20. },
            { "delta1",    "First spectral index difference",  "#Delta#gamma_{1}", "",    -4.,    -1.1277,  -0.1 },
            { "s1",        "First transition smoothness",      "s_{1}",            "",   -20.,    -3.00324,    0.01 },
            { "rigbreak2", "Second rigidity break",            "R_{b2}",           "GV",  50.,   193.995,    800. },
            { "delta2",    "Second spectral index difference", "#Delta#gamma_{2}", "",    -3.,    -0.325468,   0. },
            { "s2",        "Second transition smoothness",     "s_{2}",            "",    -1.,    -0.212441,  -0.009 }
         }
      },
      { "corti16hedffr", "Corti et al (2016), He, DFFR", "N R^{#gamma} #{}{1 + #[]{#frac{R}{R_{b1}} #(){1 + #(){#frac{R}{R_{b2}}}^{#frac{#Delta#gamma_{2}}{s_{2}}}}^{s_{2}}}^{#frac{#Delta#gamma_{1}}{s_{1}}}}^{s_{1}}", "(m^{2} sr s GV^{1+#gamma})^{-1}", 11602.2, Models::Corti16, Models::GTF::Corti16, 10, {
            /// Voyager + AMS02 + DoubleForceFieldRig (phi1 = 0.567978; phi2 = 0.570216; R1 = 0.5; R2 = 5.5) - Helium
            { "mu",        "Effective cutoff",                 "#mu",          "",        -1.0,   0.196779,    1. },
            { "sigma",     "Penumbra width",                   "#sigma",       "",         0.1,    0.479339,    1.0 },
            { "rho",       "Asymmetry",                        "#rho",         "",         0.1,    0.555868,   1.0 },
            { "g1",        "First Spectral index",             "#gamma_{1}",       "",    -3.,    -1.90322,   -0.1 },
            { "rigbreak1", "First rigidity break",             "R_{b1}",           "GV",   0.2,    2.10893,   20. },
            { "delta1",    "First spectral index difference",  "#Delta#gamma_{1}", "",    -4.,    -1.19623,  -0.1 },
            { "s1",        "First transition smoothness",      "s_{1}",            "",   -20.,    -3.10228,    0.01 },
            { "rigbreak2", "Second rigidity break",            "R_{b2}",           "GV",  50.,   189.351,    800. },
            { "delta2",    "Second spectral index difference", "#Delta#gamma_{2}", "",    -3.,    -0.334258,   0. },
            { "s2",        "Second transition smoothness",     "s_{2}",            "",    -1.,    -0.234704,  -0.009 }
         }
      },
      { "vos15", "Vos (2015)", "N/#beta^{2}T^{#gamma_{1}} (#frac{T^{s}-T_{b}^{s}}{1+T_{b}^{s}})^{(#gamma_{2}-#gamma_{1})/s}", "(m^{2} sr s GeV)^{-1}", 2.7*1000., Models::Vos15, Models::GTF::Vos15, 4, {
            { "gamma1", "First spectral index",  "#gamma_{1}", "",   -1.,  1.12,  2. },
            { "gamma2", "Second spectral index", "#gamma_{2}", "",   -3., -2.81, -2. },
            { "s",      "Smoothness",            "s",          "",    0.,  1.,  3. },
            { "Tb",     "Energy break",          "T_{b}",      "GV",  0.,  0.67,  3. }
         }
      },
      { "bon14", "Badhwar - O'Neill (2014)", "N #beta(35)^{-1} (35 + 0.938)^{#gamma} #beta^{#delta} (Tn + 0.938)^{-#gamma}", "(m^{2} sr s GeV)^{-1}", 9.5e-1, Models::BON14, Models::GTF::BON14, 2, {
            /// Proton - norm = 9.5e-1
            { "gamma", "Spectral index", "#gamma", "", 0., 2.75, 10. },
            { "delta", "Beta index",     "#delta", "", 0., -2.82, 10. }
            /// Helium - norm = 4.53e-2
            //~ { "gamma", "Spectral index", "#gamma", "", 0., 2.80, 10. },
            //~ { "delta", "Beta index",     "#delta", "", 0., -2.00, 10. }
         }
      },
      { "ghelfi16h", "Ghelfi et al (2016), H", "Spline parametrization", "(m^{2} sr s GeV)^{-1}", 1., Models::Ghelfi16, Models::GTF::Ghelfi16, 17, {
            { "c0",  "c0",  "c0",  "", 0.,  +3.606565e+00, 0. },
            { "c1",  "c1",  "c1",  "", 0.,  -5.082805e+00, 0. },
            { "c2",  "c2",  "c2",  "", 0.,  -3.042630e+00, 0. },
            { "c3",  "c3",  "c3",  "", 0.,  -2.501190e+00, 0. },
            { "c4",  "c4",  "c4",  "", 0.,  +1.827880e+00, 0. },
            { "c5",  "c5",  "c5",  "", 0.,  +1.398976e+00, 0. },
            { "c6",  "c6",  "c6",  "", 0.,  -7.028454e-01, 0. },
            { "c7",  "c7",  "c7",  "", 0.,  +1.997827e+01, 0. },
            { "c8",  "c8",  "c8",  "", 0.,  +2.885280e+00, 0. },
            { "c9",  "c9",  "c9",  "", 0.,  -7.560171e+01, 0. },
            { "c10", "c10", "c10", "", 0.,  +3.405332e+00, 0. },
            { "c11", "c11", "c11", "", 0.,  +1.168359e+02, 0. },
            { "c12", "c12", "c12", "", 0.,  -3.274338e+01, 0. },
            { "c13", "c13", "c13", "", 0.,  -6.947553e+01, 0. },
            { "c14", "c14", "c14", "", 0.,  +3.535965e+01, 0. },
            { "norm2", "Second normalization", "N_{2}", "", 0.,  -3.850699e+00,  0. },
            { "gamma", "Spectral index", "#gamma", "", 0.,  2.703917,  0. }
         }
      },
      { "ghelfi16he", "Ghelfi et al (2016), He", "Spline parametrization", "(m^{2} sr s GeV/n)^{-1}", 1., Models::Ghelfi16, Models::GTF::Ghelfi16, 17, {
            { "c0",  "c0",  "c0",  "", 0.,  +2.376233e+00, 0. },
            { "c1",  "c1",  "c1",  "", 0.,  -5.306384e+00, 0. },
            { "c2",  "c2",  "c2",  "", 0.,  -3.119940e+00, 0. },
            { "c3",  "c3",  "c3",  "", 0.,  -2.281441e+00, 0. },
            { "c4",  "c4",  "c4",  "", 0.,  +4.055121e+00, 0. },
            { "c5",  "c5",  "c5",  "", 0.,  +7.473942e+00, 0. },
            { "c6",  "c6",  "c6",  "", 0.,  -8.053260e+00, 0. },
            { "c7",  "c7",  "c7",  "", 0.,  -1.916564e+01, 0. },
            { "c8",  "c8",  "c8",  "", 0.,  +1.766888e+01, 0. },
            { "c9",  "c9",  "c9",  "", 0.,  +3.293412e+01, 0. },
            { "c10", "c10", "c10", "", 0.,  -2.955671e+01, 0. },
            { "c11", "c11", "c11", "", 0.,  -3.064750e+01, 0. },
            { "c12", "c12", "c12", "", 0.,  +2.792617e+01, 0. },
            { "c13", "c13", "c13", "", 0.,  +1.090915e+01, 0. },
            { "c14", "c14", "c14", "", 0.,  -1.019233e+01, 0. },
            { "norm2", "Second normalization", "N_{2}", "", 0.,  -4.978057e+00,  0. },
            { "gamma", "Spectral index", "#gamma", "", 0.,   2.713877,  0. }
         }
      },
      { "ghelfi16hv1", "Ghelfi et al (2016), H, Voyager1", "Spline parametrization", "(m^{2} sr s GeV)^{-1}", 1., Models::Ghelfi16, Models::GTF::Ghelfi16, 17, {
            { "c0",  "c0",  "c0",  "", 0.,  +3.461750e+00, 0. },
            { "c1",  "c1",  "c1",  "", 0.,  -4.131050e+00, 0. },
            { "c2",  "c2",  "c2",  "", 0.,  -4.640890e+00, 0. },
            { "c3",  "c3",  "c3",  "", 0.,  -1.407410e+00, 0. },
            { "c4",  "c4",  "c4",  "", 0.,  -4.750880e+00, 0. },
            { "c5",  "c5",  "c5",  "", 0.,  +8.519700e+00, 0. },
            { "c6",  "c6",  "c6",  "", 0.,  +3.262630e+01, 0. },
            { "c7",  "c7",  "c7",  "", 0.,  -2.842170e+01, 0. },
            { "c8",  "c8",  "c8",  "", 0.,  -5.817510e+01, 0. },
            { "c9",  "c9",  "c9",  "", 0.,  +4.818490e+01, 0. },
            { "c10", "c10", "c10", "", 0.,  +3.390470e+01, 0. },
            { "c11", "c11", "c11", "", 0.,  -2.961540e+01, 0. },
            { "c12", "c12", "c12", "", 0.,  +5.891620e-01, 0. },
            { "c13", "c13", "c13", "", 0.,  -1.720810e-03, 0. },
            { "c14", "c14", "c14", "", 0.,  +4.974770e-04, 0. },
            { "norm2", "Second normalization", "N_{2}", "", 0., -3.857080e+00,  0. },
            { "gamma", "Spectral index", "#gamma", "", 0.,  2.69947,  0. }
         }
      },
      { "ghelfi16hev1", "Ghelfi et al (2016), He, Voyager1", "Spline parametrization", "(m^{2} sr s GeV/n)^{-1}", 1., Models::Ghelfi16, Models::GTF::Ghelfi16, 17, {
            { "c0",  "c0",  "c0",  "", 0.,  +2.278366e+00, 0. },
            { "c1",  "c1",  "c1",  "", 0.,  -4.572648e+00, 0. },
            { "c2",  "c2",  "c2",  "", 0.,  -4.865560e+00, 0. },
            { "c3",  "c3",  "c3",  "", 0.,  +3.945156e-01, 0. },
            { "c4",  "c4",  "c4",  "", 0.,  -1.154262e+00, 0. },
            { "c5",  "c5",  "c5",  "", 0.,  +4.998593e+00, 0. },
            { "c6",  "c6",  "c6",  "", 0.,  +1.649534e+01, 0. },
            { "c7",  "c7",  "c7",  "", 0.,  -2.055111e+01, 0. },
            { "c8",  "c8",  "c8",  "", 0.,  -2.832667e+01, 0. },
            { "c9",  "c9",  "c9",  "", 0.,  +3.189124e+01, 0. },
            { "c10", "c10", "c10", "", 0.,  +1.494921e+01, 0. },
            { "c11", "c11", "c11", "", 0.,  -1.710165e+01, 0. },
            { "c12", "c12", "c12", "", 0.,  +5.813712e-01, 0. },
            { "c13", "c13", "c13", "", 0.,  -3.000221e-03, 0. },
            { "c14", "c14", "c14", "", 0.,  +1.245293e-03, 0. },
            { "norm2", "Second normalization", "N_{2}", "", 0., -4.984982e+00,  0. },
            { "gamma", "Spectral index", "#gamma", "", 0.,   2.709368,  0. }
         }
      },
      { "bisschoff16h", "Bisschoff & Potgieter (2016), H", "N/#beta^{2} T^{#gamma_{1}} (#frac{Tn^{s}-Tn_{b}^{s}}{1+Tn_{b}^{s}})^{(#gamma_{2}-#gamma_{1})/s}", "(m^{2} sr s GeV/n)^{-1}", 3719., Models::Bisschoff16, Models::GTF::Bisschoff16, 4, {
            { "gamma1", "First spectral index",  "#gamma_{1}", "",   -1.,  1.03,  2. },
            { "gamma2", "Second spectral index", "#gamma_{2}", "",   -3., -2.8178, -2. },
            { "s",      "Smoothness",            "s",          "",    0.,  1.21,  3. },
            { "Tb",     "Energy break",          "T_{b}",      "GV",  0.,  0.77,  3. }
         }
      },
      { "bisschoff16he", "Bisschoff & Potgieter (2016), He", "N/#beta^{2} T^{#gamma_{1}} (#frac{Tn^{s}-Tn_{b}^{s}}{1+Tn_{b}^{s}})^{(#gamma_{2}-#gamma_{1})/s}", "(m^{2} sr s GeV/n)^{-1}", 195.4, Models::Bisschoff16, Models::GTF::Bisschoff16, 4, {
            { "gamma1", "First spectral index",  "#gamma_{1}", "",   -1.,  1.02,  2. },
            { "gamma2", "Second spectral index", "#gamma_{2}", "",   -3., -2.7285, -2. },
            { "s",      "Smoothness",            "s",          "",    0.,  1.19,  3. },
            { "Tb",     "Energy break",          "T_{b}",      "GV",  0.,  0.60,  3. }
         }
      },
      { "herbst17", "Herbst et al (2016)", "Galprop parametrization", "(m^{2} sr s GeV)^{-1}", 0.685*TMath::Exp(3.22)*1000., Models::Herbst17, Models::GTF::Herbst17, 3, {
            { "a",     "Energy scale",                "a",      "", -10., 0.036,                    10. },
            { "N2",    "Second normalization factor", "N_{2}",  "",   0., 0.707/0.685*TMath::Exp(4.64 - 3.22), 1000. },
            { "gamma", "Spectral index",              "#gamma", "",   0., 2.78,                    10. }
         }
      },
      { "smoothplrig3", "Corti (2018)", "N R^{#gamma_{0}} #prod_{i=1}^{2}#[]{1+#(){#frac{R}{R_{i}}}^{s_{i}}}^{#Delta_{i}/s_{i}}", "(m^{2} sr s GV)^{-1}", 365323, Models::SmoothPLRig3, Models::GTF::SmoothPLRig3, 7, {
            { "gamma0",    "First spectral index",              "#gamma_{0}", "",     0.,    2.03964,    3. },
            { "rigbreak1", "First rigidity break",              "R_{1}",      "GV",   0.,    0.63413,   5. },
            { "s1",        "First transition smoothness",       "s_{1}",      "",     0.,    1.23219,   10. },
            { "delta1",    "First spectral index difference",   "#Delta_{1}", "",    -6.,   -5.07878,    0. },
            { "rigbreak2", "Second rigidity break",             "R_{2}",      "GV", 100.,    800., 2e3 },
            { "s2",        "Second transition smoothness",      "s_{2}",      "",     0.,    0.458723,   10.},
            { "delta2",    "Second spectral index difference",  "#Delta_{2}", "",    -3.,    0.624393,   3. },
         }
      },
      { "corti18hffa", "Corti et al (2018), H, FFA", "N R^{#gamma_{0}} #prod_{i=1}^{3}#[]{1+#(){#frac{R}{R_{i}}}^{s_{i}}}^{#Delta_{i}/s_{i}}", "(m^{2} sr s GV)^{-1}", 5655.2, Models::SmoothPLRig4, Models::GTF::SmoothPLRig4, 10, {
            /// Voyager + AMS02 + ForceFieldApproximation (phi = 0.599606) - Proton
            { "gamma0",    "First spectral index",              "#gamma_{0}", "",     0.,    1.66594,    3. },
            { "rigbreak1", "First rigidity break",              "R_{1}",      "GV",   0.,    0.571181,   5. },
            { "s1",        "First transition smoothness",       "s_{1}",      "",     0.,    1.78222,   10. },
            { "delta1",    "First spectral index difference",   "#Delta_{1}", "",    -6.,   -4.11009,    0. },
            { "rigbreak2", "Second rigidity break",             "R_{2}",      "GV",   1.,    6.20194,   50. },
            { "s2",        "Second transition smoothness",      "s_{2}",      "",     0.,    3.87385,   10. },
            { "delta2",    "Second spectral index difference",  "#Delta_{2}", "",    -3.,   -0.426484,   3. },
            { "rigbreak3", "Third rigidity break",              "R_{3}",      "GV", 100.,  539.745, 800. },
            { "s3",        "Third transition smoothness",       "s_{3}",      "",     0.,    1.53752,   10.},
            { "delta3",    "Third spectral index difference",   "#Delta_{3}", "",    -3.,    0.253964,   3. },
         }
      },
      { "corti18hdffr", "Corti et al (2018), H, DFFR", "N R^{#gamma_{0}} #prod_{i=1}^{3}#[]{1+#(){#frac{R}{R_{i}}}^{s_{i}}}^{#Delta_{i}/s_{i}}", "(m^{2} sr s GV)^{-1}", 5609.35, Models::SmoothPLRig4, Models::GTF::SmoothPLRig4, 10, {
            /// Voyager + AMS02 + DoubleForceFieldRig (phi1 = 0.587356, phi2 = 0.48043, R1 = 0.5, R2 = 5.5) - Proton
            { "gamma0",    "First spectral index",              "#gamma_{0}", "",     0.,    1.66072,    3. },
            { "rigbreak1", "First rigidity break",              "R_{1}",      "GV",   0.,    0.586428,   5. },
            { "s1",        "First transition smoothness",       "s_{1}",      "",     0.,    1.77672,   10. },
            { "delta1",    "First spectral index difference",   "#Delta_{1}", "",    -6.,   -4.20692,    0. },
            { "rigbreak2", "Second rigidity break",             "R_{2}",      "GV",   1.,    8.44944,   50. },
            { "s2",        "Second transition smoothness",      "s_{2}",      "",     0.,    3.90558,   10. },
            { "delta2",    "Second spectral index difference",  "#Delta_{2}", "",    -3.,   -0.305036,   3. },
            { "rigbreak3", "Third rigidity break",              "R_{3}",      "GV", 100.,  399.125, 800. },
            { "s3",        "Third transition smoothness",       "s_{3}",      "",     0.,    2.62534,   10.},
            { "delta3",    "Third spectral index difference",   "#Delta_{3}", "",    -3.,    0.171756,   3. },
         }
      },
      { "corti18he3ffa", "Corti et al (2018), He3, FFA", "N R^{#gamma_{0}} #prod_{i=1}^{3}#[]{1+#(){#frac{R}{R_{i}}}^{s_{i}}}^{#Delta_{i}/s_{i}}", "(m^{2} sr s GV)^{-1}", 15.94, Models::SmoothPLRig4, Models::GTF::SmoothPLRig4, 10, {
            /// ForceFieldApproximation (phi = 0.568276) - Helium 3
            { "gamma0",    "First spectral index",              "#gamma_{0}", "",     0.,    2.9998,   6. },
            { "rigbreak1", "First rigidity break",              "R_{1}",      "GV",   0.,    1.5146,   5. },
            { "s1",        "First transition smoothness",       "s_{1}",      "",     0.,    6.4266,   10. },
            { "delta1",    "First spectral index difference",   "#Delta_{1}", "",    -10.,   -5.0217,    0. },
            { "rigbreak2", "Second rigidity break",             "R_{2}",      "GV",   5.,    6.1718,   50. },
            { "s2",        "Second transition smoothness",      "s_{2}",      "",     0.,    2.5864,   10. },
            { "delta2",    "Second spectral index difference",  "#Delta_{2}", "",    -3.,   -1.2084,   3. },
            { "rigbreak3", "Third rigidity break",              "R_{3}",      "GV", 100.,  800., 800. },
            { "s3",        "Third transition smoothness",       "s_{3}",      "",     0.,    0.56426,   10.},
            { "delta3",    "Third spectral index difference",   "#Delta_{3}", "",    -3.,    0.56151,   3. },
         }
      },
      { "corti18he3dffr", "Corti et al (2018), He3, DFFR", "N R^{#gamma_{0}} #prod_{i=1}^{3}#[]{1+#(){#frac{R}{R_{i}}}^{s_{i}}}^{#Delta_{i}/s_{i}}", "(m^{2} sr s GV)^{-1}", 9.57515, Models::SmoothPLRig4, Models::GTF::SmoothPLRig4, 10, {
            /// DoubleForceFieldRig (phi1 = 0.568116, phi2 = 0.569736, R1 = 0.5, R2 = 5.5) - Helium 3
            { "gamma0",    "First spectral index",              "#gamma_{0}", "",     0.,    4.58975,    6. },
            { "rigbreak1", "First rigidity break",              "R_{1}",      "GV",   0.,    1.45949,   5. },
            { "s1",        "First transition smoothness",       "s_{1}",      "",     0.,    8.2897,   10. },
            { "delta1",    "First spectral index difference",   "#Delta_{1}", "",    -10.,   -6.20004,    0. },
            { "rigbreak2", "Second rigidity break",             "R_{2}",      "GV",   5.,    5.00002,   50. },
            { "s2",        "Second transition smoothness",      "s_{2}",      "",     0.,    1.76165,   10. },
            { "delta2",    "Second spectral index difference",  "#Delta_{2}", "",    -3.,   -1.51309,   3. },
            { "rigbreak3", "Third rigidity break",              "R_{3}",      "GV", 100.,  624.041, 800. },
            { "s3",        "Third transition smoothness",       "s_{3}",      "",     0.,    1.117,   10.},
            { "delta3",    "Third spectral index difference",   "#Delta_{3}", "",    -3.,    0.340474,   3. },
         }
      },
      { "corti18he4ffa", "Corti et al (2018), He4, FFA", "N R^{#gamma_{0}} #prod_{i=1}^{3}#[]{1+#(){#frac{R}{R_{i}}}^{s_{i}}}^{#Delta_{i}/s_{i}}", "(m^{2} sr s GV)^{-1}", 387.41, Models::SmoothPLRig4, Models::GTF::SmoothPLRig4, 10, {
            /// ForceFieldApproximation (phi = 0.568276) - Helium 4
            { "gamma0",    "First spectral index",              "#gamma_{0}", "",     0.,    2.2679,    6. },
            { "rigbreak1", "First rigidity break",              "R_{1}",      "GV",   0.,    1.1791,   5. },
            { "s1",        "First transition smoothness",       "s_{1}",      "",     0.,    1.2644,   10. },
            { "delta1",    "First spectral index difference",   "#Delta_{1}", "",    -10.,   -5.7923,    0. },
            { "rigbreak2", "Second rigidity break",             "R_{2}",      "GV",   5.,    6.1718,   50. },
            { "s2",        "Second transition smoothness",      "s_{2}",      "",     0.,    2.5864,   10. },
            { "delta2",    "Second spectral index difference",  "#Delta_{2}", "",    -3.,   0.62739,   3. },
            { "rigbreak3", "Third rigidity break",              "R_{3}",      "GV", 100.,       200., 800. },
            { "s3",        "Third transition smoothness",       "s_{3}",      "",     0.,    0.56426,   10.},
            { "delta3",    "Third spectral index difference",   "#Delta_{3}", "",    -3.,    0.56151,   3. },
         }
      },
      { "corti18he4dffr", "Corti et al (2018), He4, DFFR", "N R^{#gamma_{0}} #prod_{i=1}^{3}#[]{1+#(){#frac{R}{R_{i}}}^{s_{i}}}^{#Delta_{i}/s_{i}}", "(m^{2} sr s GV)^{-1}", 390.246, Models::SmoothPLRig4, Models::GTF::SmoothPLRig4, 10, {
            /// DoubleForceFieldRig (phi1 = 0.568116, phi2 = 0.569736, R1 = 0.5, R2 = 5.5) - Helium 4
            { "gamma0",    "First spectral index",              "#gamma_{0}", "",     0.,    2.25327,    6. },
            { "rigbreak1", "First rigidity break",              "R_{1}",      "GV",   0.,    1.14443,   5. },
            { "s1",        "First transition smoothness",       "s_{1}",      "",     0.,    1.32652,   10. },
            { "delta1",    "First spectral index difference",   "#Delta_{1}", "",    -10.,   -5.77971,    0. },
            { "rigbreak2", "Second rigidity break",             "R_{2}",      "GV",   5.,    5.00002,   50. },
            { "s2",        "Second transition smoothness",      "s_{2}",      "",     0.,    1.76165,   10. },
            { "delta2",    "Second spectral index difference",  "#Delta_{2}", "",    -3.,   0.736409,   3. },
            { "rigbreak3", "Third rigidity break",              "R_{3}",      "GV", 100.,  624.041, 800. },
            { "s3",        "Third transition smoothness",       "s_{3}",      "",     0.,    1.117,   10.},
            { "delta3",    "Third spectral index difference",   "#Delta_{3}", "",    -3.,    0.340474,   3. },
         }
      },
      { "smoothplrig4log", "Corti et al (2018)", "N R^{#gamma_{0}} #prod_{i=1}^{3}#[]{1+#(){#frac{R}{R_{i}}}^{s_{i}}}^{#Delta_{i}/s_{i}}", "(m^{2} sr s GV)^{-1}", 378., Models::SmoothPLRig4Log, Models::GTF::SmoothPLRig4Log, 10, {
            /// ForceFieldApproximation (phi = 0.568276) - Helium 4
            { "gamma0",    "Spectral index",                    "#gamma_{0}", "",     0.,    2.1,    6. },
            { "rigbreak1", "First rigidity break",              "R_{1}",      "GV",  -2.,    0.04,   0.5 },
            { "s1",        "First transition smoothness",       "s_{1}",      "",    -3.,    0.16,   2. },
            //~ { "gamma1",    "First spectral index",              "#gamma_{1}", "",    -5.,   -0.6,    1. },
            { "Delta1",    "First spectral index difference",   "#Delta_{1}", "",    -10.,   -5.2,    1. },
            { "rigbreak2", "Second rigidity break",             "R_{2}",      "GV",   0.5,    0.75,   1.7 },
            { "s2",        "Second transition smoothness",      "s_{2}",      "",    -3.,    0.48,   2. },
            //~ { "gamma2",    "Second spectral index",             "#gamma_{2}", "",    -5.,   -2.8,   0. },
            { "Delta2",    "Second spectral index difference",  "#Delta_{2}", "",    -3.,   0.22,   3. },
            { "rigbreak3", "Third rigidity break",              "R_{3}",      "GV", 100.,  200., 800. },
            { "s3",        "Third transition smoothness",       "s_{3}",      "",    -3.,    -0.1,   2.},
            //~ { "gamma3",    "Third spectral index",              "#gamma_{3}", "",    -4.,    -2.7,   0. },
            { "Delta3",    "Third spectral index difference",   "#Delta_{3}", "",    -3.,    0.43,   3. },
         }
      },
      { "galprop55bmp", "Galprop 55 BMP (Kunz, 2015)", "Interpolated Galprop output", "(m^{2} sr s GeV/n)^{-1}", 1., Models::GalpropKinNuc, Models::GTF::GalpropKinNuc, 2, {
            { "galprop", "Galprop Model index", "galprop", "", 0., 0., 3. },
            { "model", "Model index", "model", "", 0., 0., 30. }
         }
      },
      { "cholis16", "Cholis et al (2016)", "Interpolated Galprop output", "(m^{2} sr s GeV/n)^{-1}", 1., Models::GalpropKinNuc, Models::GTF::GalpropKinNuc, 2, {
            { "galprop", "Galprop Model index", "galprop", "", 0., 1., 3. },
            { "model", "Model index", "model", "", 0., 0., 0. }
         }
      },
      { "bisschoff17", "Bisschoof (2017)", "Interpolated Galprop output", "(m^{2} sr s GeV/n)^{-1}", 1., Models::GalpropKinNuc, Models::GTF::GalpropKinNuc, 2, {
            { "galprop", "Galprop Model index", "galprop", "", 0., 2., 3. },
            { "model", "Model index", "model", "", 0., 0., 0. },
         }
      }
   };
#pragma GCC diagnostic warning "-Wwrite-strings"
#else
   ModelInfo Info[nTypes];
#endif

   Double_t FittingModel(Double_t *x, Double_t *par);
   Double_t FittingGTF(Double_t *x, Double_t *par);

   // TF1 parameters = lismodel, energy, particle, norm, LIS parameters
   TF1 *CreateFunction(const Char_t *name, Double_t min_ene, Double_t max_ene, LISModels::Type lismodel, Particle::Type particle, Energy::Type energy, Bool_t fixlis = true);
   TF1 *CreateGTFFunction(const Char_t *name, Double_t min_ene, Double_t max_ene, LISModels::Type lismodel, Particle::Type particle, Energy::Type energy, Bool_t fixlis = true);

   const ParameterInfo *GetSpectralIndexParInfo(LISModels::Type lismodel);
   const ParameterInfo *GetGalpropSpectralIndexParInfo(LISModels::Type lismodel, UShort_t imodel);

   void LoadGalpropModels(LISModels::Models::Galprop::Type galprop, Particle::Type particle);
   TF1 *CreateGalpropModel(const Char_t *name, Double_t min_ene, Double_t max_ene, LISModels::Models::Galprop::Type galprop, UShort_t imodel, Particle::Type particle, Energy::Type energy, Bool_t fixlis = true);
   TGraph *GetGalpropModelGraph(LISModels::Models::Galprop::Type galprop, UShort_t imodel, Particle::Type particle);

   class Model
   {
      public:
         Model(const Char_t *name, Double_t min_ene, Double_t max_ene, LISModels::Type lismodel, Particle::Type particle, Energy::Type energy, Bool_t fixlis);

         Double_t operator()(Double_t *x, Double_t *par);

         TF1 *GetTF1Pointer() { return _func; }

         static TF1 *CreateFunction(const Char_t *name, Double_t min_ene, Double_t max_ene, LISModels::Type lismodel, Particle::Type particle, Energy::Type energy, Bool_t fixlis = true);

      private:
         TF1 *_func; //!

         LISModels::Type _lismodel;
         Energy::Type    _energy;
         Particle::Type  _particle;
   };
}

#endif
