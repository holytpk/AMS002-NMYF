#ifndef _DEBUG_H_
#define _DEBUG_H_

#include "headers.hh"

class Debug
{
   private:
      static ULong64_t _debug;
      static TStopwatch _watch;

   public:
      enum DebugFlag
      {
         NO          = 0,
         FUNCTION    = 1 << 0,
         POINTER     = 1 << 1,
         VARIABLE    = 1 << 2,
         STRING      = 1 << 3,
         HIST        = 1 << 4,
         BIT         = 1 << 5,
         INFO        = 1 << 6,
         PROFILETIME = 1 << 7,
         ALL         = FUNCTION | POINTER | VARIABLE | STRING | HIST | BIT | INFO | PROFILETIME
      };

      static Bool_t Enabled(DebugFlag flag);
      static void Enable(DebugFlag flag);
      static void Disable(DebugFlag flag);
      static ULong64_t Get();
      static void Set(ULong64_t debug);

      static void StartWatch();
      static void StopWatch();
      static Double_t CPUTime();
      static Double_t RealTime();

      static void PrintError(const Char_t *class_name, const Char_t *func_name, const Char_t *format, ...);

      static void dump_var(const Char_t *name, time_t value);
      static void dump_var(const Char_t *name, tm &tms);
      static void dump_var(const Char_t *name, Long64_t value);
      static void dump_var(const Char_t *name, ULong64_t value);
      static void dump_var(const Char_t *name, Int_t value);
      static void dump_var(const Char_t *name, UInt_t value);
      template <typename T>
      static void dump_var(const Char_t *name, const std::vector<T> &array, ULong64_t size)
      {
         for (ULong64_t i = 0; i < size; ++i)
         {
            std::cout << " ??? " << name << "[" << i << "] = " << array[i] << std::endl << std::flush;
         }
      }
      template <typename T>
      static void dump_var(const Char_t *name, const std::vector<T> &array)
      {
         dump_var(name, array, array.size());
      }
      template <typename T1, typename T2>
      static void dump_var(const Char_t *name, const std::vector< std::pair<T1,T2> > &array, ULong64_t size)
      {
         for (ULong64_t i = 0; i < size; ++i)
         {
            std::cout << " ??? " << name << "[" << i << "] = {" << array[i].first << ", " << array[i].second << "} " << std::endl << std::flush;
         }
      }
      template <typename T1, typename T2>
      static void dump_var(const Char_t *name, const std::vector< std::pair<T1,T2> > &array)
      {
         dump_var(name, array, array.size());
      }
      template <typename T1, typename T2>
      static void dump_var(const Char_t *name, const std::map<T1,T2> &Map)
      {
         for (typename std::map<T1,T2>::const_iterator it = Map.begin(); it != Map.end(); ++it)
         {
            std::cout << " ??? " << name << "[" << it->first << "] = " << it->second << std::endl;
         }
      }
      template <typename T1, typename T2, typename T3>
      static void dump_var(const Char_t *name, const std::map<T1, std::pair<T2,T3> > &Map)
      {
         for (typename std::map<T1, std::pair<T2, T3> >::const_iterator it = Map.begin(); it != Map.end(); ++it)
         {
            std::cout << " ??? " << name << "[" << it->first << "] = { " << it->second.first << ", " << it->second.second << " }" << std::endl;
         }
      }
      static void dump_var(const Char_t *name, const time_t *array, ULong64_t size);
      static void dump_var(const Char_t *name, const Long64_t *array, ULong64_t size);
      static void dump_var(const Char_t *name, const ULong64_t *array, ULong64_t size);
      static void dump_var(const Char_t *name, const Int_t *array, ULong64_t size);
      static void dump_var(const Char_t *name, const UInt_t *array, ULong64_t size);
      static void dump_var(const Char_t *name, const UShort_t *array, ULong64_t size);
      template <typename T, std::size_t R, std::size_t C>
      static void dump_var(const Char_t *name, const T (&array)[R][C])
      {
         for (ULong64_t i = 0; i < R; ++i)
         {
            for (ULong64_t j = 0; j < C; ++j)
            {
               std::cout << " ??? " << name << "[" << i << "][" << j << "] = " << array[i][j] << std::endl << std::flush;
            }
         }
      }
      template <typename T, std::size_t N>
      static void dump_var(const Char_t *name, const T (&array)[N])
      {
         for (ULong64_t i = 0; i < N; ++i)
         {
            std::cout << " ??? " << name << "[" << i << "] = " << array[i] << std::endl << std::flush;
         }
      }
      static void dump_var(const Char_t *name, const Long64_t **array, ULong64_t size1, ULong64_t size2);
      static void dump_var(const Char_t *name, const ULong64_t **array, ULong64_t size1, ULong64_t size2);
      static void dump_var(const Char_t *name, const Int_t **array, ULong64_t size1, ULong64_t size2);
      static void dump_var(const Char_t *name, const UInt_t **array, ULong64_t size1, ULong64_t size2);
      static void dump_var(const Char_t *name, Double_t value);
      static void dump_var(const Char_t *name, const Double_t *array, ULong64_t size);
      static void dump_var(const Char_t *name, const Float_t *array, ULong64_t size);
      static void dump_var(const Char_t *name, const Double_t **array, ULong64_t size1, ULong64_t size2);
      static void dump_var(const Char_t *name, const Float_t **array, ULong64_t size1, ULong64_t size2);
      static void dump_var(const Char_t *name, Char_t *value);
      static void dump_var(const Char_t *name, const Char_t **array, ULong64_t size);
      static void dump_var(const Char_t *name, const Char_t ***array, ULong64_t size1, ULong64_t size2);
      static void dump_var(const Char_t *name, std::string value);
      static void dump_var(const Char_t *name, const std::string *array, ULong64_t size);
      static void dump_var(const Char_t *name, const std::string **array, ULong64_t size1, ULong64_t size2);
};

#define FG_BLACK "\033[30m"
#define FG_RED "\033[31m"
#define FG_GREEN "\033[32m"
#define FG_YELLOW "\033[33m"
#define FG_BLUE "\033[34m"
#define FG_MAGENTA "\033[35m"
#define FG_CYAN "\033[36m"
#define FG_WHITE "\033[37m"
#define FG_BLACK_B "\033[1;30m"
#define FG_RED_B "\033[1;31m"
#define FG_GREEN_B "\033[1;32m"
#define FG_YELLOW_B "\033[1;33m"
#define FG_BLUE_B "\033[1;34m"
#define FG_MAGENTA_B "\033[1;35m"
#define FG_CYAN_B "\033[1;36m"
#define FG_WHITE_B "\033[1;37m"
#define RESET "\033[0m"

#define PRINT_POINTER_NAME(p) \
   if (Debug::Enabled(Debug::POINTER)) { std::cout << FG_MAGENTA_B; printf(" ??? %-40s = %p    %-75s %s\n", #p, p, p != NULL ? p->GetName() : "", p != NULL ? p->GetTitle() : ""); std::cout << RESET << std::flush; }

#define PRINT_POINTER_NAME_ARRAY(p,n) \
   if (Debug::Enabled(Debug::POINTER)) { std::cout << FG_MAGENTA_B; for (ULong64_t i = 0; i < n; ++i) { printf(" ??? %s[%llu] = %p \t %s \t %s\n", #p, i, p[i], p[i] != NULL ? p[i]->GetName() : "", p[i] != NULL ? p[i]->GetTitle() : ""); fflush(stdout); } std::cout << RESET << std::flush; }

#define PRINT_POINTER_NAME_ARRAY2(p,n,m) \
   if (Debug::Enabled(Debug::POINTER)) { std::cout << FG_MAGENTA_B; for (ULong64_t i = 0; i < n; ++i) { for (ULong64_t j = 0; j < m; ++j) { printf(" ??? %s[%llu][%llu] = %p \t %s \t %s\n", #p, i, j, p[i][j], p[i][j] != NULL ? p[i][j]->GetName() : "", p[i][j] != NULL ? p[i][j]->GetTitle() : ""); fflush(stdout); } } std::cout << RESET << std::flush; }

#define PRINT_POINTER(p) \
   if (Debug::Enabled(Debug::POINTER)) { std::cout << FG_MAGENTA_B; printf(" ??? %s = %p\n", #p, p); std::cout << RESET << std::flush; }

#define PRINT_POINTER_ARRAY(p,n) \
   if (Debug::Enabled(Debug::POINTER)) { std::cout << FG_MAGENTA_B; for (ULong64_t i = 0; i < n; ++i) { printf(" ??? %s[%llu] = %p\n", #p, i, p[i]); fflush(stdout); } std::cout << RESET << std::flush; }

#define PRINT_POINTER_ARRAY2(p,n,m) \
   if (Debug::Enabled(Debug::POINTER)) { std::cout << FG_MAGENTA_B; for (ULong64_t i = 0; i < n; ++i) { for (ULong64_t j = 0; j < m; ++j) { printf(" ??? %s[%llu][%llu] = %p\n", #p, i, j, p[i][j]); fflush(stdout); } } std::cout << RESET << std::flush; }

#define PRINT_VARIABLE(v) \
   if (Debug::Enabled(Debug::VARIABLE)) { std::cout << FG_MAGENTA_B; Debug::dump_var(#v, v); std::cout << RESET << std::flush; }

#define PRINT_VARIABLE_ARRAY(v,n) \
   if (Debug::Enabled(Debug::VARIABLE)) { std::cout << FG_MAGENTA_B; Debug::dump_var(#v, v, n); std::cout << RESET << std::flush; }

#define PRINT_VARIABLE_ARRAY2(v,n,m) \
   if (Debug::Enabled(Debug::VARIABLE)) { std::cout << FG_MAGENTA_B; Debug::dump_var(#v, v, n, m); std::cout << RESET << std::flush; }

#define PRINT_STRING(v) \
   if (Debug::Enabled(Debug::STRING)) { std::cout << FG_MAGENTA_B; printf(" ??? %s\n", v); std::cout << RESET << std::flush; }

#define PRINT_HIST(h) \
   if (Debug::Enabled(Debug::HIST)) { PRINT_POINTER_NAME(h) std::cout << FG_MAGENTA_B; for (UInt_t ibin = 1; ibin <= UInt_t(h->GetNbinsX()); ++ibin) { printf(" ??? %5u) %+12.6e (%+12.6e, %+12.6e) %+12.6e %+12.6e\n", ibin, h->GetBinCenter(ibin), h->GetBinLowEdge(ibin), h->GetBinLowEdge(ibin+1), h->GetBinContent(ibin), h->GetBinError(ibin)); } std::cout << RESET << std::flush; }

#define PRINT_TF1(f,h) \
   if (Debug::Enabled(Debug::HIST)) { PRINT_POINTER_NAME(f) std::cout << FG_MAGENTA_B; for (UInt_t ibin = 1; ibin <= UInt_t(h->GetNbinsX()); ++ibin) { Double_t x = h->GetBinCenter(ibin); printf(" ??? %5u) %+12.6e %+12.6e\n", ibin, x, f->Eval(x)); } std::cout << RESET << std::flush; }

#define PRINT_TIMEHIST(h) \
   if (Debug::Enabled(Debug::HIST)) { PRINT_POINTER_NAME(h) std::cout << FG_MAGENTA_B; TAxis *a = h->GetXaxis(); Char_t str[20]; for (UInt_t ibin = 1; ibin <= UInt_t(a->GetNbins()) + 1; ++ibin) { Double_t v = a->GetBinLowEdge(ibin); time_t t = v; strftime(str, 20, "%Y-%m-%d %H:%M:%S", gmtime(&t)); printf(" ??? %5u) %f (%ld) %s - %+12.6e %+12.6e\n", ibin, v, t, str, h->GetBinContent(ibin), h->GetBinError(ibin)); } std::cout << RESET << std::flush; }

#define PRINT_GRAPH(g) \
   if (Debug::Enabled(Debug::HIST)) { PRINT_POINTER_NAME(g) std::cout << FG_MAGENTA_B; Double_t *exl = g->GetEX() ? g->GetEX() : g->GetEXlow(); Double_t *exu = g->GetEX() ? g->GetEX() : g->GetEXhigh(); for (UInt_t ipoint = 0; ipoint < UInt_t(g->GetN()); ++ipoint) { Double_t x = g->GetX()[ipoint]; Double_t xl = x - (exl != NULL ? exl[ipoint] : 0); Double_t xu = x + (exu != NULL ? exu[ipoint] : 0); printf(" ??? %5u) %+12.6e (%+12.6e, %+12.6e) %+12.6e %+12.6e\n", ipoint, x, xl, xu, g->GetY()[ipoint], g->GetErrorY(ipoint)); }  std::cout << RESET << std::flush; }

#define PRINT_TIMEGRAPH(g) \
   if (Debug::Enabled(Debug::HIST)) { PRINT_POINTER_NAME(g) std::cout << FG_MAGENTA_B; Char_t str[20]; for (UInt_t ipoint = 0; ipoint < g->GetN(); ++ipoint) { Double_t v = g->GetX()[ipoint]; time_t t = v; strftime(str, 20, "%Y-%m-%d %H:%M:%S", gmtime(&t)); printf(" ??? [%5u] (%ld) %s - %+12.6E\n", ipoint, t, str, g->GetY()[ipoint]); } std::cout << RESET << std::flush; }

#define PRINT_HIST_SPARSE(h,n) \
   if (Debug::Enabled(Debug::HIST)) { PRINT_POINTER_NAME(h) std::cout << FG_MAGENTA_B; TAxis *a = h->GetAxis(n); Char_t str[20]; for (UInt_t ibin = 1; ibin <= UInt_t(a->GetNbins()) + 1; ++ibin) { Double_t v = a->GetBinLowEdge(ibin); time_t t = v; strftime(str, 20, "%Y-%m-%d %H:%M:%S", gmtime(&t)); printf(" ??? %5u) %f (%ld) %s\n", ibin, v, t, str); } std::cout << RESET << std::flush; }

#define PRINT_HIST_SPARSE_VAL(h) \
   if (Debug::Enabled(Debug::HIST)) { PRINT_POINTER_NAME(h) std::cout << FG_MAGENTA_B; std::cout << Form(" ??? %s:\n", #h); for (UInt_t ibin = 0; ibin < UInt_t(h->GetNbins()); ++ibin) { Double_t v = h->GetBinContent(ibin); printf(" ???    %5u) %f\n", ibin, v); } std::cout << RESET << std::flush; }

#define PRINT_BITS(n,s) \
   if (Debug::Enabled(Debug::BIT)) { std::cout << FG_MAGENTA_B; printf(" ??? %-30s = ", #n); for(Int_t i = s - 1; i >= 0; --i) { std::cout << ((n & (1UL << i)) != 0); } std::cout << endl; std::cout << RESET << std::flush; }

#define PRINT_PRETTY_FUNCTION() \
   if (Debug::Enabled(Debug::FUNCTION)) { std::cout << FG_BLUE_B; size_t l = strlen(__PRETTY_FUNCTION__); std::cout << " ??? ===="; for (size_t i = 0; i < l; ++i) std::cout << '='; std::cout << "====\n"; printf(" ???  |  %s  | \n", __PRETTY_FUNCTION__); std::cout << " ??? ===="; for (size_t i = 0; i < l; ++i) std::cout << '='; std::cout << "====\n"; std::cout << RESET; }

#define PRINT_FUNCTION() \
   if (Debug::Enabled(Debug::FUNCTION)) { std::cout << FG_BLUE_B; printf(" ??? ENTER IN %s\n", __FUNCTION__); std::cout << RESET << std::flush; }

#define PRINT_FUNCTION_EXIT() \
   if (Debug::Enabled(Debug::FUNCTION)) { std::cout << FG_BLUE_B; printf(" ??? EXIT FROM %s\n", __FUNCTION__); std::cout << RESET << std::flush; }

#define PROFILE_CPUTIME(time_var,statement) \
   if (Debug::Enabled(Debug::PROFILETIME)) Debug::StartWatch(); \
   statement \
   if (Debug::Enabled(Debug::PROFILETIME)) time_var = Debug::CPUTime();

#define PROFILE_REALTIME(time_var,statement) \
   if (Debug::Enabled(Debug::PROFILETIME)) Debug::StartWatch(); \
   statement \
   if (Debug::Enabled(Debug::PROFILETIME)) time_var = Debug::RealTime();

#endif
