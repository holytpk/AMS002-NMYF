#ifndef MODULATION_MODELS_H_
#define MODULATION_MODELS_H_

#include "headers.hh"
#include "ParameterInfo.hh"
#include "LISModels.hh"

namespace ModulationModels
{
   enum Type
   {
      ForceFieldApproximation = 0,
      DoubleForceField,
      DoubleForceFieldRig,
      nTypes
   };

   typedef Double_t (* Function)(Double_t, TGraph *, Double_t *, Particle::Type, Energy::Type);

   namespace Models
   {
      Double_t ForceFieldApproximation(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy);
      Double_t ForceFieldApproximation(Double_t x, TGraph *graph, Double_t *par, Particle::Type particle, Energy::Type energy);

      Double_t DoubleForceField(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy);
      Double_t DoubleForceField(Double_t x, TGraph *graph, Double_t *par, Particle::Type particle, Energy::Type energy);

      Double_t DoubleForceFieldRig(Double_t x, Double_t *par, Particle::Type particle, Energy::Type energy);
      Double_t DoubleForceFieldRig(Double_t x, TGraph *graph, Double_t *par, Particle::Type particle, Energy::Type energy);
   }

   template <typename T>
   Type cast(T iprefix)
   {
      return static_cast<Type>(iprefix);
   }

#if !defined(__CINT__)
#pragma GCC diagnostic ignored "-Wwrite-strings"
   const ModelInfo Info[nTypes] = {
      { "forcefield", "Force-field approximation", "#frac{E^{2}-M^{2}}{(E+#Phi)^{2}-M^{2}} J(E+#Phi)", "", 1., Models::ForceFieldApproximation, NULL, 1, {
            { "phi", "Solar potential", "#phi", "GV", 0., 0.6, 10. }
         }
      },
      { "doubleforcefield", "Double force-field approximation", "#frac{E^{2}-M^{2}}{(E+#Phi)^{2}-M^{2}} J(E+#Phi)", "", 1., Models::DoubleForceField, NULL, 4, {
            { "phi1", "Solar potential (low)",  "#phi_{1}", "GV", 0.,  0.589,  1.3 },
            { "phi2", "Solar potential (high)", "#phi_{2}", "GV", 0.,  0.485,  1.3 },
            { "R1",   "Low rigidity limit",     "R_{1}",    "GV", 0.,   0.5,  20. },
            { "R2",   "High rigidity limit",    "R_{2}",    "GV", 0.,   5.5,  1000. },
         }
      },
      { "doubleforcefieldrig", "Double force-field approximation (rig)", "#frac{E^{2}-M^{2}}{(E+#Phi)^{2}-M^{2}} J(E+#Phi)", "", 1., Models::DoubleForceFieldRig, NULL, 4, {
            { "phi1", "Solar potential (low)",  "#phi_{1}", "GV", 0.,  0.569478,  2. },
            { "phi2", "Solar potential (high)", "#phi_{2}", "GV", 0.,  0.574578,  2. },
            { "R1",   "Low rigidity limit",     "R_{1}",    "GV", 0.,   0.5,  20. },
            { "R2",   "High rigidity limit",    "R_{2}",    "GV", 0.,   5.5,  1000. },
         }
      }
   };
   const Function Apply[nTypes] = {
      Models::ForceFieldApproximation,
      Models::DoubleForceField,
      Models::DoubleForceFieldRig,
   };
#pragma GCC diagnostic warning "-Wwrite-strings"
#else
   ModelInfo Info[nTypes];
   Function Apply[nTypes];
#endif

   Double_t FittingFunction(Double_t *x, Double_t *par);

   // TF1 parameters = modmodel, energy, particle, lismodel, modulation parameters, norm, LIS parameters
   TF1 *CreateFunction(const Char_t *name, Double_t min_ene, Double_t max_ene, ModulationModels::Type modmodel, LISModels::Type lismodel, Particle::Type particle, Energy::Type energy, Bool_t fixlis = true);

   class Model
   {
      public:
         Model(const Char_t *name, Double_t min_ene, Double_t max_ene, ModulationModels::Type modmodel, LISModels::Type lismodel, Particle::Type particle, Energy::Type energy, Bool_t fixlis = true);
         ~Model();

         Double_t operator()(Double_t *x, Double_t *par);

         TF1 *GetTF1Pointer() { return _func; }

         static TF1 *CreateFunction(const Char_t *name, Double_t min_ene, Double_t max_ene, ModulationModels::Type modmodel, LISModels::Type lismodel, Particle::Type particle, Energy::Type energy, Bool_t fixlis = true);

      private:
         TF1 *_func; //!
         Double_t *_pars; //!

         ModulationModels::Type _modmodel;
         LISModels::Type        _lismodel;
         Energy::Type           _energy;
         Particle::Type         _particle;
   };

   class ForceField
   {
      public:
         ForceField(const Char_t *Name, TF1 *LIS, Energy::Type energy = Energy::KINETIC, Particle::Type particle = Particle::PROTON);
         ~ForceField();

         Double_t operator()(Double_t *x, Double_t *par);

         TF1 *GetTF1Pointer() { return _func; }
         TF1 *GetLISPointer() { return _lis; }

         Energy::Type   GetEnergy()   { return _energy; }
         Particle::Type GetParticle() { return _particle; }

         UShort_t GetNModulationParameters() { return _nmodpars; }
         UShort_t GetNLISParameters()        { return _nlispars; }

      private:
         TF1 *_lis;
         TF1 *_func;

         Energy::Type   _energy;
         Particle::Type _particle;

         UShort_t _nmodpars;
         UShort_t _nlispars;
   };

   class ModifiedForceField
   {
      public:
         ModifiedForceField(const Char_t *Name, TF1 *LIS, Energy::Type energy = Energy::KINETIC, Particle::Type particle = Particle::PROTON);
         ~ModifiedForceField();

         Double_t operator()(Double_t *x, Double_t *par);

         TF1 *GetTF1Pointer() { return _func; }
         TF1 *GetLISPointer() { return _lis; }

         Energy::Type   GetEnergy()   { return _energy; }
         Particle::Type GetParticle() { return _particle; }

         UShort_t GetNModulationParameters() { return _nmodpars; }
         UShort_t GetNLISParameters()        { return _nlispars; }

      private:
         TF1 *_lis;
         TF1 *_func;

         Energy::Type   _energy;
         Particle::Type _particle;

         UShort_t _nmodpars;
         UShort_t _nlispars;
   };
}

#endif
