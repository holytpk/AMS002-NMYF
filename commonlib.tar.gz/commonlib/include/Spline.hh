#ifndef SPLINE_H
#define SPLINE_H

#include "headers.hh"

#include <TSpline.h>

class Spline
{
   public:
      enum TypeFlag
      {
         Normal   = 0,           // 0
         LogX     = 1 << 0,      // 1
         LogY     = 1 << 1,      // 2
         PowerLaw = 1 << 2,      // 4
         Rescaled = 1 << 3,      // 8
         AMS15    = 1 << 4,      // 16
         LogLog   = LogX | LogY, // 3
      };

      Spline();
      Spline(const Char_t *Name, UShort_t nNodes, UShort_t Type = Normal, Double_t *NodesX = NULL, Double_t *NodesY = NULL, Double_t FirstDerivative = 0, Double_t LastDerivative = 0, Double_t Gamma = 0);
      Spline(const Spline &);
      virtual ~Spline();

      void Rebuild();

      Double_t operator()(Double_t *x, Double_t *par);
      Double_t Eval(Double_t x);

      void SetXNodes(Double_t *xn);
      void SetYNodes(Double_t *yn, Double_t *yn_min = NULL, Double_t *yn_max = NULL);
      void SetNodes(Double_t *xn, Double_t *yn, Double_t *yn_min = NULL, Double_t *yn_max = NULL);
      void NormalizeNodes();

      UShort_t GetnNodes() { return _nnodes; }
      Double_t *GetXNodes() { return &_func->GetParameters()[2]; }
      Double_t GetXNode(UShort_t inode) { return _func->GetParameter(2 + inode); }
      Double_t *GetYNodes() { return &_func->GetParameters()[2 + _nnodes]; }
      Double_t GetYNode(UShort_t inode) { return _func->GetParameter(2 + _nnodes + inode); }

      void SetFirstDerivative(Double_t b1);
      void SetLastDerivative(Double_t e1);
      void SetDerivatives(Double_t b1, Double_t e1);
      Double_t GetFirstDerivative() { return _func->GetParameter(0); }
      Double_t GetLastDerivative() { return _func->GetParameter(1); }

      void SetFirstSpectralIndex(Double_t gb, Double_t gbmin = 0, Double_t gbmax = 0);
      void SetLastSpectralIndex(Double_t ge, Double_t gemin = 0, Double_t gemax = 0);
      void SetSpectralIndices(Double_t gb, Double_t ge, Double_t gbmin = 0, Double_t gbmax = 0, Double_t gemin = 0, Double_t gemax = 0);
      Double_t GetFirstSpectralIndex() { return _func->GetParameter(0); }
      Double_t GetLastSpectralIndex() { return _func->GetParameter(1); }

      void SetRescalingGamma(Double_t gamma);

      void SetAMS15Parameters(Double_t *par);

      TF1 *GetTF1Pointer()  { return _func; }
      TSpline3 *GetSpline();
      TF1 *GetFirstPowerLaw();
      TF1 *GetLastPowerLaw();

      UShort_t GetType() { return _type; }

      static void GetNodesFromHistogram(TH1 *Hist, UShort_t nNodes, Double_t *&XNodes, Double_t *&YNodes, Int_t &FirstBin, Int_t &LastBin, UShort_t Type = Normal);
      static Spline *BuildFromHistogram(TH1 *Hist, const Char_t *Name, UShort_t nNodes, UShort_t Type = Normal, Double_t FirstDerivative = TMath::QuietNaN(), Double_t LastDerivative = TMath::QuietNaN(),
         Int_t FirstBin = -1, Int_t LastBin = -1);

      static void GetNodesFromGraph(TGraph *Graph, UShort_t nNodes, Double_t *&XNodes, Double_t *&YNodes, Int_t &FirstBin, Int_t &LastBin, UShort_t Type = Normal);
      static Spline *BuildFromGraph(TGraph *Graph, const Char_t *Name, UShort_t nNodes, UShort_t Type = Normal, Double_t FirstDerivative = TMath::QuietNaN(), Double_t LastDerivative = TMath::QuietNaN(),
         Int_t FirstBin = -1, Int_t LastBin = -1);

      void Print();

   private:
      Int_t _nnodes;
      Double_t *_xn; //[_nnodes]
      Double_t *_yn; //[_nnodes]

      Double_t _b1;
      Double_t _e1;
      Double_t _A;
      Double_t _B;
      Double_t _gb;
      Double_t _ge;
      Double_t _gamma;

      Double_t _ams15_pars[5]; // N, gamma, Rb, delta, s
      Double_t _ams15_flux;
      Double_t _ams15_deriv;

      UShort_t _type;
      UShort_t _is_powerlaw;
      UShort_t _log_type;

      TF1 *_func; //!
      TF1 *_first_powerlaw; //!
      TF1 *_last_powerlaw; //!
      TH1 *_hist; //!
      TGraph *_graph; //!

#ifndef __CINT__
      typedef Double_t (Spline::*spline_func_ptr)(Double_t *, Double_t *);
      spline_func_ptr _call_spline[4][4]; // [Normal,PowerLaw,AMS15,ThreePowerLaw][Normal,Logx,Logy,LogLog]
#else
      void *_call_spline[4][4]; //!
#endif

      void _update_type();

      Double_t _spline(Double_t *x, Double_t *par);
      Double_t _spline_logx(Double_t *x, Double_t *par);
      Double_t _spline_logy(Double_t *x, Double_t *par);
      Double_t _spline_loglog(Double_t *x, Double_t *par);
      Double_t _spline_powerlaw(Double_t *x, Double_t *par);
      Double_t _spline_powerlaw_logx(Double_t *x, Double_t *par);
      Double_t _spline_powerlaw_logy(Double_t *x, Double_t *par);
      Double_t _spline_powerlaw_loglog(Double_t *x, Double_t *par);
      Double_t _spline_ams15(Double_t *x, Double_t *par);
      Double_t _spline_ams15_logx(Double_t *x, Double_t *par);
      Double_t _spline_ams15_logy(Double_t *x, Double_t *par);
      Double_t _spline_ams15_loglog(Double_t *x, Double_t *par);

      Double_t _calc_ams15_flux(Double_t x);
      void _calc_ams15_deriv(Double_t x);

      void _set_ams15_boundary_conditions();
      void _set_ams15_parameters(Double_t *par);
      void _set_x_nodes(Double_t *xn);
      void _set_y_nodes(Double_t *xn, Double_t *yn_min, Double_t *yn_max);
      void _set_first_derivative(Double_t b1);
      void _set_last_derivative(Double_t e1);
      void _set_derivatives(Double_t b1, Double_t e1);
      void _set_first_spectral_index(Double_t gb, Double_t gbmin, Double_t gbmax);
      void _set_last_spectral_index(Double_t ge, Double_t gemin, Double_t gemax);
      void _set_spectral_indices(Double_t gb, Double_t ge, Double_t gbmin, Double_t gbmax, Double_t gemin, Double_t gemax);

      ClassDef(Spline,1)
};

#endif
