#ifndef _DATE_TIME_TOOLS_H_
#define _DATE_TIME_TOOLS_H_

#include "headers.hh"

typedef std::pair<time_t, time_t> TimeInterval;

class DateTimeTools
{
   public:
      static const Char_t *UTCTimeToString(time_t utime, const Char_t *format);

      static tm *StringToTM(const Char_t *date, const Char_t *format = "%Y%m%d");
      static time_t StringToUTCTime(const Char_t *date, const Char_t *format = "%Y%m%d");

      static time_t UIntToUTCTime(UInt_t date);
      static UInt_t UTCTimeToUInt(time_t utime);

      static time_t BRToUTCTime(UInt_t BR);
      static UInt_t UTCTimeToBR(time_t utime);

      static Bool_t UTCTimeFromDateAndTime(const Char_t *date, const Char_t *time, time_t &utime);

      static const Char_t *AddToDate(const Char_t *date, time_t sec, const Char_t *format = "%Y%m%d");

      static Bool_t ParseTimeIntervals(const Char_t *date, const Char_t *intervals, std::vector<TimeInterval> &bins);

      static Char_t *TimeIntervalsToString(const std::vector<TimeInterval> &bins);

      static UShort_t GetTimeBin(UInt_t time, std::vector<TimeInterval> &timebins);

      static const Char_t *NormalizeDate(const Char_t *date, const Char_t *src_frmt, const Char_t *dst_frmt);

      static Char_t *SplitDate(UInt_t date, Char_t *str_date);
      static const Char_t *SplitDate(UInt_t date);

      static UShort_t nDays(UShort_t imonth, UShort_t year);
      static UShort_t nDays(std::tm *tmd);
      static Bool_t   IsLeapYear(UShort_t year);
      static Bool_t   IsLeapYear(std::tm *tmd);
};

#endif
