#ifndef _UNITS_H_
#define _UNITS_H_

#include "headers.hh"
//~ #include <CLHEPSystemOfUnits.h>
//~ #include <CLHEPPhysicalConstants.h>

//~ #ifndef HEP_SYSTEM_OF_UNITS_H
namespace SIPrefix
{
   enum Type
   {
      NONE = 0,
      YOCTO,
      ZEPTO,
      ATTO,
      FEMTO,
      PICO,
      NANO,
      MICRO,
      MILLI,
      CENTI,
      DECI,
      DECA,
      HECTO,
      KILO,
      MEGA,
      GIGA,
      TERA,
      PETA,
      EXA,
      ZETTA,
      YOTTA,
      nPREFIXs
   };

   const Char_t * const Name[nPREFIXs] = {
      "", "yocto", "zepto", "atto", "femto", "pico", "nano", "micro", "milli", "centi", "deci", "deca", "hecto", "kilo", "Mega", "Giga", "Tera", "Peta", "Exa", "Zetta", "Yotta"
   };
   const Char_t * const Symbol[nPREFIXs] = {
      "", "y", "z", "a", "f", "p", "n", "u", "m", "c", "d", "da", "h", "k", "M", "G", "T", "P", "E", "Z", "Y"
   };

   const Double_t Factor[nPREFIXs] = { 1, 1e-24, 1e-21, 1e-18, 1e-15, 1e-12, 1e-9, 1e-6, 1e-3, 1e-2, 1e-1, 1e1, 1e2, 1e3, 1e6, 1e9, 1e12, 1e15, 1e18, 1e21, 1e24 };

   const Double_t BaseEnergyFactor     = Factor[MEGA];
   const Double_t BaseLengthFactor     = Factor[CENTI];
   const Double_t BaseTimeFactor       = Factor[NONE];
   const Double_t BaseSolidAngleFactor = Factor[NONE];

   template <typename T>
   Type cast(T iprefix)
   {
      return static_cast<Type>(iprefix);
   }

   Type FromName(const Char_t *name);
   Type FromSymbol(const Char_t *symbol);
}
//~ #endif

//~ #ifndef HEP_SYSTEM_OF_UNITS_H
namespace Unit
{
   // default units are MeV, MV, cm, s, sr
   const Double_t eV  = SIPrefix::Factor[SIPrefix::NONE]/SIPrefix::BaseEnergyFactor;
   const Double_t keV = SIPrefix::Factor[SIPrefix::KILO]/SIPrefix::BaseEnergyFactor;
   const Double_t MeV = SIPrefix::Factor[SIPrefix::MEGA]/SIPrefix::BaseEnergyFactor;
   const Double_t GeV = SIPrefix::Factor[SIPrefix::GIGA]/SIPrefix::BaseEnergyFactor;

   const Double_t V   = SIPrefix::Factor[SIPrefix::NONE]/SIPrefix::BaseEnergyFactor;
   const Double_t MV  = SIPrefix::Factor[SIPrefix::MEGA]/SIPrefix::BaseEnergyFactor;
   const Double_t GV  = SIPrefix::Factor[SIPrefix::GIGA]/SIPrefix::BaseEnergyFactor;

   const Double_t m   = SIPrefix::Factor[SIPrefix::NONE]/SIPrefix::BaseLengthFactor;
   const Double_t cm  = SIPrefix::Factor[SIPrefix::CENTI]/SIPrefix::BaseLengthFactor;
   const Double_t m2  = m*m;
   const Double_t cm2 = cm*cm;

   const Double_t s    = SIPrefix::Factor[SIPrefix::NONE]/SIPrefix::BaseTimeFactor;
   const Double_t min  = 60*s;
   const Double_t hr   = 60*min;
   const Double_t day  = 24*hr;
   const Double_t year = 365*day;

   const Double_t sr  = SIPrefix::Factor[SIPrefix::NONE]/SIPrefix::BaseSolidAngleFactor;
}
//~ #endif

namespace Particle
{
   // GCR categorization according to origin, from http://www.srl.caltech.edu/ACE/CRIS_SIS/images/nucplot_new2.gif
   // pri = primary (>75% from source)
   // sec = secondary (<5% from source)
   // mix = mixed (5%-75% from source)
   // abs = not present (usually because it has a too short lifetime, so it must be locally produced)
   enum Type
   {
      ELECTRON = 0, POSITRON, // pri, mix
      NEUTRON, PROTON, ANTIPROTON, DEUTERON, TRITIUM, // abs, pri, sec, sec, abs
      HELIUM3, HELIUM4, // sec, pri
      LITHIUM6, LITHIUM7, // sec, sec
      BERYLLIUM7, BERYLLIUM8, BERYLLIUM9, BERYLLIUM10, // sec, abs, sec, sec
      BORON10, BORON11, // sec, sec
      CARBON12, CARBON13, CARBON14, // pri, sec, abs
      NITROGEN14, NITROGEN15, // mix, sec
      OXYGEN16, OXYGEN17, OXYGEN18, // pri, sec, mix
      FLUORINE18, FLUORINE19, // abs, sec
      NEON20, NEON21, NEON22, // pri, sec, mix
      SODIUM22, SODIUM23, SODIUM24, // abs, mix, abs
      MAGNESIUM24, MAGNESIUM25, MAGNESIUM26, // pri, mix, mix
      ALUMINUM26, ALUMINUM27, // sec, mix
      SILICON28, SILICON29, SILICON30, SILICON31, SILICON32, // pri, mix, mix, abs, abs
      PHOSPHORUS29, PHOSPHORUS31, PHOSPHORUS32, PHOSPHORUS33, // abs, mix, abs, abs
      SULFUR30, SULFUR31, SULFUR32, SULFUR33, SULFUR34, SULFUR35, SULFUR36, // abs, abs, pri, sec, mix, abs, mix
      CHLORINE33, CHLORINE35, CHLORINE36, CHLORINE37, // abs, sec, sec, sec
      ARGON34, ARGON36, ARGON37, ARGON38, ARGON39, ARGON40, ARGON41, ARGON42, // abs, mix, sec, mix, abs, sec, abs, abs
      POTASSIUM37, POTASSIUM39, POTASSIUM40, POTASSIUM41, // abs sec, sec, sec
      CALCIUM40, CALCIUM41, CALCIUM42, CALCIUM43, CALCIUM44, CALCIUM45, CALCIUM46, CALCIUM47, CALCIUM48, // pri, sec, sec, sec, sec, abs, sec, abs, sec
      SCANDIUM43, SCANDIUM44, SCANDIUM45, SCANDIUM46, SCANDIUM47, SCANDIUM48, // abs, abs, sec, abs, abs, abs
      TITANIUM44, TITANIUM45, TITANIUM46, TITANIUM47, TITANIUM48, TITANIUM49, TITANIUM50, // sec, abs, sec, sec, sec, sec, sec
      VANADIUM48, VANADIUM49, VANADIUM50, VANADIUM51, // abs, sec, sec, sec
      CHROMIUM50, CHROMIUM51, CHROMIUM52, CHROMIUM53, CHROMIUM54, // sec, sec, mix, sec, sec
      MANGANESE52, MANGANESE53, MANGANESE54, MANGANESE55, // abs, sec, sec, mix
      IRON54, IRON55, IRON56, IRON57, IRON58, IRON59, IRON60, // mix, sec, pri, pri, pri, abs, abs
      COBALT56, COBALT57, COBALT58, COBALT59, COBALT60, // abs, sec, abs, pri, abs
      NICKEL56, NICKEL58, NICKEL59, NICKEL60, NICKEL61, NICKEL62, NICKEL63, NICKEL64, // abs, pri, sec, pri, pri, pri, abs, pri
      HYDROGEN, HELIUM,
      LITHIUM, BERYLLIUM, BORON, CARBON, NITROGEN, OXYGEN, FLUORINE, NEON,
      SODIUM, MAGNESIUM, ALUMINUM, SILICON, PHOSPHORUS, SULFUR, CHLORINE, ARGON,
      POTASSIUM, CALCIUM, SCANDIUM, TITANIUM, VANADIUM, CHROMIUM, MANGANESE, IRON, COBALT, NICKEL,
      nPARTICLEs
   };

   const Char_t * const Name[nPARTICLEs] = {
      "ele", "pos",
      "n", "pro", "pbar", "H2", "H3",
      "He3", "He4",
      "Li6", "Li7",
      "Be7", "Be8", "Be9", "Be10",
      "B10", "B11",
      "C12", "C13", "C14",
      "N14", "N15",
      "O16", "O17", "O18",
      "F18", "F19",
      "Ne20", "Ne21", "Ne22",
      "Na22", "Na23", "Na24",
      "Mg24", "Mg25", "Mg26",
      "Al26", "Al27",
      "Si28", "Si29", "Si30", "Si31", "Si32",
      "P29", "P31", "P32", "P33",
      "S30", "S31", "S32", "S33", "S34", "S35", "S36",
      "Cl33", "Cl35", "Cl36", "Cl37",
      "Ar34", "Ar36", "Ar37", "Ar38", "Ar39", "Ar40", "Ar41", "Ar42",
      "K37", "K39", "K40", "K41",
      "Ca40", "Ca41", "Ca42", "Ca43", "Ca44", "Ca45", "Ca46", "Ca47", "Ca48",
      "Sc43", "Sc44", "Sc45", "Sc46", "Sc47", "Sc48",
      "Ti44", "Ti45", "Ti46", "Ti47", "Ti48", "Ti49", "Ti50",
      "V48", "V49", "V50", "V51",
      "Cr50", "Cr51", "Cr52", "Cr53", "Cr54",
      "Mn52", "Mn53", "Mn54", "Mn55",
      "Fe54", "Fe55", "Fe56", "Fe57", "Fe58", "Fe59", "Fe60",
      "Co56", "Co57", "Co58", "Co59", "Co60",
      "Ni56", "Ni58", "Ni59", "Ni60", "Ni61", "Ni62", "Ni63", "Ni64",
      "H", "He",
      "Li", "Be", "B", "C", "N", "O", "F", "Ne",
      "Na", "Mg", "Al", "Si", "P", "S", "Cl", "Ar",
      "K", "Ca", "Sc", "Ti", "V", "Cr", "Mn", "Fe", "Co", "Ni"
   };
   const Char_t * const Title[nPARTICLEs]  = {
      "Electron",  "Positron",
      "Neutron", "Proton", "Anti-proton", "Deuteron", "Tritium",
      "Helium-3", "Helium-4",
      "Lithium-6", "Lithium-7",
      "Beryllium-7", "Beryllium-8", "Beryllium-9", "Beryllium-10",
      "Boron-10", "Boron-11",
      "Carbon-12", "Carbon-13", "Carbon-14",
      "Nitrogen-14", "Nitrogen-15",
      "Oxygen-16", "Oxygen-17", "Oxygen-18",
      "Fluorine-18","Fluorine-19",
      "Neon-20", "Neon-21", "Neon-22",
      "Sodium-22", "Sodium-23", "Sodium-24",
      "Magnesium-24", "Magnesium-25", "Magnesium-26",
      "Aluminum-26", "Aluminum-27",
      "Silicon-28", "Silicon-29", "Silicon-30", "Silicon-31", "Silicon-32",
      "Phosphorus-29", "Phosphorus-31", "Phosphorus-32", "Phosphorus-33",
      "Sulfur-30", "Sulfur-31", "Sulfur-32", "Sulfur-33", "Sulfur-34", "Sulfur-35", "Sulfur-36",
      "Chlorine-33", "Chlorine-35", "Chlorine-36", "Chlorine-37",
      "Argon-34", "Argon-36", "Argon-37", "Argon-38", "Argon-39", "Argon-40", "Argon-41", "Argon-42",
      "Potassium-37", "Potassium-39", "Potassium-40", "Potassium-41",
      "Calcium-40", "Calcium-41", "Calcium-42", "Calcium-43", "Calcium-44", "Calcium-45", "Calcium-46", "Calcium-47", "Calcium-48",
      "Scandium-43", "Scandium-44", "Scandium-45", "Scandium-46", "Scandium-47", "Scandium-48",
      "Titanium-44", "Titanium-45", "Titanium-46", "Titanium-47", "Titanium-48", "Titanium-49", "Titanium-50",
      "Vanadium-48", "Vanadium-49", "Vanadium-50", "Vanadium-51",
      "Chromium-50", "Chromium-51", "Chromium-52", "Chromium-53", "Chromium-54",
      "Manganese-52", "Manganese-53", "Manganese-54", "Manganese-55",
      "Iron-54", "Iron-55", "Iron-56", "Iron-57", "Iron-58", "Iron-59", "Iron-60",
      "Cobalt-56", "Cobalt-57", "Cobalt-58", "Cobalt-59", "Cobalt-60",
      "Nickel-56", "Nickel-58", "Nickel-59", "Nickel-60", "Nickel-61", "Nickel-62", "Nickel-63", "Nickel-64",
      "Hydrogen", "Helium",
      "Lithium", "Berillium", "Boron", "Carbon", "Nitrogen", "Oxygen", "Fluorine", "Neon",
      "Sodium", "Magnesium", "Aluminum", "Silicon", "Phosphorus", "Sulfur", "Chlorine", "Argon",
      "Potassium", "Calcium", "Scandium", "Titanium", "Vanadium", "Chromium", "Manganese", "Iron", "Cobalt", "Nickel",
   };
   const Char_t * const Symbol[nPARTICLEs] = {
      "e^{#minus}", "e^{#plus}",
      "n", "p", "#bar{p}", "{}^{2}H", "{}^{3}H",
      "{}^{3}He", "{}^{4}He",
      "{}^{6}Li", "{}^{7}Li",
      "{}^{7}Be", "{}^{8}Be", "{}^{9}Be", "{}^{10}Be",
      "{}^{10}B", "{}^{11}B",
      "{}^{12}C", "{}^{13}C", "{}^{14}C",
      "{}^{14}N", "{}^{15}N",
      "{}^{16}O", "{}^{17}O", "{}^{18}O",
      "{}^{18}F", "{}^{19}F",
      "{}^{20}Ne", "{}^{21}Ne", "{}^{22}Ne",
      "{}^{22}Na", "{}^{23}Na", "{}^{24}Na",
      "{}^{24}Mg", "{25}^{}Mg", "{26}^{}Mg",
      "{}^{26}Al", "{27}^{}Al",
      "{}^{28}Si", "{}^{29}Si", "{}^{30}Si", "{}^{31}Si", "{}^{32}Si",
      "{}^{29}P", "{}^{31}P", "{}^{32}P", "{}^{33}P",
      "{}^{30}S", "{}^{31}S", "{}^{32}S", "{}^{33}S", "{}^{34}S", "{}^{35}S", "{}^{36}S",
      "{}^{33}Cl", "{}^{35}Cl", "{}^{36}Cl", "{}^{37}Cl",
      "{}^{34}Ar", "{}^{36}Ar", "{}^{37}Ar", "{}^{38}Ar", "{}^{39}Ar", "{}^{40}Ar", "{}^{41}Ar", "{}^{42}Ar",
      "{}^{37}K", "{}^{39}K", "{}^{40}K", "{}^{41}K",
      "{}^{40}Ca", "{}^{41}Ca", "{}^{42}Ca", "{}^{43}Ca", "{}^{44}Ca", "{}^{45}Ca", "{}^{46}Ca", "{}^{47}Ca", "{}^{48}Ca",
      "{}^{43}Sc", "{}^{44}Sc", "{}^{45}Sc", "{}^{46}Sc", "{}^{47}Sc", "{}^{48}Sc",
      "{}^{44}Ti", "{}^{45}Ti", "{}^{46}Ti", "{}^{47}Ti", "{}^{48}Ti", "{}^{49}Ti", "{}^{50}Ti",
      "{}^{48}V", "{}^{49}V", "{}^{50}V", "{}^{51}V",
      "{}^{50}Cr", "{}^{51}Cr", "{}^{52}Cr", "{}^{53}Cr", "{}^{54}Cr",
      "{}^{52}Mn", "{}^{53}Mn", "{}^{54}Mn", "{}^{55}Mn",
      "{}^{54}Fe", "{}^{55}Fe", "{}^{56}Fe", "{}^{57}Fe", "{}^{58}Fe", "{}^{59}Fe", "{}^{60}Fe",
      "{}^{56}Co", "{}^{57}Co", "{}^{58}Co", "{}^{59}Co", "{}^{60}Co",
      "{}^{56}Ni", "{}^{58}Ni", "{}^{59}Ni", "{}^{60}Ni", "{}^{61}Ni", "{}^{62}Ni", "{}^{63}Ni", "{}^{64}Ni",
      "H", "He",
      "Li", "Be", "B", "C", "N", "O", "F", "Ne",
      "Na", "Mg", "Al", "Si", "P", "S", "Cl", "Ar",
      "K", "Ca", "Sc", "Ti", "V", "Cr", "Mn", "Fe", "Co", "Ni"
   };

//~ #ifndef HEP_SYSTEM_OF_UNITS_H
   using Unit::GeV;
   using Unit::MeV;
   using Unit::s;
   using Unit::min;
   using Unit::hr;
   using Unit::day;
   using Unit::year;
//~ #endif

   const Double_t Mass[nPARTICLEs] = { // with nuclear binding energy contribution subtracted, from AMS/data/nuclear/mass.root
      0.5109989461*MeV, 0.5109989461*MeV, // ele, pos
      939.565413*MeV, 938.2720813*MeV, 938.2720813*MeV, 1.8756129*GeV, 2.8089211*GeV, // n, p, pbar, H2, H3
      2.8083915*GeV, 3.7273793*GeV, // He3, He4
      5.6015185*GeV, 6.5338328*GeV, // Li6, Li7
      6.5341837*GeV, 7.4548505*GeV, 8.3927513*GeV, 9.3255045*GeV, // Be7, Be8, Be9, Be10
      9.3244367*GeV, 10.252548*GeV, // B10, B11
      11.174863*GeV, 12.109482*GeV, 13.040871*GeV, // C12, C13, C14
      13.040203*GeV, 13.968936*GeV, // N14, N15
      14.895080*GeV, 15.830503*GeV, 16.762023*GeV, // O16, O17, O18
      16.763168*GeV, 17.692301*GeV, // F18, F19
      18.617730*GeV, 19.550534*GeV, 20.479735*GeV, // Ne20, Ne21, Ne22
      20.482067*GeV, 21.409213*GeV, 22.341819*GeV, // Na22, Na23, Na24
      22.335792*GeV, 23.268027*GeV, 24.196500*GeV, // Mg24, Mg25, Mg26
      24.199993*GeV, 25.126501*GeV, // Al26, Al27
      26.053188*GeV, 26.984279*GeV, 27.913236*GeV, 28.846214*GeV, 29.776579*GeV, // Si28, Si29, Si30, Si31, Si32
      26.988711*GeV, 28.844211*GeV, 29.775841*GeV, 30.705303*GeV, // P29, P31, P32, P33
      27.922588*GeV, 28.849098*GeV, 29.773619*GeV, 30.704543*GeV, 31.632691*GeV, 32.565271*GeV, 33.494947*GeV, // S30, S31, S32, S33, S34, S35, S36
      30.709615*GeV, 32.564593*GeV, 33.495578*GeV, 34.424833*GeV, // Cl33, Cl35, Cl36, Cl37
      31.643223*GeV, 33.494358*GeV, 34.425136*GeV, 35.352863*GeV, 36.285829*GeV, 37.215526*GeV, 38.148992*GeV, 39.079131*GeV, // Ar34, Ar36, Ar37, Ar38, Ar39, Ar40, Ar41, Ar42
      34.430772*GeV, 36.284753*GeV, 37.216519*GeV, 38.145989*GeV, // K37, K39, K40, K41
      37.214697*GeV, 38.145900*GeV, 39.073985*GeV, 40.005617*GeV, 40.934051*GeV, 41.866202*GeV, 42.795370*GeV, 43.727659*GeV, 44.657272*GeV, // Ca40, Ca41, Ca42, Ca43, Ca44, Ca45, Ca46, Ca47, Ca48
      40.007327*GeV, 40.937193*GeV, 41.865432*GeV, 42.796237*GeV, 43.725156*GeV, 44.656482*GeV, // Sc43, Sc44, Sc45, Sc46, Sc47, Sc48
      40.93695*GeV, 41.866983*GeV, 42.793359*GeV, 43.724044*GeV, 44.651983*GeV, 45.583406*GeV, 46.512032*GeV, // Ti44, Ti45, Ti46, Ti47, Ti48, Ti49, Ti50
      44.655487*GeV, 45.583497*GeV, 46.513728*GeV, 47.442242*GeV, // V48, V49, V50, V51
      46.512179*GeV, 47.442484*GeV, 48.370011*GeV, 49.301637*GeV, 50.231483*GeV, // Cr50, Cr51, Cr52, Cr53, Cr54
      48.374211*GeV, 49.301723*GeV, 50.23235*GeV, 51.161688*GeV, // Mn52, Mn53, Mn54, Mn55
      50.231141*GeV, 51.161409*GeV, 52.089777*GeV, 53.021696*GeV, 53.951217*GeV, 54.884201*GeV, 55.814947*GeV, // Fe54, Fe55, Fe56, Fe57, Fe58, Fe59, Fe60
      52.093833*GeV, 53.022021*GeV, 53.953014*GeV, 54.882125*GeV, 55.814199*GeV, // Co56, Co57, Co58, Co59, Co60
      52.095454*GeV, 53.952121*GeV, 54.882688*GeV, 55.810865*GeV, 56.742610*GeV, 57.671580*GeV, 58.604308*GeV, 59.534216*GeV, // Ni56, Ni58, Ni59, Ni60, Ni61, Ni62, Ni63, Ni64
      // effective masses, using abundance of isotopes in GCR, extrapolated from modulated ratios to LIS
      // m = sum(w_i*m_i)/sum(w_i), w_i = abundance of isotope i, sum(w_i) = 1
      0.9566513*GeV, // 2H/1H = 0.03 < 0.1 GeV; 0.02 @ 0.3 GeV; 0.01 @ 20 GeV => 0.02
      3.5895311*GeV, // 3He/He = 0.1 < 0.1 GeV; 0.2 @ 3 GeV; 0.15 @ 10 GeV => 0.15
      6.0898736*GeV, // 7Li/6Li = 1.1
      7.3985911*GeV, // 7Be/Be = 0.56; 9Be/Be = 0.39; 10Be/Be = 0.05
      9.9645134*GeV, // 10B/11B = 0.45
      11.236006*GeV, // 13C/12C = 0.07
      13.551006*GeV, // 15N/N = 0.55
      15.231325*GeV, // 16O/O = 0.9; 17O/O = 0.1; 18O/O = 0.02
      17.692301*GeV, // F19 = 1
      19.269612*GeV, // 20Ne/Ne = 0.6, 21Ne/Ne = 0.1, 22Ne/Ne = 0.3
      21.409213*GeV, // 23Na = 1
      22.875811*GeV, // 24Mg/Mg = 0.6, 25Mg/Mg = 0.22, 26Mg/Mg = 0.18
      25.080176*GeV, // 26Al/Al = 0.05, 27Al/Al = 0.95
      26.285854*GeV, // 28Si/Si = 0.8, 29Si/Si = 0.15, 30Si/Si = 0.05
      28.844211*GeV, // 31P = 1
      30.192118*GeV, // 32S/S = 0.7, 33S/S = 0.15, 34S/S = 0.15
      33.262226*GeV, // 35Cl/Cl = 0.6, 36Cl/Cl = 0.05, 37Cl/Cl = 0.35
      34.702999*GeV, // 36Ar/Ar = 0.48, 37Ar/Ar = 0.02, 38Ar/Ar = 0.36, 40Ar/Ar = 0.14
      37.494786*GeV, // 39K/K = 0.25, 40K/K = 0.2, 41K/K = 0.55
      38.572328*GeV, // 40Ca/Ca = 0.47, 41Ca/Ca = 0.03, 42Ca/Ca = 0.27, 43Ca/Ca = 0.07, 44Ca/Ca = 0.14, 46Ca/Ca = 0.02
      41.865432*GeV, // 45Sc = 1
      43.788272*GeV, // 44Ti/Ti = 0.03, 46Ti/Ti = 0.46, 47Ti/Ti = 0.12, 48Ti/Ti = 0.22, 49Ti/Ti = 0.11, 50Ti/Ti = 0.06
      46.698916*GeV, // 49V/V = 0.3, 50V/V = 0.2, 51V/V = 0.5
      48.575618*GeV, // 50Cr/Cr = 0.1, 51Cr/Cr = 0.1, 52Cr/Cr = 0.45, 53Cr/Cr = 0.18, 54Cr/Cr = 0.17
      50.436443*GeV, // 53Mn/Mn = 0.28, 54Mn/Mn = 0.22, 55Mn/Mn = 0.5
      51.987748*GeV, // 54Fe/Fe = 0.07; 55Fe/Fe = 0.04; 56Fe/Fe = 0.83; 57Fe/Fe = 0.05; 58Fe/Fe = 0.01
      54.268291*GeV, // 57Co/Co = 0.33, 59Co/Co = 0.67
      54.901396*GeV, // 56Ni/Ni = 0.03, 58Ni/Ni = 0.43, 60Ni/Ni = 0.45, 62Ni/Ni = 0.03; NB = sum(w_i) = 0.94!!!
   };
   const Double_t Z[nPARTICLEs] = { // abs(Z)
      1, 1, // ele, pos
      0, 1, 1, 1, 1, // n, p, pbar, H2, H3,
      2, 2, // He3, He4
      3, 3, // Li6, Li7
      4, 4, 4, 4, // Be7, Be8, Be9, Be10
      5, 5, // B10, B11
      6, 6, 6, // C12, C13, C14
      7, 7, // N14, N15
      8, 8, 8, // O16, O17, O18
      9, 9, // F18, F19
      10, 10, 10, // Ne20, Ne21, Ne22
      11, 11, 11, // Na22, Na23, Na24
      12, 12, 12, // Mg24, Mg25, Mg26
      13, 13, // Al26, Al27
      14, 14, 14, 14, 14, // Si28, Si29, Si30, Si31, Si32
      15, 15, 15, 15, // P29, P31, P32, P33
      16, 16, 16, 16, 16, 16, 16, // S30, S31, S32, S33, S34, S35, S36
      17, 17, 17, 17, // Cl33, Cl35, Cl36, Cl37
      18, 18, 18, 18, 18, 18, 18, 18, // Ar34, Ar36, Ar37, Ar38, Ar39, Ar40, Ar41, Ar42
      19, 19, 19, 19, // K37, K39, K40, K41
      20, 20, 20, 20, 20, 20, 20, 20, 20, // Ca40, Ca41, Ca42, Ca43, Ca44, Ca45, Ca46, Ca47, Ca48
      21, 21, 21, 21, 21, 21, // Sc43, Sc44, Sc45, Sc46, Sc47, Sc48
      22, 22, 22, 22, 22, 22, 22, // Ti44, Ti45, Ti46, Ti47, Ti48, Ti49, Ti50
      23, 23, 23, 23, // V48, V49, V50, V51
      24, 24, 24, 24, 24, // Cr50, Cr51, Cr52, Cr53, Cr54
      25, 25, 25, 25, // Mn52, Mn53, Mn54, Mn55
      26, 26, 26, 26, 26, 26, 26, // Fe54, Fe55, Fe56, Fe57, Fe58, Fe59, Fe60
      27, 27, 27, 27, 27, // Co56, Co57, Co58, Co59, Co60
      28, 28, 28, 28, 28, 28, 28, 28, // Ni56, Ni58, Ni59, Ni60, Ni61, Ni62, Ni63, Ni64
      1, 2, // H, He
      3, 4, 5, 6, 7, 8, 9, 10, // Li, Be, B, C, N, O, F, Ne
      11, 12, 13, 14, 15, 16, 17, 18, // Na, Mg, Al, Si, P, S, Cl, Ar
      19, 20, 21, 22, 23, 24, 25, 26, 27, 28 // K, Ca, Sc, Ti, Va, Cr, Mn, Fe, Co, Ni
   };
   const Double_t A[nPARTICLEs] = {
      1, 1, // ele, pos
      1, 1, 1, 2, 3, // n, p, pbar, H2, H3,
      3, 4, // He3, He4
      6, 7, // Li6, Li7
      7, 8, 9, 10, // Be7, Be8, Be9, Be10
      10, 11, // B10, B11
      12, 13, 14, // C12, C13, C14
      14, 15, // N14, N15
      16, 17, 18, // O16, O17, O18
      18, 19, // F18, F19
      20, 21, 22, // Ne20, Ne21, Ne22
      22, 23, 24, // Na22, Na23, Na24
      24, 25, 26, // Mg24, Mg25, Mg26
      26, 27, // Al26, Al27
      28, 29, 30, 31, 32, // Si28, Si29, Si30, Si31, Si32
      29, 31, 32, 33, // P29, P31, P32, P33
      30, 31, 32, 33, 34, 35, 36, // S30, S31, S32, S33, S34, S35, S36
      33, 35, 36, 37, // Cl33, Cl35, Cl36, Cl37
      34, 36, 37, 38, 39, 40, 41, 42, // Ar34, Ar36, Ar37, Ar38, Ar39, Ar40, Ar41, Ar42
      37, 39, 40, 41, // K37, K39, K40, K41
      40, 41, 42, 43, 44, 45, 46, 47, 48, // Ca40, Ca41, Ca42, Ca43, Ca44, Ca45, Ca46, Ca47, Ca48
      43, 44, 45, 46, 47, 48, // Sc43, Sc44, Sc45, Sc46, Sc47, Sc48
      44, 45, 46, 47, 48, 49, 50, // Ti44, Ti45, Ti46, Ti47, Ti48, Ti49, Ti50
      48, 49, 50, 51, // V48, V49, V50, V51
      50, 51, 52, 53, 54, // Cr50, Cr51, Cr52, Cr53, Cr54
      52, 53, 54, 55, // Mn52, Mn53, Mn54, Mn55
      54, 55, 56, 57, 58, 59, 60, // Fe54, Fe55, Fe56, Fe57, Fe58, Fe59, Fe60
      56, 57, 58, 59, 60, // Co56, Co57, Co58, Co59, Co60
      56, 58, 59, 60, 61, 62, 63, 64, // Ni56, Ni58, Ni59, Ni60, Ni61, Ni62, Ni63, Ni64
      // effective A, using abundance of isotopes in GCR, extrapolated from modulated ratios to LIS
      1.01961, // H
      3.85, // He
      6.52381, // Li
      7.93, // Be
      10.6897, // B
      12.0654, // C
      14.55, // N
      16.36, // O
      19, // F
      20.7, // Ne
      23, //Na
      24.58, // Mg
      26.95, // Al
      28.25, // Si
      31., // P
      32.45, // S
      35.75, // Cl
      37.3, // Ar
      40.3, // K
      41.46, // Ca
      45., // Sc
      47.07, // Ti
      50.2, // V
      52.22, // Cr
      54.22, // Mn
      55.89, // Fe
      58.34, // Co
      59.02, // Ni
   };
   const Double_t InverseHalfLife[nPARTICLEs] = { // 1/s, from Wikipedia
      0., 0., // ele, pos
      1./(881.5*s), 0., 0., 0., 1./(12.32*year), // n, p, pbar, H2, H3,
      0., 0., // He3, He4
      0., 0., // Li6, Li7
      1./(53.12*day), 1./(8.19e-17*s), 0., 1./(1.39e6*year), // Be7, Be8, Be9, Be10
      0., 0., // B10, B11
      0., 0., 1./(5730*year), // C12, C13, C14
      0., 0., // N14, N15
      0., 0., 0., // O16, O17, O18
      1./(109.8*min), 0., // F18, F19
      0., 0., 0., // Ne20, Ne21, Ne22
      1./(2.602*year), 0., 1./(14.96*hr), // Na22, Na23, Na24
      0., 0., 0., // Mg24, Mg25, Mg26
      1./(7.17e5*year), 0., // Al26, Al27
      0., 0., 0., 1./(2.62*hr), 1./(153*year), // Si28, Si29, Si30, Si31, Si32
      1./(4.142*s), 0., 1./(14.28*day), 1./(25.3*day), // P29, P31, P32, P33
      1./(1.178*s), 1./(2.572), 0., 0., 0., 1./(87.32*day), 0., // S30, S31, S32, S33, S34, S35, S36
      1./(2.511*s), 0., 1./(3.01e5*year), 0., // Cl33, Cl35, Cl36, Cl37
      1./(0.8445*s), 0., 1./(35*day), 0., 1./(269*year), 0., 1./(109.34*min), 1./(32.9*year), // Ar34, Ar36, Ar37, Ar38, Ar39, Ar40, Ar41, Ar42
      1./(1.226*s), 0., 1./(1.248e9*year), 0., // K37, K39, K40, K41
      0., 1./(1.03e5*year), 0., 0., 0., 1./(162.7*day), 0., 1./(4.5*day), 1./(6.4e19*year), // Ca40, Ca41, Ca42, Ca43, Ca44, Ca45, Ca46, Ca47, Ca48
      1./(3.891*hr), 1./(58.61*hr), 0., 1./(83.79*day), 1./(80.38*day), 1./(43.67*hr), // Sc43, Sc44, Sc45, Sc46, Sc47, Sc48
      1./(63*year), 1./(60.0*year), 0., 0., 0., 0., 0., // Ti44, Ti45, Ti46, Ti47, Ti48, Ti49, Ti50
      1./(16*day), 1./(330*day), 1./(1.5e17*year), 0., // V48, V49, V50, V51
      0., 1./(27.7025*day), 0., 0., 0., // Cr50, Cr51, Cr52, Cr53, Cr54
      1./(5.6*day), 1./(3.74e6*year), 1./(312.03*day), 0., // Mn52, Mn53, Mn54, Mn55
      0., 1./(2.73*year), 0., 0., 0., 1./(44.6*day), 1./(2.6e6*year), // Fe54, Fe55, Fe56, Fe57, Fe58, Fe59, Fe60
      1./(77.27*day), 1./(271.79*day), 1./(70.86*day), 0., 1./(5.2714*year), // Co56, Co57, Co58, Co59, Co60
      1./(6.075*day), 0., 1./(7.6e4*year), 0., 0., 0., 1./(100*year), 0., // Ni56, Ni58, Ni59, Ni60, Ni61, Ni62, Ni63, Ni64
      0. // everything else
   };

   template <typename T>
   Type cast(T iprefix)
   {
      return static_cast<Type>(iprefix);
   }

   Type FromName(const Char_t *name);
   Type FromSymbol(const Char_t *symbol);
   Type FromChargeMassNumber(Double_t Z, Double_t A);
}

namespace Energy
{
   enum Type
   {
      KINETICPERNUCLEON = 0,
      MOMENTUM,
      KINETIC,
      RIGIDITY,
      TOTAL,
      nENERGYs
   };

   const Char_t * const Name[nENERGYs]       = { "nuc", "mom", "kin", "rig", "ene" };
   const Char_t * const Title[nENERGYs]      = { "Kinetic energy", "Momentum", "Kinetic energy", "Rigidity", "Energy" };
   const Char_t * const TitleShort[nENERGYs] = { "Kin./nuc.", "Mom.", "Kin.", "Rig.", "Ene." };
   const Char_t * const Symbol[nENERGYs]     = { "T/n", "p", "T", "R", "E" };
   const Char_t * const UnitName[nENERGYs]   = { "eV/n", "eV/c", "eV", "V", "eV" };

   template <typename T>
   Type cast(T iprefix)
   {
      return static_cast<Type>(iprefix);
   }

   Type FromName(const Char_t *name);
   Type FromTitle(const Char_t *title);
   Type FromTitleShort(const Char_t *title);
   Type FromSymbol(const Char_t *symbol);
   Type FromUnitName(const Char_t *unit);

   typedef Double_t *Range;
}

namespace Unit
{
//~ #ifndef HEP_SYSTEM_OF_UNITS_H
   Bool_t ParseEnergyUnit(const Char_t *energy_unit, Energy::Type &energy_type, SIPrefix::Type &energy_siprefix);

   Bool_t ParseDifferentialFluxUnit(const Char_t *flux_unit, Energy::Type &flux_energy_type, SIPrefix::Type &flux_energy_siprefix, SIPrefix::Type &flux_length_prefix);
   Bool_t ParseIntegralFluxUnit(const Char_t *flux_unit, SIPrefix::Type &flux_length_prefix);

   Char_t *GetEnergyLabelNew(Energy::Type energy_type, SIPrefix::Type energy_prefix);
   Char_t *GetEnergyLabelNew(const Char_t *energy_unit);
   const Char_t *GetEnergyLabel(Energy::Type energy_type, SIPrefix::Type energy_prefix);
   const Char_t *GetEnergyLabel(const Char_t *energy_unit);

   Char_t *GetDifferentialFluxLabelNew(Energy::Type flux_energy_type, SIPrefix::Type flux_energy_prefix, SIPrefix::Type flux_length_prefix);
   Char_t *GetDifferentialFluxLabelNew(const Char_t *flux_unit);
   const Char_t *GetDifferentialFluxLabel(Energy::Type flux_energy_type, SIPrefix::Type flux_energy_prefix, SIPrefix::Type flux_length_prefix);
   const Char_t *GetDifferentialFluxLabel(const Char_t *flux_unit);

   Char_t *GetIntegralFluxLabelNew(SIPrefix::Type flux_length_prefix);
   Char_t *GetIntegralFluxLabelNew(const Char_t *flux_unit);
   const Char_t *GetIntegralFluxLabel(SIPrefix::Type flux_length_prefix);
   const Char_t *GetIntegralFluxLabel(const Char_t *flux_unit);

   Char_t *GetDifferentialFluxLabelNew(Energy::Type flux_energy_type, SIPrefix::Type flux_energy_prefix, SIPrefix::Type flux_length_prefix);
   Char_t *GetDifferentialFluxLabelNew(const Char_t *flux_unit);
   const Char_t *GetDifferentialFluxLabel(Energy::Type flux_energy_type, SIPrefix::Type flux_energy_prefix, SIPrefix::Type flux_length_prefix);
   const Char_t *GetDifferentialFluxLabel(const Char_t *flux_unit);

   Double_t ConvertEnergyType(Double_t energy, Particle::Type particle, Energy::Type from_energy_type, SIPrefix::Type from_energy_prefix, Energy::Type to_energy_type);
   void     ConvertEnergyType(Energy::Range range, Particle::Type particle, Energy::Type from_energy_type, SIPrefix::Type from_energy_prefix, Energy::Type to_energy_type);

   Double_t EnergyJacobian(Double_t energy, Particle::Type particle, Energy::Type from_energy_type, SIPrefix::Type from_energy_prefix, Energy::Type to_energy_type);
   Double_t Beta(Double_t energy, Particle::Type particle, Energy::Type energy_type, SIPrefix::Type energy_prefix);
   Double_t Beta(Double_t energy, Double_t A, Double_t Z, Energy::Type energy_type, SIPrefix::Type energy_prefix);
   Double_t Beta(Double_t gamma);
   Double_t Gamma(Double_t energy, Particle::Type particle, Energy::Type energy_type, SIPrefix::Type energy_prefix);
   Double_t Gamma(Double_t beta);

   Double_t ConvertEnergy(Double_t energy, SIPrefix::Type from_energy_prefix, SIPrefix::Type to_energy_prefix);
   void     ConvertEnergy(Energy::Range range, SIPrefix::Type from_energy_prefix, SIPrefix::Type to_energy_prefix);

   Double_t ConvertEnergy(Double_t energy, const Char_t *from_energy_unit, const Char_t *to_energy_unit, Particle::Type particle);
   Bool_t   ConvertEnergy(Energy::Range range, const Char_t *from_energy_unit, const Char_t *to_energy_unit, Particle::Type particle);

   Double_t ConvertDifferentialFluxType(Double_t flux, Energy::Range range, Particle::Type particle, Energy::Type from_energy_type, SIPrefix::Type from_energy_prefix, Energy::Type to_energy_type);
   Double_t ConvertDifferentialFluxType(Double_t flux, Double_t energy, Particle::Type particle, Energy::Type from_energy_type, SIPrefix::Type from_energy_prefix, Energy::Type to_energy_type);

   Double_t ConvertDifferentialFlux(Double_t flux, SIPrefix::Type from_flux_energy_prefix, SIPrefix::Type from_flux_length_prefix, SIPrefix::Type to_flux_energy_prefix, SIPrefix::Type to_flux_length_prefix);
   Double_t ConvertDifferentialFlux(Double_t flux, const Char_t *from_flux_unit, const Char_t *to_flux_unit);
   Double_t ConvertDifferentialFlux(Double_t flux, Energy::Range range, const Char_t *from_flux_unit, const Char_t *to_flux_unit, Particle::Type particle);
   Double_t ConvertDifferentialFlux(Double_t flux, Double_t energy, const Char_t *from_flux_unit, const Char_t *to_flux_unit, Particle::Type particle);

   Double_t ConvertIntegralFlux(Double_t flux, SIPrefix::Type from_flux_length_prefix, SIPrefix::Type to_flux_length_prefix);
   Double_t ConvertIntegralFlux(Double_t flux, const Char_t *from_flux_unit, const Char_t *to_flux_unit);
//~ #endif
}

namespace Format
{
   extern UShort_t SignificantDigits;

   std::string ToPrecision(Double_t num, UInt_t ndigits = SignificantDigits);
   std::string ToPrecision(Double_t val, Double_t err);

   // latex: 0 = no LaTeX formatting; 1 = TLatex formatting (default); 2 = LaTeX formatting
   std::string Measurement(Double_t val, Double_t err, UShort_t latex = 1);
   std::string Measurement(Double_t val, Double_t lerr, Double_t uerr, UShort_t latex = 1);
}

#endif
