#ifndef _HEADERS_H_
#define _HEADERS_H_

/// C headers
#include <cstdlib>
#include <climits>
#include <cfloat>
#include <cstring>
#include <ctime>
#include <cmath>

#ifndef _XOPEN_SOURCE
#define _XOPEN_SOURCE
#endif
#include <time.h>

/// C++ headers
#include <iostream>
#include <iomanip>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <memory>
#include <algorithm>
#include <utility>

#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wdeprecated-declarations"

/// ROOT headers: system
#include <TROOT.h>
#include <TSystem.h>
#include <TError.h>
#include <TGClient.h>
/// ROOT headers: generic
#include <TString.h>
#include <TRegexp.h>
#include <TExec.h>
#include <TTimeStamp.h>
#include <TParticlePDG.h>
#include <TDatabasePDG.h>
#include <TStopwatch.h>
/// ROOT headers: graphic stuff
#include <TStyle.h>
#include <TCanvas.h>
#include <TAxis.h>
#include <TGaxis.h>
#include <TColor.h>
#include <TArrow.h>
#include <TPaveText.h>
#include <TLegend.h>
#include <TLegendEntry.h>
#include <TAttLine.h>
#include <TAttFill.h>
#include <TAttMarker.h>
/// ROOT headers: histograms
#include <TH1.h>
#include <TH2.h>
#include <THnSparse.h>
#include <THStack.h>
/// ROOT headers: graphs
#include <TGraph.h>
#include <TGraphErrors.h>
#include <TGraphAsymmErrors.h>
#include <TMultiGraph.h>
#include <TGraphSmooth.h>
/// ROOT headers: trees and files
#include <TFile.h>
#include <TChain.h>
#include <TTree.h>
#include <TLeaf.h>
#include <TNtuple.h>
/// ROOT headers: math
#include <TF1.h>
#include <TMath.h>
#include <TMatrixTSym.h>
#include <TVectorT.h>
#include <Math/Integrator.h>
#include <Math/IntegratorMultiDim.h>
#include <TRandom3.h>
/// ROOT headers: fitting
#include <TVirtualFitter.h>
#include <TMinuit.h>
#include <Math/Factory.h>
#include <Math/Minimizer.h>
#include <Math/MinimizerOptions.h>
#include <Math/WrappedMultiTF1.h>
#include <Fit/DataRange.h>
#include <Fit/BinData.h>
#include <Fit/Fitter.h>
#include <Fit/FitConfig.h>
#include <Fit/ParameterSettings.h>
#include <Fit/Chi2FCN.h>
#include <HFitInterface.h>
#include <TBackCompFitter.h>
#include <TFitResult.h>
#include <TFitResultPtr.h>

#pragma GCC diagnostic pop

#endif
