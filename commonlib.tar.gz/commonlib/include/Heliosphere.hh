#ifndef HELIOSPHERE_H_
#define HELIOSPHERE_H_

#include "headers.hh"

#include <TF2.h>
//~ #include <TH3.h>

namespace Heliosphere
{
   class HMF;

   class SolarWindSpeed
   {
      friend class HMF;

      public:
         SolarWindSpeed(Double_t VEq, Double_t VPol, Double_t TiltAngle, Double_t RTS, Double_t s = 2.5, Double_t L = 1.2, Double_t R = 1., Double_t Theta = 90., Double_t Phi = 0.);
         ~SolarWindSpeed();

         TF1 *GetRadialTF1() { return fRadFunc; }    // radial dependence
         TF1 *GetPolarTF1()  { return fPolFunc; }    // polar dependence
         TF2 *GetTF2()       { return fRadPolFunc; } // radial vs polar dependence

         TF1 *GetRadialDivTF1() { return fRadDivFunc; }    // radial dependence of the divergence
         TF1 *GetPolarDivTF1()  { return fPolDivFunc; }    // polar dependence of the divergence
         TF2 *GetDivTF2()       { return fRadPolDivFunc; } // radial vs polar dependence of the divergence

         void SetRadius(Double_t R)       { fR     = R; }
         void SetLatitude(Double_t Theta) { fTheta = Theta; }
         void SetAzimuth(Double_t Phi)    { fPhi   = Phi; }

         Double_t GetSpeed(Double_t R, Double_t Theta, Double_t Phi);

         Double_t GetVEq()       { return fVEq; }
         Double_t GetVPol()      { return fVPol; }
         Double_t GetTiltAngle() { return fTiltAngle; }
         Double_t GetRTS()       { return fRTS; }

         void SetVEq(Double_t VEq);
         void SetVPol(Double_t VPol);
         void SetTiltAngle(Double_t TiltAngle);
         void SetRTS(Double_t RTS);

         //~ TH3 *DrawPolarCone(Double_t Theta, Bool_t same = false);
         //~ TH2 *DrawThetaSlice(Double_t Theta, Option_t *option = "COLZ");
         //~ TH2 *DrawPhiSlice(Double_t Phi, Option_t *option = "COLZ");

      private:
         // coordinates
         Double_t fR;     // Radial distance from the Sun [AU]
         Double_t fTheta; // Polar angle [°]
         Double_t fPhi;   // Azimuthal angle [°]

         // free parameters
         Double_t fVEq;        // Average equatorial solar wind speed at 1 AU [km/s]
         Double_t fVPol;       // Average polar solar wind speed at 1 AU [km/s]
         Double_t fTiltAngle;  // Heliocurrent sheet tilt angle [°]
         Double_t fRTS;        // Position of the termination shock [AU]
         Double_t fs;          // Termination shock compression ratio
         Double_t fL;          // Termination shock scale length

         const Double_t fRSun; // Radius of Sun [AU]
         const Double_t fR0;   // Earth distance from the Sun [AU]
         const Double_t fRHP;  // Position of the heliopause [AU]

         TF1 *fRadFunc;    //! radial dependence
         TF1 *fPolFunc;    //! polar dependence
         TF2 *fRadPolFunc; //! radial vs polar dependence

         TF1 *fRadDivFunc;    //! radial dependence of the divergence
         TF1 *fPolDivFunc;    //! polar dependence of the divergence
         TF2 *fRadPolDivFunc; //! radial vs polar dependence of the divergence

         // radial dependence
         Double_t Radial(Double_t *x, Double_t *par);

         // polar dependence
         Double_t Polar(Double_t *x, Double_t *par);

         // radius vs polar dependence
         Double_t RadialPolar(Double_t *x, Double_t *par);

         // radial dependence
         Double_t RadialDiv(Double_t *x, Double_t *par);

         // polar dependence
         Double_t PolarDiv(Double_t *x, Double_t *par);

         // radius vs polar dependence
         Double_t RadialPolarDiv(Double_t *x, Double_t *par);

         // radial dependence before the termination shock
         Double_t vr_r(Double_t r);

         // polar dependence before the termination shock
         Double_t vr_t(Double_t theta);

         // radial component before the termination shock
         Double_t vr_inn(Double_t r, Double_t theta);

         // radial component inside the heliosheath
         Double_t vr_hs(Double_t r, Double_t theta);

         // radial dependence of the divergence before the termination shock
         Double_t div_vr_r(Double_t r);

         // radial component of the divergence before the termination shock
         Double_t div_vr_inn(Double_t r, Double_t theta);

         // radial component of the divergence inside the heliosheath
         Double_t div_vr_hs(Double_t r, Double_t theta);

         void update_parameter(UShort_t ipar, Double_t par);

         ClassDef(SolarWindSpeed,1)
   };

   class HMF
   {
      public:
         enum Type
         {
            Parker = 0,
            JokipiiKota,
            SmithBieber,
            Fisk, // not implemented
            nTypes
         };

         HMF();
         HMF(Type FieldType, SolarWindSpeed *SolarWind, Double_t B0, Double_t delta = 0, Double_t AlfvenRadius = 20, Double_t R = 1., Double_t Theta = 90., Double_t Phi = 0.);
         ~HMF();

         TF2 *GetMagnitudeTF2() { return fMagFunc; } // radial vs polar dependence of the magnitude
         TF2 *GetRadialTF2()    { return fRadFunc; } // radial vs polar dependence of ther radial component
         TF2 *GetPolarTF2()     { return fPolFunc; } // radial vs polar dependence of the polar component
         TF2 *GetAzimuthalTF2() { return fAziFunc; } // radial vs polar dependence of the azimuthal component

         void SetRadius(Double_t R)       { fR     = R;     fVSW->fR = fR; }
         void SetLatitude(Double_t Theta) { fTheta = Theta; fVSW->fTheta = fTheta; }
         void SetAzimuth(Double_t Phi)    { fPhi   = Phi;   fVSW->fTheta = fTheta; }

         Type     GetType()         { return fFieldType; }
         Double_t GetB0()           { return fB0; }
         Double_t GetDelta()        { return fdelta; }
         Double_t GetAlfvenRadius() { return fb; }

         void SetType(Type FieldType);
         void SetB0(Double_t B0);
         void SetDelta(Double_t delta);
         void SetAlfvenRadius(Double_t AlfvenRadius);

         //~ TH2 *DrawThetaSlice(UShort_t icoo, Double_t Theta, Option_t *option = "COLZ1"); // icoo = { 0=R, 1=Theta, 2=Phi, 3=Magnitude }
         //~ TH2 *DrawPhiSlice(UShort_t icoo, Double_t Phi, Option_t *option = "COLZ1");

      private:
         // coordinates
         Double_t fR;     // Radial distance from the Sun [AU]
         Double_t fTheta; // Polar angle [°]
         Double_t fPhi;   // Azimuthal angle [°]

         Type fFieldType; // Type of HMF

         // free parameters
         Double_t fB0;    // HMF magnitude at Earth [nT]
         Double_t fdelta; // Jokipii-Kóta/Smith-Bieber modification term
         Double_t fb;     // Smith-Bieber modification: Alfvén radius [fRSun]

         Short_t fPolarity; // HMF polarity: positive above HCS, negative below

         const Double_t fOmega; // Average angular rotation speed of the Sun [rad/s]

         SolarWindSpeed *fVSW; // Solar wind speed

         TF2 *fMagFunc; //! radial vs polar dependence of the magnitude
         TF2 *fRadFunc; //! radial vs polar dependence of the radial component
         TF2 *fPolFunc; //! radial vs polar dependence of the radial component
         TF2 *fAziFunc; //! radial vs polar dependence of the radial component

   #ifndef __CINT__
         typedef Double_t (HMF::*hmf_func_ptr)();
         hmf_func_ptr hmf[nTypes][3];
   #else
         void *hmf[nTypes][3]; //!
   #endif

         // radial vs polar dependence of the magnitude
         Double_t Magnitude(Double_t *, Double_t *par);

         // radial vs polar dependence of the radial component
         Double_t Radial(Double_t *x, Double_t *par);

         // radial vs polar dependence of the polar component
         Double_t Polar(Double_t *x, Double_t *par);

         // radial vs polar dependence of the azimuthal component
         Double_t Azimuthal(Double_t *x, Double_t *par);

         // Parker type components
         Double_t parker_radial();
         Double_t parker_polar();
         Double_t parker_azimuthal();

         // Jokipii-Kóta type components
         Double_t jokipiikota_radial();
         Double_t jokipiikota_polar();
         Double_t jokipiikota_azimuthal();

         // Smith-Bieber type components
         Double_t smithbieber_radial();
         Double_t smithbieber_polar();
         Double_t smithbieber_azimuthal();

         ClassDef(HMF,1)
   };

   extern std::string DataPath;
   extern std::string OMNIWebDateRange;

   // tilt angle [deg] (radial model, WSO) for every Carrington rotation
   TGraph *GetTiltAngle(Long64_t begin_date = 0, Long64_t end_date = UINT_MAX, Bool_t radial = false);

   // daily average of the interplanetary magnetic field [nT] (OMNIWeb)
   TGraph *GetIMF(Long64_t begin_date = 0, Long64_t end_date = UINT_MAX);

   // daily average of the solar wind speed [km/s] (OMNIWeb)
   TGraph *GetSWSpeed(Long64_t begin_date = 0, Long64_t end_date = UINT_MAX);

   // 10-days average smoothed Sun's polar field (average, North pole, South pole) [muT] (WSO)
   TMultiGraph *GetPolarField(Long64_t begin_date = 0, Long64_t end_date = UINT_MAX);

   // daily or monthly sunspot number (WDC-SILSO)
   // type = "daily", "monthly", or "smoothed"
   TGraphErrors *GetSunspotNumber(const Char_t *type, Long64_t begin_date = 0, Long64_t end_date = UINT_MAX, Bool_t only_definitive = true);

   // daily or monthly hemispheric sunspot number (North hemisphere, South hemisphere) (WDC-SILSO)
   // type = "daily" or "montlhy"
   TMultiGraph *GetHemisphericSunspotNumber(const Char_t *type, Long64_t begin_date = 0, Long64_t end_date = UINT_MAX, Bool_t only_definitive = true);

   // type = "KFML"
   TGraphErrors *GetSILSOPredictedSunspotNumber(const Char_t *type, Long64_t begin_date = 0, Long64_t end_date = UINT_MAX);

   TGraphAsymmErrors *GetNOAAPredictedSunspotNumber(Long64_t begin_date = 0, Long64_t end_date = UINT_MAX);

   TGraphAsymmErrors *GetNOAAPredictedRadioFlux(Long64_t begin_date = 0, Long64_t end_date = UINT_MAX);

   // daily components with error (North pole, South pole, axial dipole, equatorial dipole) [G] (Sun et al, 2015, ApJ, 798; private communication)
   TMultiGraph *GetSunMagneticFieldComponents(Long64_t begin_date = 0, Long64_t end_date = UINT_MAX);

   class SunspotNumber
   {
      public:
         enum Type
         {
            Total = 0, Hemispheric, nTypes
         };

         enum Period
         {
            Daily = 0, Monthly, nPeriods
         };

         enum ErrorType
         {
            StdDev = 0, StdErr, nErrorTypes
         };

         SunspotNumber(Type type, Period period);

         ~SunspotNumber();

         TGraphErrors *GetTotal(Long64_t begin_date = 0, Long64_t end_date = UINT_MAX, Bool_t only_definitive = true, ErrorType err = StdDev);
         TGraphErrors *GetTotalAverage(std::vector< std::pair<time_t, time_t> > &ranges, Bool_t only_definitive = true, ErrorType err = StdDev);

         TMultiGraph *GetHemispheric(Long64_t begin_date = 0, Long64_t end_date = UINT_MAX, Bool_t only_definitive = true, ErrorType err = StdDev);
         TMultiGraph *GetHemisphericAverage(std::vector< std::pair<time_t, time_t> > &ranges, Bool_t only_definitive = true, ErrorType err = StdDev);

      private:
         TFile *fFile;
         TTree *fTree;

         Type   fType;
         Period fPeriod;

         static const Char_t * const fPeriodName[nPeriods];
         static const Char_t * const fPeriodTitle[nPeriods];
   };
}

#endif
