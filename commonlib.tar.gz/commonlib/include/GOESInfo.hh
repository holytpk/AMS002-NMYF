#ifndef _GOES_INFO_H_
#define _GOES_INFO_H_

#include "headers.hh"
#include "Units.hh"

class GOES;

class GOESInfo
{
   friend class GOES;

   public:
      enum Detector
      {
         EPEAD_A = 0,
         EPEAD_B,
         HEPAD,
         nDETECTORs
      };
      static const UShort_t nDetectors = static_cast<UShort_t>(nDETECTORs);

      enum DataSet
      {
         FULL = 0,
         AVG1M,
         AVG5M,
         SCIENCE,
         STATUS,
         nDATASETs
      };
      static const UShort_t nDataSets = static_cast<UShort_t>(nDATASETs);

      enum DataType
      {
         UNCORRECTED_RATE = 0,    // e FULL 0-2; p FULL 0-6
         CORRECTED_RATE,          // He FULL 0-8; p FULL 7-10
         UNCORRECTED_FLUX,        // e FULL 0-2; e AVG1M,AVG5M 0-2; p FULL 0-6; p AVG1M,AVG5M 0-6
         CORRECTED_FLUX,          // He FULL 0-8; He AVG1M,AVG5M 0-8; e AVG5M 0-2; e SCIENCE 0-1; p FULL 7-10; p AVG5M 0-6; p AVG1M,AVG5M 7-10; p AVG5M 11-17 Z; p AVG5M 18-23
         DEADTIME_CORRECTED_FLUX, // e SCIENCE 0-1
         QUALITY,
         DATA_POINTS,
         YAW_FLIP,
         nDATATYPEs
      };
      static const UShort_t nDataTypes = static_cast<UShort_t>(nDATATYPEs);

      static const UShort_t nParticles = 3;

      typedef std::vector<Detector> DetectorList;

      static const Energy::Type   EnergyType;
      static const SIPrefix::Type EnergyPrefix;
      static const Energy::Type   FluxEnergyType;
      static const SIPrefix::Type FluxEnergyPrefix;
      static const SIPrefix::Type FluxLengthPrefix;

      static const Char_t *EnergyUnit;
      static const Char_t *FluxUnit;

   private:
      static const Particle::Type _particle[nParticles];

      static const Char_t *_detector_name[nDetectors];
      static const Char_t  _detector_symb[nDetectors];

      static UShort_t detector_index(Detector detector);
      static UShort_t detector_index(Char_t detector);
      static UShort_t detector_index(const Char_t *detector);

      static const Char_t *_dataset_name[nDataSets];

      static const Char_t *_datatype_name[nDataTypes];
      static const Char_t *_datatype_title[nDataTypes];
      static const Char_t *_datatype_abbreviation[nDataTypes];

      static const UShort_t  _nMAX_BINs = 24;
      static const UShort_t  _nbins[nParticles][nDataSets];
      static const Double_t  _bin_time[nParticles][nDataSets][_nMAX_BINs];
      static const Double_t  _bin_range[nParticles][_nMAX_BINs][2];
      static const Double_t  _bin_center[nParticles][_nMAX_BINs];
      static const Double_t  _bin_geometrical_factor[nParticles][_nMAX_BINs];
      static const Double_t  _bin_correction_factor[nParticles][_nMAX_BINs];

      static const UShort_t  _nMAX_DATAFILEs = 9;
      static const UShort_t  _nDATAFILEs[nDataSets];
      static const Char_t   *_DATAFILE_NAME[nDataSets][_nMAX_DATAFILEs];
      static const UShort_t  _nPARTICLE_DATAFILEs[nParticles][nDataSets];
      static const UShort_t  _PARTICLE_DATAFILE[nParticles][nDataSets][_nMAX_DATAFILEs];

      static UShort_t _nassociated_particles(UShort_t idataset, UShort_t ifile);
      static Bool_t _is_associated(UShort_t idataset, UShort_t ifile, Particle::Type particle);
      static Bool_t _is_associated(Particle::Type particle);

      static const Bool_t _available_channel[nParticles][nDataSets][nDataTypes][_nMAX_BINs];

   public:
      static Particle::Type Particle(UShort_t iparticle);
      static Particle::Type Particle(const Char_t *particle_name);
      static UShort_t         iParticle(Particle::Type particle);
      static UShort_t         iParticle(const Char_t *particle_name);

      static GOESInfo::DataSet Dataset(UShort_t idataset);
      static GOESInfo::DataSet Dataset(const Char_t *dataset_name);
      static UShort_t            iDataset(DataSet dataset);
      static UShort_t            iDataset(const Char_t *dataset_name);

      static UShort_t nBins(UShort_t iparticle, UShort_t idataset);
      static UShort_t nBins(Particle::Type particle, UShort_t idataset);
      static UShort_t nBins(const Char_t *particle_name, UShort_t idataset);
      static UShort_t nBins(Particle::Type particle, DataSet dataset);
      static UShort_t nBins(const Char_t *particle_name, DataSet dataset);
      static UShort_t nBins(Particle::Type particle, const Char_t *dataset_name);
      static UShort_t nBins(const Char_t *particle_name, const Char_t *dataset_name);

      static Double_t BinTime(UShort_t iparticle, UShort_t idataset, UShort_t ibin);
      static Double_t BinTime(Particle::Type particle, UShort_t idataset, UShort_t ibin);
      static Double_t BinTime(const Char_t *particle_name, UShort_t idataset, UShort_t ibin);
      static Double_t BinTime(Particle::Type particle, DataSet dataset, UShort_t ibin);
      static Double_t BinTime(const Char_t *particle_name, DataSet dataset, UShort_t ibin);
      static Double_t BinTime(Particle::Type particle, const Char_t *dataset_name, UShort_t ibin);
      static Double_t BinTime(const Char_t *particle_name, const Char_t *dataset_name, UShort_t ibin);

      static const Char_t *BinRangeName(UShort_t iparticle, UShort_t ibin, Energy::Type energy_type = EnergyType, SIPrefix::Type energy_prefix = EnergyPrefix);
      static const Char_t *BinRangeName(Particle::Type particle, UShort_t ibin, Energy::Type energy_type = EnergyType, SIPrefix::Type energy_prefix = EnergyPrefix);
      static const Char_t *BinRangeName(const Char_t *particle_name, UShort_t ibin, Energy::Type energy_type = EnergyType, SIPrefix::Type energy_prefix = EnergyPrefix);
      static const Char_t *BinRangeName(UShort_t iparticle, UShort_t ibin, const Char_t *energy_unit);
      static const Char_t *BinRangeName(Particle::Type particle, UShort_t ibin, const Char_t *energy_unit);
      static const Char_t *BinRangeName(const Char_t *particle_name, UShort_t ibin, const Char_t *energy_unit);

      static const Energy::Range BinRange(UShort_t iparticle, UShort_t ibin);
      static const Energy::Range BinRange(Particle::Type particle, UShort_t ibin);
      static const Energy::Range BinRange(const Char_t *particle_name, UShort_t ibin);

      static Double_t BinCenter(UShort_t iparticle, UShort_t ibin);
      static Double_t BinCenter(Particle::Type particle, UShort_t ibin);
      static Double_t BinCenter(const Char_t *particle_name, UShort_t ibin);

      static const Char_t *BinCenterName(UShort_t iparticle, UShort_t ibin, Energy::Type energy_type = EnergyType, SIPrefix::Type energy_prefix = EnergyPrefix);
      static const Char_t *BinCenterName(Particle::Type particle, UShort_t ibin, Energy::Type energy_type = EnergyType, SIPrefix::Type energy_prefix = EnergyPrefix);
      static const Char_t *BinCenterName(const Char_t *particle_name, UShort_t ibin, Energy::Type energy_type = EnergyType, SIPrefix::Type energy_prefix = EnergyPrefix);
      static const Char_t *BinCenterName(UShort_t iparticle, UShort_t ibin, const Char_t *energy_unit);
      static const Char_t *BinCenterName(Particle::Type particle, UShort_t ibin, const Char_t *energy_unit);
      static const Char_t *BinCenterName(const Char_t *particle_name, UShort_t ibin, const Char_t *energy_unit);

      static Double_t BinGeometricalFactor(UShort_t iparticle, UShort_t ibin);
      static Double_t BinGeometricalFactor(Particle::Type particle, UShort_t ibin);
      static Double_t BinGeometricalFactor(const Char_t *particle_name, UShort_t ibin);

      static Double_t BinFluxFactor(UShort_t iparticle, UShort_t ibin);
      static Double_t BinFluxFactor(Particle::Type particle, UShort_t ibin);
      static Double_t BinFluxFactor(const Char_t *particle_name, UShort_t ibin);

      static Double_t BinCorrectionFactor(UShort_t iparticle, UShort_t ibin);
      static Double_t BinCorrectionFactor(Particle::Type particle, UShort_t ibin);
      static Double_t BinCorrectionFactor(const Char_t *particle_name, UShort_t ibin);

      static const Char_t *DetectorName(UShort_t idetector);
      static const Char_t *DetectorName(Detector detector);
      static const Char_t *DetectorName(Char_t detector);

      static const Char_t *DatasetName(UShort_t idataset);
      static const Char_t *DatasetName(DataSet dataset);

      static const Char_t *DatatypeName(UShort_t idatatype);
      static const Char_t *DatatypeName(DataType datatype);

      static const Char_t *DatatypeTitle(UShort_t idatatype);
      static const Char_t *DatatypeTitle(DataType datatype);

      static Char_t DetectorSymbol(UShort_t idetector);
      static Char_t DetectorSymbol(Detector detector);
      static Char_t DetectorSymbol(const Char_t *detector);

      static DetectorList &Detectors(UShort_t iparticle, UShort_t ibin);
      static DetectorList &Detectors(Particle::Type particle, UShort_t ibin);
      static DetectorList &Detectors(const Char_t *particle_name, UShort_t ibin);
};

#endif
