#ifndef PARAMETER_H_
#define PARAMETER_H_

#include "headers.hh"
#include "Units.hh"

struct ParameterInfo
{
   Char_t *Name;
   Char_t *Title;
   Char_t *Symbol;
   Char_t *Unit;

   Double_t Min;
   Double_t Med;
   Double_t Max;

   const Char_t *GetLabel() const;

   void Print(std::ostream &out, Option_t *opt = "") const;
   void Print(Option_t *opt = "") const;
};

struct ModelInfo
{
   Char_t *Name;
   Char_t *Title;
   Char_t *Formula;
   Char_t *NormalizationUnit;

   Double_t Normalization;

   typedef Double_t(Function)(Double_t, Double_t *, Particle::Type, Energy::Type);
   Function *Model;
   Function *GTF;

   UInt_t nParameters;

   ParameterInfo Parameter[20];

   void Print(std::ostream &out, Option_t *opt = "") const;
   void Print(Option_t *opt = "") const;
};

#ifndef PARAMETERINFO_OSTREAM
#define PARAMETERINFO_OSTREAM
std::ostream &operator<<(std::ostream &out, const ParameterInfo &parameter)
#ifndef __DICT__
{
   parameter.Print(out);

   return out;
}
#else
;
#endif

std::ostream &operator<<(std::ostream &out, const ModelInfo &model)
#ifndef __DICT__
{
   model.Print(out);

   return out;
}
#else
;
#endif
#endif

#endif
