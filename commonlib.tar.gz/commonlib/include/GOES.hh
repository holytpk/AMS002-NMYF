#ifndef _GOES_H_
#define _GOES_H_

#include "headers.hh"
#include "DateTimeTools.hh"
#include "GOESInfo.hh"

using namespace std;

class GOES
{
   public:
      GOES(); // default constructor
      GOES(const Char_t *date, const Char_t *particles = ""); // useful constructor
      GOES(const GOES &obj); // copy constructor

#ifndef __clang__
      GOES& operator=(GOES obj); // assignment operator
#endif

      ~GOES(); // destructor

      Bool_t LoadData(const Char_t *date, const Char_t *particles = "");

      void SetDatafilePath(const Char_t *path);
      const Char_t *GetDatafilePath() const;

      void SetScriptPath(const Char_t *path);
      const Char_t *GetScriptPath() const;

      const Char_t *GetDate() const;
      const vector<Particle::Type> &GetParticles() const;

      static const vector<Particle::Type> &ParseParticles(const Char_t *particles);

      const vector<TimeInterval> &GetTimeIntervals() const;
      Bool_t SetTimeIntervals(const Char_t *intervals);
      void SetTimeIntervals(const vector<TimeInterval> &timebins);

      /* Available channels:
       * =============================================================================================================================================================================================================================
       *  Particle | Dataset | _tree_data | Time | Detector  |          Channel names                          | Index |       Range      |   Center   | Comments                           | Datatypes
       * =============================================================================================================================================================================================================================
       *  Helium   | FULL    | [0][0]     |  32s | EPEAD B   | A1E_{QUAL_FLAG,CR,FLUX}                         |   0   |     3.8 -    9.9 |       6.9  |                                    | QUALITY, CORRECTED_RATE, CORRECTED_FLUX
       *           |         |            |      |           | A2E_{QUAL_FLAG,CR,FLUX}                         |   1   |     9.9 -   21.3 |      16.1  |                                    |
       *           |         |            |      |           | A3E_{QUAL_FLAG,CR,FLUX}                         |   2   |    21.3 -   61.0 |      41.2  |                                    |
       *           |         |            |      |           | A4E_{QUAL_FLAG,CR,FLUX}                         |   3   |    60.0 -  160.0 |     120.0  |                                    |
       *           |         |            |      |           | A5E_{QUAL_FLAG,CR,FLUX}                         |   4   |   160.0 -  260.0 |     210.0  |                                    |
       *           |         |            |      |           | A6E_{QUAL_FLAG,CR,FLUX}                         |   5   |   300.0 -  500.0 |     435.0  |                                    |
       * -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
       *           |         | [0][1]     |      | EPEAD A   | A1W_{QUAL_FLAG,CR,FLUX}                         |   0   |     3.8 -    9.9 |       6.9  |                                    |
       *           |         |            |      |           | A2W_{QUAL_FLAG,CR,FLUX}                         |   1   |     9.9 -   21.3 |      16.1  |                                    |
       *           |         |            |      |           | A3W_{QUAL_FLAG,CR,FLUX}                         |   2   |    21.3 -   61.0 |      41.2  |                                    |
       *           |         |            |      |           | A4W_{QUAL_FLAG,CR,FLUX}                         |   3   |    60.0 -  160.0 |     120.0  |                                    |
       *           |         |            |      |           | A5W_{QUAL_FLAG,CR,FLUX}                         |   4   |   160.0 -  260.0 |     210.0  |                                    |
       *           |         |            |      |           | A6W_{QUAL_FLAG,CR,FLUX}                         |   5   |   300.0 -  500.0 |     435.0  |                                    |
       * -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
       *           |         | [0][8]     |      | HEPAD     | A7_{QUAL_FLAG,COUNT_RATE,FLUX}                  |   6   |  2560.0 - 3400.0 |    2980.0  |                                    |
       *           |         |            |      |           | A8_{QUAL_FLAG,COUNT_RATE,FLUX}                  |   7   | >3400.0          |   >3400.0  |                                    |
       * -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
       *           | AVG1M   | [1][0]     |   1m | EPEAD B,A | A1{E,W}_{NUM_PTS,QUAL_FLAG,FLUX}                |   0   |     3.8 -    9.9 |       6.9  |                                    | DATA_POINTS, QUALITY, CORRECTED_FLUX
       *           |         |            |      |           | A2{E,W}_{NUM_PTS,QUAL_FLAG,FLUX}                |   1   |     9.9 -   21.3 |      16.1  |                                    |
       *           |         |            |      |           | A3{E,W}_{NUM_PTS,QUAL_FLAG,FLUX}                |   2   |    21.3 -   61.0 |      41.2  |                                    |
       *           |         |            |      |           | A4{E,W}_{NUM_PTS,QUAL_FLAG,FLUX}                |   3   |    60.0 -  160.0 |     120.0  |                                    |
       *           |         |            |      |           | A5{E,W}_{NUM_PTS,QUAL_FLAG,FLUX}                |   4   |   160.0 -  260.0 |     210.0  |                                    |
       *           |         |            |      |           | A6{E,W}_{NUM_PTS,QUAL_FLAG,FLUX}                |   5   |   300.0 -  500.0 |     435.0  |                                    |
       * -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
       *           | AVG5M   | [2][0]     |   5m |           | A1{E,W}_{NUM_PTS,QUAL_FLAG,FLUX}                |   0   |     3.8 -    9.9 |       6.9  |                                    |
       *           |         |            |      |           | A2{E,W}_{NUM_PTS,QUAL_FLAG,FLUX}                |   1   |     9.9 -   21.3 |      16.1  |                                    |
       *           |         |            |      |           | A3{E,W}_{NUM_PTS,QUAL_FLAG,FLUX}                |   2   |    21.3 -   61.0 |      41.2  |                                    |
       *           |         |            |      |           | A4{E,W}_{NUM_PTS,QUAL_FLAG,FLUX}                |   3   |    60.0 -  160.0 |     120.0  |                                    |
       *           |         |            |      |           | A5{E,W}_{NUM_PTS,QUAL_FLAG,FLUX}                |   4   |   160.0 -  260.0 |     210.0  |                                    |
       *           |         |            |      |           | A6{E,W}_{NUM_PTS,QUAL_FLAG,FLUX}                |   5   |   300.0 -  500.0 |     435.0  |                                    |
       * -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
       *           | AVG1M   | [1][3]     |   1m | HEPAD     | A7_{QUAL_FLAG,NUM_PTS,FLUX}                     |   6   |  2560.0 - 3400.0 |    2980.0  |                                    | QUALITY, DATA_POINTS, CORRECTED_FLUX
       *           |         |            |      |           | A8_{QUAL_FLAG,NUM_PTS,FLUX}                     |   7   | >3400.0          |   >3400.0  |                                    |
       * -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
       *           | AVG5M   | [2][3]     |   5m |           | A7_{QUAL_FLAG,NUM_PTS,FLUX}                     |   6   |  2560.0 - 3400.0 |    2980.0  |                                    |
       *           |         |            |      |           | A8_{QUAL_FLAG,NUM_PTS,FLUX}                     |   7   | >3400.0          |   >3400.0  |                                    |
       * =============================================================================================================================================================================================================================
       *  Electron | FULL    | [0][2]     |   4s | EPEAD B,A | E1{E,W}_{QUAL_FLAG,UNCOR_CR,UNCOR_FLUX}         |   0   |    >0.8          |      >0.8  | UNCOR: not corrected for           | QUALITY, UNCORRECTED_RATE,
       *           |         |            |      |           |                                                 |       |                  |            |        particle contamination      | UNCORRECTED_FLUX
       * -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
       *           |         | [0][3]     |  16s |           | E2{E,W}_{QUAL_FLAG,UNCOR_CR,UNCOR_FLUX}         |   1   |    >2.0          |      >2.0  |                                    |
       * -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
       *           |         | [0][4]     |      |           | E3{E,W}_{QUAL_FLAG,UNCOR_CR,UNCOR_FLUX}         |   2   |    >4.0          |      >4.0  |                                    |
       * -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
       *           | AVG1M   | [1][1]     |   1m | EPEAD B,A | E1{E,W}_{NUM_PTS,QUAL_FLAG,UNCOR_FLUX}          |   0   |    >0.8          |      >0.8  |                                    | DATA_POINTS, QUALITY, UNCORRECTED_FLUX
       *           |         |            |      |           | E2{E,W}_{NUM_PTS,QUAL_FLAG,UNCOR_FLUX}          |   1   |    >2.0          |      >2.0  |                                    |
       *           |         |            |      |           | E3{E,W}_{NUM_PTS,QUAL_FLAG,UNCOR_FLUX}          |   2   |    >4.0          |      >4.0  |                                    |
       * -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
       *           | AVG5M   | [2][1]     |   5m | EPEAD B,A | E1{E,W}_{NUM_PTS,QUAL_FLAG,UNCOR_FLUX,COR_FLUX} |   0   |    >0.8          |      >0.8  | COR: corrected for proton          | DATA_POINTS, QUALITY, UNCORRECTED_FLUX
       *           |         |            |      |           | E2{E,W}_{NUM_PTS,QUAL_FLAG,UNCOR_FLUX,COR_FLUX} |   1   |    >2.0          |      >2.0  |      contamination                 | CORRECTED_FLUX
       *           |         |            |      |           | E3{E,W}_{NUM_PTS,QUAL_FLAG,UNCOR_FLUX,COR_FLUX} |   2   |    >4.0          |      >4.0  |                                    |
       * -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
       *           | SCIENCE | [3][0]     |   1m | EPEAD A,B | E1{W,E}_{DTC_FLUX,COR_FLUX,COR_ERR,DQF}         |   0   |    >0.8          |      >0.8  | DTC: corrected for dead time       | DEADTIME_CORRECTED_FLUX,
       *           |         |            |      |           | E2{W,E}_{DTC_FLUX,COR_FLUX,COR_ERR,DQF}         |   1   |    >2.0          |      >2.0  | COR: corrected for dead time       | CORRECTED_FLUX, QUALITY
       *           |         |            |      |           |                                                 |       |                  |            |      and proton contamination,     |
       *           |         |            |      |           |                                                 |       |                  |            |      backgrounds removed           |
       *           |         |            |      |           |                                                 |       |                  |            | ERR: fractional standard deviation |
       *           |         |            |      |           |                                                 |       |                  |            | DQF: quality due to solar proton   |
       *           |         |            |      |           |                                                 |       |                  |            |      contamination                 |
       * =============================================================================================================================================================================================================================
       *  Proton   | FULL    | [0][5]     |   8s | EPEAD B,A | P1{E,W}_{QUAL_FLAG,UNCOR_CR,UNCOR_FLUX}         |   0   |     0.74-    4.2 |       2.5  | UNCOR: not corrected for           | QUALITY, UNCORRECTED_RATE,
       *           |         |            |      |           |                                                 |       |                  |            |        particle contamination      | UNCORRECTED_FLUX
       * -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
       *           |         | [0][6]     |  32s | EPEAD B   | P2E_{QUAL_FLAG,UNCOR_CR,UNCOR_FLUX}             |   1   |     4.2 -    8.7 |       6.5  |                                    |
       *           |         |            |      |           | P3E_{QUAL_FLAG,UNCOR_CR,UNCOR_FLUX}             |   2   |     8.7 -   14.5 |      11.6  |                                    |
       *           |         |            |      |           | P4E_{QUAL_FLAG,UNCOR_CR,UNCOR_FLUX}             |   3   |    15.0 -   40.0 |      30.6  |                                    |
       *           |         |            |      |           | P5E_{QUAL_FLAG,UNCOR_CR,UNCOR_FLUX}             |   4   |    38.0 -   82.0 |      63.1  |                                    |
       *           |         |            |      |           | P6E_{QUAL_FLAG,UNCOR_CR,UNCOR_FLUX}             |   5   |    84.0 -  200.0 |     165.0  |                                    |
       *           |         |            |      |           | P7E_{QUAL_FLAG,UNCOR_CR,UNCOR_FLUX}             |   6   |   110.0 -  900.0 |     433.0  |                                    |
       * -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
       *           |         | [0][7]     |  32s | EPEAD A   | P2W_{QUAL_FLAG,UNCOR_CR,UNCOR_FLUX}             |   1   |     4.2 -    8.7 |       6.5  |                                    |
       *           |         |            |      |           | P3W_{QUAL_FLAG,UNCOR_CR,UNCOR_FLUX}             |   2   |     8.7 -   14.5 |      11.6  |                                    |
       *           |         |            |      |           | P4W_{QUAL_FLAG,UNCOR_CR,UNCOR_FLUX}             |   3   |    15.0 -   40.0 |      30.6  |                                    |
       *           |         |            |      |           | P5W_{QUAL_FLAG,UNCOR_CR,UNCOR_FLUX}             |   4   |    38.0 -   82.0 |      63.1  |                                    |
       *           |         |            |      |           | P6W_{QUAL_FLAG,UNCOR_CR,UNCOR_FLUX}             |   5   |    84.0 -  200.0 |     165.0  |                                    |
       *           |         |            |      |           | P7W_{QUAL_FLAG,UNCOR_CR,UNCOR_FLUX}             |   6   |   110.0 -  900.0 |     433.0  |                                    |
       * -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
       *           |         | [0][8]     |  32s | HEPAD     | P8_{QUAL_FLAG,COUNT_RATE,FLUX}                  |   7   |    330.0 - 420.0 |     375.0  |                                    | QUALITY, CORRECTED_RATE, CORRECTED_FLUX
       *           |         |            |      |           | P9_{QUAL_FLAG,COUNT_RATE,FLUX}                  |   8   |    420.0 - 510.0 |     465.0  |                                    |
       *           |         |            |      |           | P10_{QUAL_FLAG,COUNT_RATE,FLUX}                 |   9   |    510.0 - 700.0 |     605.0  |                                    |
       *           |         |            |      |           | P11_{QUAL_FLAG,COUNT_RATE,FLUX}                 |  10   |   >700.0         |    >700.0  |                                    |
       * -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
       *           | AVG5M   | [2][4]     |   5m | EPEAD B,A | ZPGT1{E,W}{,_QUAL_FLAG}                         |  11   |      >1.0        |      >1.0  | corrected for particle             | CORRECTED_FLUX, QUALITY
       *           |         |            |      |           | ZPGT5{E,W}{,_QUAL_FLAG}                         |  12   |      >5.0        |      >5.0  | contamination                      |
       *           |         |            |      |           | ZPGT10{E,W}{,_QUAL_FLAG}                        |  13   |     >10.0        |     >10.0  |                                    |
       *           |         |            |      |           | ZPGT30{E,W}{,_QUAL_FLAG}                        |  14   |     >30.0        |     >30.0  |                                    |
       *           |         |            |      |           | ZPGT50{E,W}{,_QUAL_FLAG}                        |  15   |     >50.0        |     >50.0  |                                    |
       *           |         |            |      |           | ZPGT60{E,W}{,_QUAL_FLAG}                        |  16   |     >60.0        |     >60.0  |                                    |
       *           |         |            |      |           | ZPGT100{E,W}{,_QUAL_FLAG}                       |  17   |    >100.0        |    >100.0  |                                    |
       *           |         |            |      |           | ZPEQ5{E,W}{,_QUAL_FLAG}                         |  18   |                  |       5.0  |                                    |
       *           |         |            |      |           | ZPEQ15{E,W}{,_QUAL_FLAG}                        |  19   |                  |      10.0  |                                    |
       *           |         |            |      |           | ZPEQ30{E,W}{,_QUAL_FLAG}                        |  20   |                  |      30.0  |                                    |
       *           |         |            |      |           | ZPEQ50{E,W}{,_QUAL_FLAG}                        |  21   |                  |      50.0  |                                    |
       *           |         |            |      |           | ZPEQ60{E,W}{,_QUAL_FLAG}                        |  21   |                  |      60.0  |                                    |
       *           |         |            |      |           | ZPEQ100{E,W}{,_QUAL_FLAG}                       |  23   |                  |     100.0  |                                    |
       * -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
       *           | AVG1M   | [1][2]     |   1m | EPEAD B,A | P1{E,W}_{NUM_PTS,QUAL_FLAG,UNCOR_FLUX}          |   0   |     0.74-    4.2 |       2.5  | UNCOR: not corrected for           | DATA_POINTS, QUALITY, UNCORRECTED_FLUX
       *           |         |            |      |           | P2{E,W}_{NUM_PTS,QUAL_FLAG,UNCOR_FLUX}          |   1   |     4.2 -    8.7 |       6.5  |        particle contamination      |
       *           |         |            |      |           | P3{E,W}_{NUM_PTS,QUAL_FLAG,UNCOR_FLUX}          |   2   |     8.7 -   14.5 |      11.6  |                                    |
       *           |         |            |      |           | P4{E,W}_{NUM_PTS,QUAL_FLAG,UNCOR_FLUX}          |   3   |    15.0 -   40.0 |      30.6  |                                    |
       *           |         |            |      |           | P5{E,W}_{NUM_PTS,QUAL_FLAG,UNCOR_FLUX}          |   4   |    38.0 -   82.0 |      63.1  |                                    |
       *           |         |            |      |           | P6{E,W}_{NUM_PTS,QUAL_FLAG,UNCOR_FLUX}          |   5   |    84.0 -  200.0 |     165.0  |                                    |
       *           |         |            |      |           | P7{E,W}_{NUM_PTS,QUAL_FLAG,UNCOR_FLUX}          |   6   |   110.0 -  900.0 |     433.0  |                                    |
       * -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
       *           | AVG5M   | [2][2]     |   5m | EPEAD B,A | P1{E,W}_{NUM_PTS,QUAL_FLAG,UNCOR_FLUX,COR_FLUX} |   0   |     0.74-    4.2 |       2.5  | COR: corrected for electron        | DATA_POINTS, QUALITY, UNCORRECTED_FLUX
       *           |         |            |      |           | P2{E,W}_{NUM_PTS,QUAL_FLAG,UNCOR_FLUX,COR_FLUX} |   1   |     4.2 -    8.7 |       6.5  |      contamination                 | CORRECTED_FLUX
       *           |         |            |      |           | P3{E,W}_{NUM_PTS,QUAL_FLAG,UNCOR_FLUX,COR_FLUX} |   2   |     8.7 -   14.5 |      11.6  |                                    |
       *           |         |            |      |           | P4{E,W}_{NUM_PTS,QUAL_FLAG,UNCOR_FLUX,COR_FLUX} |   3   |    15.0 -   40.0 |      30.6  |                                    |
       *           |         |            |      |           | P5{E,W}_{NUM_PTS,QUAL_FLAG,UNCOR_FLUX,COR_FLUX} |   4   |    38.0 -   82.0 |      63.1  |                                    |
       *           |         |            |      |           | P6{E,W}_{NUM_PTS,QUAL_FLAG,UNCOR_FLUX,COR_FLUX} |   5   |    84.0 -  200.0 |     165.0  |                                    |
       *           |         |            |      |           | P7{E,W}_{NUM_PTS,QUAL_FLAG,UNCOR_FLUX,COR_FLUX} |   6   |   110.0 -  900.0 |     433.0  |                                    |
       * -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
       *           | AVG1M   | [1][3]     |   1m | HEPAD     | P8_{QUAL_FLAG,NUM_PTS,FLUX}                     |   7   |    330.0 - 420.0 |     375.0  |                                    | QUALITY, DATA_POINTS, CORRECTED_FLUX
       *           |         |            |      |           | P9_{QUAL_FLAG,NUM_PTS,FLUX}                     |   8   |    420.0 - 510.0 |     465.0  |                                    |
       *           |         |            |      |           | P10_{QUAL_FLAG,NUM_PTS,FLUX}                    |   9   |    510.0 - 700.0 |     605.0  |                                    |
       *           |         |            |      |           | P11_{QUAL_FLAG,NUM_PTS,FLUX}                    |  10   |   >700.0         |    >700.0  |                                    |
       * -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
       *           | AVG5M   | [2][3]     |   5m | HEPAD     | P8_{QUAL_FLAG,NUM_PTS,FLUX}                     |   7   |    330.0 - 420.0 |     375.0  |                                    |
       *           |         |            |      |           | P9_{QUAL_FLAG,NUM_PTS,FLUX}                     |   8   |    420.0 - 510.0 |     465.0  |                                    |
       *           |         |            |      |           | P10_{QUAL_FLAG,NUM_PTS,FLUX}                    |   9   |    510.0 - 700.0 |     605.0  |                                    |
       *           |         |            |      |           | P11_{QUAL_FLAG,NUM_PTS,FLUX}                    |  10   |   >700.0         |    >700.0  |                                    |
       * =============================================================================================================================================================================================================================
       *           | STATUS  | [4][0]     |   1m | EPEAD     | ORIENTATION_FLAG                                |       |                  |            | Yaw-flip flag (EPEADorientation)   | YAW_FLIP
       *           |         |            |      |           |                                                 |       |                  |            |    0: EPEAD B faces West,          |
       *           |         |            |      |           |                                                 |       |                  |            |       EPEAD A faces East           |
       *           |         |            |      |           |                                                 |       |                  |            |    1: EPEAD B faces East,          |
       *           |         |            |      |           |                                                 |       |                  |            |       EPEAD A faces West           |
       *           |         |            |      |           |                                                 |       |                  |            |    2: flipping in progress         |
       * =============================================================================================================================================================================================================================
       */

      TGraphErrors *GetTimeDependence(GOESInfo::DataSet dataset, GOESInfo::DataType datatype, Particle::Type particle, UShort_t ibin, GOESInfo::Detector detector, Bool_t exclude_bad_quality = true, Bool_t sideband_correction = true,
         Bool_t use_corrected_geometrical_factor = true);

      TGraphAsymmErrors **GetEnergyDependence(GOESInfo::DataSet dataset, GOESInfo::DataType datatype, Particle::Type particle, vector<UShort_t> &bins, const Char_t *intervals, GOESInfo::Detector detector, Bool_t sideband_correction = true,
         Bool_t error_is_statistical = true, Bool_t use_corrected_geometrical_factor = true);
      TGraphAsymmErrors **GetEnergyDependence(GOESInfo::DataSet dataset, GOESInfo::DataType datatype, Particle::Type particle, vector<UShort_t> &bins, GOESInfo::Detector detector, Bool_t sideband_correction = true,
         Bool_t error_is_statistical = true, Bool_t use_corrected_geometrical_factor = true);

      // Get corrected differential proton flux from HEPAD: choice between FULL, AVG1M, AVG5M
      TGraphAsymmErrors **GetDifferentialProtonFluxFromHEPAD(GOESInfo::DataSet dataset, const Char_t *intervals, Bool_t sideband_correction = true, Bool_t error_is_statistical = true, Bool_t use_corrected_geometrical_factor = true);
      TGraphAsymmErrors **GetDifferentialProtonFluxFromHEPAD(GOESInfo::DataSet dataset, Bool_t sideband_correction = true, Bool_t error_is_statistical = true, Bool_t use_corrected_geometrical_factor = true);
      // Get corrected differential proton flux from EPEAD: only AVG5M
      TGraphAsymmErrors **GetDifferentialProtonFluxFromEPEAD(GOESInfo::Detector detector, const Char_t *intervals, Bool_t error_is_statistical = true, Bool_t use_corrected_geometrical_factor = true);
      TGraphAsymmErrors **GetDifferentialProtonFluxFromEPEAD(GOESInfo::Detector detector, Bool_t error_is_statistical = true, Bool_t use_corrected_geometrical_factor = true);
      // Get corrected differential proton flux from EPEAD+HEPAD: only AVG5M
      TGraphAsymmErrors **GetDifferentialProtonFluxFullRange(GOESInfo::Detector detector, const Char_t *intervals, Bool_t sideband_correction = true, Bool_t error_is_statistical = true, Bool_t use_corrected_geometrical_factor = true);
      TGraphAsymmErrors **GetDifferentialProtonFluxFullRange(GOESInfo::Detector detector, Bool_t sideband_correction = true, Bool_t error_is_statistical = true, Bool_t use_corrected_geometrical_factor = true);
      // Get corrected differential proton flux from EPEAD integral channels: only AVG5M
      TGraphAsymmErrors **GetDifferentialProtonFluxFromIntegralChannels(GOESInfo::Detector detector, const Char_t *intervals, Bool_t error_is_statistical = true);
      TGraphAsymmErrors **GetDifferentialProtonFluxFromIntegralChannels(GOESInfo::Detector detector, Bool_t error_is_statistical = true);
      // Get corrected differential proton flux from EPEAD integral channels + HEPAD: only AVG5M
      TGraphAsymmErrors **GetDifferentialProtonFluxFromIntegralChannelsFullRange(GOESInfo::Detector detector, const Char_t *intervals, Bool_t sideband_correction, Bool_t error_is_statistical = true, Bool_t use_corrected_geometrical_factor = true);
      TGraphAsymmErrors **GetDifferentialProtonFluxFromIntegralChannelsFullRange(GOESInfo::Detector detector, Bool_t sideband_correction, Bool_t error_is_statistical = true, Bool_t use_corrected_geometrical_factor = true);

      // Get corrected differential helium flux from HEPAD: choice between FULL, AVG1M, AVG5M
      TGraphAsymmErrors **GetDifferentialHeliumFluxFromHEPAD(GOESInfo::DataSet dataset, const Char_t *intervals, Bool_t error_is_statistical = true, Bool_t use_corrected_geometrical_factor = true);
      TGraphAsymmErrors **GetDifferentialHeliumFluxFromHEPAD(GOESInfo::DataSet dataset, Bool_t error_is_statistical = true, Bool_t use_corrected_geometrical_factor = true);
      // Get corrected differential helium flux from EPEAD: choice between FULL, AVG1M, AVG5M
      TGraphAsymmErrors **GetDifferentialHeliumFluxFromEPEAD(GOESInfo::DataSet dataset, GOESInfo::Detector detector, const Char_t *intervals, Bool_t error_is_statistical = true, Bool_t use_corrected_geometrical_factor = true);
      TGraphAsymmErrors **GetDifferentialHeliumFluxFromEPEAD(GOESInfo::DataSet dataset, GOESInfo::Detector detector, Bool_t error_is_statistical = true, Bool_t use_corrected_geometrical_factor = true);
      // Get corrected differential helium flux from EPEAD+HEPAD: choice between FULL, AVG1M, AVG5M
      TGraphAsymmErrors **GetDifferentialHeliumFluxFullRange(GOESInfo::DataSet dataset, GOESInfo::Detector detector, const Char_t *intervals, Bool_t error_is_statistical = true, Bool_t use_corrected_geometrical_factor = true);
      TGraphAsymmErrors **GetDifferentialHeliumFluxFullRange(GOESInfo::DataSet dataset, GOESInfo::Detector detector, Bool_t error_is_statistical = true, Bool_t use_corrected_geometrical_factor = true);

   private:
      TFile *_file_data[GOESInfo::nDataSets][GOESInfo::_nMAX_DATAFILEs];
      TTree *_tree_data[GOESInfo::nDataSets][GOESInfo::_nMAX_DATAFILEs];

      static const UShort_t _PATH_LENGTH = 256;
      static const UShort_t _STR_LENGTH  = 128;
      Char_t _datafile_path[_PATH_LENGTH];
      Char_t _script_path[_PATH_LENGTH];

      Char_t *_date;
      vector<Particle::Type> _particles;

      Char_t *_intervals;
      vector<TimeInterval> _timebins;

      void _init(const Char_t *date = "", const Char_t *particles = "");
      void _reset();

      void _parse_particles(const Char_t *particles);

      Bool_t _set_date(const Char_t *date);
      Char_t *_set_string(const Char_t *string);

      Bool_t _load_data();
      Bool_t _load_datafile(UShort_t idatatype, UShort_t ifile);

      Bool_t _lazy_parse_intervals(const Char_t *intervals);

      Bool_t _get_timegraph_name(Char_t *name, GOESInfo::DataSet dataset, GOESInfo::DataType datatype, Particle::Type particle, UShort_t ibin, GOESInfo::Detector detector, Bool_t exclude_bad_quality, Bool_t sideband_correction,
         Bool_t use_corrected_geometrical_factor);
      Bool_t _get_timegraph_title(Char_t *title, GOESInfo::DataSet dataset, GOESInfo::DataType datatype, Particle::Type particle, UShort_t ibin, GOESInfo::Detector detector, Bool_t exclude_bad_quality, Bool_t sideband_correction,
         Bool_t use_corrected_geometrical_factor);

      Bool_t _get_energygraph_title(Char_t *title, GOESInfo::DataSet dataset, GOESInfo::DataType datatype, Particle::Type particle, vector<UShort_t> &bins, TimeInterval &interval, GOESInfo::Detector detector, Bool_t sideband_correction,
         Bool_t error_is_statistical, Bool_t use_corrected_geometrical_factor);
      Bool_t _get_energygraph_name(Char_t *name, GOESInfo::DataSet dataset, GOESInfo::DataType datatype, Particle::Type particle, vector<UShort_t> &bins, TimeInterval &interval, GOESInfo::Detector detector, Bool_t sideband_correction,
         Bool_t error_is_statistical, Bool_t use_corrected_geometrical_factor);

      TGraphErrors *_get_graph_vs_time(GOESInfo::DataSet dataset, GOESInfo::DataType datatype, Particle::Type particle, UShort_t ibin, GOESInfo::Detector detector, Bool_t exclude_bad_quality, Bool_t sideband_correction,
         Bool_t use_corrected_geometrical_factor);
      TGraphAsymmErrors **_get_graph_vs_energy(GOESInfo::DataSet dataset, GOESInfo::DataType datatype, Particle::Type particle, vector<UShort_t> &bins, GOESInfo::Detector detector, Bool_t sideband_correction, Bool_t error_is_statistical,
         Bool_t use_corrected_geometrical_factor);

      TGraphErrors *_get_time_graph_helium(GOESInfo::DataSet dataset, GOESInfo::DataType datatype, UShort_t ibin, GOESInfo::Detector detector, Bool_t exclude_bad_quality, Bool_t use_corrected_geometrical_factor);
      TGraphErrors *_get_time_graph_proton(GOESInfo::DataSet dataset, GOESInfo::DataType datatype, UShort_t ibin, GOESInfo::Detector detector, Bool_t exclude_bad_quality, Bool_t sideband_correction, Bool_t use_corrected_geometrical_factor);
      TGraphErrors *_get_time_graph_yawflip();
};

#endif
