#ifndef FIT_TOOLS_H_
#define FIT_TOOLS_H_

#include "headers.hh"
#include "ModulationModels.hh"
#include "LISModels.hh"
#include "Experiments.hh"
#include "Spline.hh"

namespace FitTools
{
   // structure to holds the sum of the chi2 of the single functions to be fitted
   struct GlobalChi2
   {
      public:
         // par_indices = each element is a vector whose elements are the indices of the corresponding parameter in the array par passed to operator()
         GlobalChi2(std::vector<ROOT::Math::IMultiGenFunction *> &f_chi2s, std::vector< std::vector<Int_t> > &par_indices);

         Double_t operator() (const Double_t *par) const;
         Double_t operator() (UShort_t ichi2, const Double_t *par) const;

         UShort_t nDatasets() { return _f_chi2s.size(); }
         UInt_t DataSize();

         void Print();

      private:
         std::vector<ROOT::Math::IMultiGenFunction *> _f_chi2s;
         std::vector< std::vector<Int_t> > _par_indices;
         std::vector<Double_t *> _pars;
   };

   struct EnergyRange
   {
      Double_t Min;
      Double_t Max;
   };
#ifndef ENERGYRANGE_OSTREAM
#define ENERGYRANGE_OSTREAM
std::ostream &operator<<(std::ostream &out, const FitTools::EnergyRange &range)
#ifndef __DICT__
{
   out << "{ " << range.Min << ", " << range.Max << "}";

   return out;
}
#else
;
#endif
#endif

   class ModelWithShift
   {
      public:
         ModelWithShift(TF1 *model, Double_t shift);

         Double_t operator()(Double_t *x, Double_t *par) const;

      private:
         TF1 *_model;
         Double_t _shift; // [GV]
   };

   TF1 *CreateModelWithShift(TF1 *fit_model, Double_t shift);

   class ModelPlusError
   {
      public:
         ModelPlusError(TF1 *model, TGraph *error, Double_t sign);

         Double_t operator()(Double_t *x, Double_t *par) const;

      private:
         TF1 *_model;
         TGraph *_error;
         Double_t _sign;
         Particle::Type _particle;
         Energy::Type _energy;
         ModulationModels::Type _modmodel;
   };

   TF1 *CreateModelPlusError(TF1 *fit_model, TGraph *error, Double_t sign);

   void PrintParamSettings(ROOT::Fit::Fitter &fitter);

   // Minimize a parabola on the given graph range (errors are not taken into account)
   Double_t MinimizeParabola(TGraph *g, UInt_t first_point, UInt_t last_point, Double_t &a, Double_t &b, Double_t &c);

   void SetCommonFitterOptions(ROOT::Fit::Fitter &fitter);

   // from generic TF1 to Fitter
   void CopyParameters(TF1 *f_fit, ROOT::Fit::Fitter &fitter);

   // from ModulationModels TF1 to Fitter
   void CopyParameters(TF1 *f_fit, UShort_t nlisfluxes, UShort_t nmodfluxes, ROOT::Fit::Fitter &fitter, Int_t **par_index);

   // from ModulationModels TF1 to Fitter
   void CopyParameters(ModulationModels::ForceField *ffa, TF1 *f_fit, UShort_t nlisfluxes, UShort_t nmodfluxes, ROOT::Fit::Fitter &fitter, Int_t **par_index);

   // from ModulationModels TF1 to LISModels TF1
   void CopyParameters(TF1 *f_mod, TF1 *f_lis);

   void GetFitRange(TObject *obj, TF1 *f_fit, Bool_t use_range, Double_t &enemin, Double_t &enemax);

   void GetFitRange(TObjArray &arr, TF1 *f_fit, Bool_t use_range, std::vector<Double_t> &enemin, std::vector<Double_t> &enemax, Double_t &minrange, Double_t &maxrange);

   void GetFitRange(TObjArray &lis, TObjArray &mod, TF1 *f_fit, Bool_t use_range, std::vector<FitTools::EnergyRange> &range, Double_t &minrange, Double_t &maxrange);

   /* Fit and chi2 options
    * I = compute integral of TF1 in bin
    * R = use TF1 range
    * E = use MINOS errors
    */

   // Get chi2 between f_fit and obj
   Double_t GetChiSquare(TObject *obj, TF1 *f_fit, Option_t *option, Double_t enemin = DBL_MIN, Double_t enemax = DBL_MAX);

   // Fit obj with f_fit
   void Fit(TObject *obj, TF1 *f_fit, Option_t *option, ROOT::Fit::Fitter &fitter, Double_t enemin = DBL_MIN, Double_t enemax = DBL_MAX, UShort_t nfits = 1);

   // Get chi2 between f_fit and all objs
   Double_t GetCombinedChiSquare(TObjArray &arr, TF1 *f_fit, Option_t *option, std::vector<Double_t> &enemin, std::vector<Double_t> &enemax, std::vector<Double_t> &chi2norm);

   // Fit all objs in arr with f_fit
   void FitCombinedData(TObjArray &arr, TF1 *f_fit, Option_t *option, std::vector<Double_t> &enemin, std::vector<Double_t> &enemax, std::vector<Double_t> &chi2norm, ROOT::Fit::Fitter &fitter, UShort_t nfits = 1);

   // Fit all objs in lis with f_fit (no modulation) and all objs in mod with f_fit (modulation)
   void FitCombinedLISData(TObjArray &lis, TObjArray &mod, TF1 *f_fit, Option_t *option, std::vector<FitTools::EnergyRange> &enerange, std::vector<Double_t> &chi2norm, std::vector<TF1 *> &fits,
      ROOT::Fit::Fitter &fitter, UShort_t nfits = 1);

   void FitCombinedLISData(ModulationModels::ForceField *ffa, TObjArray &lis, TObjArray &mod, Option_t *option, std::vector<FitTools::EnergyRange> &enerange, std::vector<Double_t> &chi2norm, std::vector<TF1 *> &fits,
      ROOT::Fit::Fitter &fitter, UShort_t nfits = 1);

   // Fit all objs in lis with f_fit (no modulation) and all objs in mod with f_fit (modulation); apply 1/x -> 1/x + 1/shift
   void FitCombinedLISDataWithShift(TObjArray &lis, TObjArray &mod, TF1 *f_fit, Double_t shift, Option_t *option, std::vector<FitTools::EnergyRange> &enerange, std::vector<Double_t> &chi2norm, std::vector<TF1 *> &fits,
      ROOT::Fit::Fitter &fitter, UShort_t nfits = 1);

   // Fit all objs in lis with f_fit (no modulation) and all objs in mod with f_fit (modulation)
   GlobalChi2 *BuildGlobalChi2(TObjArray &lis, TObjArray &mod, TF1 *f_fit, Option_t *option, std::vector<FitTools::EnergyRange> &enerange, ROOT::Fit::Fitter &fitter);

   struct FitResult
   {
      Particle::Type Particle;
      Energy::Type Energy;

      const Experiments::DatasetInfo *Dataset;
      TH1 *Data;
      Double_t Range[2];

      ROOT::Fit::Fitter Fitter;
      TF1 *FitModel;
      Double_t Chi2Norm;

      TH1 *ConfidenceInterval;
      TH1 *FitRatio;
      TH1 *FitResidual;
      TH1 *FitError;

      void Copy(FitResult *obj, Bool_t copy_result = true);

      void Fit(Option_t *option = "I", UShort_t nfits = 1);

      void RescaleDataErrors();

      void ComputeResiduals(Bool_t use_range = false, Bool_t use_integral = true, Bool_t is_log = true, Double_t confint = 0.683, Bool_t force = false);

      void ComputeModelErrors(Bool_t use_range = true, Bool_t use_integral = false, Bool_t is_log = true, Double_t confint = 0.683, Bool_t force = false);

      TDirectory *Write(const Char_t *dirname = "FitResult");

      void Read();

      Bool_t residuals_computed;
      Bool_t model_errors_computed;
   };

   struct LISFitResult
   {
      Particle::Type Particle;
      Energy::Type Energy;
      LISModels::Type LISModel;

      const Experiments::DatasetInfo *Dataset;
      TH1 *Data;
      Double_t Range[2];

      ROOT::Fit::Fitter Fitter;
      TF1 *FitModel;

      TH1 *ConfidenceInterval;
      TH1 *FitRatio;
      TH1 *FitResidual;
      TH1 *FitError;

      void Copy(LISFitResult *obj);

      void Fit(Option_t *option = "I", UShort_t nfits = 1);

      void RescaleDataErrors();

      void ComputeResiduals(Bool_t use_range = false, Bool_t use_integral = true, Bool_t is_log = true, Double_t confint = 0.683);

      void ComputeModelErrors(Bool_t use_range = true, Bool_t use_integral = false, Bool_t is_log = true, Double_t confint = 0.683);

      Bool_t residuals_computed;
      Bool_t model_errors_computed;
   };

   struct SplineFitResult
   {
      Particle::Type Particle;
      Energy::Type   Energy;

      const Experiments::DatasetInfo *Dataset;
      TH1 *Data;
      Double_t Range[2];

      Spline *SplineModel;

      ROOT::Fit::Fitter Fitter;

      TH1 *ConfidenceInterval;
      TH1 *FitRatio;
      TH1 *FitResidual;
      TH1 *FitError;

      void Copy(SplineFitResult &obj);

      void Fit(Option_t *option = "I", UShort_t nfits = 1);

      void RescaleDataErrors();

      void ComputeResiduals(Bool_t use_range = false, Bool_t use_integral = true, Bool_t is_log = true, Double_t confint = 0.683);

      void ComputeModelErrors(Bool_t use_range = true, Bool_t use_integral = false, Bool_t is_log = true, Double_t confint = 0.683);

      Bool_t residuals_computed;
      Bool_t model_errors_computed;
   };

   struct CombinedLISFitResult
   {
      Particle::Type         Particle;
      Energy::Type           Energy;
      LISModels::Type        LISModel;
      ModulationModels::Type ModulationModel;

      const Experiments::DatasetInfo *LowEnergyDataset;
      TH1 *LowEnergyData;
      Double_t LowEnergyRange[2];

      const Experiments::DatasetInfo *HighEnergyDataset;
      TH1 *HighEnergyData;
      Double_t HighEnergyRange[2];

      ROOT::Fit::Fitter Fitter;
      TF1 *FitModel;
      Int_t *LISParametersIndex;

      Double_t GlobalChi2Norm;
      Double_t LowEnergyChi2Norm;
      Double_t HighEnergyChi2Norm;

      TF1 *LowEnergyModel;
      TH1 *LowEnergyConfidenceInterval;
      TH1 *LowEnergyFitRatio;
      TH1 *LowEnergyFitResidual;
      TH1 *LowEnergyFitError;

      TF1 *HighEnergyModel;
      TH1 *HighEnergyConfidenceInterval;
      TH1 *HighEnergyFitResidual;
      TH1 *HighEnergyFitRatio;
      TH1 *HighEnergyFitError;

      void Copy(CombinedLISFitResult *obj);

      void Fit(Option_t *option = "I", UShort_t nfits = 1);

      void FitWithShift(Double_t shift, Option_t *option = "I", UShort_t nfits = 1);

      void RescaleDataErrors(Bool_t global = true);

      void ComputeResiduals(Bool_t use_range = false, Bool_t use_integral = true, Bool_t is_log = true, Double_t confint = 0.683, Bool_t force = false);

      void ComputeModelErrors(Bool_t use_range = true, Bool_t use_integral = false, Bool_t is_log = true, Double_t confint = 0.683, Bool_t force = false);

      void Print(std::ostream &out);

      // Write the content of the object to the current directory
      TDirectory *Write(const Char_t *dirname = "CombinedLisFitResult");

      Bool_t residuals_computed;
      Bool_t model_errors_computed;
   };
}

#endif
