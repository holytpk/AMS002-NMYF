{
   gROOT->ProcessLine("#include \"RVersion.h\"");
   int root_version = ROOT_VERSION_CODE >> 16;
   printf(" === ROOT version: %d\n", root_version);

   Char_t pwd[256];
   strncpy(pwd, gSystem->pwd(), 256);
   printf(" === Current folder: %s\n", pwd);

   Char_t arch[256];
   strncpy(arch, gSystem->GetBuildArch(), 256);
   printf(" === Architecture: %s\n", arch);

   Char_t str[256];
   snprintf(str, 256, "%s/build/%s/lib", pwd, arch);
   gSystem->cd(str);

   const UShort_t nlibs = 14;
   const Char_t *lib_name[nlibs] = { "debug", "Units", "DateTimeTools", "Spline", "HistTools", "GOESInfo", "GOES",
      "Heliosphere", "Experiments", "ParameterInfo", "NeutronMonitors", "LISModels", "ModulationModels", "FitTools" };
   for (UShort_t ilib = 0; ilib < nlibs; ++ilib)
   {
      snprintf(str, 256, "lib%s", lib_name[ilib]);
      printf(" === Loading library '%s' ...", str);
      fflush(stdout);
      if (!gSystem->Load(str))
      {
#if ROOT_VERSION_CODE >= ROOT_VERSION(6,0,0)
         snprintf(str, 256, "#include \"%s/include/%s.hh\"", pwd, lib_name[ilib]);
         gInterpreter->ProcessLine(str);
#endif
         printf(" Loaded\n");
      }
      else
      {
         cerr <<  "\n !!! Not compiled and/or not loaded!\n";
         return;
      }
   }

   gSystem->cd(pwd);
   gSystem->AddIncludePath("-Iinclude");

   // time axis style
   gSystem->Setenv("TZ", "UTC");
   gStyle->SetTimeOffset(0);

   gStyle->SetPalette(55);
   gStyle->SetNumberContours(99);

   // text style
   gStyle->SetLabelFont(43, "xyz");
   gStyle->SetLabelSize(26, "xyz");
   gStyle->SetLabelOffset(0.003, "xyz");
   gStyle->SetTitleFont(43, "xyz");
   gStyle->SetTitleSize(26, "xyz");
   gStyle->SetTitleOffset(1.2, "x");
   gStyle->SetTitleOffset(1., "y");

   TVirtualFitter::SetDefaultFitter("Minuit2");
   TVirtualFitter::SetMaxIterations(1000);

   gStyle->SetOptStat(0);

#if ROOT_VERSION_CODE >= ROOT_VERSION(6,0,0)
   gInterpreter->ProcessLine("Heliosphere::DataPath = gSystem->ExpandPathName(Heliosphere::DataPath.c_str());");
   gInterpreter->ProcessLine("Experiments::DataPath = gSystem->ExpandPathName(Experiments::DataPath.c_str());");
   gInterpreter->ProcessLine("Debug::Enable(Debug::ALL);");
#else
   Heliosphere::DataPath = gSystem->ExpandPathName(Heliosphere::DataPath.c_str());
   Experiments::DataPath = gSystem->ExpandPathName(Experiments::DataPath.c_str());
   Debug::Enable(Debug::ALL);
#endif
}
