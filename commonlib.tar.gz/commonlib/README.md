# common-lib
Common libraries extending ROOT functionalities, by C. Corti.

## Compilation
Simply `make` and then `root -l -q` to test that libraries are correctly loaded.
The environmental variable `LD_LIBRARY_PATH` must be changed as:
* Bash
```bash
export LD_LIBRARY_PATH="$COMMONLIB_DIR/build/$(root-config --arch)/lib::$LD_LIBRARY_PATH"
```
* TCSH
```tcsh
setenv LD_LIBRARY_PATH $COMMONLIB_DIR/build/`root-config --arch`/lib::$LD_LIBRARY_PATH
```
where `$COMMONLIB_DIR` is the directory where this repository has been cloned.

## List of libraries
1. libdebug
2. libUnits
3. libDateTimeTools
4. libSpline
5. libHistTools
6. libGOESInfo
7. libGOES
8. libNeutronMonitors
9. libHeliosphere
10. libExperiments
11. libParameterInfo
12. libLISModels
13. libModulationModels
14. libFitTools

### libdebug
`Debug` class and macros to quickly print variables, histograms, graphs and simple time profiling.

### libUnits
Set of namespaces for dealing with various units, including conversion between them, particles,
and printing values and errors with the right rounding.
* `SIPrefix`: prefixes for the International System of Units (kilo, Mega, Giga and all the others)
* `Energy`: definition of the various relativistic energies (kinetic energy, rigidity, momentum, etc)
* `Unit`: common units for energy, flux and time; functions for converting energy and flux
between different units, compute relativistic beta and gamma
* `Particle`: definition of common particles and nuclei, with their properties
* `Format`: functions for formatting value +/- error, with correct rounding

### libDateTimeTools
`DateTimeTools` namespace with functions for converting between different time formats, including string representations.

### libSpline
`Spline` class for fitting, with possible power-law extrapolation and support for log space.

### libHistTools
`HistTools` namespace with multiple functions extending ROOT functionalities for histograms, graphs and canvases.
Categories of functions:
* Style manipulation: copy, set and reset line, marker and fill style
* TF1 manipulation: support for common operations (addition, multiplication, division, composition, derivatives)
on TF1s created from C functions.
* Histogram and graph manipulation: support for common operations (addition, multiplication, division, composition, log, exp,
power-law rescaling, relative difference, average, interpolation, correlation, residuals, units conversion and more)
on TH* and TGraph*.
* Canvas manipulation: functions for dividing a TCanvas in sub-pads, with better handling of margins,
support for adjacent frames, with axis removal, coordinate conversions within canvases and pads.

### libGOESInfo & libGOES
`GOESInfo` and `GOES` classes, with properties of GOES sub-detectors and support for various data corrections,
real-time download, time averaging and flux calculations.

### libNeutronMonitors
`NeutronMonitors` namespace with solar modulation parameter table from Usoskin.

### libHeliosphere
`Heliosphere` namespace with functions for getting various heliospheric quantities (sunspot numbers, magnetic field,
tilt angle, etc).

### libExperiments
`Experiments` namespace with different datasets of cosmic ray data and helping functions. Supported experiments:
AMS-01, AMS-02, PAMELA, BESS, Voyager 1.

### libParameterInfo
`ParameterInfo` and `ModelInfo` structs used by libLISModels and libModulationModels.

### libLISModels
`LISModels` namespace with definition of many LIS models.

### libModulationModels
`ModulationModels` namespace with definition of solar modulation models.

### libFitTools
`FitTools` namespace with multiple functions and classes to extend fitting functionalities of ROOT.
* `GlobalChi2`: support for simultaneous fitting of multiple functions and datasets.
* `FitResult`, `LISFitResult`, `SplineFitResult`, `CombinedFitResult`: structs for helping in fitting data,
with various combinations of functions and datasets, mostly geared toward simultaneous fits of LIS and modulated fluxes.
* Various helping functions supporting both the classical ROOT fitting method (TH1::Fit, TGraph::Fit) and
ROOT::Fit::Fitter interface.
